var roleTable;
var languageURL = "";
$(function() {
	if(currentLanguage && currentLanguage === 'es'){
		languageURL = baseUrl+"/resources/javascript/pages/datatable_spanish.json";
	}
	initRoleListTable();
});

function initRoleListTable(){
	if($("#roleTable").length){
		var roleViewButton = '';
		var editRoleButton = '';
		var deleteRoleButton = '';
		if($("#roleedit").val() === 'true'){
			editRoleButton = '<a href="javascript:;" class="btn btn-sm btn-secondary" data-toggle="tooltip" title="" data-original-title="Edit"><i class="fa fa-pencil-alt"></i><span class="sr-only">Edit</span></a>';
		}
		if($("#roledelete").val() === 'true'){
			deleteRoleButton = '<a href="javascript:;" class="btn btn-sm btn-secondary" data-toggle="tooltip" title="" data-original-title="Delete"><i class="fas fa-trash"></i><span class="sr-only">Delete</span></a>';
		}
		if($("#roleview").val() === 'true'){
			roleViewButton = '<a href="javascript:;" class="btn btn-sm btn-secondary" data-toggle="tooltip" title="" data-original-title="View"><i class="fas fa-eye"></i><span class="sr-only">View</span></a>';
		}
		roleTable = $("#roleTable").DataTable( {
			"lengthMenu": [[10, 25, 50], [10, 25, 50]],
			"columnDefs": [ {"targets": 2, "orderable": false} ],
			"processing": true,
			"serverSide": true,
			"autoWidth": false,
			"ordering": false,
			"searching": false,
			"ajax": {
				url:fetchRoles,
				data: function(data) {
				     data.roleStatus = $("#roleStatus").val();
				     data.roleSearch = $("#roleSearch").val();
			    }
			},
			"columns": [
	            { "data": "name" },
	            { "data": "status" },
	            { "data": "" ,"sClass":"align-middle text-center actions-btn"}
	        ],
	        "language": {
	            "url": languageURL
	        },
	        "columnDefs": [{
	            "targets": 1,
	            "createdCell": function(td, cellData, rowData, row, col) {
	                switch(cellData) {
	                case "ACTIVE":
	                    $(td).addClass('text-success');
	                    break;
	                case "DELETED":
	                    $(td).addClass('text-danger');
	                    break;
	                }
	            }
	        },{
	            "targets": -1,
	            "data": null,
	            "defaultContent": roleViewButton+editRoleButton+deleteRoleButton
	        } ]
		});
		
		$('#roleTable tbody').on( 'click', 'a', function () {
	        var data = roleTable.row( $(this).parents('tr') ).data();
	        var roleId = data.roleId;
	        var action = $(this).attr("data-original-title");
	        if(action === "View"){
	        	viewRole(roleId);
	        }
	        if(action === "Edit"){
	        	editRole(roleId);
	        }
	        if(action === "Delete"){
	        	deleteRole(roleId);
	        }
	    });
	}
}

function filterRoleTable(){
	roleTable.ajax.reload();
}
function searchRoleTable(){
	if($("#roleSearch").val()){
		roleTable.ajax.reload();
	}
}
function resetRoleTable(){
	$("#roleSearch").val('');
	$("#roleStatus").val("5");
	roleTable.ajax.reload();
}
function validateRole(){
	$("#selectedItems option").prop("selected", "selected");
}
function viewRole(roleId){
	$("#roleIdview").val(roleId);
	$("#viewRoleForm").submit();
}
function editRole(roleId){
	$("#roleIdEdit").val(roleId);
	$("#editRoleForm").submit();
}
function editRoleRedirect(){
	$("#editRoleForm").submit();
}
function deleteRole(roleId){
	$("#roleIdDelete").val(roleId);
	$("#myModal").modal("show");
}

function filterSelected() {
    var keyword = document.getElementById("searchSelected").value;
    var fleet = document.getElementById("selectedItems");
    for (var i = 0; i < fleet.length; i++) {
        var txt = fleet.options[i].text;
        if (txt.substring(0, keyword.length).toLowerCase() !== keyword.toLowerCase() && keyword.trim() !== "") {
            fleet.options[i].style.display = 'none';
        } else {
            fleet.options[i].style.display = 'list-item';
        }
    }
}
function filterAvailable() {
    var keyword = document.getElementById("searchAll").value;
    var fleet = document.getElementById("allItems");
    for (var i = 0; i < fleet.length; i++) {
        var txt = fleet.options[i].text;
        if (txt.substring(0, keyword.length).toLowerCase() !== keyword.toLowerCase() && keyword.trim() !== "") {
            fleet.options[i].style.display = 'none';
        } else {
            fleet.options[i].style.display = 'list-item';
        }
    }
}

function moveItems(origin, dest) {
	$(origin).find(':selected').appendTo(dest);
}

function moveAllItems(origin, dest) {
	$(origin).children().appendTo(dest);
}

$('#left').click(function() {
	moveItems('#allItems', '#selectedItems');
});

$('#right').on('click', function() {
	moveItems('#selectedItems', '#allItems');
});

$('#leftall').on('click', function() {
	moveAllItems('#allItems', '#selectedItems');
});

$('#rightall').on('click', function() {
	moveAllItems('#selectedItems', '#allItems');
});