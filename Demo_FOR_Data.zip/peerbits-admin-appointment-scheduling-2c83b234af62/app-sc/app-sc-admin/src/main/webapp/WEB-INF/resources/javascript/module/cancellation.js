var cancelTable;
var languageURL = "";
$(function() {
	if(currentLanguage && currentLanguage === 'es'){
		languageURL = baseUrl+"/resources/javascript/pages/datatable_spanish.json";
	}
	initCancellationTable();
});
function initCancellationTable(){
	if($("#cancelTable").length){
		var editCancelButton = '';
		var deleteCancelButton = '';
		if($("#canceledit").val() === 'true'){
			editCancelButton = '<a href="javascript:;" class="btn btn-sm btn-secondary" data-toggle="tooltip" title="" data-original-title="Edit"><i class="fa fa-pencil-alt"></i><span class="sr-only">Edit</span></a>';
		}
		if($("#canceldelete").val() === 'true'){
			deleteCancelButton = '<a href="javascript:;" class="btn btn-sm btn-secondary" data-toggle="tooltip" title="" data-original-title="Delete"><i class="fas fa-trash"></i><span class="sr-only">Delete</span></a>';
		}
		cancelTable = $("#cancelTable").DataTable( {
			"lengthMenu": [[10, 25, 50], [10, 25, 50]],
			"columnDefs": [ {"targets": 4, "orderable": false} ],
			"processing": true,
			"serverSide": true,
			"autoWidth": false,
			"ordering": false,
			"searching": false,
			"ajax": {
				url: cancelPagination,
				data: function(data) {
				}
			},
			"columns": [
	            { "data": "reason" },
	            { "data": "reasonInSpanish" },
	            { "data": "actor" },
	            { "data": "status"},
	            { "data": "" ,"sClass":"align-middle text-center actions-btn"}
	        ],
	        "language": {
	            "url": languageURL
	        },
	        "columnDefs": [ {
	            "targets": 3,
	            "createdCell": function(td, cellData, rowData, row, col) {
	                switch(cellData) {
	                case "ACTIVE":
	                    $(td).addClass('text-success');
	                    break;
	                case "DELETED":
	                    $(td).addClass('text-danger');
	                    break;
	                }
	            }
	        },{
	            "targets": -1,
	            "data": null,
	            "defaultContent": editCancelButton+deleteCancelButton
	        } ]
		});
		
		$('#cancelTable tbody').on( 'click', 'a', function () {
	        var data = cancelTable.row( $(this).parents('tr') ).data();
	        var cancelId = data.id;
	        var reason = data.reason;
	        var reasonInSpanish = data.reasonInSpanish;
	        var actor = data.actor;
	        var action = $(this).attr("data-original-title");
	        if(action === "Edit"){
	        	editCancel(cancelId,reason,reasonInSpanish,actor);
	        }
	        if(action === "Delete"){
	        	deleteCancel(cancelId);
	        }
	    });
	}
}
function editCancel(cancelId,reason,reasonInSpanish,actor) {
	$("#ids").val(cancelId);
	$("#reasons").val(reason);
	$("#reasonInSpanishs").val(reasonInSpanish);
	$("#actors").val(actor);
	$("#editCancellation").modal("show");
}
function deleteCancel(id) {
	$("#deleteCancelId").val(id);
	$("#myModal").modal("show");
}
function closeCancelModel() {
	$("#id").val('');
	$("#reason").val('');
	$("#reasonInSpanish").val('');
	$("#AddNewCancellation").modal("hide");
}


