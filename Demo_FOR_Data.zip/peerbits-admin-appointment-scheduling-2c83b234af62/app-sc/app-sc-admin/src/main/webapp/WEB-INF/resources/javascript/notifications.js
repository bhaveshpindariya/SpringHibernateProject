var stompClient = null;
var notificationLoaded = false;

$(function(){
	connect();
	hasNotifications();
});

function connect() {
    var socket = new SockJS(baseUrl+'/appointment');
    stompClient = Stomp.over(socket);  
    stompClient.connect({}, function(frame) {
        stompClient.subscribe('/user/'+userId+'/messages', function(messageOutput) {
        	var notifications = messageOutput.body;
        	addNotification(notifications);
        });
    });
}
 
function disconnect() {
    if(stompClient != null) {
        stompClient.disconnect();
    }
}
 
function sendMessage() {
    var text = "sdsadsa";
    stompClient.send("/app/appointment", {}, 
	JSON.stringify({'notificationId':1234, 'message':text}));
}
 
function addNotification(notifications) {
	if(notificationLoaded){
		var notification = JSON.parse(notifications);
		var content = getNotificationContent(notification);
		$("#notificationList").prepend(content);
		 increamentUnreadCount();
	}
	$("#notification-status").addClass("has-notified");
}

function increamentUnreadCount(){
	var unreadNotifications = parseInt($("#unreadNotifiationCount").text());
	if(unreadNotifications > 0){
		$("#unreadNotifiationCount").text(unreadNotifications+1);
	}else{
		$("#unreadNotifiationCount").text("1");
	}
}
function hasNotifications(){
	var hasNotificationsURL = baseUrl+"/notifications/hasNotifications";
	$.ajax({
		url:hasNotificationsURL,
		success:function(rdata){
			var data = JSON.parse(rdata);
			if(data.hasNotifications){
				$("#notification-status").addClass("has-notified");
			}
		},error:function(){
			console.error("notification service is unavailable");
		}
	});
}

function fetchNotifications(){
	if(notificationLoaded){
		return;
	}
	var fetchNotificationsURL = baseUrl+"/notifications/fetchNotifications";
	$.ajax({
		url:fetchNotificationsURL,
		success:function(rdata){
			$("#notification-items").html(rdata);
			notificationLoaded = true;
		},error:function(){
			console.error("notification service is unavailable");
		}
	});
}

function markAllNotificationRead(){
	var markReadNotificationsURL = baseUrl+"/notifications/markReadNotifications";
	$.ajax({
		url:markReadNotificationsURL,
		success:function(rdata){
			var data = JSON.parse(rdata);
			if(data.markedRead){
				markRead();
			}
		},error:function(){
			console.error("notification service is unavailable");
		}
	});
}

function markAllNotificationListRead(){
	var markReadNotificationsURL = baseUrl+"/notifications/markReadNotifications";
	$.ajax({
		url:markReadNotificationsURL,
		success:function(rdata){
			var data = JSON.parse(rdata);
			if(data.markedRead){
				$("#receivedList .list-group-item").removeClass("unread");
				$("#unreadNotifiationsCount").text("0");
				var typeReceived = $("#receivedList").hasClass("active");
				if(typeReceived){
					markRead();
				}
			}
		},error:function(){
			console.error("notification service is unavailable");
		}
	});
}

function markRead(){
	$("#notification-status").removeClass("has-notified");
	$(".notification-item").removeClass("unread");
	$("#unreadNotifiationCount").text("0");
}

function clearNotifications(){
	var typeReceived = $("#receivedList").hasClass("active");
	if(typeReceived){
		$("#clearTypeLabel").text("received");
		$("#clearType").val("received");
	}else{
		$("#clearTypeLabel").text("sent");
		$("#clearType").val("sent");
	}
	$("#deleteNotification").modal("show");
}

function getNotificationContent(notifications){
	var notificationId = notifications.notificationId;
	var message = notifications.message;
	var dateFormatted = notifications.dateFormatted;
	var senderImagePath = baseUrl+"/"+notifications.senderImagePath;
	var unread = notifications.unread;
	var unreadClass = "";
	if(unread){
		unreadClass = "unread";
	}
	var notificationTemplate = '<a href="javascript:;" id="notification_'+notificationId+'" onclick="redirectToNotification('+notificationId+');" class="dropdown-item notification-item '+unreadClass+'">'+
									'<div class="user-avatar"><img src="'+senderImagePath+'"></div>'+
									'<div class="dropdown-item-body">'+
										'<p class="text">'+message+'</p>'+
										'<span class="date">'+dateFormatted+'</span>'+
									'</div>'+
								'</a>';
	return notificationTemplate;
}

function loadUsers(){
	var notifyTo = $("#notifyTo").val();
	if(notifyTo === "affiliates" || notifyTo === "doctors"){
		fetchUsers(notifyTo);
	}else{
		$("#selectedUsersPart").addClass("d-none");
	}
}

function fetchUsers(userType){
	var fetchUsersURL = baseUrl+"/user/fetchUsersByType";
	$.ajax({
		url:fetchUsersURL,
		data:{userType:userType},
		success:function(rdata){
			var data = JSON.parse(rdata);
			$("#selectedUsers").html('');
			for(var i=0;i<data.length;i++){
				$("#selectedUsers").append("<option value='"+data[i].userId+"'>"+data[i].userName+"</option>");
			}
			$("#selectedUsersPart").removeClass("d-none");
			$("#selectedUsers").select2();
		},error:function(){
			console.error("user service is unavailable");
		}
	});
}

function validateNotificationForm(){
	var notifyTo = $("#notifyTo").val();
	var message = $("#notificationMessage").val();
	if(notifyTo && message.trim()){
		return true;
	}
	return false;
}

function redirectToNotification(notificationId){
	var redirectToNotificationURL = baseUrl+"/notifications/redirectToNotification";
	$.ajax({
		url:redirectToNotificationURL,
		data:{notificationId:notificationId},
		success:function(rdata){
			var data = JSON.parse(rdata);
			if(data.markedRead){
				$("#notification_"+notificationId).removeClass("unread");
			}
		},error:function(){
			console.error("notification service is unavailable");
		}
	});
}