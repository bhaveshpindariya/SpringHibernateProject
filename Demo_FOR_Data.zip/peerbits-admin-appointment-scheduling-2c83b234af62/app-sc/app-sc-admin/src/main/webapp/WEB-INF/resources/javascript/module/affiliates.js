var affiliatesTable;
var waitingTable;
var requestTable;
var languageURL = "";
$(function() {
	if(currentLanguage && currentLanguage === 'es'){
		languageURL = baseUrl+"/resources/javascript/pages/datatable_spanish.json";
	}
	initAffiliatesTable();
	initAppointmentsTable();
	initWaitlistTable();
});
function initWaitlistTable(){	
	waitingTable = $("#waitlistTable").DataTable( {
		"lengthMenu": [[10, 25, 50], [10, 25, 50]],
		"columnDefs": [{"orderable": false}],
		"processing": true,
		"serverSide": true,
		"autoWidth": false,
		"ordering": false,
		"searching": false,
		"ajax": {
			url:getWaitlistsURL,
			data: function(data) {
			     data.userName = "";
			     data.userId = $("#userIdForUser").val();
			     data.waitlistType = $("#waitlistType").val();
			     data.categoryId = $("#appointmentCategory").val();
		    }
		},
		"columns": [
            { "data": "date" },
            { "data": "categoryName" },
            { "data": "hasLegalDocs" },
            { "data": "type" },
            { "data": "actions" ,"sClass":"align-middle text-center actions-btn"}
        ],
        "language": {
            "url": languageURL
        }
	});
	$('#waitlistTable tbody').on( 'click', 'a.action-button', function () {
        var data = waitingTable.row($(this).parents('tr')).data();
        var action = $(this).attr("data-original-title");
        if(action === "View"){
        	viewRequest(data);
        }
    });
}
function filterWaitingTable(){
	waitingTable.ajax.reload();
}

function resetWaitingTable(){
	$("#waitlistType").val('');
	$("#appointmentCategory").val('');
	waitingTable.ajax.reload();
}
function viewRequest(data){
	$("#appointmentsIds").val(data.appointmentId);
	$("#userIdFilter").val($("#userIdForUser").val());
	$("#waitlistTypeFilter").val($("#waitlistType").val());
	$("#categoryIdFilter").val($("#appointmentCategory").val());
	$("#viewRequest").submit();
}
function initAffiliatesTable(){
	if($("#affiliatesTable").length){
		var viewaffiliatesButton = '';
		var editaffiliatesButton = '';
		var deleteaffiliatesButton = '';
		if($("#affiliatesedit").val() === 'true'){
			editaffiliatesButton = '<a href="javascript:;" class="btn btn-sm btn-secondary" data-toggle="tooltip" title="" data-original-title="Edit"><i class="fa fa-pencil-alt"></i><span class="sr-only">Edit</span></a>';
		}
		if($("#affiliatesdelete").val() === 'true'){
			deleteaffiliatesButton = '<a href="javascript:;" class="btn btn-sm btn-secondary" data-toggle="tooltip" title="" data-original-title="Delete"><i class="fas fa-trash"></i><span class="sr-only">Delete</span></a>';
		}
		if($("#affiliatesview").val() === 'true'){
			viewaffiliatesButton = '<a href="javascript:;" class="btn btn-sm btn-secondary" data-toggle="tooltip" title="" data-original-title="View"><i class="fas fa-eye"></i><span class="sr-only">View</span></a>';
		}
		affiliatesTable = $("#affiliatesTable").DataTable( {
			"lengthMenu": [[10, 25, 50], [10, 25, 50]],
			"columnDefs": [ {"targets": 5, "orderable": false} ],
			"processing": true,
			"serverSide": true,
			"autoWidth": false,
			"ordering": false,
			"searching": false,
			"ajax": {
				url: affiliatesPagination,
				data: function(data) {
					 data.affiliatesStatus = $("#affiliatesStatus").val();
				}
			},
			"columns": [
	            { "data": "fullName" },
	            { "data": "contactNo" },
	            { "data": "emailAddress" },
	            { "data": "totalAppointments","sClass":"align-middle text-center"},
	            { "data": "status"},
	            { "data": "" ,"sClass":"align-middle text-center actions-btn"}
	        ],
	        "columnDefs": [ {
	            "targets": 4,
	            "createdCell": function(td, cellData, rowData, row, col) {
	                switch(cellData) {
	                case "ACTIVE":
	                    $(td).addClass('text-success');
	                    break;
	                case "DELETED":
	                    $(td).addClass('text-danger');
	                    break;
	                }
	            }
	        },{
	            "targets": -1,
	            "data": null,
	            "defaultContent": viewaffiliatesButton+editaffiliatesButton+deleteaffiliatesButton
	        } ],
	        "language": {
                "url": languageURL
            }
		});
		
		$('#affiliatesTable tbody').on( 'click', 'a', function () {
	        var data = affiliatesTable.row( $(this).parents('tr') ).data();
	        var userId = data.userId;
	        var contactNo = data.contactNos;
	        var emailAddress = data.emailAddress;
	        var action = $(this).attr("data-original-title");
	        if(action === "View"){
	        	viewaffiliates(userId);
	        }
	        if(action === "Edit"){
	        	editaffiliates(userId,contactNo,emailAddress);
	        }
	        if(action === "Delete"){
	        	deleteaffiliates(userId);
	        }
	    });
	}	
}
function initAppointmentsTable(){
	if($("#appointmentsTable").length){
		requestTable = $("#appointmentsTable").DataTable( {
			"lengthMenu": [[10, 25, 50], [10, 25, 50]],
			"columnDefs": [{"orderable": false}],
			"processing": true,
			"serverSide": true,
			"autoWidth": false,
			"ordering": false,
			"searching": false,
			"ajax": {
				url:getAppointmentsForUserURL,
				data: function(data) {
				     data.userName = $("#userIdForUser").val();
				     data.appointmentDate = $("#appointmentDate").val();
				     data.statusCode = 1;
			    }
			},
			"columns": [
	            { "data": "doctorName" },
	            { "data": "appointmentDate" },
	            { "data": "timeSlot" },
	            { "data": "location" },
	            { "data": "status" },
	            { "data": "actions" ,"sClass":"align-middle text-center actions-btn"}
	        ],
	        "language": {
                "url": languageURL
            }
		});
		$('#appointmentsTable tbody').on( 'click', 'a.action-button', function () {
	        var data = requestTable.row($(this).parents('tr')).data();
	        var action = $(this).attr("data-original-title");
	        if(action === "View"){
	        	viewAppointment(data);
	        }
	        if(action === "Cancel"){
	        	cancelAppointment(data);
	        }
	    });
	}
}
function validateReason(){
	var cancellationReason = $("#cancellationReason").val();
	if(cancellationReason === "-1"){
		$("#customReasonInput").attr("required","required");
		$("#customReason").removeClass("d-none");
	}else{
		$("#customReasonInput").removeAttr("required");
		$("#customReason").addClass("d-none");
	}
}
function viewAppointment(data){
	$("#appointmentsId").val(data.appointmentId);
	$("#userNameSearch").val($("#userSearch").val());
	$("#appointmentDateFilter").val($("#appointmentDate").val());
	$("#statusFilter").val(1);
	$("#viewAppointment").submit();
}

function cancelAppointment(data){
	$("#appointmentsIdReject").val(data.appointmentId);
	$("#RejectRequestModal").modal('show');
}
function filterTable(){
	requestTable.ajax.reload();
}

function resetTable(){
	$("#appointmentDate").val('');
	requestTable.ajax.reload();
}
function viewaffiliates(userId) {
	$("#userIds").val(userId);
	$("#viewAffiliatesForm").submit();
}
function editaffiliates(userId,contactNo,emailAddress) {
	$("#userId").val(userId);
	$("#contactNo").val(contactNo);
	$("#emailAddress").val(emailAddress);
	$("#editAffiliates").modal("show");
}
function deleteaffiliates(userId) {
	$("#userIdDelete").val(userId);
	$("#myModal").modal("show");
}
function resetAffiliatesTable(){
	$("#affiliatesStatus").val("-1");
	affiliatesTable.ajax.reload();
}
function filterAffiliatesTable(){
	affiliatesTable.ajax.reload();
}
function resetPassword() {
	$("#data").modal("hide");
	$("#password").val('');
	$("#cpassword").val('');
}
function closeModel(){
	$("#data").modal("hide");
	$("#password").val('');
	$("#cpassword").val('');
	$('.modal-backdrop').remove();
	$("#resetPassword").modal('hide');
}
function checkPassword() {
	if($("#password").val() != $("#cpassword").val()){
		$("#message").text("Password you entered did not match");
		$("#data").modal("show");
		return false;
	}else if($("#password").val().length < 6){
		$("#message").text("Please Enter Atleast 6 letter");
		$("#data").modal("show");
		return false;
	}else{
		$("#resetPasswordForm").submit();
	}
}

