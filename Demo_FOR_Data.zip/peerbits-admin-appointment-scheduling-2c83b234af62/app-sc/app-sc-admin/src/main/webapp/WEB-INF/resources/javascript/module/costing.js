function updateWageModal(wageType){
	var wageValue = $("#"+wageType).text();
	$("#legalWageType").val(wageType);
	$("#legalWageValue").val(wageValue);
	$("#EditMinimum").modal("show");
}

function updateWage(updateWageURL){
	var wageType = $("#legalWageType").val();
	var wageValue = $("#legalWageValue").val();
	$("#wageMessages").hide();
	$.ajax({
		url:updateWageURL,
		data:{
				wageType:wageType,
				wageValue:wageValue
		},
		success:function(rdata){
			var data = JSON.parse(rdata);
			if(data.success !== "success"){
				$("#wageMessage").text(data.message);
				$("#wageMessages").show();
			}else{
				$("#"+wageType).text(wageValue);
			}
		},error:function(){
			console.error("error calling wage services");
		}
	});
}

function addAnother(){
	var rawNumber = parseInt($("#totalRows").val())+1;
	var template = $("#costing-template").html();
	template = replaceAll(template,"rawNumber",rawNumber);
	$("#raw-sections").append(template);
	$("#totalRows").val(rawNumber);
}

function deleteItem(rawNumber){
	var totalSection = $('#raw-sections [id^="section_"]').length;
	if(totalSection > 1){
		$("#deleteCostingButton").attr("onclick","deleteCosting("+rawNumber+")");
		$("#deleteCosting").modal("show");
	}else{
		$("#deleteWarning").modal("show");
	}
}
function deleteCosting(rawNumber){
	if(parseInt(rawNumber) === 0){
		$("#markedDeleted").val("true");
	}
	$("#section_"+rawNumber).remove();
}

function deleteItemFromTable(costingId){
	$("#costingIdDelete").val(costingId);
	$("#deleteCosting").modal("show");
}

function calculateDailyWage(eleId, perEleId){
	var dailyMinimumLegalWage = parseFloat($("#dailyMinimumLegalWage").val());
	var percentage = parseFloat($("#"+eleId).val());
	var per = calculatePercentageRound(dailyMinimumLegalWage, percentage);
	$("#"+perEleId).text(per);
}
function calculateMonthlyWage(eleId, perEleId){
	var monthlyMinimumLegalWage = parseFloat($("#monthlyMinimumLegalWage").val());
	var percentage = parseFloat($("#"+eleId).val());
	var per = calculatePercentageRound(monthlyMinimumLegalWage, percentage);
	$("#"+perEleId).text(per);
}
function editCostionData(id){
	$("#costingId").val(id);
	$("#editCostForm").submit();
}