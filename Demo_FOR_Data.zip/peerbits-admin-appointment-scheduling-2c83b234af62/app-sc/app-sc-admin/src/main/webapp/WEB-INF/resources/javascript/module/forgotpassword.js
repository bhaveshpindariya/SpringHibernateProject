function validateEmail() {
	$("#errorMessage").addClass("d-none");
	$("#successMessage").addClass("d-none");
	$('#resetButton').prop('disabled', true);
	var emailAddress = $("#inputUser").val();
	$.ajax({
		type : "POST",
		url : forgotPassword,
		data : {"emailAddress" : emailAddress},
		dataType : "text",
		success : function(result) {
			console.log(result);
			var data = JSON.parse(result);
			if (data.error) {
				$('#resetButton').prop('disabled', false);
				$("#errorMessage").text(data.error);
				$("#errorMessage").removeClass("d-none");
			}
			if (data.success) {
				$('#resetButton').prop('disabled', false);
				$("#successMessage").text(data.success);
				$("#successMessage").removeClass("d-none");
			}
			$("#inputUser").val("");
		}
	});
}