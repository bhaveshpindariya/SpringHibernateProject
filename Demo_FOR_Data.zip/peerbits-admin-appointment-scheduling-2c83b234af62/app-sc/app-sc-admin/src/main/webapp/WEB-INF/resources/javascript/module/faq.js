var faqTable;
var languageURL = "";
$(function() {
	if(currentLanguage && currentLanguage === 'es'){
		languageURL = baseUrl+"/resources/javascript/pages/datatable_spanish.json";
	}
	initFAQTable();
});
function initFAQTable(){
	if($("#faqTable").length){
		var viewFaqButton = '';
		var editFaqButton = '';
		if($("#faqedit").val() === 'true'){
			editFaqButton = '<a href="javascript:;" class="btn btn-sm btn-secondary" data-toggle="tooltip" title="" data-original-title="Edit"><i class="fa fa-pencil-alt"></i><span class="sr-only">Edit</span></a>';
		}
		if($("#faqview").val() === 'true'){
			viewFaqButton = '<a href="javascript:;" class="btn btn-sm btn-secondary" data-toggle="tooltip" title="" data-original-title="View"><i class="fas fa-eye"></i><span class="sr-only">View</span></a>';
		}
		faqTable = $("#faqTable").DataTable( {
			"lengthMenu": [[10, 25, 50], [10, 25, 50]],
			"columnDefs": [ {"targets": 2, "orderable": false} ],
			"processing": true,
			"serverSide": true,
			"autoWidth": false,
			"ordering": false,
			"searching": false,
			"ajax": {
				url: faqPagination,
				data: function(data) {
					 data.faqStatus = $("#faqStatus").val();
				}
			},
			"columns": [
	            { "data": "question" },
	            { "data": "status" },
	            { "data": "" ,"sClass":"align-middle text-center actions-btn"}
	        ],
	        "language": {
	            "url": languageURL
	        },
	        "columnDefs": [ {
	            "targets": 1,
	            "createdCell": function(td, cellData, rowData, row, col) {
	                switch(cellData) {
	                case "ACTIVE":
	                    $(td).addClass('text-success');
	                    break;
	                case "DELETED":
	                    $(td).addClass('text-danger');
	                    break;
	                }
	            }
	        },{
	            "targets": -1,
	            "data": null,
	            "defaultContent": viewFaqButton+editFaqButton
	        } ]
		});
		
		$('#faqTable tbody').on( 'click', 'a', function () {
	        var data = faqTable.row( $(this).parents('tr') ).data();
	        var faqId = data.id;
	        var action = $(this).attr("data-original-title");
	        if(action === "View"){
	        	viewfaq(faqId);
	        }
	        if(action === "Edit"){
	        	editfaq(faqId);
	        }
	    });
	}
}

function viewfaq(faqId) {
	$("#ids").val(faqId);
	$("#viewFaqForm").submit();
}
function editfaq(faqId) {
	$("#id").val(faqId);
	$("#editFaqForm").submit();
}

function editfaqData() {
	$("#editFaqFormData").submit();
}

function resetFaqTable(){
	$("#faqStatus").val("-1");
	faqTable.ajax.reload();
}
function filterFaqTable(){
	faqTable.ajax.reload();
}