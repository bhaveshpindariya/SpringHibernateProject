var consultationTable;
var proceduresTable;
var no_of_sub_div = 1;
var counter = 1;

var mainIndex = 0;
var rawNumber = 4;
var radioIndex = 0;
var languageURL = "";
$(function() {
	if(currentLanguage && currentLanguage === 'es'){
		languageURL = baseUrl+"/resources/javascript/pages/datatable_spanish.json";
	}
	initConsultingCategoryTable();
	initProcedureCategoryTable();
	var mainCount = (parseInt($("#subcategoryCount").val())-1);
	if(mainCount > 0){
		mainIndex = mainCount;
		rawNumber = (mainCount * 2) ;
		radioIndex = mainCount;
	}
});

function initConsultingCategoryTable(){
	if($("#consultationTable").length){
		var viewConsultationButton = '';
		var editConsultationButton = '';
		var deleteConsultationButton = '';
		if($("#categoryedit").val() === 'true'){
			editConsultationButton = '<a href="javascript:;" class="btn btn-sm btn-secondary" data-toggle="tooltip" title="" data-original-title="Edit"><i class="fa fa-pencil-alt"></i><span class="sr-only">Edit</span></a>';
		}
		if($("#categorydelete").val() === 'true'){
			deleteConsultationButton = '<a href="javascript:;" class="btn btn-sm btn-secondary" data-toggle="tooltip" title="" data-original-title="Delete"><i class="fas fa-trash"></i><span class="sr-only">Delete</span></a>';
		}
		if($("#categoryview").val() === 'true'){
			viewConsultationButton = '<a href="javascript:;" class="btn btn-sm btn-secondary" data-toggle="tooltip" title="" data-original-title="View"><i class="fas fa-eye"></i><span class="sr-only">View</span></a>';
		}
		consultationTable = $("#consultationTable").DataTable( {
			"lengthMenu": [[10, 25, 50], [10, 25, 50]],
			"columnDefs": [ {"targets": 4, "orderable": false} ],
			"processing": true,
			"serverSide": true,
			"autoWidth": false,
			"ordering": false,
			"searching": false,
			"ajax": {
				url: consultationPagination,
				data: function(data) {
					data.categoryStatus = $("#categoryStatus").val();
				}
			},
			"columns": [
	            { "data": "category" },
	            { "data": "subCategory" },
	            { "data": "laterality" },
	            { "data": "Status" },
	            { "data": "" ,"sClass":"align-middle text-center actions-btn"}
	        ],
	        "language": {
	            "url": languageURL
	        },
	        "columnDefs": [{
		            "targets": 3,
		            "createdCell": function(td, cellData, rowData, row, col) {
		                switch(cellData) {
		                case "ACTIVE":
		                    $(td).addClass('text-success');
		                    break;
		                case "DELETED":
		                    $(td).addClass('text-danger');
		                    break;
		                }
		            }
		        },{
	            "targets": -1,
	            "data": null,
	            "defaultContent": viewConsultationButton+editConsultationButton+deleteConsultationButton
	        } ]
		});
		
		$('#consultationTable tbody').on( 'click', 'a', function () {
	        var data = consultationTable.row( $(this).parents('tr') ).data();
	        var categoryId = data.categoryId;
	        var action = $(this).attr("data-original-title");
	        if(action === "View"){
	        	viewConsultation(categoryId);
	        }
	        if(action === "Edit"){
	        	editConsultation(categoryId);
	        }
	        if(action === "Delete"){
	        	deleteConsultation(categoryId);
	        }
	    });
	}
}

function initProcedureCategoryTable(){
	if($("#proceduresTable").length){
		var viewProceduresButton = '';
		var editProceduresButton = '';
		var deleteProceduresButton = '';
		if($("#categoryedit").val() === 'true'){
			editProceduresButton = '<a href="javascript:;" class="btn btn-sm btn-secondary" data-toggle="tooltip" title="" data-original-title="Edit"><i class="fa fa-pencil-alt"></i><span class="sr-only">Edit</span></a>';
		}
		if($("#categorydelete").val() === 'true'){
			deleteProceduresButton = '<a href="javascript:;" class="btn btn-sm btn-secondary" data-toggle="tooltip" title="" data-original-title="Delete"><i class="fas fa-trash"></i><span class="sr-only">Delete</span></a>';
		}
		if($("#categoryview").val() === 'true'){
			viewProceduresButton = '<a href="javascript:;" class="btn btn-sm btn-secondary" data-toggle="tooltip" title="" data-original-title="View"><i class="fas fa-eye"></i><span class="sr-only">View</span></a>';
		}
		proceduresTable = $("#proceduresTable").DataTable( {
			"lengthMenu": [[10, 25, 50], [10, 25, 50]],
			"columnDefs": [ {"targets": 5, "orderable": false} ],
			"processing": true,
			"serverSide": true,
			"autoWidth": false,
			"ordering": false,
			"searching": false,
			"ajax": {
				url: proceduresPagination,
				data: function(data) {
					data.categoryStatus = $("#categoryStatus").val();
				}
			},
			"columns": [
	            { "data": "category" },
	            { "data": "subCategory" },
	            { "data": "eps" },
	            { "data": "cost" },
	            { "data": "Status" },
	            { "data": "" ,"sClass":"align-middle text-center actions-btn"}
	        ],
	        "language": {
	            "url": languageURL
	        },
	        "columnDefs": [{
		            "targets": 4,
		            "createdCell": function(td, cellData, rowData, row, col) {
		                switch(cellData) {
		                case "ACTIVE":
		                    $(td).addClass('text-success');
		                    break;
		                case "DELETED":
		                    $(td).addClass('text-danger');
		                    break;
		                }
		            }
		        },{
	            "targets": -1,
	            "data": null,
	            "defaultContent": viewProceduresButton+editProceduresButton+deleteProceduresButton
	        } ]
		});
		
		$('#proceduresTable tbody').on( 'click', 'a', function () {
	        var data = proceduresTable.row( $(this).parents('tr') ).data();
	        var categoryId = data.categoryId;
	        var action = $(this).attr("data-original-title");
	        if(action === "View"){
	        	viewProcedures(categoryId);
	        }
	        if(action === "Edit"){
	        	editProcedures(categoryId);
	        }
	        if(action === "Delete"){
	        	deleteProcedures(categoryId);
	        }
	    });
	}
}

function reloadCategoryTable(){
	consultationTable.ajax.reload();
	proceduresTable.ajax.reload();
}
function viewProcedures(categoryId){
	$("#procedureIdView").val(categoryId);
	$("#viewProcedure").submit();
}
function editProcedures(categoryId){
	$("#procedureIdEdit").val(categoryId);
	$("#editProcedure").submit();
}
function deleteProcedures(categoryId){
	$("#procedureIdDelete").val(categoryId);
	$("#myModal1").modal("show");
}
function viewConsultation(categoryId){
	$("#consultationIdView").val(categoryId);
	$("#viewConsultation").submit();
}
function editConsultation(categoryId){
	$("#consultationIdEdit").val(categoryId);
	$("#editConsultation").submit();
}
function deleteConsultation(categoryId){
	$("#consultationIdDelete").val(categoryId);
	$("#myModal").modal("show");
}

// Add Consultions Sub Categories
$(document).on('click','#addButton_Consultions', function() {
	var template = $("#subcategory-template").html();
	template = replaceAll(template, "rawNumber", rawNumber+1);
	template = replaceAll(template, "rawNumberNext", rawNumber+2);
	template = replaceAll(template, "mainIndex", mainIndex+1);
	template = replaceAll(template, "radioIndex", radioIndex+1);
	rawNumber +=2;
	mainIndex +=1;
	radioIndex +=1;
	$("#sub-categories").append(template);
	$("#subcategoryCount").val(mainIndex);
});

// Add Procedure Category 
$(document).on('click','#addButton_Procedure', function() {
	var template = $("#subcategory-template").html();
	template = replaceAll(template, "rawNumber", rawNumber+1);
	template = replaceAll(template, "rawNumberNext", rawNumber+2);
	template = replaceAll(template, "mainIndex", mainIndex+1);
	template = replaceAll(template, "radioIndex", radioIndex+1);
	rawNumber +=2;
	mainIndex +=1;
	radioIndex +=1;
	$("#sub-categories").append(template);
	$("#subcategoryCount").val(mainIndex);
	$("[name=subcategory_"+mainIndex+"_eps_0]").select2();
});

// Delete Consultions Sub Categories
function rmvsubdiv_Consultions(n) {
	var totalSection = $('#sub-categories [id^="subCategory_"].subdiv').length;
	if(totalSection >= 0){
		$("#deleteCategoriesButton").attr("onclick","Consultions('"+n+"')");
		$("#deleteCategories").modal("show");
	}else{
		$("#deleteWarning").modal("show");
	}
}
function Consultions(n) {
	$('#'+n).remove();
}

//Delete Consultions Sub Categories for edit
function rmvsubdiv_ConsultionsData(n,m){
	var totalSection = $('#sub-categories [id^="subCategory_"].subdiv').length;
	if(totalSection > 0){
		var deleteDataId=$('#deleteCategoryId').val();
		if(deleteDataId == null || deleteDataId == ''){
			$('#deleteCategoryId').val(m);
		}else{
			var s=deleteDataId+','+m;
			$('#deleteCategoryId').val(s);
		}
		$("#deleteCategoriesButton").attr("onclick","Consultions('"+n+"')");
		$("#deleteCategories").modal("show");
	}else{
		$("#deleteWarning").modal("show");
	}
}
function Consultions(n) {
	$('#'+n).remove();
}

// Procedure Category EPS+COST ADD
function addEPS(subcategory){
	var count = parseInt($("#"+subcategory+"_eps_count").val());
	if(count > 0){
		count += 1;
	}else{
		count = 1;
	}
	var template = $("#epscost-template").html();
	template = replaceAll(template, "subcategory", subcategory);
	template = replaceAll(template, "epsIndex", count);
	template = replaceAll(template, "subcategory_eps_epsIndex", subcategory+"_eps_"+count);
	template = replaceAll(template, "subcategory_cost_epsIndex", subcategory+"_cost_"+count);
	$("#"+subcategory+"_eps").append(template);
	$("#"+subcategory+"_eps_count").val(count);
	$("[name="+subcategory+"_eps_"+count+"]").select2();
}

// Delete Procedure Sub Category
function deleteItem(rawNumber){
	var totalSection = $('#sub-categories [id^="subcategory_"].subdiv').length;
	if(totalSection > 1){
		$("#deleteCategoriesButton").attr("onclick","rmvsubdiv_Procedure('"+rawNumber+"')");
		$("#deleteCategories").modal("show");
	}else{
		$("#deleteWarning").modal("show");
	}
}
function rmvsubdiv_Procedure(n) {
	$('#' + n).remove();
}

//Delete Procedure Sub Category Edit
function deleteSubCategory(n,m){
	var totalSection = $('#sub-categories [id^="subcategory_"].subdiv').length;
	if(totalSection > 1){
		var deleteDataId=$('#deleteCategoryId').val();
		if(deleteDataId == null || deleteDataId == ''){
			$('#deleteCategoryId').val(m);
		}else{
			var s=deleteDataId+','+m;
			$('#deleteCategoryId').val(s);
		}
		$("#deleteCategoriesButton").attr("onclick","rmvsubdiv_Procedure('"+n+"')");
		$("#deleteCategories").modal("show");
	}else{
		$("#deleteWarning").modal("show");
	}
}
function rmvsubdiv_Procedure(n) {
	$('#' + n).remove();
}

// Procedure Category EPS+COST Delete
function rmvsubdiv_ProcedureEps(n) {
	$("#deleteCategoriesButton").attr("onclick","rmvsubdiv_ProcedureEpsData('"+n+"')");
	$("#deleteCategories").modal("show");
}
function rmvsubdiv_ProcedureEpsData(n) {
	$('#'+n).remove();
}

//Procedure Category EPS+COST Edit Delete
function deleteProcedureEps(n,m) {
	var deleteDataId=$('#deleteEpsp').val();
	if(deleteDataId == null || deleteDataId == ''){
		$('#deleteEpsp').val(m);
	}else{
		var s=deleteDataId+','+m;
		$('#deleteEpsp').val(s);
	}
	$("#deleteCategoriesButton").attr("onclick","rmvsubdiv_ProcedureEpsData('"+n+"')");
	$("#deleteCategories").modal("show");
}
function rmvsubdiv_ProcedureEpsData(n) {
	$('#'+n).remove();
}

function closeCategoryModel() {
	$("#categoryFile").val('');
	$("#importCategory").modal("hide");
}
