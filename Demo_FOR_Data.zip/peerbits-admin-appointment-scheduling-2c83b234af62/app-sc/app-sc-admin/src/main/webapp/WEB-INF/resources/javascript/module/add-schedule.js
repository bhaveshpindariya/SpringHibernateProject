function timeCompare(startTime, endTime) {
	var startTime24 = convertTime12to24(startTime);
	var endTime24 = convertTime12to24(endTime);
	let [hoursStart, minutesStart] = startTime24.split(':');
	let [hoursEnd, minutesEnd] = endTime24.split(':');
	if(parseInt(hoursEnd,10) < parseInt(hoursStart,10)){
		return "false";
	} else if(parseInt(hoursEnd,10) == parseInt(hoursStart,10)) {
		if(parseInt(minutesEnd,10) <= parseInt(minutesStart,10)) {
			return "false";
		} else {
			return "true";
		}
	} else {
		return "true";
	}
}

function convertTime12to24(time12h) {
	  const [time, modifier] = time12h.split(' ');

	  let [hours, minutes] = time.split(':');

	  if (hours === '12') {
	    hours = '00';
	  }

	  if (modifier === 'PM') {
	    hours = parseInt(hours, 10) + 12;
	  }

	  return hours + ':' + minutes;
}

$('#modify-sc-fm').on('keydown', '#maxAppointmentsModal', function(e){-1!==$.inArray(e.keyCode,[46,8,9,27,13,110])||(/65|67|86|88/.test(e.keyCode)&&(e.ctrlKey===true||e.metaKey===true))&&(!0===e.ctrlKey||!0===e.metaKey)||35<=e.keyCode&&40>=e.keyCode||(e.shiftKey||48>e.keyCode||57<e.keyCode)&&(96>e.keyCode||105<e.keyCode)&&e.preventDefault()});


/*ADD SCHEDULE*/
$('#sc-add').off('click').click(function(){
	submitSchedule();
});
	
$('input[name="iscopy"]').change(function(){
	var copyval = $(this).val();
	if(copyval == "yes") {
		$('#endDate').attr("required", "required");
	} else {
		$('#endDate').removeAttr("required");
	}
});
var months = ["January","Febrary","March","April","May","June","July","August","September","October","November","December"];

var weekDays = ["sunday", "monday", "tuesday", "wednesday", "friday", "saturday"];

function submitSchedule() {
	var startdate = $('#startdate').val();
	var enddate = $('#endDate').val();
	var starttime = $('#startTime').val();
	var endtime = $('#endTime').val();
	var location = $('#location').val();
	var iscopy = $('input[name="rdGroup1"]:checked').val();
	var days = $('input[type="checkbox"][name="q1"]:checked').length;
	var selectedEpsLength = $('input[type="radio"][name="eps"]:checked').length;
	var doctor = $('#doctor').val();
	var maxAppointments = $('#maxAppointmentsModal').val();
	var isvalidfm = false;
	var messageErr = "Your request could not be completed";
	/*startLoader("item-image");*/
	
	if(doctor && startdate && starttime && endtime && location && maxAppointments && selectedEpsLength>0){
		if(iscopy && iscopy=="yes") {
			var sdate = new Date(startdate);
			var edate = new Date(enddate);
			if(days && enddate){
				if(edate>sdate) {
					var repeatDays = [];
				     $.each($("input[type='checkbox'][name='q1']:checked"), function(){            
				    	 repeatDays.push($(this).val());
				     });
					var isDaySelected = false;
					for(d=sdate; d<=edate; d.setDate(d.getDate()+1)) {
						if(repeatDays.indexOf(weekDays[d.getDay()])>-1) {
							isDaySelected = true;
						}
					}
					if(isDaySelected) {
						if(timeCompare(starttime, endtime) == "true"){
							isvalidfm = true;
						} else {
							messageErr = "End Time cannot be smaller than start time";
						}
					} else {
						messageErr = "Repeat Days must be within selected dates range";
					}
				}else{
					messageErr = "The end date cannot be smaller than the selected date";
				}
			} else {
				messageErr = "Days and End date are required if copying for other days";
			}
		} else {
			if(timeCompare(starttime, endtime) == "true"){
				isvalidfm = true;
			} else {
				messageErr = "End Time cannot be smaller than start time";
			}
		}
	} else {
		messageErr = "Please fill all required fields";
	}
	if(isvalidfm) {
		var addScheduleUrl = baseUrl+"/add-schedule/addNewSchedule";
		var formData = $('#schedule-fm').serialize();
		startLoader("page-section");
		$.ajax({
			url:addScheduleUrl,
			data:formData,
			success:function(rdata){
				var data = JSON.parse(rdata);
				if(data.status=="success"){
					$('#message').val(data.message);
					$('#addscheduleSuccess').submit();
					stopLoader("page-section");
				} else {
					$('.submit-err').html(data.message);
					$('.submit-err').show();
					$('html, body').animate({
					       scrollTop: $(".submit-err").offset().top
					}, 500);
					stopLoader("page-section");
				}
			},error:function(){
				console.error("schedule add service is unavailable");
				stopLoader("page-section");
			}
		});
	} else {
		$('.submit-err').html(messageErr);
		$('.submit-err').show();
		stopLoader("page-section");
	}
}

function disabledays(show){
	if(show){
		$("#enddiv").removeClass("d-none");
		$("#enddiv1").removeClass("d-none");
	}else{
		$("#enddiv").addClass("d-none");
		$("#enddiv1").addClass("d-none");
	}
}


