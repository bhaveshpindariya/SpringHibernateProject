var months = ["January","Febrary","March","April","May","June","July","August","September","October","November","December"];

var doctorTable;
var appointmnetTable;
var languageURL = "";
$(function() {
	if(currentLanguage && currentLanguage === 'es'){
		languageURL = baseUrl+"/resources/javascript/pages/datatable_spanish.json";
	}
	initDoctorTable();
	initAppointmnetTable();
	getDoctorSchedules();
});

function filterTable(){
	appointmnetTable.ajax.reload();
}

function resetTable(){
	$("#appointmentDate").val('');
	$("#statusCode").val('-1');
	appointmnetTable.ajax.reload();
}
function initAppointmnetTable(){
	if($("#appointmnetTable").length){
		appointmnetTable = $("#appointmnetTable").DataTable( {
			"lengthMenu": [[10, 25, 50], [10, 25, 50]],
			"columnDefs": [{"orderable": false}],
			"processing": true,
			"serverSide": true,
			"autoWidth": false,
			"ordering": false,
			"searching": false,
			"ajax": {
				url:getAppointmentForDoctorURL,
				data: function(data) {
				     data.userName = $("#userIdForDoctor").val();
				     data.appointmentDate = $("#appointmentDate").val();
				     data.status = $("#statusCode").val();;
			    }
			},
			"columns": [
	            { "data": "userName" },
	            { "data": "appointmentDate"},
	            { "data": "timeSlot" },
	            { "data": "location" },
	            { "data": "status" },
	            { "data": "actions" ,"sClass":"align-middle text-center actions-btn"}
	        ],
	        "language": {
                "url": languageURL
            }
		});
		$('#appointmnetTable tbody').on( 'click', 'a.action-button', function () {
	        var data = appointmnetTable.row($(this).parents('tr')).data();
	        var action = $(this).attr("data-original-title");
	        if(action === "View"){
	        	viewAppointment(data);
	        }
	        if(action === "Cancel"){
	        	cancelAppointment(data);
	        }
	    });
	}
}
function viewAppointment(data){
	$("#appointmentsId").val(data.appointmentsId);
	$("#userNameSearch").val($("#userSearch").val());
	$("#appointmentDateFilter").val($("#appointmentDate").val());
	$("#statusFilter").val(1);
	$("#viewDoctorAppointment").submit();
}
function cancelAppointment(data){
	$("#appointmentsIdReject").val(data.appointmentsId);
	$("#RejectRequestModal").modal("show");
}
function validateReason(){
	var cancellationReason = $("#cancellationReason").val();
	if(cancellationReason === "-1"){
		$("#customReasonInput").attr("required","required");
		$("#customReason").removeClass("d-none");
	}else{
		$("#customReasonInput").removeAttr("required");
		$("#customReason").addClass("d-none");
	}
}
function initDoctorTable(){
	if($("#doctorTable").length){
		var viewdoctorButton = '';
		var editdoctorButton = '';
		var deletedoctorButton = '';
		if($("#doctoredit").val() === 'true'){
			editdoctorButton = '<a href="javascript:;" class="btn btn-sm btn-secondary" data-toggle="tooltip" title="" data-original-title="Edit"><i class="fa fa-pencil-alt"></i><span class="sr-only">Edit</span></a>';
		}
		if($("#doctordelete").val() === 'true'){
			deletedoctorButton = '<a href="javascript:;" class="btn btn-sm btn-secondary" data-toggle="tooltip" title="" data-original-title="Delete"><i class="fas fa-trash"></i><span class="sr-only">Delete</span></a>';
		}
		if($("#doctorview").val() === 'true'){
			viewdoctorButton = '<a href="javascript:;" class="btn btn-sm btn-secondary" data-toggle="tooltip" title="" data-original-title="View"><i class="fas fa-eye"></i><span class="sr-only">View</span></a>';
		}
		doctorTable = $("#doctorTable").DataTable( {
			"lengthMenu": [[10, 25, 50], [10, 25, 50]],
			"columnDefs": [ {"targets": 6, "orderable": false} ],
			"processing": true,
			"serverSide": true,
			"autoWidth": false,
			"ordering": false,
			"searching": false,
			"ajax": {
				url: doctorPagination,
				data: function(data) {
					 data.doctorStatus = $("#doctorStatus").val();
				     data.doctorAcess = $("#doctorAcess").val();
				}
			},
			"columns": [
	            { "data": "fullName" },
	            { "data": "contactNo" },
	            { "data": "emailAddress" },
	            { "data": "privacy" },
	            { "data": "eps" },
	            { "data": "status"},
	            { "data": "" ,"sClass":"align-middle text-center actions-btn"}
	        ],
	        "language": {
	            "url": languageURL
	        },
	        "columnDefs": [ {
	            "targets": 5,
	            "createdCell": function(td, cellData, rowData, row, col) {
	                switch(cellData) {
	                case "ACTIVE":
	                    $(td).addClass('text-success');
	                    break;
	                case "DELETED":
	                    $(td).addClass('text-danger');
	                    break;
	                }
	            }
	        },{
	            "targets": -1,
	            "data": null,
	            "defaultContent": viewdoctorButton+editdoctorButton+deletedoctorButton
	        } ]
		});
		
		$('#doctorTable tbody').on( 'click', 'a', function () {
	        var data = doctorTable.row( $(this).parents('tr') ).data();
	        var userId = data.userId;
	        var action = $(this).attr("data-original-title");
	        if(action === "View"){
	        	viewDoctor(userId);
	        }
	        if(action === "Edit"){
	        	editDoctor(userId);
	        }
	        if(action === "Delete"){
	        	deleteDoctor(userId);
	        }
	    });
	}
	function moveItems(origin, dest) {
		$(origin).find(':selected').appendTo(dest);
	}

	function moveAllItems(origin, dest) {
		$(origin).children().appendTo(dest);
	}

	$('#left').click(function() {
		moveItems('#sbTwo', '#sbOne');
	});

	$('#right').on('click', function() {
		moveItems('#sbOne', '#sbTwo');
	});

	$('#leftall').on('click', function() {
		moveAllItems('#sbTwo', '#sbOne');
	});

	$('#rightall').on('click', function() {
		moveAllItems('#sbOne', '#sbTwo');
	});
}
function viewDoctor(userId) {
	$("#userIds").val(userId);
	$("#viewDoctorForm").submit();
}
function editDoctor(userId) {
	$("#userId").val(userId);
	$("#editDoctorForm").submit();
}
function editDoctorPage() {
	$("#editDoctorData").submit();
}
function deleteDoctor(userId) {
	$("#userIdDelete").val(userId);
	$("#myModal").modal("show");
}
function resetDoctorTable(){
	$("#doctorAcess").val("-1");
	$("#doctorStatus").val("-1");
	doctorTable.ajax.reload();
}
function filterDoctorTable(){
	doctorTable.ajax.reload();
}
function resetPassword() {
	$("#data").modal("hide");
	$("#password").val('');
	$("#cpassword").val('');
}
function closeModel(){
	$("#data").modal("hide");
	$("#password").val('');
	$("#cpassword").val('');
	$('.modal-backdrop').remove();
	$("#resetPassword").modal('hide');
}
function checkPassword() {
	if($("#password").val() != $("#cpassword").val()){
		$("#message").text("Password you entered did not match");
		$("#data").modal("show");
		return false;
	}else if($("#password").val().length < 6){
		$("#message").text("Please Enter Atleast 6 letter");
		$("#data").modal("show");
		return false;
	}else{
		$("#resetPasswordForm").submit();
	}
}

$('#flatpickr10').change(function() {
	getDoctorSchedules();
/*	alert("ghhvh");*/
});


function getDoctorSchedules() {
	var filterDate = $('#flatpickr10').val();
    var filterLocation = $("#sFilterLocation").val();
    var filterStatus = $("#sFilterStatus").val();
    var filterEps = $("#sFilterEPS").val();
    var doctorId = $('#userIdForDoctor').val();
    var dt = new Date();
    if(filterDate) {
	    dt = new Date(filterDate);
    }
    var month = months[dt.getMonth()];
	var date = dt.getDate();
	var year = dt.getFullYear();
	var dateHtml = dateConstant.replace("MONTH",month).replace("DATE",date).replace("YEAR",year);
	$('.schDateClass').html(dateHtml);
    if(doctorId !=null){
		$.ajax({
			url:fetchDoctorSchedules,
			data:{
				"selectedDoctorId":doctorId,
				"filterDate":filterDate,
				"filterLocation":filterLocation,
				"filterStatus":filterStatus,
				"filterEps":filterEps
			},
			success:function(rdata){
				$("#doctorScheduleTable tbody").html('');
				var data = JSON.parse(rdata);
				var rowData = "";
				for(var i=0; i<data.length; i++){
					var schedule = data[i];
					rowData += '<tr>';
					rowData += '<td>'+schedule.startTime+'</td>';
					rowData += '<td>'+schedule.endTime+'</td>';
					rowData += '<td>'+schedule.locationEnglish+'</td>';
					rowData += '<td>'+schedule.maxAppointments+'</td>';
					rowData += '<td>'+schedule.appointmentsBooked+'</td>';
					rowData += '<td><span class="badge badge-success">'+schedule.status+'</span></td>';
					rowData += '<td>';
					rowData += schedule.actionBtns;
					rowData += '</td>';
					rowData += '</tr>';
					rowData += '<tr id="sc_'+schedule.scheduleId+'" style="display:none"><td>'+JSON.stringify(schedule)+'</td></tr>'
				}
				$("#doctorScheduleTable tbody").append(rowData);
				$('.doc-sch-cancel').off('click').click(function(){
					var scId = $(this).data('schid');
					populateCancelReasons(scId);
				});
				$('.doc-sch-view').off('click').click(function(){
					var scid = $(this).data('schid');
					viewSeduler(scid);
				});	
			},error:function(){
				console.error("doctor schedule get service is unavailable");
			}
		});
    }
}

function validateReasonSedule(){
	var cancellationReason = $("#cancellationReasonScedule").val();
	if(cancellationReason === "-1"){
		$("#otherReasonText").attr("required","required");
		$("#otherReason").removeClass("d-none");
	}else{
		$("#otherReasonText").removeAttr("required");
		$("#otherReason").addClass("d-none");
	}
}

function populateCancelReasons(scId) {
	$("#scheduleIds").val(scId);
}
function viewSeduler(scId) {
	$("#scheduleId").val(scId);
	$("#viewDoctorSeduler").submit();
}

function filtersch() {
	getDoctorSchedules();
}

function resetSch() {
	$("#sFilterLocation").val('-1');
    $("#sFilterStatus").val('-1');
    $("#sFilterEPS").val('-1');
    getDoctorSchedules();
}