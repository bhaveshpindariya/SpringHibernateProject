var requestTable;
var languageURL = "";
$(function() {
	if(currentLanguage && currentLanguage === 'es'){
		languageURL = baseUrl+"/resources/javascript/pages/datatable_spanish.json";
	}
	if($("#requestTable").length){
		initRequestTable();
	}
});

function initRequestTable(){
	requestTable = $("#requestTable").DataTable( {
		"lengthMenu": [[10, 25, 50], [10, 25, 50]],
		"columnDefs": [{"orderable": false}],
		"processing": true,
		"serverSide": true,
		"autoWidth": false,
		"ordering": false,
		"searching": false,
		"ajax": {
			url:getCancellationRequestsURL,
			data: function(data) {
			     data.userName = $("#userSearch").val();
			     data.appointmentDate = $("#appointmentDate").val();
			     data.categoryId = $("#appointmentCategory").val();
		    }
		},
		"columns": [
            { "data": "reason" },
            { "data": "cancellationDate" },
            { "data": "userName" },
            { "data": "categoryName" },
            { "data": "hasLegalDocs" },
            { "data": "appointmentDate" },
            { "data": "timeSlot" },
            { "data": "doctorName" },
            { "data": "actions" ,"sClass":"align-middle text-center actions-btn"}
        ],
        "language": {
            "url": languageURL
        }
	});
	$('#requestTable tbody').on( 'click', 'a.action-button', function () {
        var data = requestTable.row($(this).parents('tr')).data();
        var action = $(this).attr("data-original-title");
        if(action === "View"){
        	viewRequest(data);
        }
        if(action === "Accept"){
        	acceptRequest(data);
        }
        if(action === "Reject"){
        	rejectRequest(data);
        }
    });
}

function searchTable(){
	if($("#userSearch").val()){
		requestTable.ajax.reload();
	}
}

function filterTable(){
	requestTable.ajax.reload();
}

function resetTable(){
	$("#userSearch").val('');
	$("#appointmentDate").val('');
	$("#appointmentCategory").val('');
	requestTable.ajax.reload();
}

function viewRequest(data){
	$("#appointmentsId").val(data.appointmentId);
	$("#userNameSearch").val($("#userSearch").val());
	$("#appointmentDateFilter").val($("#appointmentDate").val());
	$("#categoryIdFilter").val($("#appointmentCategory").val());
	$("#viewAppointment").submit();
}

function acceptRequest(data){
	$("#appointmentsIdAccept").val(data.appointmentId);
	acceptRequestView();
}

function rejectRequest(data){
	$("#appointmentsIdReject").val(data.appointmentId);
	rejectRequestView();
}

function acceptRequestView(){
	$("#acceptRequestForm").submit();
}

function rejectRequestView(){
	$("#RejectRequestModal").modal("show");
}

function validateReason(){
	var cancellationReason = $("#cancellationReason").val();
	if(cancellationReason === "-1"){
		$("#customReasonInput").attr("required","required");
		$("#customReason").removeClass("d-none");
	}else{
		$("#customReasonInput").removeAttr("required");
		$("#customReason").addClass("d-none");
	}
}

function viewAppointmentNext(appointmentId){
	$("#appointmentsId").val(appointmentId);
	$("#viewAppointment").submit();
}