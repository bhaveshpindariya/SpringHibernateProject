var cmsTable;
var languageURL = "";
$(function() {
	if(currentLanguage && currentLanguage === 'es'){
		languageURL = baseUrl+"/resources/javascript/pages/datatable_spanish.json";
	}
	initCMSTable();
});
function initCMSTable(){
	if($("#cmsTable").length){
		var viewCmsButton = '';
		var editCmsButton = '';
		if($("#cmsedit").val() === 'true'){
			editCmsButton = '<a href="javascript:;" class="btn btn-sm btn-secondary" data-toggle="tooltip" title="" data-original-title="Edit"><i class="fa fa-pencil-alt"></i><span class="sr-only">Edit</span></a>';
		}
		if($("#cmsview").val() === 'true'){
			viewCmsButton = '<a href="javascript:;" class="btn btn-sm btn-secondary" data-toggle="tooltip" title="" data-original-title="View"><i class="fas fa-eye"></i><span class="sr-only">View</span></a>';
		}
		cmsTable = $("#cmsTable").DataTable( {
			"lengthMenu": [[10, 25, 50], [10, 25, 50]],
			"columnDefs": [ {"targets": 4, "orderable": false} ],
			"processing": true,
			"serverSide": true,
			"autoWidth": false,
			"ordering": false,
			"searching": false,
			"ajax": {
				url: cmsPagination,
				data: function(data) {
					 data.cmsStatus = $("#cmsStatus").val();
				     data.cmsRole = $("#cmsRole").val();
				}
			},
			"columns": [
	            { "data": "particular" },
	            { "data": "role" },
	            { "data": "update" },
	            { "data": "status" },
	            { "data": "" ,"sClass":"align-middle text-center actions-btn"}
	        ],
	        "language": {
	            "url": languageURL
	        },
	        "columnDefs": [ {
	            "targets": 3,
	            "createdCell": function(td, cellData, rowData, row, col) {
	                switch(cellData) {
	                case "ACTIVE":
	                    $(td).addClass('text-success');
	                    break;
	                case "DELETED":
	                    $(td).addClass('text-danger');
	                    break;
	                }
	            }
	        },{
	            "targets": -1,
	            "data": null,
	            "defaultContent": viewCmsButton+editCmsButton
	        } ]
		});
		
		$('#cmsTable tbody').on( 'click', 'a', function () {
	        var data = cmsTable.row( $(this).parents('tr') ).data();
	        var id = data.id;
	        var action = $(this).attr("data-original-title");
	        if(action === "View"){
	        	viewcms(id);
	        }
	        if(action === "Edit"){
	        	editcms(id);
	        }
	    });
	}
}

function viewcms(id) {
	$("#ids").val(id);
	$("#viewCmsForm").submit();
}
function editcms(id) {
	$("#id").val(id);
	$("#editCmsForm").submit();
}
function editcmsforview(id) {
	$("#ides").val(id);
	$("#editCms").submit();
}
function resetCmsTable(){
	$("#cmsRole").val("-1");
	$("#cmsStatus").val("-1");
	cmsTable.ajax.reload();
}
function filterCmsTable(){
	cmsTable.ajax.reload();
}
function closeCmsModel(){
	
	$("#cmsFile").val('');
	$("#importCms").hide();
	

}
