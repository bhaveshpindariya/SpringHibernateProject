var requestTable;
var languageURL = "";
$(function() {
	if(currentLanguage && currentLanguage === 'es'){
		languageURL = baseUrl+"/resources/javascript/pages/datatable_spanish.json";
	}
	initRequestTable();
	initAppointmentsTable();
});

function initRequestTable(){
	if($("#requestTable").length){
		var hasPermission = $("#hasModifyPermission").val();
		var viewButton = '<a href="javascript:;" class="btn action-button btn-sm btn-secondary" data-toggle="tooltip" title="" data-original-title="View"><i class="fas fa-eye"></i><span class="sr-only">View</span></a>&nbsp;';
		var acceptButton = '';
		var rejectButton = '';
		if(hasPermission === "true"){
			acceptButton = '<a href="javascript:;" class="btn action-button btn-sm btn-secondary" data-toggle="tooltip" title="" data-original-title="Accept"><i class="fas fa-check"></i><span class="sr-only">Accept</span></a>&nbsp;';
			rejectButton = '<a href="javascript:;" class="btn action-button btn-sm btn-secondary" data-toggle="tooltip" title="" data-original-title="Reject"><i class="fas fa-times"></i><span class="sr-only">Reject</span></a>';			
		}
		
		requestTable = $("#requestTable").DataTable( {
			"lengthMenu": [[10, 25, 50], [10, 25, 50]],
			"columnDefs": [{"orderable": false}],
			"processing": true,
			"serverSide": true,
			"autoWidth": false,
			"ordering": false,
			"searching": false,
			"ajax": {
				url:getAppointmentRequestsURL,
				data: function(data) {
				     data.userName = $("#userSearch").val();
				     data.appointmentDate = $("#appointmentDate").val();
				     data.categoryId = $("#appointmentCategory").val();
			    }
			},
			"columns": [
	            { "data": "appointmentDate" },
	            { "data": "userName" },
	            { "data": "categoryName" },
	            { "data": "hasLegalDocs" },
	            { "data": "timeSlot" },
	            { "data": "doctorName" },
	            { "data": "" ,"sClass":"align-middle text-center actions-btn"}
	        ],
	        "columnDefs": [{
	            "targets": -1,
	            "data": null,
	            "defaultContent": viewButton+acceptButton+rejectButton
	        }],
	        "language": {
                "url": languageURL
            }
		});
		$('#requestTable tbody').on( 'click', 'a.action-button', function () {
	        var data = requestTable.row($(this).parents('tr')).data();
	        var action = $(this).attr("data-original-title");
	        if(action === "View"){
	        	viewRequest(data);
	        }
	        if(action === "Accept"){
	        	acceptRequest1(data);
	        }
	        if(action === "Reject"){
	        	rejectRequest(data);
	        }
	    });
	}
}

function searchTable(){
	if($("#userSearch").val()){
		requestTable.ajax.reload();
	}
}

function filterTable(){
	requestTable.ajax.reload();
}

function resetTable(){
	$("#userSearch").val('');
	$("#appointmentDate").val('');
	$("#appointmentCategory").val('');
	$("#appointmentStatus").val('-1');
	requestTable.ajax.reload();
}

function viewRequest(data){
	$("#appointmentsId").val(data.appointmentId);
	$("#userNameSearch").val($("#userSearch").val());
	$("#appointmentDateFilter").val($("#appointmentDate").val());
	$("#categoryIdFilter").val($("#appointmentCategory").val());
	$("#viewAppointmentRequest").submit();
}

function acceptRequest1(data){
	$("#appointmentsIdAccept").val(data.appointmentId);
	acceptRequest();
}

function rejectRequest(data){
	$("#appointmentsIdReject").val(data.appointmentId);
	$("#RejectRequestModal").modal("show");
}

function validateReason(){
	var cancellationReason = $("#cancellationReason").val();
	if(cancellationReason === "-1"){
		$("#customReasonInput").attr("required","required");
		$("#customReason").removeClass("d-none");
	}else{
		$("#customReasonInput").removeAttr("required");
		$("#customReason").addClass("d-none");
	}
}
function acceptRequest(){
	$("#acceptRequestForm").submit();
}

function viewAppointmentRequest(appointmentId){
	$("#appointmentsId").val(appointmentId);
	$("#viewAppointmentRequest").submit();
}
function rescheduleRequest(){
	$("#reScheduleRequest").submit()
}

function initAppointmentsTable(){
	if($("#appointmentsTable").length){
		requestTable = $("#appointmentsTable").DataTable( {
			"lengthMenu": [[10, 25, 50], [10, 25, 50]],
			"columnDefs": [{"orderable": false}],
			"processing": true,
			"serverSide": true,
			"autoWidth": false,
			"ordering": false,
			"searching": false,
			"ajax": {
				url:getAppointmentsURL,
				data: function(data) {
				     data.userName = $("#userSearch").val();
				     data.appointmentDate = $("#appointmentDate").val();
				     data.statusCode = $("#appointmentStatus").val();
			    }
			},
			"columns": [
	            { "data": "userName" },
	            { "data": "doctorName" },
	            { "data": "appointmentDate" },
	            { "data": "timeSlot" },
	            { "data": "location" },
	            { "data": "status" },
	            { "data": "actions" ,"sClass":"align-middle text-center actions-btn"}
	        ],
	        "language": {
                "url": languageURL
            }
		});
		$('#appointmentsTable tbody').on( 'click', 'a.action-button', function () {
	        var data = requestTable.row($(this).parents('tr')).data();
	        var action = $(this).attr("data-original-title");
	        if(action === "View"){
	        	viewAppointment(data);
	        }
	        if(action === "Reject"){
	        	cancelAppointment(data);
	        }
	    });
	}
}

function viewAppointment(data){
	$("#appointmentsId").val(data.appointmentId);
	$("#userNameSearch").val($("#userSearch").val());
	$("#appointmentDateFilter").val($("#appointmentDate").val());
	$("#statusFilter").val($("#appointmentStatus").val());
	$("#viewAppointment").submit();
}

function viewAppointmentNext(appointmentId){
	$("#appointmentsId").val(appointmentId);
	$("#viewAppointment").submit();
}

function cancelAppointment(data){
	$("#appointmentsIdReject").val(data.appointmentId);
	$("#RejectRequestModal").modal("show");
}