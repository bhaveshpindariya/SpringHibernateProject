var epsTable;
var languageURL = "";
$(function() {
	if(currentLanguage && currentLanguage === 'es'){
		languageURL = baseUrl+"/resources/javascript/pages/datatable_spanish.json";
	}
	initEpsTable();
});
function initEpsTable(){	
	var editEpsButton = '';
	var deleteEpsButton = '';
	if($("#epsedit").val() === 'true'){
		editEpsButton = '<a href="javascript:;" class="btn btn-sm btn-secondary" data-toggle="tooltip" title="" data-original-title="Edit"><i class="fa fa-pencil-alt"></i><span class="sr-only">Edit</span></a>';
	}
	if($("#epsdelete").val() === 'true'){
		deleteEpsButton = '<a href="javascript:;" class="btn btn-sm btn-secondary" data-toggle="tooltip" title="" data-original-title="Delete"><i class="fas fa-trash"></i><span class="sr-only">Delete</span></a>';
	}
	epsTable = $("#epsTable").DataTable( {
		"lengthMenu": [[10, 25, 50], [10, 25, 50]],
		"columnDefs": [ {"targets": 5, "orderable": false} ],
		"processing": true,
		"serverSide": true,
		"autoWidth": false,
		"ordering": false,
		"searching": false,
		"ajax": {
			url: epsPagination,
			data: function(data) {
			}
		},
		"columns": [
			{ "data": "epsCode" },
			{ "data": "type" },
            { "data": "eps" },
            { "data": "epsInSpanish" },
            { "data": "status"},
            { "data": "" ,"sClass":"align-middle text-center actions-btn"}
        ],
        "columnDefs": [{
	            "targets": 4,
	            "createdCell": function(td, cellData, rowData, row, col) {
	                switch(cellData) {
	                case "ACTIVE":
	                    $(td).addClass('text-success');
	                    break;
	                case "DELETED":
	                    $(td).addClass('text-danger');
	                    break;
	                }
	            }
	        },{
            "targets": -1,
            "data": null,
            "defaultContent": editEpsButton+deleteEpsButton
        } ],
        "language": {
            "url": languageURL
        }
	});
	
	$('#epsTable tbody').on( 'click', 'a', function () {
        var data = epsTable.row( $(this).parents('tr') ).data();
        var epsId = data.epsId;
        var epscode = data.epsCode;
        var type = data.type;
        var eps = data.eps;
        var epsInSpanish = data.epsInSpanish;
        var action = $(this).attr("data-original-title");
        if(action === "Edit"){
        	editEps(epsId,epscode,type,eps,epsInSpanish);
        }
        if(action === "Delete"){
        	deleteEps(epsId);
        }
    });
	
}
function editEps(epsId,epscode,type,eps,epsInSpanish) {
	$("#epsIds").val(epsId);
	$("#epsCodes").val(epscode);
	$("#epss").val(eps);
	$("#types").val(type);
	$("#epsInSpanishs").val(epsInSpanish);
	$("#editEps").modal("show");
}
function deleteEps(id) {
	$("#epsIdDelete").val(id);
	$("#myModal").modal("show");
}

function closeEpsModel() {
	$("#epsId").val('');
	$("#eps").val('');
	$("#epsInSpanish").val('');
	$("#epsFile").val('');
	$("#AddNewEps").modal("hide");
	$("#importEps").modal("hide");
}


