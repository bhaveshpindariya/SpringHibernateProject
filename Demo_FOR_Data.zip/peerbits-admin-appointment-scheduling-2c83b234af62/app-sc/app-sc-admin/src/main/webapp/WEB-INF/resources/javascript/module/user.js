var subAdminTable;
var languageURL = "";
$(function() {
	if(currentLanguage && currentLanguage === 'es'){
		languageURL = baseUrl+"/resources/javascript/pages/datatable_spanish.json";
	}
	initSubadminTable();
});
function initSubadminTable(){
	if($("#subAdminTable").length){
		var userViewButton = '';
		var editUserButton = '';
		var deleteUserButton = '';
		if($("#useredit").val() === 'true'){
			editUserButton = '<a href="javascript:;" class="btn btn-sm btn-secondary" data-toggle="tooltip" title="" data-original-title="Edit"><i class="fa fa-pencil-alt"></i><span class="sr-only">Edit</span></a>';
		}
		if($("#userdelete").val() === 'true'){
			deleteUserButton = '<a href="javascript:;" class="btn btn-sm btn-secondary" data-toggle="tooltip" title="" data-original-title="Delete"><i class="fas fa-trash"></i><span class="sr-only">Delete</span></a>';
		}
		if($("#userview").val() === 'true'){
			userViewButton = '<a href="javascript:;" class="btn btn-sm btn-secondary" data-toggle="tooltip" title="" data-original-title="View"><i class="fas fa-eye"></i><span class="sr-only">View</span></a>';
		}
		subAdminTable = $("#subAdminTable").DataTable( {
			"lengthMenu": [[10, 25, 50], [10, 25, 50]],
			"columnDefs": [ {"targets": 5, "orderable": false} ],
			"processing": true,
			"serverSide": true,
			"autoWidth": false,
			"ordering": false,
			"searching": false,
			"ajax": {
				url:fetchSubAdmins,
				data: function(data) {
				     data.userStatus = $("#userStatus").val();
				     data.roleSearch = $("#roleSearch").val();
			    }
			},
			"columns": [
	            { "data": "name" },
	            { "data": "contactNumber" },
	            { "data": "email" },
	            { "data": "role" },
	            { "data": "status" },
	            { "data": "" ,"sClass":"align-middle text-center actions-btn"}
	        ],
	        "language": {
	            "url": languageURL
	        },
	        "columnDefs": [{
	            "targets": 4,
	            "createdCell": function(td, cellData, rowData, row, col) {
	                switch(cellData) {
	                case "ACTIVE":
	                    $(td).addClass('text-success');
	                    break;
	                case "DELETED":
	                    $(td).addClass('text-danger');
	                    break;
	                }
	            }
	        },{
	            "targets": -1,
	            "data": null,
	            "defaultContent": userViewButton+editUserButton+deleteUserButton
	        } ]
		});
		
		$('#subAdminTable tbody').on( 'click', 'a', function () {
	        var data = subAdminTable.row( $(this).parents('tr') ).data();
	        var userId = data.userId;
	        var action = $(this).attr("data-original-title");
	        if(action === "View"){
	        	viewSubAdmin(userId);
	        }
	        if(action === "Edit"){
	        	editSubAdmin(userId);
	        }
	        if(action === "Delete"){
	        	deleteSubAdmin(userId);
	        }
	    });
		
	}
}

function editSubAdmin(uid) {
	$("#editUserId").val(uid);
	$('#subAdminEdit').submit();
}

function viewSubAdmin(uid) {
	$("#viewUserId").val(uid);
	$('#subAdminView').submit();
}

function deleteSubAdmin(uid) {
	$("#deleteuserId").val(uid);
	$("#myModal").modal("show");
}

function resetUserTable(){
	$("#roleSearch").val('-1');
	$("#userStatus").val("5");
	subAdminTable.ajax.reload();
}
function filterUserTable(){
	subAdminTable.ajax.reload();
}
function resetPasswordForUser() {
	$("#data").modal("hide");
	$("#password").val('');
	$("#cpassword").val('');
}
function checkPasswordRules(){
	if($("#password").val() != $("#cpassword").val()){
		$("#message").text("Password you entered did not match");
		$("#data").modal("show");
		return false;
	}else if($("#password").val().length < 6){
		$("#message").text("Please Enter Atleast 6 letter");
		$("#data").modal("show");
		return false;
	}else{
		$("#resetPasswordForm").submit();
	}
}
function closeModel(){
	$("#data").modal("hide");
	$("#password").val('');
	$("#cpassword").val('');
	$('.modal-backdrop').remove();
	$("#resetPassword").modal('hide');
}
function checkPassword(){
	if($("#password").val() != $("#cpassword").val()){
		$("#message").text("Password you entered did not match");
		$("#data").modal("show");
		return false;
	}else if($("#password").val().length < 6){
		$("#message").text("Please Enter Atleast 6 letter");
		$("#data").modal("show");
		return false;
	}else{
		return true;
	}
}