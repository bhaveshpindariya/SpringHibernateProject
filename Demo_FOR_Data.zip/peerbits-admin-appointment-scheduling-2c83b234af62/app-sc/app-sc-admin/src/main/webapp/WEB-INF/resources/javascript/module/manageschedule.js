var managescheduleTable;
var languageURL = "";
$(function() {
	if(currentLanguage && currentLanguage === 'es'){
		languageURL = baseUrl+"/resources/javascript/pages/datatable_spanish.json";
	}
	initManageScheduleTable();
});
function initManageScheduleTable(){
	if($("#managescheduleTable").length){
		var schViewButton = '';
		var schAcceptButton = '';
		var schRejectButton = '';
		if($("#schModifyPermission").val() === 'true'){
			schAcceptButton = '<a href="javascript:;" class="btn btn-sm btn-secondary" id="acceptschedule" data-toggle="modal" data-target="#ModifySlotSchedule" title="" data-original-title="Approve"><i class="fas fa-check"></i><span class="sr-only">Accept</span></a>';
			schRejectButton = '<a href="javascript:;" class="btn btn-sm btn-secondary" id="rejectschedule" data-toggle="modal" data-target="#RejectRequestModal" title="" data-original-title="Reject"><i class="fas fa-times"></i><span class="sr-only">Reject</span></a>';
		}
		if($("#schViewPermission").val() === 'true'){
			schViewButton = '<a href="javascript:;" class="btn btn-sm btn-secondary" id="viewschedule" data-toggle="tooltip" title="" data-original-title="View"><i class="fas fa-eye"></i><span class="sr-only">View</span></a>';
		}
		
			managescheduleTable = $("#managescheduleTable").DataTable( {
			"lengthMenu": [[10, 25, 50], [10, 25, 50]],
			"columnDefs": [ {"targets": 5, "orderable": false} ],
			"processing": true,
			"serverSide": true,
			"autoWidth": false,
			"ordering": false,
			"searching": false,
			"ajax": {
				url:fetchSchedules,
				data: function(data) {
				     data.schDate = $("#scDate").val();
				     data.schStatus = $("#scheduleStatus").val();
			    }
			},
			"columns": [
	            { "data": "doctorName" },
	            { "data": "dateTimeSlot" },
	            { "data": "maxAppointments" },
	            { "data": "appointmentsBooked" },
	            { "data": "status" },
	            { "data": "actionBtns" ,"sClass":"align-middle text-center actions-btn"}
	        ],
	        "language": {
	            "url": languageURL
	        },
	        "columnDefs": [{
	            "targets": 4,
	            "createdCell": function(td, cellData, rowData, row, col) {
	                switch(cellData) {
	                case "Active":
	                    $(td).addClass('text-success');
	                    break;
	                case "Cancelled":
	                    $(td).addClass('text-danger');
	                    break;
	                }
	            }
	        },{
	            "targets": -1,
	            "data": null,
	        } ]
		});
		
		$('#managescheduleTable tbody').on( 'click', 'a', function () {
			
			var data = managescheduleTable.row( $(this).parents('tr') ).data();
	        var scid = data.scheduleId;
	        if(data['parentScheduleId']) {
	        	scid = data.parentScheduleId;
	        }
			var action = $(this).data('original-title');
			
			if(action=="View") {
				$('#viewscheduleId').val(scid);
				$('#scheduleview').submit();
			} else if(action == "Accept") {
				acceptClick(scid,data);
			} else if(action == "Reject") {
				cancelClick(scid);
			}
		});
		
	}
	
}
function resetScRequestTable(){
	$("#scDate").val('');
	$("#scheduleStatus").val("-1");
	managescheduleTable.ajax.reload();
}
function filterScRequestTable(){
	console.log("filter");
	managescheduleTable.ajax.reload();
}

$('#ViewSchedule').change(function(){
	$('#viewscheduleId').val(scid);
	$('#scheduleview').submit();
});

$('#modifySlotScheduleOpen').off('click').click(function(){
	var scheduleId = $('#scheduleidH').val();
	var stime = $('#stimeH').val();
	var etime = $('#etimeH').val();
	var maxApp = $('#maxAppH').val();
	var epsid = $('#epsH').val();
	/*$('#scheduleId').val(scheduleId);*/
	populateModifyScheduleModal(scheduleId, stime, etime, maxApp, epsid);
	populateEPSDD(epsid);
});

$('#activeModifyBtn').off('click').click(function(){
	var scheduleId = $(this).data('schid');
	var stime = $('#stime_'+scheduleId).html();
	var etime = $('#etime_'+scheduleId).html();
	var maxApp = $('#maxapp_'+scheduleId).html();
	var epsid = $(this).data('eps');
	populateModifyScheduleModal(scheduleId, stime, etime, maxApp, epsid);
	populateEPSDD(epsid);
});

$('#activeCancelBtn').off('click').click(function(){
	var scheduleId = $(this).data('schid');
	$('#modalCancelscheduleId').val(scheduleId)
	populateCancelReasons(scheduleId);
});

$('#rejectRequestModalOpen').off('click').click(function(){
	var scheduleId = $('#scheduleidH').val();
	$('.rejecterr').html('');
	$('#modalCancelscheduleId').val(scheduleId);
	populateCancelReasons(cancelreaason);
});

$('#rejectschedule').click(function(){
	$('#RejectRequestModal').modal('show');
	var scheduleId = $('#scheduleidH').val();
	$('.rejecterr').html('');
	$('#modalCancelscheduleId').val(scheduleId);
	populateCancelReasons();
});

$('#cancelschedule').click(function(){
	var scheduleId = $('#scheduleidH').val();
	$('.rejecterr').html('');
	$('#modalCancelscheduleId').val(scheduleId);
	populateCancelReasons();
});

function acceptClick(scheduleId, data) {
	var startTime = data.startTime;
	var endTime = data.endTime;
	var maxApp = data.maxAppointments;
	var epsId = "";
	if(data['epsId']) {
		epsId = data.epsId;
	}
	populateEPSDD(epsId);
	populateModifyScheduleModal(scheduleId, startTime, endTime, maxApp, epsId);
}


function cancelClick(scheduleId) {
	$('#modalCancelscheduleId').val(scheduleId);
	$('#cancel-sc-fm').submit();
}


function populateEPSDD(epsId) {
	$('#modaleps').empty();
	$.ajax({
		url:fetchAllEPS,
		success:function(epsData){
			epsData = JSON.parse(epsData);
			var options = "";
			console.log("epsData.length: "+epsData.length);
			for(var i=0; i<epsData.length; i++) {
				var eps = epsData[i];
				if(epsId == eps.epsId){
					options += '<option selected="selected" value="'+eps.epsId+'">'+eps.eps+'</option>';
				}else{
					options += '<option value="'+eps.epsId+'">'+eps.eps+'</option>';
				}
			}
			$('#modaleps').append(options);
		},error:function(){
			console.error("get all active local EPS service is unavailable");
		}
	});
}

function populateCancelReasons(scheduleId) {
	$('#cancelReasonModal').empty();
	$.ajax({
		url:fetchCancelReasons,
		success:function(cancelReasons){
			cancelReasons = JSON.parse(cancelReasons);
			var options = "";
			console.log("cancelReason.length: "+cancelReasons.length);
			for(var i=0; i<cancelReasons.length; i++) {
				var data = cancelReasons[i];
				options += '<option value="'+data.reason+'">'+data.reason+'</option>';
			}
			options += '<option value="other">Other</option>';
			$('#cancelReasonModal').append(options);
			showHideOtherReason();
		},error:function(){
			console.error("get all active local cancelReason service is unavailable");
		}
	});
}
$('#cancelReasonModal').change(function(){
	showHideOtherReason();
	$('.rejecterr').html('');
});

function showHideOtherReason() {
	var selectedReason = $('#cancelReasonModal').val();
	if(!selectedReason || selectedReason == "other") {
		$('.othereason').show();
	} else {
		$('.othereason').hide();
	}
}

function populateModifyScheduleModal(scheduleid, startTime, endTime, maxApp, epsId) {
	
	$('.submit-err').html('');
	$('.submit-err').hide();
	
	$('#modalscheduleId').val(scheduleid);
	$('#modalstartTime').val(startTime);
	$('#modalEndTime').val(endTime);
	if(maxApp && Number(maxApp)>0) {
		$('#maxAppointmentsModal').val(maxApp);
	}
	if(epsId) {
		$('#modaleps').select2('val',epsId);
	}
}
function approveSc() {
	var validfm = validateModifyModalForm();
	if(validfm) {
		$('#modify-sc-fm').submit();
	} 
}


function openRejectModal(e,scid){
	e.stopPropagation();
	e.preventDefault();
	var scheduleId = jQuery('#scheduleidH').val();
	$('.rejecterr').html('');
	$('#RejectRequestModal').modal('show');
	$('#modalCancelscheduleId').val(scid);
	populateCancelReasons();
	
}

$(document).off('click').on('click','#rejectSubmit',function(e){
	var scid = $('#modalCancelscheduleId').val();
	var reason = $('#cancelReasonModal').val();
	if(scid && reason) {
		if(reason == "other") {
			var otherreason = $('#reasonOtherModal').val();
			if(otherreason) {
				$('#cancel-sc-fm').submit();
			} else {
				e.preventDefault();
				$('.rejecterr').html('<div class="alert alert-danger">All fields are required</div>');
			}
		} else {
			$('#cancel-sc-fm').submit();
		}
	}
});

function validateModifyModalForm() {
	var errMessage = "";
	isvalid = true;
	var scId = $('#modalscheduleId').val();
	var sTime = $('#modalstartTime').val();
	var eTime = $('#modalEndTime').val();
	var maxAp = $('#maxAppointmentsModal').val();
	var epsId = $('#modaleps').val();
	if(scId && sTime && eTime && maxAp && epsId) {
		if(timeCompare(sTime, eTime) != "true") {
			isvalid = false;
			errMessage = "Start time must be less than End time";
		}
	} else {
		isvalid = false;
		errMessage = "All fields are mandatory";
	}
	if(!isvalid) {
		var eDiv = errDiv.replace('ERRMESSAGE',errMessage);
		$('.submit-err').html(eDiv);
		$('.submit-err').show();
	}
	return isvalid;
}

function timeCompare(startTime, endTime) {
	var startTime24 = convertTime12to24(startTime);
	var endTime24 = convertTime12to24(endTime);
	let [hoursStart, minutesStart] = startTime24.split(':');
	let [hoursEnd, minutesEnd] = endTime24.split(':');
	if(parseInt(hoursEnd,10) < parseInt(hoursStart,10)){
		return "false";
	} else if(parseInt(hoursEnd,10) == parseInt(hoursStart,10)) {
		if(parseInt(minutesEnd,10) <= parseInt(minutesStart,10)) {
			return "false";
		} else {
			return "true";
		}
	} else {
		return "true";
	}
}

function convertTime12to24(time12h) {
	  const [time, modifier] = time12h.split(' ');

	  let [hours, minutes] = time.split(':');

	  if (hours === '12') {
	    hours = '00';
	  }

	  if (modifier === 'PM') {
	    hours = parseInt(hours, 10) + 12;
	  }

	  return hours + ':' + minutes;
}
$('#modify-sc-fm').on('keydown', '#maxAppointmentsModal', function(e){-1!==$.inArray(e.keyCode,[46,8,9,27,13,110])||(/65|67|86|88/.test(e.keyCode)&&(e.ctrlKey===true||e.metaKey===true))&&(!0===e.ctrlKey||!0===e.metaKey)||35<=e.keyCode&&40>=e.keyCode||(e.shiftKey||48>e.keyCode||57<e.keyCode)&&(96>e.keyCode||105<e.keyCode)&&e.preventDefault()});