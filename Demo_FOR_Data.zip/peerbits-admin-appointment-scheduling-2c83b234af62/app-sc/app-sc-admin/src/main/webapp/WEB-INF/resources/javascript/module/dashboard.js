function openWaitlists(notificationId) {
	redirectAppointment("viewWaitlist", notificationId);
}

function openRequest(itemId, itemType, requestType) {
	if(itemType === "appointment"){
		if(requestType === "add"){
			redirectAppointment("viewRequest", itemId);
		}
		if(requestType === "cancel"){
			redirectAppointment("viewCancellation", itemId);
		}
	}
	if(itemType === "schedule"){
		redirectSchedule("viewSchedule", itemId);
	}
}

function redirectAppointment(formId, notificationId){
	$("#"+formId+" input[name=appointmentsId]").val(notificationId);
	$("#"+formId).submit();
}

function redirectSchedule(formId, scheduleId){
	$("#"+formId+" input[name=scheduleId]").val(scheduleId);
	$("#"+formId).submit();
}