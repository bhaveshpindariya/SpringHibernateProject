var subjectTable;
var languageURL = "";
$(function() {
	if(currentLanguage && currentLanguage === 'es'){
		languageURL = baseUrl+"/resources/javascript/pages/datatable_spanish.json";
	}
	initSubjectTable();
});
function initSubjectTable(){
	if($("#subjectTable").length){
		var editSubjectButton = '';
		var deleteSubjectButton = '';
		if($("#subjectedit").val() === 'true'){
			editSubjectButton = '<a href="javascript:;" class="btn btn-sm btn-secondary" data-toggle="tooltip" title="" data-original-title="Edit"><i class="fa fa-pencil-alt"></i><span class="sr-only">Edit</span></a>';
		}
		if($("#subjectdelete").val() === 'true'){
			deleteSubjectButton = '<a href="javascript:;" class="btn btn-sm btn-secondary" data-toggle="tooltip" title="" data-original-title="Delete"><i class="fas fa-trash"></i><span class="sr-only">Delete</span></a>';
		}
		subjectTable = $("#subjectTable").DataTable( {
			"lengthMenu": [[10, 25, 50], [10, 25, 50]],
			"columnDefs": [ {"targets": 3, "orderable": false} ],
			"processing": true,
			"serverSide": true,
			"autoWidth": false,
			"ordering": false,
			"searching": false,
			"ajax": {
				url: subjectPagination,
				data: function(data) {
				}
			},
			"columns": [
	            { "data": "subject"},
	            { "data": "usertype"},
	            { "data": "status"},
	            { "data": "" ,"sClass":"align-middle text-center actions-btn"}
	        ],
	        "language": {
	            "url": languageURL
	        },
	        "columnDefs": [{
		            "targets": 2,
		            "createdCell": function(td, cellData, rowData, row, col) {
		                switch(cellData) {
		                case "ACTIVE":
		                    $(td).addClass('text-success');
		                    break;
		                case "DELETED":
		                    $(td).addClass('text-danger');
		                    break;
		                }
		            }
		        },{
	            "targets": -1,
	            "data": null,
	            "defaultContent": editSubjectButton+deleteSubjectButton
	        } ]
		});
		
		$('#subjectTable tbody').on( 'click', 'a', function () {
	        var data = subjectTable.row( $(this).parents('tr') ).data();
	        var subjectId = data.subjectId;
	        var subject = data.subject;
	        var userType = data.userType;
	        var action = $(this).attr("data-original-title");
	        if(action === "Edit"){
	        	editSubject(subjectId,subject,userType);
	        }
	        if(action === "Delete"){
	        	deleteSubject(subjectId);
	        }
	    });
	}
}
function editSubject(subjectId,subject,userType) {
	$("#subjectIds").val(subjectId);
	$("#subjects").val(subject);
	$("#actors").val(userType);
	$("#editSubject").modal("show");
}
function deleteSubject(id) {
	$("#deleteSubjectId").val(id);
	$("#myModal").modal("show");
}

function closeSubjectModel() {
	$("#subjectId").val('');
	$("#subject").val('');
	$("#AddNewSubject").modal("hide");
}


