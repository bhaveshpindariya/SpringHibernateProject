var locationTable;
var languageURL = "";
$(function() {
	if(currentLanguage && currentLanguage === 'es'){
		languageURL = baseUrl+"/resources/javascript/pages/datatable_spanish.json";
	}
	initLocationTable();
});

function initLocationTable(){
	if($("#locationTable").length){
		var editLocationButton = '';
		var deleteLocationButton = '';
		if($("#locationedit").val() === 'true'){
			editLocationButton = '<a href="javascript:;" class="btn btn-sm btn-secondary" data-toggle="tooltip" title="" data-original-title="Edit"><i class="fa fa-pencil-alt"></i><span class="sr-only">Edit</span></a>';
		}
		if($("#locationdelete").val() === 'true'){
		    deleteLocationButton = '<a href="javascript:;" class="btn btn-sm btn-secondary" data-toggle="tooltip" title="" data-original-title="Delete"><i class="fas fa-trash"></i><span class="sr-only">Delete</span></a>';
		}
		locationTable = $("#locationTable").DataTable( {
			"lengthMenu": [[10, 25, 50], [10, 25, 50]],
			"columnDefs": [ {"targets": 4, "orderable": false} ],
			"processing": true,
			"serverSide": true,
			"autoWidth": false,
			"ordering": false,
			"searching": false,
			"ajax": {
				url: locationPagination,
				data: function(data) {
					data.locationStatus = $("#locationStatus").val();
				}
			},
			"columns": [
				{ "data": "zuesLocationCode" },
	            { "data": "location" },
	            { "data": "locationInSpanish" },
	            { "data": "status"},
	            { "data": "" ,"sClass":"align-middle text-center actions-btn"}
	        ],
	        "language": {
	            "url": languageURL
	        },
	        "columnDefs": [{
		            "targets": 3,
		            "createdCell": function(td, cellData, rowData, row, col) {
		                switch(cellData) {
		                case "ACTIVE":
		                    $(td).addClass('text-success');
		                    break;
		                case "DELETED":
		                    $(td).addClass('text-danger');
		                    break;
		                }
		            }
		        },{
	            "targets": -1,
	            "data": null,
	            "defaultContent": editLocationButton+deleteLocationButton
	        } ]
		});
		
		$('#locationTable tbody').on( 'click', 'a', function () {
	        var data = locationTable.row( $(this).parents('tr') ).data();
	        var locationCode = data.zuesLocationCode;
	        var locationId = data.locationId;
	        var location = data.location;
	        var locationInSpanish = data.locationInSpanish;
	        var action = $(this).attr("data-original-title");
	        if(action === "Edit"){
	        	editloc(locationCode,locationId,location,locationInSpanish);
	        }
	        if(action === "Delete"){
	        	deleteLocation(locationId);
	        }
	    });
	}
}

function editloc(locationCode,locationId,location,locationInSpanish){
	$("#locationIds").val(locationId);
	$("#zuesLocationCodes").val(locationCode)
	$("#locations").val(location);
	$("#locationInSpanishs").val(locationInSpanish);
	startLoader("page-section");
	$.ajax({
		type : "GET",
		url : editlocurl,
		dataType : 'json',
		data: {
			LocationId : $("#locationIds").val()
		},
		success : function(result) {
			$("#editDepartment").val(result.department);
			$("#editMunicipality").val(result.municipality);
			$("#editHeadquarters").val(result.headquarters);
			$("#editLocation").modal("show");
			stopLoader("page-section");
			
		},
		error:function(){
			console.error("service is unavailable");
			stopLoader("page-section");
		}
	});
}
function deleteLocation(locationId) {
	$("#deleteLocationId").val(locationId);
	$("#myModal").modal("show");
}

function closeLocationModels() {
	$("#locationId").val('');
	$("#locationInSpanish").val('');
	$("#location").val('');
	$("#AddNewLocation").modal("hide");
}
function reloadLocationTable(){
	locationTable.ajax.reload();
}

