function editprofile(userId) {
	$("#profileid").val(userId);
	$("#editProfileForm").submit();
}