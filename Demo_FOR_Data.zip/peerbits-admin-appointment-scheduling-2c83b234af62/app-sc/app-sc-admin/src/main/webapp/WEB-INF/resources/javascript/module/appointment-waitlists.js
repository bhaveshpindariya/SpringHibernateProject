var requestTable;
var languageURL = "";
$(function() {
	if(currentLanguage && currentLanguage === 'es'){
		languageURL = baseUrl+"/resources/javascript/pages/datatable_spanish.json";
	}
	if($("#waitlistTable").length){
		initWaitlistTable();
	}
});

function initWaitlistTable(){	
	requestTable = $("#waitlistTable").DataTable( {
		"lengthMenu": [[10, 25, 50], [10, 25, 50]],
		"columnDefs": [{"orderable": false}],
		"processing": true,
		"serverSide": true,
		"autoWidth": false,
		"ordering": false,
		"searching": false,
		"ajax": {
			url:getWaitlistsURL,
			data: function(data) {
			     data.userName = $("#userSearch").val();
			     data.waitlistType = $("#waitlistType").val();
			     data.categoryId = $("#appointmentCategory").val();
		    }
		},
		"columns": [
            { "data": "date" },
            { "data": "userName" },
            { "data": "categoryName" },
            { "data": "hasLegalDocs" },
            { "data": "type" },
            { "data": "actions" ,"sClass":"align-middle text-center actions-btn"}
        ],
        "language": {
            "url": languageURL
        }
	});
	$('#waitlistTable tbody').on( 'click', 'a.action-button', function () {
        var data = requestTable.row($(this).parents('tr')).data();
        var action = $(this).attr("data-original-title");
        if(action === "View"){
        	viewRequest(data);
        }
    });
}

function searchTable(){
	if($("#userSearch").val()){
		requestTable.ajax.reload();
	}
}

function filterTable(){
	requestTable.ajax.reload();
}

function resetTable(){
	$("#userSearch").val('');
	$("#waitlistType").val('');
	$("#appointmentCategory").val('');
	requestTable.ajax.reload();
}

function viewRequest(data){
	$("#appointmentsId").val(data.appointmentId);
	$("#userNameSearch").val($("#userSearch").val());
	$("#waitlistTypeFilter").val($("#waitlistType").val());
	$("#categoryIdFilter").val($("#appointmentCategory").val());
	$("#viewRequest").submit();
}

function viewAppointmentNext(appointmentId){
	$("#appointmentsId").val(appointmentId);
	$("#viewAppointment").submit();
}

function rescheduleRequest(){
	$("#reScheduleRequest").submit()
}