$(function(){
	$('#appointmentFiles').fileinput({language: currentLanguage});
	initEditAppointment();
});

var appointmentsId = 0;
var steps = [ 1, 2, 3, 4 ];
var categoriesArray = [];
var totalChildCategories = 0;
var childCategoryArray = [];

var firstName;
var lastName;
var fullName;
var idType;
var idNumber;
var dateOfBirth;
var emailAddress;
var contact;
var userImagePath;

var selectedUserId = 0;
var epsId = 0;
var categoryId = 0;
var childCategoryId = 0;
var scheduleDate;
var selectedDate="";
var doctorsArray = [];
var slotArray = [];
var selectedDoctorId = 0;
var selectedSlotId = 0;
var selectedSlot;
var noDoctorMessage = $("#nodoctormessage").text();
function validateStep(step) {
	startLoader("page-section");
	hideErrorMsgs();
	var valid = false;
	var curStep = parseInt(step);
	var nextStep = curStep+1;
	if(curStep === 1){
		valid = validateStep1();
	}
	if(curStep === 2){
		valid = validateStep2();
		if(valid){
			moreDates();
		}
	}
	if(curStep === 3){
		valid = validateStep3();
	}
	if(valid){
		openStep(nextStep);
	}
	stopLoader("page-section");
}

function validateStep1(){
	selectedUserId = parseInt($("#selectedUserId").val());
	if(selectedUserId > 0 &&  epsId > 0){
		return true;
	}else{
		validateUser();
	}
}
function checkUser(){
	selectedUserId = 0;
	$("#selectedUserId").val(0);
}
function validateUser(){
	if(!setUserData()){
		return;
	}
	var validateUserURL = baseUrl+"/appointments/validateUser";
	$.ajax({
		async: false,
		timeout: 9000,
		url:validateUserURL,
		data:{
			idType:idType,
			idNumber:idNumber
		},
		success:function(rdata){
			var data = JSON.parse(rdata);
			if(data.error){
				$("."+data.error).removeClass("d-none");
			}else{
				updateUserData(data);
			}
		},error:function(){
			$(".error-msg.error").removeClass("d-none");
			console.error("service is unavailable");
		}
	});
}

function setUserData(){
	idType = $("#idType").val();
	idNumber = $("#idNumber").val();
	if(idType && idNumber){
		return true;
	}
	$(".allrequired").removeClass("d-none");
	return false;
}

function updateUserData(data){
	selectedUserId = data.userId;
	fullName = data.userName;
	emailAddress = data.emailAddress;
	contact = data.contactNo;
	userImagePath = data.imagePath;
	firstName = data.firstName;
	lastName = data.lastName;
	dateOfBirth = data.dateOfBirth;
	epsId = data.epsId;
	
	$("#selectedUserId").val(selectedUserId)
	$("#firstName").val(firstName);
	$("#lastName").val(lastName);
	$("#dateOfBirth").val(dateOfBirth);
	$("#epsId").val(epsId);
	$('#epsId').select2("destroy");
	$('#epsId').select2();
	
	changeEPS();
}

function hideErrorMsgs(){
	$(".error-msg").addClass("d-none");
}

function validateStep2(){
	if(categoryId > 0 && childCategoryId > 0){
		return true;
	} else if(categoryId > 0 && childCategoryArray.length > 0 && !childCategoryArray[0].categoryId){
		return true;
	}
	return false;
}
function validateStep3(){
	if(scheduleDate && selectedDoctorId > 0 && selectedSlotId > 0){
		validateStep4();
		return true;
	}
	return false;
}
function validateStep4(){
	$("#reviewUserImage").html("<img src='"+baseUrl+userImagePath+"'>");
	$("#reviewUserName").text(fullName);
	$("#reviewUserEmail").text(emailAddress);
	$("#reviewUserPhone").text(contact);
	$("#reviewCategory").text(getCategoryName(categoryId));
	$("#reviewCost").text($("#costingValue").text());
	
	var doctor = getDoctor(selectedDoctorId);
	$("#reviewDoctorImage").html("<img src='"+baseUrl+doctor.imagePath+"'>");
	$("#reviewDoctorName").text(doctor.fullName);
	$("#reviewLocation").text(selectedSlot.location);
	$("#reviewDate").text(selectedDate);
	$("#reviewTime").text(selectedSlot.time);
	
	if(hasFiles()){
		$("#legalDocuments").html($(".file-drop-zone").html());
		$("#reviewLegalDocuments").removeClass("d-none");
	}else{
		$("#legalDocuments").html('');
		$("#reviewLegalDocuments").addClass("d-none");
	}
}
function openStep(step) {
	steps.forEach(function(currentValue, index, arr){
		if(step == currentValue){
			$("#step-"+currentValue).removeClass("d-none");
			
		}else{
			$("#step-"+currentValue).addClass("d-none");
			$("#step-"+currentValue).addClass("d-none");
			$("#step-"+currentValue).addClass("d-none");
		}
		if(currentValue < step){
			$("#header-step-"+currentValue).addClass("success");
		}else if(currentValue == step){
			$("#header-step-"+currentValue).addClass("active");
			$("#header-step-"+currentValue).removeClass("success");
		}else{
			$("#header-step-"+currentValue).removeClass("active success");
		}
	});
}

function changeEPS(){
	epsId = parseInt($("#epsId").val());
	categoryId = 0;
	if(epsId > 0){
		fetchCategoriesEpsConsultant();
		clearStep2(true);
	}
}

function changeCategory(){
	categoryId = parseInt($("#categoryId").val());
	childCategoryId = 0;
	clearStep2(true);
	clearStep3(true);
	if(epsId > 0 && categoryId > 0){
		fetchSubCategories(categoryId, epsId);
	}	
}

function changeSubCategory(){
	var index = parseInt($("#childCategorySelect").val());
	if(index > -1){
		updateChildCategory(childCategoryArray[index]);
	}else{
		clearStep2(false);
	}
}

function fetchCategoriesEpsConsultant(){
	var fetchCategoriesEpsConsultantURL = baseUrl+"/category/fetchCategoriesEpsConsultant";
	$.ajax({
		url:fetchCategoriesEpsConsultantURL,
		data:{
			epsId:epsId
		},
		success:function(rdata){
			var data = JSON.parse(rdata);
			categoriesArray = data;
			processCategory();
		},error:function(){
			console.error("service is unavailable");
		}
	});
}
function fetchSubCategories(categoryId, epsId){
	var fetchCategoriesEpsConsultantURL = baseUrl+"/category/fetchSubCategories";
	$.ajax({
		url:fetchCategoriesEpsConsultantURL,
		data:{
			epsId:epsId,
			categoryId:categoryId,
			userId:selectedUserId
		},
		success:function(rdata){
			var data = JSON.parse(rdata);
			childCategoryArray = data.childCategories;
			totalChildCategories = data.total;
			processChildCategory();
		},error:function(){
			console.error("service is unavailable");
		}
	});
}

function processCategory(){
	var previousCategoryId = parseInt($('#categoryId').val());
	$('#categoryId').children('option:not(:first)').remove();
	categoriesArray.forEach(function(currentValue, index, arr){
		if(currentValue.categoryId == previousCategoryId){
			$("#categoryId").append("<option selected='selected' value='"+currentValue.categoryId+"'>"+currentValue.name+"</option>");
		}else{
			$("#categoryId").append("<option value='"+currentValue.categoryId+"'>"+currentValue.name+"</option>");
		}
	});
	$('#categoryId').select2("destroy");
	$('#categoryId').select2();
}

function getCategoryName(categoryId){
	var categoryName = "";
	for(var i =0;i<categoriesArray.length;i++){
		if(categoriesArray[i].categoryId == categoryId){
			categoryName = categoriesArray[i].name;
		}
	}
	return categoryName;
}

function processChildCategory(){
	if(totalChildCategories > 0){
		var previousChildCategoryId = parseInt($("#childCategorySelect").val());
		$('#childCategorySelect').children('option:not(:first)').remove();
		childCategoryArray.forEach(function(currentValue, index, arr){
			if(currentValue.categoryId == previousChildCategoryId){
				$("#childCategorySelect").append("<option selected='selected' value='"+index+"'>"+currentValue.name+"</option>");
			}else{
				$("#childCategorySelect").append("<option value='"+index+"'>"+currentValue.name+"</option>");
			}
		});
		$('#childCategorySelect').select2("destroy");
		$('#childCategorySelect').select2();
		$("#childCategory").removeClass("d-none");
	}else{
		updateChildCategory(childCategoryArray[0]);
	}
}

function updateChildCategory(categoryObject){
	if(categoryObject.laterality){
		$("#laterality").removeClass("d-none");
	}
	$("#costingValue").text(categoryObject.cost);
	$("#costing").removeClass("d-none");
	if(categoryObject.categoryId){
		$("#childCategoryId").val(categoryObject.categoryId);
		childCategoryId = categoryObject.categoryId;
	}else{
		$("#childCategoryId").val(0);
		childCategoryId = 0;
	}
}

function clearStep2(hideChildCategory){
	$("#childCategoryId").val(0);
	childCategoryId = 0;
	if(hideChildCategory){
		$('#childCategorySelect').children('option:not(:first)').remove();
		$("#childCategory").addClass("d-none");
	}
	$("#laterality").addClass("d-none");
	$("#costingValue").text("0.0");
	$("#costing").addClass("d-none");
}

function clearStep3(removeDates){
	if(removeDates){
		$("#datesTable").html("");
		scheduleDate = null;
	}
	$("#timeSlots").html("");
	$("#slotLocations").html("");
	$("#availableDoctors").html("");
}

function moreDates(){
	getAvailableDatesInMonth(getNextMonthDate());
}

function getNextMonthDate(){
	if(scheduleDate){
		scheduleDate.setDate(1);
		scheduleDate.setMonth(scheduleDate.getMonth()+1);
	}else{
		scheduleDate = new Date();
	}
	var date = 1;
	var month = scheduleDate.getMonth()+1;
	var nextMonth = date+"/"+month+"/"+scheduleDate.getFullYear();
	return nextMonth;
}

function getAvailableDatesInMonth(date){
	var getAvailableDatesInMonthURL = baseUrl+"/appointments/getAvailableDatesInMonth";
	$.ajax({
		url:getAvailableDatesInMonthURL,
		data:{
			date:date,
			epsId:epsId
		},
		success:function(rdata){
			var data = JSON.parse(rdata);
			appendDates(data);
		},error:function(){
			console.error("service is unavailable");
		}
	});
}

function appendDates(data){
	var monthName = data.month;
	var date = data.date;
	var availableDates = data.availableDates;
	var dates = "";
	availableDates.forEach(function(currentValue, index, arr){
		dates+='<a href="javascript:;" onclick=getAvailableDoctors("'+currentValue.date+'") class="btn btn-xs btn-outline-secondary circle">'+currentValue.displayDate+'</a>';
	});
	if(!dates){
		dates = noDoctorMessage;
	}
	var tr = '<tr>'+
				'<td class="text-left"><a href="javascript:;" onclick=monthDates("'+date+'",this)><label>'+monthName+'</label></a></td>'+
				'<td class="text-left"><p class="skills m-0">'+dates+'</p></td>'+
			 '</tr>';
	$("#datesTable").append(tr);
}

function getAvailableDoctors(date){
	selectedDate = date;
	var getAvailableDoctorsURL = baseUrl+"/appointments/getAvailableDoctors";
	$.ajax({
		url:getAvailableDoctorsURL,
		data:{
			date:date,
			epsId:epsId
		},
		success:function(rdata){
			var data = JSON.parse(rdata);
			doctorsArray = data;
			appendDoctors();
		},error:function(){
			console.error("service is unavailable");
		}
	});
}

function appendDoctors(){
	clearStep3(false);
	showPrivateDoctorsDefault();
	doctorsArray.forEach(function(currentValue, index, arr){
		var imageStr = '<img src="'+baseUrl+currentValue.imagePath+'" alt="">';
		var doctorHTML = '<a href="javascript:;" onclick=getAvailableSlots('+currentValue.userId+') class="list-group-item list-group-item-action '+currentValue.privacy+'">'+
			'<div class="list-group-item-figure">'+
				'<div class="user-avatar user-avatar-lg">'+imageStr+'</div>'+
			'</div>'+
			'<div class="list-group-item-body">'+
				'<h4 class="list-group-item-title"> '+currentValue.fullName+' </h4>'+
			'</div>'+
			'<div class="list-group-item-figure">'+
				'<span class="badge badge-success">'+currentValue.privacy+'</span>'+
			'</div>'+
		'</a>';
		$("#availableDoctors").append(doctorHTML);
	});
}

function getDoctor(doctorId){
	var doctor = {};
	for(var i =0;i<doctorsArray.length;i++){
		if(doctorsArray[i].userId == doctorId){
			doctor = doctorsArray[i];
			break;
		}
	}
	return doctor;
}

function showPrivateDoctors(){
	if($("#showPrivateDoctors").is(":checked")){
		$(".Private").removeClass("d-none");
		$("#timeSlots").html("");
		$("#slotLocations").html("");
		selectedSlot = {};
		selectedSlotId = 0;
	}else{
		$(".Private").addClass("d-none");
		$("#timeSlots").html("");
		$("#slotLocations").html("");
		selectedSlot = {};
		selectedSlotId = 0;
	}
}

function showPrivateDoctorsDefault(){
	$("#showPrivateDoctors").prop("checked",true)
}

function getAvailableSlots(doctorId){
	clearSlot();
	var getAvailableSlotsURL = baseUrl+"/appointments/getAvailableSlots";
	selectedDoctorId = doctorId;
	$.ajax({
		url:getAvailableSlotsURL,
		data:{
			doctorId:doctorId,
			selectedDate:selectedDate,
			epsId:epsId
		},
		success:function(rdata){
			var data = JSON.parse(rdata);
			slotArray = data;
			appendSlots();
		},error:function(){
			console.error("service is unavailable");
		}
	});
}

function clearSlot(){
	selectedSlot = {};
	selectedSlotId = 0;
	$("#slotLocations").html("");
}

function appendSlots(){
	$("#timeSlots").html("");
	$("#slotLocations").html("");
	slotArray.forEach(function(currentValue, index, arr){
		$("#timeSlots").append('<a href="javascript:;" onclick=selectSlot('+index+') class="btn btn-xs btn-outline-secondary circle mt-1">'+currentValue.time+'</a>');
	});
}

function selectSlot(index){
	selectedSlot = slotArray[index];
	selectedSlotId = selectedSlot.slotId;
	$("#slotLocations").html("");
	$("#slotLocations").append('<a href="javascript:;" class="btn btn-xs badge badge-subtle badge-dark mt-1">'+selectedSlot.location+'</a>');
}

function addToWaitingList(){
	selectedDate = "";
	selectedDoctorId = 0;
	selectedSlotId = 0;
	confirmAppointment();
}

function confirmAppointment(){
	startLoader("page-section");
	var data = getAppointmentData();
	var bookAppointmentURL = baseUrl+"/appointments/bookAppointment";
	$.ajax({
		url:bookAppointmentURL,
		data:data,
		success:function(rdata){
			var response = JSON.parse(rdata);
			if(response.success){
				if(hasFiles()){
					uploadAppointmentFiles(response.appointmentsId);
				}else{
					bookedMessage(response.success);
				}
			}else{
				$(".error-msg.step-4").removeClass("d-none");
			}
			stopLoader("page-section");
		},error:function(){
			$(".error-msg.step-4").removeClass("d-none");
			console.error("service is unavailable");
			stopLoader("page-section");
		}
	});
}

function getAppointmentData(){
	var data = {};
	data.appointmentsId=appointmentsId;
	data.selectedUserId=selectedUserId;
	data.epsId=epsId;
	data.categoryId=categoryId;
	data.childCategoryId=childCategoryId;
	data.laterality=$("#lateralityValue").val();
	data.selectedDate=selectedDate;
	data.selectedDoctorId=selectedDoctorId;
	data.selectedSlotId=selectedSlotId;
	data.deletedFilesId=$("#deletedFilesId").val();
	return data;
}
function showFileUploader(show){
	if(show){
		$(".custom-file-uploader").removeClass("d-none");
	}else{
		$(".custom-file-uploader").addClass("d-none");
	}
}

function uploadAppointmentFiles(appointmentsId){
	var data = new FormData();
	var fileInput = document.getElementById("appointmentFiles");
	for(var i=0;i<fileInput.files.length;i++){
		data.append("files", fileInput.files[i]);	
	}
	data.append("appointmentsId", appointmentsId);
	var uploadAppointmentFilesURL = baseUrl+'/appointments/uploadAppointmentFiles';
	$.ajax({
        type: "POST",
        enctype: 'multipart/form-data',
        url: uploadAppointmentFilesURL,
        data: data,
        processData: false,
        contentType: false,
        success: function (rdata) {
        	var response = JSON.parse(rdata);
        	bookedMessage(response.success);
        },
        error: function (e) {
			console.log(e.responseText);
        }
    });
}

function hasFiles(){
	if($("#rd1").is(":checked")){
		var fileInput = document.getElementById("appointmentFiles");
		if(fileInput.files.length > 0){
			return true;
		}		
	}
	return false;
}

function bookedMessage(message){
	$("#appointmentBookingMessage").text(message);
	$("#appointmentBooking").modal("show");
}

function deleteFile(aFileId){
	$("#deletedFilesId").val($("#deletedFilesId").val()+","+aFileId);
	$(".appointment-files-"+aFileId).remove();
}

function monthDates(date,ths){
	
}

function initEditAppointment(){
	appointmentsId = parseInt($("#appointmentsId").val());
	if(appointmentsId > 0){
		selectedUserId = parseInt($("#selectedUserId").val());
		emailAddress = $("#selectedUserEmailAddress").val();
		contact = $("#selectedUserContactNo").val();
		userImagePath = $("#selectedUserImagePath").val();
		setUserData();
		
		selectedDate = $("#selectedDate").val();
		epsId = parseInt($("#epsId").val());
		
		categoryId = parseInt($("#categoryId").val());
		var categoryName = $("#categoryName").val();
		categoriesArray = [{"categoryId":categoryId,"name":categoryName}];
		
		childCategoryId = parseInt($("#childCategorySelect").val());
		var childCategoryName = $("#childCategoryName").val();
		totalChildCategories = 1;
		childCategoryArray = [{"categoryId":childCategoryId, "name":childCategoryName}];
		
		selectedDoctorId = $("#selectedDoctorId").val();
		var doctorName = $("#selectedDoctorName").val();
		var doctorPrivacy = $("#selectedDoctorPrivacy").val();
		var doctorImagePath = $("#selectedDoctorImagePath").val();
		doctorsArray = [{"userId":selectedDoctorId,"fullName":doctorName,"privacy":doctorPrivacy,"imagePath":doctorImagePath}];
		
		selectedSlotId = $("#selectedSlotId").val();
		var selectedSlotLocation = $("#selectedSlotLocation").val();
		var selectedSlotTime = $("#selectedSlotTime").val();
		selectedSlot = {"slotId":selectedSlotId,"location":selectedSlotLocation,"time":selectedSlotTime};
		fetchCategoriesEpsConsultant();
		fetchSubCategories(categoryId, epsId);
	}
}