package com.peer.admin.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.peer.admin.constant.AdminConstant;
import com.peer.admin.util.PermissionUtil;
import com.peer.constant.ActionConstant;
import com.peer.constant.CommonConstants;
import com.peer.enm.Status;
import com.peer.enm.UserIdType;
import com.peer.enm.UserType;
import com.peer.scenity.entity.local.Appointments;
import com.peer.scenity.entity.local.Cancellation;
import com.peer.scenity.entity.local.Category;
import com.peer.scenity.entity.local.Eps;
import com.peer.scenity.entity.local.ScheduleSlot;
import com.peer.scenity.entity.local.User;
import com.peer.scenity.entity.pojo.AppointmentDTO;
import com.peer.scenity.entity.pojo.FilesDTO;
import com.peer.scenity.service.constant.ServiceConstant;
import com.peer.scenity.service.intf.IAppointmentFilesService;
import com.peer.scenity.service.intf.IAppointmentsService;
import com.peer.scenity.service.intf.ICancellationService;
import com.peer.scenity.service.intf.IEpsService;
import com.peer.scenity.service.intf.IScheduleSlotService;
import com.peer.scenity.service.intf.ISettingsService;
import com.peer.scenity.service.intf.IUserService;
import com.peer.scenity.service.intf.MessageByLocaleService;
import com.peer.scenity.util.ServiceUtils;
import com.peer.scenity.util.SessionUtil;
import com.peer.util.CommonUtil;
import com.peer.util.DateUtil;
import com.peer.util.DownloadFile;

@Controller
@RequestMapping(AdminConstant.APPOINTMENT_CONTROLLER)
public class AppointmentController {

	public static Logger _log = Logger.getLogger(AppointmentController.class);
	public static final String NEW_APPOINTMENT_PAGE = "appointment/schedule";
	public static final String APPOINTMENT_REQUESTS = "appointment/requests";
	public static final String APPOINTMENTS = "appointment/appointments";
	public static final String APPOINTMENT_VIEW_REQUESTS = "appointment/view-request";
	public static final String APPOINTMENT_VIEW = "appointment/view";
	public static final String WAITLISTS = "appointment/wailists";
	public static final String WAITLISTS_VIEW = "appointment/wailists-view";
	public static final String CANCELLATIONS = "appointment/cancellations";
	public static final String CANCELLATIONS_VIEW = "appointment/cancellation-view";

	@Autowired
	private IEpsService epsService;

	@Autowired
	private IScheduleSlotService scheduleSlotService;

	@Autowired
	private IUserService userService;

	@Autowired
	private IAppointmentsService appointmentService;

	@Autowired
	private IAppointmentFilesService appointmentFilesService;

	@Autowired
	private ICancellationService cancellationService;

	@Autowired
	private ISettingsService settingService;

	@Autowired
	private MessageByLocaleService messageService;

	@RequestMapping(AdminConstant.APPOINTMENT_REQUESTS)
	public String appointmentRequests(Model model, HttpServletRequest request) {
		PermissionUtil.checkPermission(request, ActionConstant.VIEW_APPOINTMENT);
		List<Category> categoryList = appointmentService.findAppointmentCategories(Status.PENDING);
		model.addAttribute("categoryList", categoryList);
		List<Cancellation> cancellationList = cancellationService.findByUserType(UserType.Admin);
		model.addAttribute("cancellationList", cancellationList);
		return APPOINTMENT_REQUESTS;
	}

	@RequestMapping(AdminConstant.GET_APPOINTMENT_REQUESTS)
	@ResponseBody
	public ResponseEntity<Object> getAppointmentRequests(HttpServletRequest request) {
		String draw = request.getParameter("draw");
		int start = CommonUtil.getIntValue(request, "start");
		int max = CommonUtil.getIntValue(request, "length");
		String userName = request.getParameter("userName");
		Long categoryId = CommonUtil.getLongValue(request, "categoryId");
		String date = request.getParameter("appointmentDate");
		if (max <= 0) {
			max = 10;
		}
		Date appointmentDate = StringUtils.isNotBlank(date) ? DateUtil.parseDate(date, DateUtil.YYYY_MM_DD) : null;
		JSONArray jsonArray = appointmentService.findAppointmentsRequests(Status.PENDING, userName, appointmentDate,
				categoryId, start, max);
		Long total = appointmentService.findAppointmentsRequestsCount(Status.PENDING, userName, appointmentDate,
				categoryId);

		JSONObject jsonObject = new JSONObject();
		jsonObject.put("data", jsonArray);
		jsonObject.put("draw", draw);
		jsonObject.put("recordsTotal", total);
		jsonObject.put("recordsFiltered", total);
		return new ResponseEntity<Object>(jsonObject.toString(), HttpStatus.OK);
	}

	@RequestMapping(AdminConstant.APPOINTMENTS)
	public String appointments(HttpServletRequest request, Model model) {
		PermissionUtil.checkPermission(request, ActionConstant.VIEW_APPOINTMENT);
		List<Cancellation> cancellationList = cancellationService.findByUserType(UserType.Admin);
		model.addAttribute("cancellationList", cancellationList);
		return APPOINTMENTS;
	}

	@RequestMapping(AdminConstant.GET_APPOINTMENTS)
	@ResponseBody
	public ResponseEntity<Object> getAppointments(HttpServletRequest request) {
		String draw = request.getParameter("draw");
		int start = CommonUtil.getIntValue(request, "start");
		int max = CommonUtil.getIntValue(request, "length");
		String userName = request.getParameter("userName");
		String date = request.getParameter("appointmentDate");
		int statusCode = CommonUtil.getIntValue(request, "statusCode");
		Status status = null;
		if (statusCode > -1) {
			status = Status.parse(statusCode);
		}
		List<Status> statusList = ServiceUtils.getStatusList(status);
		if (max <= 0) {
			max = 10;
		}
		boolean hasModifyPermission = PermissionUtil.hasPermission(request, ActionConstant.MODIFY_APPOINTMENTS);
		Date appointmentDate = StringUtils.isNotBlank(date) ? DateUtil.parseDate(date, DateUtil.YYYY_MM_DD) : null;
		JSONArray jsonArray = appointmentService.findAppointments(statusList, userName, appointmentDate, 0L, start, max,
				hasModifyPermission);
		Long total = appointmentService.findAppointmentsCount(statusList, userName, appointmentDate, 0L);

		JSONObject jsonObject = new JSONObject();
		jsonObject.put("data", jsonArray);
		jsonObject.put("draw", draw);
		jsonObject.put("recordsTotal", total);
		jsonObject.put("recordsFiltered", total);
		return new ResponseEntity<Object>(jsonObject.toString(), HttpStatus.OK);
	}

	@RequestMapping(AdminConstant.VIEW_REQUESTS)
	public String viewRequest(HttpServletRequest request, Model model) {
		PermissionUtil.checkPermission(request, ActionConstant.VIEW_APPOINTMENT);
		Long appointmentsId = CommonUtil.getLongValue(request, "appointmentsId");
		String userName = request.getParameter("userName");
		Long categoryId = CommonUtil.getLongValue(request, "categoryId");
		String date = request.getParameter("appointmentDate");
		Date appointmentDate = StringUtils.isNotBlank(date) ? DateUtil.parseDate(date, DateUtil.YYYY_MM_DD) : null;

		Appointments appointments = null;
		List<Appointments> appointmentRequests = appointmentService.findAppointmentsRequestsAll(Status.PENDING,
				userName, appointmentDate, categoryId, 0, -1);
		int appointmentRequestsLength = appointmentRequests.size();
		Long previousAppointmentId = 0L;
		Long nextAppointmentId = 0L;
		for (int i = 0; i < appointmentRequestsLength; i++) {
			Appointments appointments2 = appointmentRequests.get(i);
			if (appointments2.getAppointmentsId().equals(appointmentsId)) {
				appointments = appointments2;
				if (i > 0) {
					previousAppointmentId = appointmentRequests.get(i - 1).getAppointmentsId();
				}
				if ((i + 1) < appointmentRequestsLength) {
					nextAppointmentId = appointmentRequests.get(i + 1).getAppointmentsId();
				}
			}
		}

		if (null != appointments) {
			AppointmentDTO appointmentObject = appointmentService.getAppointmentDTO(appointments);
			List<FilesDTO> appointmentFiles = appointmentFilesService
					.getAppointmentFiles(appointments.getAppointmentsId());
			List<Cancellation> cancellationList = cancellationService.findByUserType(UserType.Admin);
			model.addAttribute("appointments", appointments);
			model.addAttribute("appointmentObject", appointmentObject);
			model.addAttribute("appointmentFiles", appointmentFiles);
			model.addAttribute("cancellationList", cancellationList);
			model.addAttribute("previousAppointmentId", previousAppointmentId);
			model.addAttribute("nextAppointmentId", nextAppointmentId);
			model.addAttribute("userName", userName);
			model.addAttribute("appointmentDate", date);
			model.addAttribute("categoryId", categoryId);
		}
		return APPOINTMENT_VIEW_REQUESTS;
	}

	@RequestMapping(AdminConstant.VIEW_APPOINTMENT)
	public String viewAppointment(HttpServletRequest request, Model model) {
		PermissionUtil.checkPermission(request, ActionConstant.VIEW_APPOINTMENT);
		Long appointmentsId = CommonUtil.getLongValue(request, "appointmentsId");
		String userName = request.getParameter("userName");
		String date = request.getParameter("appointmentDate");
		int statusCode = CommonUtil.getIntValue(request, "statusCode");
		Date appointmentDate = StringUtils.isNotBlank(date) ? DateUtil.parseDate(date, DateUtil.YYYY_MM_DD) : null;
		Status status = null;
		if (statusCode > -1) {
			status = Status.parse(statusCode);
		}
		List<Status> statusList = ServiceUtils.getStatusList(status);
		Appointments appointments = null;
		List<Appointments> appointmentRequests = appointmentService.findAppointmentsAll(statusList, userName,
				appointmentDate, 0L, 0, -1);
		int appointmentRequestsLength = appointmentRequests.size();
		Long previousAppointmentId = 0L;
		Long nextAppointmentId = 0L;
		for (int i = 0; i < appointmentRequestsLength; i++) {
			Appointments appointments2 = appointmentRequests.get(i);
			if (appointments2.getAppointmentsId().equals(appointmentsId)) {
				appointments = appointments2;
				if (i > 0) {
					previousAppointmentId = appointmentRequests.get(i - 1).getAppointmentsId();
				}
				if ((i + 1) < appointmentRequestsLength) {
					nextAppointmentId = appointmentRequests.get(i + 1).getAppointmentsId();
				}
			}
		}

		if (null != appointments) {
			AppointmentDTO appointmentObject = appointmentService.getAppointmentDTO(appointments);
			List<FilesDTO> appointmentFiles = appointmentFilesService
					.getAppointmentFiles(appointments.getAppointmentsId());
			List<Cancellation> cancellationList = cancellationService.findByUserType(UserType.Admin);
			model.addAttribute("appointments", appointments);
			model.addAttribute("appointmentObject", appointmentObject);
			model.addAttribute("appointmentFiles", appointmentFiles);
			model.addAttribute("cancellationList", cancellationList);
			model.addAttribute("previousAppointmentId", previousAppointmentId);
			model.addAttribute("nextAppointmentId", nextAppointmentId);
			model.addAttribute("userName", userName);
			model.addAttribute("appointmentDate", date);
			model.addAttribute("statusCode", statusCode);
			model.addAttribute("appointmentStatus", ServiceUtils.getStatus(appointments.getStatus().getStatusCode()));
			model.addAttribute("placedOn",
					DateUtil.formateDate(appointments.getCreatedOn(), DateUtil.DD_MMM_YYYY_AM_PM));
			String cancelledDate = "";
			boolean cancellable = false;
			boolean cancelled = false;
			if (Status.CANCELLED.equals(appointments.getStatus())) {
				cancelled = true;
				cancelledDate = DateUtil.formateDate(appointments.getUpdatedOn(), DateUtil.DD_MMM_YYYY_AM_PM);
			} else if (PermissionUtil.hasPermission(request, ActionConstant.CANCEL_APPOINTMENT)) {
				cancellable = settingService.isAppointmentCancellable(appointments.getAppointmentDate(),
						appointments.getAppointmentTime(), appointments.getMedian());
			}
			model.addAttribute("cancelled", cancelled);
			model.addAttribute("cancellable", cancellable);
			model.addAttribute("cancelledDate", cancelledDate);
		}
		return APPOINTMENT_VIEW;
	}

	@RequestMapping("/waitlists")
	public String waitlists(HttpServletRequest request, Model model) {
		PermissionUtil.checkPermission(request, ActionConstant.VIEW_WAITLISTS);
		List<Category> categoryList = appointmentService.findAppointmentCategories(Status.WAITING);
		model.addAttribute("categoryList", categoryList);
		return WAITLISTS;
	}

	@RequestMapping("/getWaitlists")
	@ResponseBody
	public ResponseEntity<Object> getWaitlists(HttpServletRequest request) {
		String draw = request.getParameter("draw");
		int start = CommonUtil.getIntValue(request, "start");
		int max = CommonUtil.getIntValue(request, "length");
		String userName = request.getParameter("userName");
		String waitlistType = request.getParameter("waitlistType");
		Long categoryId = CommonUtil.getLongValue(request, "categoryId");
		Long userId = CommonUtil.getLongValue(request, "userId");

		List<Status> statusList = ServiceUtils.getStatusList(Status.WAITING);
		if (max <= 0) {
			max = 10;
		}
		JSONArray jsonArray = appointmentService.findWaitlists(userId, statusList, userName, categoryId, waitlistType,
				start, max);
		Long total = appointmentService.findWaitlistsCount(userId, statusList, userName, categoryId, waitlistType);
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("data", jsonArray);
		jsonObject.put("draw", draw);
		jsonObject.put("recordsTotal", total);
		jsonObject.put("recordsFiltered", total);
		return new ResponseEntity<Object>(jsonObject.toString(), HttpStatus.OK);
	}

	@RequestMapping("/waitlists/view")
	public String waitlistsView(HttpServletRequest request, Model model) {
		PermissionUtil.checkPermission(request, ActionConstant.VIEW_WAITLISTS);
		Long appointmentsId = CommonUtil.getLongValue(request, "appointmentsId");
		String userName = request.getParameter("userName");
		String waitlistType = request.getParameter("waitlistType");
		Long categoryId = CommonUtil.getLongValue(request, "categoryId");

		List<Status> statusList = ServiceUtils.getStatusList(Status.WAITING);
		Appointments appointments = null;
		List<Appointments> appointmentRequests = appointmentService.findWaitlistsAll(0L, statusList, userName,
				categoryId, waitlistType, 0, -1);
		int appointmentRequestsLength = appointmentRequests.size();
		Long previousAppointmentId = 0L;
		Long nextAppointmentId = 0L;
		for (int i = 0; i < appointmentRequestsLength; i++) {
			Appointments appointments2 = appointmentRequests.get(i);
			if (appointments2.getAppointmentsId().equals(appointmentsId)) {
				appointments = appointments2;
				if (i > 0) {
					previousAppointmentId = appointmentRequests.get(i - 1).getAppointmentsId();
				}
				if ((i + 1) < appointmentRequestsLength) {
					nextAppointmentId = appointmentRequests.get(i + 1).getAppointmentsId();
				}
			}
		}

		if (null != appointments) {
			AppointmentDTO appointmentObject = appointmentService.getAppointmentDTO(appointments);
			List<FilesDTO> appointmentFiles = appointmentFilesService
					.getAppointmentFiles(appointments.getAppointmentsId());
			model.addAttribute("appointments", appointments);
			model.addAttribute("appointmentObject", appointmentObject);
			model.addAttribute("appointmentFiles", appointmentFiles);
			model.addAttribute("previousAppointmentId", previousAppointmentId);
			model.addAttribute("nextAppointmentId", nextAppointmentId);
			model.addAttribute("userName", userName);
			model.addAttribute("waitlistType", waitlistType);
			model.addAttribute("categoryId", categoryId);
			model.addAttribute("expired", DateUtil.isWaitlistsExpired(appointments.getCreatedOn()));
			model.addAttribute("placedOn",
					DateUtil.formateDate(appointments.getCreatedOn(), DateUtil.DD_MMM_YYYY_AM_PM));
		}
		return WAITLISTS_VIEW;
	}

	@RequestMapping("/cancellations")
	public String cancellationRequests(HttpServletRequest request, Model model) {
		PermissionUtil.checkPermission(request, ActionConstant.VIEW_APPOINTMENT_CANCELLATIONS);
		List<Category> categoryList = appointmentService
				.findAppointmentCategories(Status.AWAITING_CANCELLATION_APPROVAL);
		List<Cancellation> cancellationList = cancellationService.findByUserType(UserType.Admin);
		model.addAttribute("categoryList", categoryList);
		model.addAttribute("cancellationList", cancellationList);
		return CANCELLATIONS;
	}

	@RequestMapping("/getCancellationRequests")
	@ResponseBody
	public ResponseEntity<Object> getCancellationRequests(HttpServletRequest request) {
		String draw = request.getParameter("draw");
		int start = CommonUtil.getIntValue(request, "start");
		int max = CommonUtil.getIntValue(request, "length");
		String userName = request.getParameter("userName");
		Long categoryId = CommonUtil.getLongValue(request, "categoryId");
		String date = request.getParameter("appointmentDate");
		if (max <= 0) {
			max = 10;
		}
		Date appointmentDate = StringUtils.isNotBlank(date) ? DateUtil.parseDate(date, DateUtil.YYYY_MM_DD) : null;
		boolean hasModifyPermission = PermissionUtil.hasPermission(request, ActionConstant.CANCEL_APPOINTMENT);
		JSONArray jsonArray = appointmentService.findAppointmentCancellationRequests(
				Status.AWAITING_CANCELLATION_APPROVAL, userName, appointmentDate, categoryId, start, max,
				hasModifyPermission);
		Long total = appointmentService.findAppointmentsRequestsCount(Status.AWAITING_CANCELLATION_APPROVAL, userName,
				appointmentDate, categoryId);

		JSONObject jsonObject = new JSONObject();
		jsonObject.put("data", jsonArray);
		jsonObject.put("draw", draw);
		jsonObject.put("recordsTotal", total);
		jsonObject.put("recordsFiltered", total);
		return new ResponseEntity<Object>(jsonObject.toString(), HttpStatus.OK);
	}

	@RequestMapping("/cancellations/view")
	public String cancellationView(HttpServletRequest request, Model model) {
		PermissionUtil.checkPermission(request, ActionConstant.VIEW_APPOINTMENT_CANCELLATIONS);
		Long appointmentsId = CommonUtil.getLongValue(request, "appointmentsId");
		String userName = request.getParameter("userName");
		Long categoryId = CommonUtil.getLongValue(request, "categoryId");
		String date = request.getParameter("appointmentDate");
		Date appointmentDate = StringUtils.isNotBlank(date) ? DateUtil.parseDate(date, DateUtil.YYYY_MM_DD) : null;

		Appointments appointments = null;
		List<Appointments> appointmentRequests = appointmentService.findAppointmentsRequestsAll(
				Status.AWAITING_CANCELLATION_APPROVAL, userName, appointmentDate, categoryId, 0, -1);
		int appointmentRequestsLength = appointmentRequests.size();
		Long previousAppointmentId = 0L;
		Long nextAppointmentId = 0L;
		for (int i = 0; i < appointmentRequestsLength; i++) {
			Appointments appointments2 = appointmentRequests.get(i);
			if (appointments2.getAppointmentsId().equals(appointmentsId)) {
				appointments = appointments2;
				if (i > 0) {
					previousAppointmentId = appointmentRequests.get(i - 1).getAppointmentsId();
				}
				if ((i + 1) < appointmentRequestsLength) {
					nextAppointmentId = appointmentRequests.get(i + 1).getAppointmentsId();
				}
			}
		}

		if (null != appointments) {
			AppointmentDTO appointmentObject = appointmentService.getAppointmentDTO(appointments);
			List<FilesDTO> appointmentFiles = appointmentFilesService
					.getAppointmentFiles(appointments.getAppointmentsId());
			List<Cancellation> cancellationList = cancellationService.findByUserType(UserType.Admin);
			model.addAttribute("appointments", appointments);
			model.addAttribute("appointmentObject", appointmentObject);
			model.addAttribute("appointmentFiles", appointmentFiles);
			model.addAttribute("cancellationList", cancellationList);
			model.addAttribute("previousAppointmentId", previousAppointmentId);
			model.addAttribute("nextAppointmentId", nextAppointmentId);
			model.addAttribute("userName", userName);
			model.addAttribute("appointmentDate", date);
			model.addAttribute("categoryId", categoryId);
			model.addAttribute("cancellationDate",
					DateUtil.formateDate(appointments.getUpdatedOn(), DateUtil.DD_MMM_YYYY_AM_PM));
			model.addAttribute("placedOn",
					DateUtil.formateDate(appointments.getCreatedOn(), DateUtil.DD_MMM_YYYY_AM_PM));
		}
		return CANCELLATIONS_VIEW;
	}

	@RequestMapping(AdminConstant.ACCEPT_REQUESTS)
	public String acceptRequest(HttpServletRequest request, Model model, RedirectAttributes redirectAttributes) {
		PermissionUtil.checkPermission(request, ActionConstant.MODIFY_APPOINTMENTS);
		User currentUser = SessionUtil.getUserFromRequestSession(request);
		Long appointmentsId = CommonUtil.getLongValue(request, "appointmentsId");
		try {
			appointmentService.acceptRequest(currentUser, appointmentsId);
			Appointments appointments = appointmentService.findByIdLocal(appointmentsId);
			ServiceUtils.sendSMS(appointments, ServiceConstant.APPT_BOOKING);
			redirectAttributes.addFlashAttribute("success", CommonConstants.SUCCESS);
		} catch (Exception e) {
			_log.error("", e);
			redirectAttributes.addFlashAttribute("error", CommonConstants.ERROR);
		}
		return "redirect:" + AdminConstant.APPOINTMENT_CONTROLLER + AdminConstant.APPOINTMENT_REQUESTS;
	}

	@RequestMapping(AdminConstant.REJECT_REQUESTS)
	public String rejectRequest(HttpServletRequest request, Model model, RedirectAttributes redirectAttributes) {
		PermissionUtil.checkPermission(request, ActionConstant.MODIFY_APPOINTMENTS);
		boolean isCancellable = true;
		User currentUser = SessionUtil.getUserFromRequestSession(request);
		String currentPage = request.getParameter("currentPage");
		Long appointmentsId = CommonUtil.getLongValue(request, "appointmentsId");
		int statusCode = CommonUtil.getIntValue(request, "status");
		String reason = request.getParameter("cancellationReason");
		if (StringUtils.isNotBlank(reason) && "-1".equals(reason)) {
			reason = request.getParameter("customReason");
		}
		try {
			Status status = Status.parse(statusCode);
			if (Status.CANCELLED.equals(status)) {
				Appointments appointments = appointmentService.findByIdLocal(appointmentsId);
				isCancellable = settingService.isAppointmentCancellable(appointments.getAppointmentDate(),
						appointments.getAppointmentTime(), appointments.getMedian());
			}
			if (isCancellable) {
				Appointments appointments = appointmentService.findByIdLocal(appointmentsId);
				appointmentService.rejectRequest(currentUser, appointmentsId, reason, status);
				ServiceUtils.sendSMS(appointments, ServiceConstant.APPT_CANCELLATION);
				redirectAttributes.addFlashAttribute("success", CommonConstants.SUCCESS);
			} else {
				redirectAttributes.addFlashAttribute("message",
						messageService.getMessage(CommonConstants.CANCELLATION_TIME_ERROR));
			}
		} catch (Exception e) {
			_log.error("", e);
			redirectAttributes.addFlashAttribute("error", CommonConstants.ERROR);
		}
		if ("appointment-list".equals(currentPage)) {
			return "redirect:" + AdminConstant.APPOINTMENT_CONTROLLER + AdminConstant.APPOINTMENTS;
		}
		if ("cancellations".equals(currentPage)) {
			return "redirect:" + AdminConstant.APPOINTMENT_CONTROLLER + "/cancellations";
		}
		return "redirect:" + AdminConstant.APPOINTMENT_CONTROLLER + AdminConstant.APPOINTMENT_REQUESTS;
	}

	@RequestMapping(AdminConstant.SCHEDULE_APPOINTMENT)
	public String scheduleAppointment(HttpServletRequest request, Model model) {
		PermissionUtil.checkPermission(request, ActionConstant.CREATE_NEW_APPOINTMENT);
		List<Eps> epsList = epsService.findAllLocal();
		model.addAttribute("epsList", epsList);
		model.addAttribute("userIdTypes", UserIdType.values());
		return NEW_APPOINTMENT_PAGE;
	}

	@RequestMapping(AdminConstant.RE_SCHEDULE_APPOINTMENT)
	public String reScheduleAppointment(HttpServletRequest request, Model model) {
		PermissionUtil.checkPermission(request, ActionConstant.MODIFY_APPOINTMENTS);
		Long appointmentsId = CommonUtil.getLongValue(request, "appointmentsId");
		List<Eps> epsList = epsService.findAllLocal();
		Appointments appointments = appointmentService.findByIdLocal(appointmentsId);
		if (null != appointments) {
			AppointmentDTO appointmentObject = appointmentService.getAppointmentDTO(appointments);
			List<FilesDTO> appointmentFiles = appointmentFilesService.getAppointmentFiles(appointmentsId);
			model.addAttribute("appointments", appointments);
			model.addAttribute("appointmentObject", appointmentObject);
			model.addAttribute("appointmentFiles", appointmentFiles);
		}
		model.addAttribute("epsList", epsList);
		model.addAttribute("userIdTypes", UserIdType.values());
		return NEW_APPOINTMENT_PAGE;
	}

	@RequestMapping(AdminConstant.AVAILABLE_DATES_IN_MONTH)
	@ResponseBody
	public ResponseEntity<Object> getAvailableDatesInMonth(HttpServletRequest request) {
		JSONObject jsonObject = scheduleSlotService.getAvailableDatesInMonth(request);
		return new ResponseEntity<Object>(jsonObject.toString(), HttpStatus.OK);
	}

	@RequestMapping(AdminConstant.AVAILABLE_DOCTORS)
	@ResponseBody
	public ResponseEntity<Object> getAvailableDoctors(HttpServletRequest request) {
		JSONArray availableDoctors = scheduleSlotService.getAvailableDoctorsOnDate(request,
				ServiceUtils.getPrivacyList(true));
		return new ResponseEntity<Object>(availableDoctors.toString(), HttpStatus.OK);
	}

	@RequestMapping(AdminConstant.AVAILABLE_SLOTS)
	@ResponseBody
	public ResponseEntity<Object> getAvailableSlots(HttpServletRequest request) {
		JSONArray availableSlots = scheduleSlotService.getAvailableSlots(request);
		return new ResponseEntity<Object>(availableSlots.toString(), HttpStatus.OK);
	}

	@RequestMapping(AdminConstant.VALIDATE_USER)
	@ResponseBody
	public ResponseEntity<Object> validateUser(HttpServletRequest request) {
		String idType = request.getParameter("idType");
		String idNumber = request.getParameter("idNumber");
		JSONObject userObject = userService.getZeusUser(request, idType, idNumber);
		return new ResponseEntity<Object>(userObject.toString(), HttpStatus.OK);
	}

	@RequestMapping(AdminConstant.BOOK_APPOINTMENT)
	@ResponseBody
	public ResponseEntity<Object> bookAppointment(HttpServletRequest request) {
		PermissionUtil.checkPermission(request, ActionConstant.CREATE_NEW_APPOINTMENT);
		JSONObject userObject = appointmentService.createAppointment(request);
		return new ResponseEntity<Object>(userObject.toString(), HttpStatus.OK);
	}

	@RequestMapping(AdminConstant.UPLOAD_APPOINTMENT_FILES)
	@ResponseBody
	public ResponseEntity<Object> uploadAppointmentFiles(@RequestParam("files") MultipartFile[] filesArray,
			HttpServletRequest request) {
		Long appointmentsId = CommonUtil.getLongValue(request, "appointmentsId");
		JSONObject jsonObject = appointmentFilesService.addAppointmentFiles(request, filesArray, appointmentsId);
		return new ResponseEntity<Object>(jsonObject.toString(), HttpStatus.OK);
	}

	@RequestMapping(value = AdminConstant.EXPORT_APPOINTMENT, method = RequestMethod.POST)
	public void exportAppointment(Model model, HttpServletRequest request, HttpServletResponse response,
			@ModelAttribute("doctor") User doctor) throws IOException {

		List<Appointments> appoinmentData = appointmentService.findGetAll();
		net.sf.json.JSONObject jsonObject = new net.sf.json.JSONObject();
		net.sf.json.JSONObject jsonColumn = new net.sf.json.JSONObject();
		net.sf.json.JSONArray columnArray = new net.sf.json.JSONArray();
		List<String> colList = new ArrayList<String>(0);
		colList.add("User");
		colList.add("Doctor");
		colList.add("Appointment Date");
		colList.add("Time Slot");
		colList.add("Location");
		colList.add("Status");
		for (int i = 0; i < colList.size(); i++) {
			net.sf.json.JSONObject jsonColData = new net.sf.json.JSONObject();
			jsonColData.put("key", colList.get(i));
			columnArray.add(jsonColData);
		}
		jsonColumn.put("col_data", columnArray);
		net.sf.json.JSONObject jsonObjData = new net.sf.json.JSONObject();
		net.sf.json.JSONArray rowArray = new net.sf.json.JSONArray();
		for (Appointments appoinment : appoinmentData) {
			net.sf.json.JSONObject cellCol = new net.sf.json.JSONObject();
			net.sf.json.JSONArray cell = new net.sf.json.JSONArray();
			for (String colName : colList) {
				switch (colName) {
				case "User":
					net.sf.json.JSONObject jsonRowData = new net.sf.json.JSONObject();
					jsonRowData.put("key", colName);
					User user = appoinment.getUser();
					jsonRowData.put("value", user.getFullName());
					cell.add(jsonRowData);
					break;
				case "Doctor":
					net.sf.json.JSONObject jsonRowDatas = new net.sf.json.JSONObject();
					jsonRowDatas.put("key", colName);
					User users = appoinment.getDoctor();
					if (users != null) {
						jsonRowDatas.put("value", users.getFullName());
					} else {
						jsonRowDatas.put("value", "");
					}
					cell.add(jsonRowDatas);
					break;
				case "Appointment Date":
					net.sf.json.JSONObject jsonRowData1 = new net.sf.json.JSONObject();
					jsonRowData1.put("key", colName);
					if (null != appoinment.getAppointmentDate()) {
						jsonRowData1.put("value", DateUtil.getFormatterDate(appoinment.getAppointmentDate()));
					} else {
						jsonRowData1.put("value", "");
					}
					cell.add(jsonRowData1);
					break;
				case "Time Slot":
					net.sf.json.JSONObject jsonRowData2 = new net.sf.json.JSONObject();
					jsonRowData2.put("key", colName);
					ScheduleSlot slot = appoinment.getSlot();
					if (null != slot) {
						String timeSlot = DateUtil.concatDate(slot.getStartDate(), slot.getEndDate(),
								DateUtil.HH_MM_AM_PM);
						jsonRowData2.put("value", timeSlot);
					} else {
						jsonRowData2.put("value", "");
					}
					cell.add(jsonRowData2);
					break;
				case "Location":
					net.sf.json.JSONObject jsonRowData3 = new net.sf.json.JSONObject();
					jsonRowData3.put("key", colName);
					if (null != appoinment.getLocation()) {
						jsonRowData3.put("value", appoinment.getLocation().getLocation());
					} else {
						jsonRowData3.put("value", "");
					}
					cell.add(jsonRowData3);
					break;
				case "Status":
					net.sf.json.JSONObject jsonRowData4 = new net.sf.json.JSONObject();
					jsonRowData4.put("key", colName);
					jsonRowData4.put("value", ServiceUtils.getStatus(appoinment.getStatus().getStatusCode()));
					cell.add(jsonRowData4);
					break;
				default:
					break;
				}
				cellCol.put("cell", cell);
			}
			rowArray.add(cellCol);
			jsonObjData.put("row", rowArray);
		}
		jsonObject.put("col", jsonColumn);
		jsonObject.put("data", jsonObjData);

		DownloadFile.downloadFile(AdminConstant.APPOINTMENT_FILENAME, AdminConstant.EXPORT_EXTENSION, jsonObject,
				request, response);
	}
}
