package com.peer.admin.validate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.peer.scenity.entity.local.Eps;
import com.peer.scenity.service.constant.ServiceConstant;
import com.peer.scenity.service.intf.MessageByLocaleService;

@Component
public class EpsValidator implements Validator {

	@Autowired
	private MessageByLocaleService messageByLocaleService;
	
	@Override
	public boolean supports(Class<?> clazz) {
		return Eps.class.isAssignableFrom(clazz);
	}

	@Override
	public void validate(Object target, Errors errors) {
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "eps", "error.field.empty",messageByLocaleService.getMessage(ServiceConstant.EPS));
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "epsInSpanish", "error.field.empty",messageByLocaleService.getMessage(ServiceConstant.EPSINSPANISH));
		
	}

}
