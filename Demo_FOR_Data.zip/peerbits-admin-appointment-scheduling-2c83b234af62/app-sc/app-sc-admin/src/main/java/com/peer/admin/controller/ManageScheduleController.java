package com.peer.admin.controller;

import java.io.IOException;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.peer.admin.constant.AdminConstant;
import com.peer.constant.CommonConstants;
import com.peer.enm.Action;
import com.peer.enm.Status;
import com.peer.scenity.entity.local.Appointments;
import com.peer.scenity.entity.local.Schedule;
import com.peer.scenity.entity.local.ScheduleSlot;
import com.peer.scenity.entity.local.User;
import com.peer.scenity.entity.pojo.Response;
import com.peer.scenity.entity.pojo.ScheduleDTO;
import com.peer.scenity.entity.zeus.ProgramacionMedico;
import com.peer.scenity.service.intf.IAppointmentsService;
import com.peer.scenity.service.intf.ICancellationService;
import com.peer.scenity.service.intf.IEpsService;
import com.peer.scenity.service.intf.IFilesService;
import com.peer.scenity.service.intf.IScheduleService;
import com.peer.scenity.service.intf.IScheduleSlotService;
import com.peer.scenity.service.intf.MessageByLocaleService;
import com.peer.scenity.service.intf.ProgrammacionMedicoDetalleService;
import com.peer.scenity.service.intf.ZeusProgrammacionMedicoService;
import com.peer.scenity.util.ServiceUtils;
import com.peer.scenity.util.SessionUtil;
import com.peer.util.DownloadFile;

@Controller
@RequestMapping(AdminConstant.MANAGE_SCHEDULE_CONTROLLER)
public class ManageScheduleController {

	public static Logger _log = Logger.getLogger(ManageScheduleController.class);
	public static final String MANAGE_SCHEDULE_PAGE = "manage-schedule/viewall";
	public static final String VIEW_SCHEDULE_PAGE = "manage-schedule/view";

	@Autowired
	private IScheduleService scheduleService;

	@Autowired
	private IScheduleSlotService scheduleSlotService;

	@Autowired
	private IEpsService epsService;

	@Autowired
	private ICancellationService cancellationService;

	@Autowired
	private MessageByLocaleService messageByLocaleService;

	@Autowired
	private ZeusProgrammacionMedicoService programmacionService;

	@Autowired
	private IAppointmentsService appointmentService;

	@Autowired
	private IFilesService fileService;

	@Autowired
	private ProgrammacionMedicoDetalleService programmacionMedicoDetalleService;

	@RequestMapping(AdminConstant.VIEW_ALL_SCHEDULE)
	public String viewAllSchedule(Model model) {
		_log.info("Inside landing manage schedule");
		return MANAGE_SCHEDULE_PAGE;
	}

	@RequestMapping(AdminConstant.VIEW_SCHEDULE)
	public String viewSelectedSchedule(Model model, @ModelAttribute("schedule") Schedule schedule,
			HttpServletRequest request) {
		User user = SessionUtil.getUserFromRequestSession(request);
		Schedule schedule2 = scheduleService.findByIdLocal(schedule.getScheduleId());
		ScheduleDTO dto = scheduleService.convertScheduleToScheduleDTO(schedule2);
		model.addAttribute("selectedSchedule", dto);
		List<Schedule> lst = scheduleService.getRequiredSchedules(schedule2.getStartDate(), -1, 0, 0,schedule2.getScheduleId());
		if(lst.size()>0){
			for(Schedule sc:lst){
				Long count=appointmentService.findScheduleAppointmentCount(Status.APPROVED, sc.getScheduleId());
				sc.setCount(count);
			}
		}
		String profileImagePath = fileService.getFilePath(user.getProfileImg());
		model.addAttribute("profileImagePath", profileImagePath);
		model.addAttribute("schedulelist", lst);
		return VIEW_SCHEDULE_PAGE;
	}

	@RequestMapping("/fetchSchedules")
	@ResponseBody
	public ResponseEntity<Object> getAppointmentSchedules(HttpServletRequest request,
			@ModelAttribute("schedule") Schedule schedule) {
		String start = request.getParameter("start");
		String length = request.getParameter("length");
		String draw = request.getParameter("draw");
		String scheduleStatus = request.getParameter("schStatus");

		String scheduleDateStr = request.getParameter("schDate");
		Date scheduleDate = null;
		if (StringUtils.isNotBlank(scheduleDateStr)) {
			scheduleDate = Date.from(LocalDate.parse(scheduleDateStr, CommonConstants.FORMATTER).atStartOfDay()
					.atZone(ZoneId.systemDefault()).toInstant());
		}
		int status = -1;
		int startI = 0;
		int lengthI = 10;
		if (StringUtils.isNotEmpty(scheduleStatus) && StringUtils.isNumeric(scheduleStatus)) {
			status = Integer.parseInt(scheduleStatus);
		}
		if (StringUtils.isNotBlank(start) && StringUtils.isNumeric(start)) {
			startI = Integer.parseInt(start);
		}
		if (StringUtils.isNotBlank(length) && StringUtils.isNumeric(length)) {
			lengthI = Integer.parseInt(length);
		}
		List<Schedule> listSchedule = scheduleService.getRequiredSchedules(scheduleDate, status, startI, lengthI,
				CommonConstants.ZERO);
		List<Schedule> listSchedules = scheduleService.getRequiredSchedules(scheduleDate, status, 0, 0,
				CommonConstants.ZERO);
		JSONArray jsonArray = scheduleService.getArrayFromListWithAdminActionBtns(listSchedule);
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("data", jsonArray);
		jsonObject.put("draw", draw);
		jsonObject.put("recordsTotal", listSchedules.size());
		jsonObject.put("recordsFiltered", listSchedules.size());
		return new ResponseEntity<>(jsonObject.toString(), HttpStatus.OK);
	}

	@RequestMapping(AdminConstant.MANAGE_SCHEDULE_GET_ACTIVE_EPS)
	@ResponseBody
	public ResponseEntity<Object> getActiveEPS(HttpServletRequest request) {
		return new ResponseEntity<>(epsService.findAllLocalActiveJSON().toString(), HttpStatus.OK);
	}

	@RequestMapping(AdminConstant.MANAGE_SCHEDULE_GET_CANCELLATION_REASONS)
	@ResponseBody
	public ResponseEntity<Object> getCancellationREasons(HttpServletRequest request) {
		return new ResponseEntity<>(cancellationService.findAllLocalActiveJSON().toString(), HttpStatus.OK);
	}

	@RequestMapping(AdminConstant.MANAGE_SCHEDULE_CANCEL_ACTION)
	public String cancelActiveSchedule(HttpServletRequest request, RedirectAttributes redirectAttributes) {
		Response response = null;
		long cancelScheduleId = Long.parseLong(request.getParameter("scheduleId"));
		String cancelReason = request.getParameter("cancelReasonModal");
		try {
			if (cancelReason.equalsIgnoreCase("other")) {
				cancelReason = request.getParameter("otherReasonText");
			}
			Schedule schedule = scheduleService.findByIdLocal(cancelScheduleId);
			schedule.setCancelReason(cancelReason);
			schedule.setStatus(Status.CANCELLED);
			schedule.setUpdatedBy(SessionUtil.getUserFromRequestSession(request));
			schedule.setUpdatedOn(new Date());
			schedule = scheduleService.mergeLocal(schedule);
			inactiveSlots(cancelScheduleId);
			ProgramacionMedico zeusSchedule = programmacionService.findByIdZeus(schedule.getZeusScheduleId());
			zeusSchedule.setActivo(false);
			moveAllAppointmentstoWaitlist(schedule.getScheduleId());
			programmacionMedicoDetalleService.deleteDetalle(schedule.getZeusScheduleId());
			response = setMessage(CommonConstants.SUCCESS, AdminConstant.SCHEDULE_CANCEL_SUCCESS);
			redirectAttributes.addFlashAttribute(response.getStatus(), response.getMessage());
			scheduleService.sendNotification(schedule, Action.CANCELLED);
		} catch (Exception e) {
			response = setMessage(CommonConstants.ERROR, AdminConstant.SCHEUDULE_MODIFY_ERROR);
		}
		return "redirect:" + AdminConstant.MANAGE_SCHEDULE_CONTROLLER + AdminConstant.VIEW_ALL_SCHEDULE;
	}

	@RequestMapping(AdminConstant.MANAGE_SCHEDULE_APPROVE_ACTION)
	public String modifyActiveSchedule(HttpServletRequest request, RedirectAttributes redirectAttributes) {
		Response response = null;
		long scheduleId = Long.parseLong(request.getParameter("scheduleId"));
		String docStimeModal = request.getParameter("startTime");
		String docEtimeModal = request.getParameter("endTime");
		long epsId = Long.parseLong(request.getParameter("epsId"));
		long maxAppts = Long.parseLong(request.getParameter("maxAppointments"));
		Schedule schedule = scheduleService.findByIdLocal(scheduleId);
		schedule.setStartTime(docStimeModal);
		schedule.setEndTime(docEtimeModal);
		schedule.setMaxAppointments(maxAppts);
		schedule.setEps(epsService.findByIdLocal(epsId));
		Response responseValidate = scheduleSlotService.scheduleValidator(schedule);
		if (responseValidate.getStatus().equals(CommonConstants.ERROR)) {
			response = responseValidate;
		} else {
			try {
				if (appointmentService.findScheduleAppointmentCount(Status.APPROVED, schedule.getScheduleId()) > 0) {
					moveAllAppointmentstoWaitlist(schedule.getScheduleId());
				}
				programmacionMedicoDetalleService.deleteDetalle(schedule.getZeusScheduleId());
				scheduleSlotService.deleteAllSlotsFromDB(schedule.getScheduleId());
				response=scheduleSlotService.addScheduleSlots(schedule, schedule.getZeusScheduleId());
				if (response.getStatus().equals(CommonConstants.SUCCESS)) {
					scheduleSlotService.updateZeus(schedule);
					schedule.setUpdatedBy(SessionUtil.getUserFromRequestSession(request));
					schedule.setUpdatedOn(new Date());
					schedule = scheduleService.mergeLocal(schedule);
					response = setMessage(CommonConstants.SUCCESS, AdminConstant.SCHEDULE_MODIFY_SUCCESS);
					scheduleService.sendNotification(schedule, Action.MODIFIED);
				}
			} catch (Exception e) {
				e.printStackTrace();
				response = setMessage(CommonConstants.ERROR, AdminConstant.SCHEUDULE_MODIFY_ERROR);
			}
		}
		redirectAttributes.addFlashAttribute(response.getStatus(), response.getMessage());
		return "redirect:" + AdminConstant.MANAGE_SCHEDULE_CONTROLLER + AdminConstant.VIEW_ALL_SCHEDULE;
	}

	private void inactiveSlots(long scheduleId) {
		List<ScheduleSlot> slots = scheduleSlotService.getBySlotsByScheduleId(scheduleId);
		for (ScheduleSlot scheduleSlot : slots) {
			scheduleSlot.setStatus(Status.CANCELLED);
			scheduleSlotService.mergeLocal(scheduleSlot);
		}
	}

	private Response setMessage(String type, String message) {
		Response response = new Response();
		response.setStatus(type);
		response.setMessage(messageByLocaleService.getMessage(message));
		return response;
	}

	private void moveAllAppointmentstoWaitlist(long scheduleId) {
		List<Appointments> appointments = appointmentService.getAllScheduleAppointment(Status.APPROVED, scheduleId);
		for (Appointments appointment : appointments) {
			appointment.setSlot(null);
			appointment.setStatus(Status.WAITING);
			appointmentService.mergeLocal(appointment);
		}
	}

	@RequestMapping(value = AdminConstant.EXPORT_SCHEDULE, method = RequestMethod.POST)
	public void exportSchedule(Model model, HttpServletRequest request, HttpServletResponse response)
			throws IOException {

		List<Schedule> listSchedule = scheduleService.getRequiredSchedules(null, -1, 0, 0, CommonConstants.ZERO);
		net.sf.json.JSONObject jsonObject = new net.sf.json.JSONObject();
		net.sf.json.JSONObject jsonColumn = new net.sf.json.JSONObject();
		net.sf.json.JSONArray columnArray = new net.sf.json.JSONArray();
		List<String> colList = new ArrayList<String>(0);
		colList.add("Start Date");
		colList.add("End Date");
		colList.add("Start Time");
		colList.add("End Time");
		colList.add("Doctor Name");
		colList.add("Location");
		colList.add("Appts. Booked");
		colList.add("Appts. To Be token");
		colList.add("Status");
		for (int i = 0; i < colList.size(); i++) {
			net.sf.json.JSONObject jsonColData = new net.sf.json.JSONObject();
			jsonColData.put("key", colList.get(i));
			columnArray.add(jsonColData);
		}
		jsonColumn.put("col_data", columnArray);
		net.sf.json.JSONObject jsonObjData = new net.sf.json.JSONObject();
		net.sf.json.JSONArray rowArray = new net.sf.json.JSONArray();
		for (Schedule sc : listSchedule) {
			net.sf.json.JSONObject cellCol = new net.sf.json.JSONObject();
			net.sf.json.JSONArray cell = new net.sf.json.JSONArray();
			for (String colName : colList) {
				switch (colName) {
				case "Start Date":
					net.sf.json.JSONObject jsonRowData10 = new net.sf.json.JSONObject();
					jsonRowData10.put("key", colName);
					if (sc.getStartDate() != null) {
						jsonRowData10.put("value", CommonConstants.FORMAT2.format(sc.getStartDate()));
					} else {
						jsonRowData10.put("value", "");
					}
					cell.add(jsonRowData10);
					break;
				case "End Date":
					net.sf.json.JSONObject jsonRowData11 = new net.sf.json.JSONObject();
					jsonRowData11.put("key", colName);
					if (sc.getEndDate() != null) {
						jsonRowData11.put("value", CommonConstants.FORMAT2.format(sc.getEndDate()));
					} else {
						jsonRowData11.put("value", "");
					}
					cell.add(jsonRowData11);
					break;
				case "Start Time":
					net.sf.json.JSONObject jsonRowData12 = new net.sf.json.JSONObject();
					jsonRowData12.put("key", colName);
					if (sc.getStartTime() != null) {
						jsonRowData12.put("value", sc.getStartTime());
					} else {
						jsonRowData12.put("value", "");
					}
					cell.add(jsonRowData12);
					break;
				case "End Time":
					net.sf.json.JSONObject jsonRowData13 = new net.sf.json.JSONObject();
					jsonRowData13.put("key", colName);
					if (sc.getEndTime() != null) {
						jsonRowData13.put("value", sc.getEndTime());
					} else {
						jsonRowData13.put("value", "");
					}
					cell.add(jsonRowData13);
					break;
				case "Doctor Name":
					net.sf.json.JSONObject jsonRowData14 = new net.sf.json.JSONObject();
					jsonRowData14.put("key", colName);
					if (sc.getDoctor().getFullName() != null) {
						jsonRowData14.put("value", sc.getDoctor().getFullName());
					} else {
						jsonRowData14.put("value", "");
					}
					cell.add(jsonRowData14);
					break;
				case "Location":
					net.sf.json.JSONObject jsonRowData1 = new net.sf.json.JSONObject();
					jsonRowData1.put("key", colName);
					if (sc.getLocation().getLocation() != null) {
						jsonRowData1.put("value", sc.getLocation().getLocation());
					} else {
						jsonRowData1.put("value", "");
					}
					cell.add(jsonRowData1);
					break;
				case "Appts. Booked":
					net.sf.json.JSONObject jsonRowData2 = new net.sf.json.JSONObject();
					jsonRowData2.put("key", colName);
					if (null != sc.getMaxAppointments() && sc.getMaxAppointments() != 0L) {
						jsonRowData2.put("value", sc.getMaxAppointments());
					} else {
						jsonRowData2.put("value", 0);
					}
					cell.add(jsonRowData2);
					break;
				case "Appts. To Be token":
					net.sf.json.JSONObject jsonRowData3 = new net.sf.json.JSONObject();
					jsonRowData3.put("key", colName);
					jsonRowData3.put("value",
							appointmentService.findScheduleAppointmentCount(Status.APPROVED, sc.getScheduleId()));
					cell.add(jsonRowData3);
					break;
				case "Status":
					net.sf.json.JSONObject jsonRowData6 = new net.sf.json.JSONObject();
					jsonRowData6.put("key", colName);
					jsonRowData6.put("value", ServiceUtils.getStatus(sc.getStatus().getStatusCode()));
					cell.add(jsonRowData6);
					break;
				default:
					break;
				}
				cellCol.put("cell", cell);
			}
			rowArray.add(cellCol);
			jsonObjData.put("row", rowArray);
		}
		jsonObject.put("col", jsonColumn);
		jsonObject.put("data", jsonObjData);

		DownloadFile.downloadFile(AdminConstant.DOCTOR_APPOINTMENT_SCHEDULE_NAME, AdminConstant.EXPORT_EXTENSION,
				jsonObject, request, response);
	}
}
