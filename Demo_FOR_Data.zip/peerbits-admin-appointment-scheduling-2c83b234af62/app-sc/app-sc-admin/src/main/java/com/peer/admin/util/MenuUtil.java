package com.peer.admin.util;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;

import com.peer.constant.ActionConstant;
import com.peer.scenity.entity.local.User;
import com.peer.scenity.util.SessionUtil;
import com.peer.util.CommonUtil;

public class MenuUtil {
	
	private static Logger _log = Logger.getLogger(MenuUtil.class);
	
	public static void createMenu(HttpServletRequest request) {
		Map<String, String> menuMap = new HashMap<>(0);
		User user = SessionUtil.getUserFromRequestSession(request);
		String portalURL = CommonUtil.getPortalURL(request);
		
		String dashBoardMenu = "";
		String requestMenu = "";
		
		boolean hasPermission = PermissionUtil.hasPermission(user, ActionConstant.VIEW_DASHBOARD);
		if (hasPermission) {
			dashBoardMenu = "<li class='menu-item has-active'>" 
								+ "<a href='" + portalURL + "/dashboard/index' class='menu-link'>" 
									+ "<span class='menu-icon oi oi-dashboard'></span>"
									+ "<span class='menu-text'>Dashboard</span>" 
								+ "</a>"
							+ "</li>";
			
		}
		
		StringBuffer requestMenuBuffer = new StringBuffer();
		hasPermission = PermissionUtil.hasPermission(user, ActionConstant.VIEW_APPOINTMENT);
		if(hasPermission) {
			requestMenuBuffer.append("<li class='menu-item'><a href='"+portalURL+"' class='menu-link'>Appointment Requests</a></li>");
		}
		hasPermission = PermissionUtil.hasPermission(user, ActionConstant.VIEW_SCHEDULE);
		if(hasPermission) {
			requestMenuBuffer.append("<li class='menu-item'><a href='"+portalURL+"' class='menu-link'>Schedule Requests</a></li>");
		}
		hasPermission = PermissionUtil.hasPermission(user, ActionConstant.CREATE_NEW_APPOINTMENT);
		if(hasPermission) {
			requestMenuBuffer.append("<li class='menu-item'><a href='"+portalURL+"' class='menu-link'>Create New Appointment</a></li>");
		}
		hasPermission = PermissionUtil.hasPermission(user, ActionConstant.CREATE_NEW_SCHEDULE);
		if(hasPermission) {
			requestMenuBuffer.append("<li class='menu-item'><a href='"+portalURL+"' class='menu-link'>Create New Schedule</a></li>");
		}
		hasPermission = PermissionUtil.hasPermission(user, ActionConstant.VIEW_APPOINTMENT_CANCELLATIONS);
		if(hasPermission) {
			requestMenuBuffer.append("<li class='menu-item'><a href='"+portalURL+"' class='menu-link'>Appointment Cancellation Requests</a></li>");
		}
		String requestSubMenu = requestMenuBuffer.toString();
		if(StringUtils.isNotEmpty(requestSubMenu)) {
			requestMenu = "<li class='menu-item has-child'>" 
							+ "<a href='javascript:;' class='menu-link'>"
								+ "<span class='menu-icon fa fa-question'></span>"
								+ "<span class='menu-text'>Manage Requests</span>" 
							+ "</a>" 
							+ "<ul class='menu'>" + requestSubMenu + "</ul>" 
						+ "</li>";
			
		}
		
		
		
		menuMap.put(ActionConstant.VIEW_DASHBOARD, dashBoardMenu);
		menuMap.put(ActionConstant.MANAGE_REQUESTS, requestMenu);
		SessionUtil.updateSessionAttribute(request, ActionConstant.MENU_MAP, menuMap);
	}
	
	@SuppressWarnings("unchecked")
	public static Map<String, String> getMenuMap(HttpServletRequest request) {
		Map<String, String> menuMap = null;
		try {
			menuMap = (Map<String, String>) SessionUtil.getSessionAttribute(request, ActionConstant.MENU_MAP);
			if(null == menuMap) {
				createMenu(request);
				menuMap = (Map<String, String>) SessionUtil.getSessionAttribute(request, ActionConstant.MENU_MAP);
			}
		}catch(Exception e) {
			_log.error("", e);
		}
		return menuMap;
	}
}
