package com.peer.admin.controller;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.peer.admin.constant.AdminConstant;
import com.peer.admin.util.PermissionUtil;
import com.peer.admin.validate.ConsultationCategoryValidator;
import com.peer.admin.validate.ProcedureCategoryValidator;
import com.peer.constant.ActionConstant;
import com.peer.constant.CommonConstants;
import com.peer.enm.CategoryType;
import com.peer.enm.Status;
import com.peer.scenity.entity.local.Category;
import com.peer.scenity.entity.local.CategoryEps;
import com.peer.scenity.entity.local.Eps;
import com.peer.scenity.entity.local.User;
import com.peer.scenity.entity.pojo.Response;
import com.peer.scenity.entity.zeus.Asunto;
import com.peer.scenity.service.intf.ICategoryEpsService;
import com.peer.scenity.service.intf.ICategoryService;
import com.peer.scenity.service.intf.IEpsService;
import com.peer.scenity.service.intf.IUserService;
import com.peer.scenity.service.intf.MessageByLocaleService;
import com.peer.scenity.service.intf.ZeusAsuntoService;
import com.peer.scenity.util.SessionUtil;
import com.peer.util.CommonUtil;
import com.peer.util.DownloadFile;

@Controller
@RequestMapping(AdminConstant.CATEGORY_CONTROLLER)
public class CategoryController {

	private static Logger _log = Logger.getLogger(CategoryController.class);

	private static final String VIEW_CATEGORY = "category/category";
	private static final String ADD_CONSULTATION_CATEGORY = "category/addConsultionsCategory";
	private static final String ADD_PROCEDURE_CATEGORY = "category/addProcedureCategory";
	private static final String EDIT_CONSULTATION_CATEGORY = "category/editConsultionsCategory";
	private static final String EDIT_PROCEDURE_CATEGORY = "category/editProcedureCategory";
	private static final String VIEW_CONSULTATION_CATEGORY = "category/viewConsultionsCategory";
	private static final String VIEW_PROCEDURE_CATEGORY = "category/viewProcedureCategory";

	@Autowired
	private ConsultationCategoryValidator consultationcategoryValidator;

	@Autowired
	private ProcedureCategoryValidator procedureCategoryValidator;

	@Autowired
	private ICategoryService categoryService;

	@Autowired
	private ICategoryEpsService categoryEpsService;

	@Autowired
	private IEpsService epsService;
	
	@Autowired
	private ZeusAsuntoService zeusAsuntoService;

	@Autowired
	private IUserService userService;

	@Autowired
	private MessageByLocaleService messageByLocaleService;

	@RequestMapping(AdminConstant.VIEW_ALL_CATEGORY)
	public String categoryPage(Locale locale, Model model, HttpServletRequest request) {
		User sender = SessionUtil.getUserFromRequestSession(request);
		PermissionUtil.checkPermission(sender, ActionConstant.VIEW_CATEGORY);
		_log.info("inside Category page loading");
		return VIEW_CATEGORY;
	}

	@RequestMapping(AdminConstant.VIEW_ALL_PROCEDURE)
	public String allProcedure(Locale locale, Model model, HttpServletRequest request) {
		User sender = SessionUtil.getUserFromRequestSession(request);
		PermissionUtil.checkPermission(sender, ActionConstant.VIEW_CATEGORY);
		_log.info("inside Category page loading");
		model.addAttribute("Message", CategoryType.PROCEDURE);
		return VIEW_CATEGORY;
	}

	@RequestMapping(AdminConstant.VIEW_ALL_CONSULTATION)
	public String allConsultation(Locale locale, Model model, HttpServletRequest request) {
		User sender = SessionUtil.getUserFromRequestSession(request);
		PermissionUtil.checkPermission(sender, ActionConstant.VIEW_CATEGORY);
		_log.info("inside Category page loading");
		model.addAttribute("Message", CategoryType.CONSULTATION);
		return VIEW_CATEGORY;
	}

	@RequestMapping(AdminConstant.FETCH_CONSULTATION)
	@ResponseBody
	public ResponseEntity<Object> fetchConsultation(Locale locale, Model model, HttpServletRequest request) {
		String start = request.getParameter("start");
		String length = request.getParameter("length");
		String draw = request.getParameter("draw");
		String categoryStatus = request.getParameter("categoryStatus");
		int startI = 0;
		int lengthI = 10;
		int status = -1;
		if (StringUtils.isNotEmpty(categoryStatus) && StringUtils.isNumeric(categoryStatus)) {
			status = Integer.parseInt(categoryStatus);
		}
		if (StringUtils.isNotBlank(start) && StringUtils.isNumeric(start)) {
			startI = Integer.parseInt(start);
		}
		if (StringUtils.isNotBlank(length) && StringUtils.isNumeric(length)) {
			lengthI = Integer.parseInt(length);
		}
		JSONArray jsonArray = categoryService.paginateConsultation(startI, lengthI, status);
		Long totalConsultation = categoryService.paginateConsultationCount(startI, lengthI, status);
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("data", jsonArray);
		jsonObject.put("draw", draw);
		jsonObject.put("recordsTotal", totalConsultation);
		jsonObject.put("recordsFiltered", totalConsultation);
		return new ResponseEntity<Object>(jsonObject.toString(), HttpStatus.OK);
	}

	@RequestMapping(AdminConstant.FETCH_PROCEDURE)
	@ResponseBody
	public ResponseEntity<Object> fetchProcedures(Locale locale, Model model, HttpServletRequest request) {
		String start = request.getParameter("start");
		String length = request.getParameter("length");
		String draw = request.getParameter("draw");
		String categoryStatus = request.getParameter("categoryStatus");
		int startI = 0;
		int lengthI = 10;
		int status = -1;
		if (StringUtils.isNotEmpty(categoryStatus) && StringUtils.isNumeric(categoryStatus)) {
			status = Integer.parseInt(categoryStatus);
		}
		if (StringUtils.isNotBlank(start) && StringUtils.isNumeric(start)) {
			startI = Integer.parseInt(start);
		}
		if (StringUtils.isNotBlank(length) && StringUtils.isNumeric(length)) {
			lengthI = Integer.parseInt(length);
		}
		JSONArray jsonArray = categoryService.paginateProcedures(startI, lengthI, status);
		Long totalProcedures = categoryService.paginateProceduresCount(startI, lengthI, status);
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("data", jsonArray);
		jsonObject.put("draw", draw);
		jsonObject.put("recordsTotal", totalProcedures);
		jsonObject.put("recordsFiltered", totalProcedures);
		return new ResponseEntity<Object>(jsonObject.toString(), HttpStatus.OK);
	}

	@RequestMapping(AdminConstant.ADD_CONSULTATION_CATEGORY)
	public String addConsultation(Locale locale, Model model, HttpServletRequest request) {
		User sender = SessionUtil.getUserFromRequestSession(request);
		PermissionUtil.checkPermission(sender, ActionConstant.ADD_NEW_CATEGORY);
		_log.info("inside landing add consultation page ");
		model.addAttribute("consultationCategory", new Category());
		return ADD_CONSULTATION_CATEGORY;
	}

	@RequestMapping(AdminConstant.ADD_PROCEDURE_CATEGORY)
	public String addProcedure(Locale locale, Model model, HttpServletRequest request) {
		User sender = SessionUtil.getUserFromRequestSession(request);
		PermissionUtil.checkPermission(sender, ActionConstant.ADD_NEW_CATEGORY);
		_log.info("inside landing add procedure page ");
		List<Eps> eps = epsService.findAllLocalActive();
		model.addAttribute("procedureCategory", new Category());
		model.addAttribute("eps", eps);
		return ADD_PROCEDURE_CATEGORY;

	}

	@RequestMapping(value = AdminConstant.VIEW_CONSULTATION_CATEGORY, method = RequestMethod.POST)
	public String viewConsultationCategory(Locale locale, Model model,
			@ModelAttribute("consultationCategory") Category category, HttpServletRequest request) {
		User sender = SessionUtil.getUserFromRequestSession(request);
		PermissionUtil.checkPermission(sender, ActionConstant.VIEW_CATEGORY);
		_log.info("inside landing view consultation category page ");
		Category foundCategory = categoryService.findByIdById(category);
		model.addAttribute("consultationCategory", foundCategory);
		return VIEW_CONSULTATION_CATEGORY;
	}

	@RequestMapping(value = AdminConstant.VIEW_PROCEDURE_CATEGORY, method = RequestMethod.POST)
	public String viewProcedureCategory(Locale locale, Model model,
			@ModelAttribute("procedureCategory") Category category, HttpServletRequest request) {
		User sender = SessionUtil.getUserFromRequestSession(request);
		PermissionUtil.checkPermission(sender, ActionConstant.VIEW_CATEGORY);
		_log.info("inside landing view procedure category page ");
		Category foundCategory = categoryService.findByIdById(category);
		model.addAttribute("procedureCategory", foundCategory);
		return VIEW_PROCEDURE_CATEGORY;

	}

	@RequestMapping(value = AdminConstant.EDIT_CONSULTATION_CATEGORY, method = RequestMethod.POST)
	public String editConsultationCategory(Locale locale, Model model,
			@ModelAttribute("consultationCategory") Category category, HttpServletRequest request) {
		User sender = SessionUtil.getUserFromRequestSession(request);
		PermissionUtil.checkPermission(sender, ActionConstant.EDIT_CATEGORY);
		_log.info("inside landing edit consultation category page ");
		Category foundCategory = categoryService.findByIdById(category);
		Asunto asunto =zeusAsuntoService.findByIdZeus(foundCategory.getZeusCategoryId());
		model.addAttribute("consultationCategory", foundCategory);
		model.addAttribute("oportunidad", asunto.getId_oportunidad());
		return EDIT_CONSULTATION_CATEGORY;
	}

	@RequestMapping(value = AdminConstant.EDIT_PROCEDURE_CATEGORY, method = RequestMethod.POST)
	public String editProcedureCategory(Locale locale, Model model,
			@ModelAttribute("procedureCategory") Category category, HttpServletRequest request) {
		User sender = SessionUtil.getUserFromRequestSession(request);
		PermissionUtil.checkPermission(sender, ActionConstant.EDIT_CATEGORY);
		_log.info("inside landing edit procedure category page ");
		Category foundCategory = categoryService.findByIdById(category);
		Asunto asunto =zeusAsuntoService.findByIdZeus(foundCategory.getZeusCategoryId());
		List<Eps> eps = epsService.findAllLocalActive();
		model.addAttribute("procedureCategory", foundCategory);
		model.addAttribute("eps", eps);
		model.addAttribute("oportunidad", asunto.getId_oportunidad());
		return EDIT_PROCEDURE_CATEGORY;
	}

	@RequestMapping(value = AdminConstant.ADD_CONSULTATION_CATEGORY_SUBMIT, method = RequestMethod.POST)
	public String addConsultationCategory(Locale locale, RedirectAttributes redirectAttrs, Model model,
			HttpServletRequest request, @ModelAttribute("consultationCategory") Category category, HttpSession session,
			BindingResult bindingResult) {
		User sender = SessionUtil.getUserFromRequestSession(request);
		PermissionUtil.checkPermission(sender, ActionConstant.ADD_NEW_CATEGORY);
		Response response = new Response();
		String opportunity_id = request.getParameter("opportunity_id");
		Long id_oportunidad = Long.parseLong(opportunity_id);
		Category categoryConsultation = categoryService.setConsultationData(request, category);
		Boolean isEmpty = CommonUtil.checkNull(categoryConsultation);
		if (!isEmpty) {
			boolean check = validateConsultationCategory(model, categoryConsultation, session, request, bindingResult,response);
			if (check) {
				Long categorycheck = categoryService.findByAllLocalCategoryNameAndIds(categoryConsultation);
				if(categorycheck>0){
					if(categorycheck == 2){
						Asunto aunto =zeusAsuntoService.findAsunto(categoryConsultation);
						List<Category> data = categoryService.findByAllLocalCategoryNameAndId(categoryConsultation);
						if(data.size()>0){
							response=setMessage(CommonConstants.WARNING,AdminConstant.CONSULTATION_CATEGORY_EXIT);
						}else{
							try {
								_log.info("add data in consultation category");
								categoryConsultation.setZeusCategoryId(aunto.getId());
								Category mastercategory = categoryService.persistLocal(categoryConsultation);
								if (categoryConsultation.getConsultationData().size() > 0) {
									for (Category subCategory : categoryConsultation.getConsultationData()) {
										subCategory.setType(categoryConsultation.getType());
										subCategory.setParentCategoryId(mastercategory);
										List<Category> categorysubcheck = categoryService.findAllLocalSubCategoryNameAndId(subCategory);
										if (categorysubcheck.size() > 0) {
											response = setMessage(CommonConstants.WARNING,AdminConstant.CONSULTATION_SUBCATEGORY_EXIT);
											redirectAttrs.addFlashAttribute("error",subCategory.getName() + " " + response.getMessage());
											redirectAttrs.addFlashAttribute("Message", CategoryType.CONSULTATION);
											return "redirect:" + AdminConstant.CATEGORY_CONTROLLER+ AdminConstant.VIEW_ALL_CATEGORY;
										} else {
											try {
												_log.info("add data in consultation subcategory");
												subCategory.setCreatedOn(new Date());
												subCategory.setUpdatedOn(new Date());
												subCategory.setStatus(Status.ACTIVE);
												subCategory.setCreatedBy(SessionUtil.getUserFromRequestSession(request));
												subCategory.setUpdatedBy(SessionUtil.getUserFromRequestSession(request));
												categoryService.persistLocal(subCategory);
											} catch (Exception e) {
												_log.error("Error:--", e);
												response = setMessage(CommonConstants.ERROR,AdminConstant.CONSULTATION_SUBCATEGORY_EXCEPTION);
												redirectAttrs.addFlashAttribute("error", response.getMessage());
												redirectAttrs.addFlashAttribute("Message", CategoryType.CONSULTATION);
												return "redirect:" + AdminConstant.CATEGORY_CONTROLLER+ AdminConstant.VIEW_ALL_CATEGORY;
											}
										}
									}
								}
								response = setMessage(CommonConstants.SUCCESS, AdminConstant.CONSULTATION_CATEGORY_SUCCESS);
							} catch (Exception e) {
								_log.error("Error:--", e);
								response = setMessage(CommonConstants.ERROR, AdminConstant.CONSULTATION_CATEGORY_EXCEPTION);
								model.addAttribute("error", response.getMessage());
								return ADD_CONSULTATION_CATEGORY;
							}
						}
					}else{
						response=setMessage(CommonConstants.WARNING,AdminConstant.CONSULTATION_CATEGORY_EXIT);
					}
				}else {
					try {
						_log.info("add data in consultation category");
						Asunto asunto=new Asunto();
						asunto.setTipo(CommonConstants.APPOINTMENT_CONSULTATION);
						asunto.setName(categoryConsultation.getNameInSpanish());
						asunto.setStatus(true);
						asunto.setCitaOnline(false);
						asunto.setEspecializada(false);
						asunto.setCierrafacturaconfirmarcita(true);
						asunto.setDefectoCitaOnline(false);
						asunto.setEsPrimeraVez(true);
						asunto.setEsPyP(false);
						asunto.setEsTerapia(false);
						asunto.setId_oportunidad(id_oportunidad);
						asunto=zeusAsuntoService.persistZeus(asunto);
						categoryConsultation.setZeusCategoryId(asunto.getId());
						Category mastercategory = categoryService.persistLocal(categoryConsultation);
						if (categoryConsultation.getConsultationData().size() > 0) {
							for (Category subCategory : categoryConsultation.getConsultationData()) {
								subCategory.setType(categoryConsultation.getType());
								subCategory.setParentCategoryId(mastercategory);
								List<Category> categorysubcheck = categoryService
										.findAllLocalSubCategoryNameAndId(subCategory);
								if (categorysubcheck.size() > 0) {
									response = setMessage(CommonConstants.WARNING,
											AdminConstant.CONSULTATION_SUBCATEGORY_EXIT);
									redirectAttrs.addFlashAttribute("error",
											subCategory.getName() + " " + response.getMessage());
									redirectAttrs.addFlashAttribute("Message", CategoryType.CONSULTATION);
									return "redirect:" + AdminConstant.CATEGORY_CONTROLLER
											+ AdminConstant.VIEW_ALL_CATEGORY;
								} else {
									try {
										_log.info("add data in consultation subcategory");
										subCategory.setCreatedOn(new Date());
										subCategory.setUpdatedOn(new Date());
										subCategory.setStatus(Status.ACTIVE);
										subCategory.setCreatedBy(SessionUtil.getUserFromRequestSession(request));
										subCategory.setUpdatedBy(SessionUtil.getUserFromRequestSession(request));
										categoryService.persistLocal(subCategory);
									} catch (Exception e) {
										_log.error("Error:--", e);
										response = setMessage(CommonConstants.ERROR,
												AdminConstant.CONSULTATION_SUBCATEGORY_EXCEPTION);
										redirectAttrs.addFlashAttribute("error", response.getMessage());
										redirectAttrs.addFlashAttribute("Message", CategoryType.CONSULTATION);
										return "redirect:" + AdminConstant.CATEGORY_CONTROLLER
												+ AdminConstant.VIEW_ALL_CATEGORY;
									}
								}
							}
						}
						response = setMessage(CommonConstants.SUCCESS, AdminConstant.CONSULTATION_CATEGORY_SUCCESS);
					} catch (Exception e) {
						_log.error("Error:--", e);
						response = setMessage(CommonConstants.ERROR, AdminConstant.CONSULTATION_CATEGORY_EXCEPTION);
						model.addAttribute("error", response.getMessage());
						return ADD_CONSULTATION_CATEGORY;
					}
				}
			} else {
				return ADD_CONSULTATION_CATEGORY;
			}
		} else {
			response = setMessage(CommonConstants.ERROR, AdminConstant.CONSULTATION_CATEGORY_ERROR);
		}
		if (response.getStatus().equals(CommonConstants.SUCCESS)) {
			redirectAttrs.addFlashAttribute("success", response.getMessage());
		} else {
			model.addAttribute("error", response.getMessage());
			return ADD_CONSULTATION_CATEGORY;
		}
		redirectAttrs.addFlashAttribute("Message", CategoryType.CONSULTATION);
		return "redirect:" + AdminConstant.CATEGORY_CONTROLLER + AdminConstant.VIEW_ALL_CATEGORY;

	}

	@RequestMapping(value = AdminConstant.EDIT_CONSULTATION_CATEGORY_SUBMIT, method = RequestMethod.POST)
	public String editConsultationCategory(Locale locale, RedirectAttributes redirectAttrs, Model model,
			HttpServletRequest request, @ModelAttribute("consultationCategory") Category category, HttpSession session,
			BindingResult bindingResult) {
		User sender = SessionUtil.getUserFromRequestSession(request);
		PermissionUtil.checkPermission(sender, ActionConstant.EDIT_CATEGORY);
		Response response = new Response();
		Category categoryConsultation = categoryService.setEditConsultationData(request, category);
		Boolean isEmpty = CommonUtil.checkNull(categoryConsultation);
		String opportunity_id = request.getParameter("opportunity_id");
		Long id_oportunidad = Long.parseLong(opportunity_id);
		if (!isEmpty) {
			boolean check = validateConsultationCategory(model, categoryConsultation, session, request, bindingResult,
					response);
			if (check) {
				Category categoryObject = categoryService.findByIdLocal(categoryConsultation.getCategoryId());
				categoryConsultation.setCreatedBy(categoryObject.getCreatedBy());
				categoryConsultation.setCreatedOn(categoryObject.getCreatedOn());
				categoryConsultation.setZeusCategoryId(categoryObject.getZeusCategoryId());
				Long categorycheck = categoryService.findByAllLocalCategoryNameAndIds(categoryConsultation);
				if (categorycheck > 0) {
					response = setMessage(CommonConstants.WARNING, AdminConstant.CONSULTATION_CATEGORY_DUBLICATE);
				} else {
					Asunto aunto =zeusAsuntoService.findByIdZeus(categoryConsultation.getZeusCategoryId());
					aunto.setName(categoryConsultation.getNameInSpanish());
					aunto.setId_oportunidad(id_oportunidad);
					try {
						_log.info("update data in consultation category");
						aunto=zeusAsuntoService.mergeZeus(aunto);
						categoryConsultation.setZeusCategoryId(aunto.getId());
						Category categoryUpdated = categoryService.mergeLocal(categoryConsultation);
						if (categoryConsultation.getConsultationData().size() > 0) {
							for (Category subCategory : categoryConsultation.getConsultationData()) {
								subCategory.setParentCategoryId(categoryUpdated);
								subCategory.setType(categoryConsultation.getType());
								List<Category> categorysubcheck = categoryService.findAllLocalSubCategoryNameAndId(subCategory);
								if (categorysubcheck.size() > 0) {
									response = setMessage(CommonConstants.WARNING,AdminConstant.CONSULTATION_CATEGORY_DUBLICATE);
									redirectAttrs.addFlashAttribute("error",subCategory.getName() + " " + response.getMessage());
									redirectAttrs.addFlashAttribute("Message", CategoryType.CONSULTATION);
									return "redirect:" + AdminConstant.CATEGORY_CONTROLLER+ AdminConstant.VIEW_ALL_CATEGORY;
								} else {
									try {
										_log.info("update data in consultation subcategory");
										subCategory.setUpdatedOn(new Date());
										subCategory.setStatus(Status.ACTIVE);
										subCategory.setUpdatedBy(SessionUtil.getUserFromRequestSession(request));
										if (subCategory.getCategoryId() == null || subCategory.getCategoryId().equals(0L)) {
											subCategory.setCreatedOn(new Date());
											subCategory.setCreatedBy(SessionUtil.getUserFromRequestSession(request));
										} else {
											Category subCategorydata = categoryService.findByIdLocal(subCategory.getCategoryId());
											subCategory.setCreatedOn(subCategorydata.getCreatedOn());
											subCategory.setCreatedBy(subCategorydata.getCreatedBy());
										}
										if (subCategory.getCategoryId() == null	|| subCategory.getCategoryId().equals(0L)) {
											categoryService.persistLocal(subCategory);
										} else {
											categoryService.mergeLocal(subCategory);
										}
									} catch (Exception e) {
										_log.error("Error:--", e);
										response = setMessage(CommonConstants.ERROR,AdminConstant.CONSULTATION_SUBCATEGORY_EXCEPTION);
										redirectAttrs.addFlashAttribute("error",subCategory.getName() + " " + response.getMessage());
										redirectAttrs.addFlashAttribute("Message", CategoryType.CONSULTATION);
										return "redirect:" + AdminConstant.CATEGORY_CONTROLLER+ AdminConstant.VIEW_ALL_CATEGORY;
									}
								}

							}
						}
						response = setMessage(CommonConstants.SUCCESS, AdminConstant.CONSULTATION_CATEGORY_UPDATE);
					} catch (Exception e) {
						_log.error("Error:--", e);
						response = setMessage(CommonConstants.ERROR, AdminConstant.CONSULTATION_CATEGORY_EXCEPTION);
						model.addAttribute("error", response.getMessage());
						model.addAttribute("consultationCategory", categoryConsultation);
						return EDIT_CONSULTATION_CATEGORY;
					}
					response = setMessage(CommonConstants.SUCCESS, AdminConstant.CONSULTATION_CATEGORY_UPDATE);
				}
			} else {
				model.addAttribute("consultationCategory", categoryConsultation);
				return EDIT_CONSULTATION_CATEGORY;
			}
		} else {
			response = setMessage(CommonConstants.ERROR, AdminConstant.CONSULTATION_CATEGORY_ERROR);
		}
		if (response.getStatus().equals(CommonConstants.SUCCESS)) {
			redirectAttrs.addFlashAttribute("success", response.getMessage());
		} else {
			model.addAttribute("error", response.getMessage());
			model.addAttribute("consultationCategory", categoryConsultation);
			return EDIT_CONSULTATION_CATEGORY;
		}
		redirectAttrs.addFlashAttribute("Message", CategoryType.CONSULTATION);
		return "redirect:" + AdminConstant.CATEGORY_CONTROLLER + AdminConstant.VIEW_ALL_CATEGORY;
	}

	@RequestMapping(value = AdminConstant.ADD_PROCEDURE_CATEGORY_SUBBMIT, method = RequestMethod.POST)
	public String addProcedureCategory(Locale locale, RedirectAttributes redirectAttrs, Model model,
			HttpServletRequest request, @ModelAttribute("procedureCategory") Category category,
			BindingResult bindingResult) {
		User sender = SessionUtil.getUserFromRequestSession(request);
		PermissionUtil.checkPermission(sender, ActionConstant.ADD_NEW_CATEGORY);
		Response response = new Response();
		Category procedureConsultation = categoryService.setProcedureData(request, category);
		String opportunity_id = request.getParameter("opportunity_id");
		Long id_oportunidad = Long.parseLong(opportunity_id);
		Boolean isEmpty = CommonUtil.checkNull(procedureConsultation);
		if (!isEmpty) {
			boolean check = validateprocedureCategory(model, procedureConsultation, request, bindingResult, response);
			if (check) {
				Long categorycheck = categoryService.findByAllLocalCategoryNameAndIds(procedureConsultation);
				if(categorycheck>0){
					if(categorycheck == 2){
						Asunto aunto =zeusAsuntoService.findAsunto(procedureConsultation);
						List<Category> data = categoryService.findByAllLocalCategoryNameAndId(procedureConsultation);
						if(data.size()>0){
							response=setMessage(CommonConstants.WARNING,AdminConstant.PROCEDURE_CATEGORY_EXIT);
						}else{
							try {
								_log.info("add data in procedure category");
								procedureConsultation.setZeusCategoryId(aunto.getId());
								Category mastercategory = categoryService.persistLocal(procedureConsultation);
								if (procedureConsultation.getProcedureData().size() > 0) {
									for (Category subCategory : procedureConsultation.getProcedureData()) {
										subCategory.setType(procedureConsultation.getType());
										subCategory.setParentCategoryId(mastercategory);
										List<Category> categorysubcheck = categoryService
												.findAllLocalSubCategoryNameAndId(subCategory);
										if (categorysubcheck.size() > 0) {
											response = setMessage(CommonConstants.WARNING,AdminConstant.PROCEDURE_SUBCATEGORY_EXIT);
											redirectAttrs.addFlashAttribute("error",subCategory.getName() + " " + response.getMessage());
											redirectAttrs.addFlashAttribute("Message", CategoryType.PROCEDURE);
											return "redirect:" + AdminConstant.CATEGORY_CONTROLLER+ AdminConstant.VIEW_ALL_CATEGORY;
										} else {
											try {
												_log.info("add data in procedure subcategory");
												subCategory.setCreatedOn(new Date());
												subCategory.setUpdatedOn(new Date());
												subCategory.setStatus(Status.ACTIVE);
												subCategory.setCreatedBy(SessionUtil.getUserFromRequestSession(request));
												subCategory.setUpdatedBy(SessionUtil.getUserFromRequestSession(request));
												Category childcategory = categoryService.persistLocal(subCategory);
												if (subCategory.getProcedureCategoryEps().size() > 0) {
													for (CategoryEps ceps : subCategory.getProcedureCategoryEps()) {
														ceps.setCategoryId(childcategory);
														ceps.setCreatedOn(new Date());
														ceps.setUpdatedOn(new Date());
														ceps.setStatus(Status.ACTIVE);
														ceps.setCreatedBy(SessionUtil.getUserFromRequestSession(request));
														ceps.setUpdatedBy(SessionUtil.getUserFromRequestSession(request));
														try {
															categoryEpsService.persistLocal(ceps);
														} catch (Exception e) {
															_log.error("Error:--", e);
															response = setMessage(CommonConstants.ERROR,AdminConstant.PROCEDURE_SUBCATEGORY_EPS_EXCEPTION);
															redirectAttrs.addFlashAttribute("error", response.getMessage());
															redirectAttrs.addFlashAttribute("Message", CategoryType.PROCEDURE);
															return "redirect:" + AdminConstant.CATEGORY_CONTROLLER+ AdminConstant.VIEW_ALL_CATEGORY;
														}
													}
												}
											} catch (Exception e) {
												_log.error("Error:--", e);
												response = setMessage(CommonConstants.ERROR,AdminConstant.PROCEDURE_SUBCATEGORY_EXCEPTION);
												redirectAttrs.addFlashAttribute("error", response.getMessage());
												redirectAttrs.addFlashAttribute("Message", CategoryType.PROCEDURE);
												return "redirect:" + AdminConstant.CATEGORY_CONTROLLER+ AdminConstant.VIEW_ALL_CATEGORY;
											}
										}
									}
								}
								response = setMessage(CommonConstants.SUCCESS, AdminConstant.PROCEDURE_CATEGORY_SUCCESS);
							} catch (Exception e) {
								_log.error("Error:--", e);
								response = setMessage(CommonConstants.ERROR, AdminConstant.CONSULTATION_CATEGORY_EXCEPTION);
								model.addAttribute("error", response.getMessage());
								return ADD_CONSULTATION_CATEGORY;
							}
						}
					}else{
						response=setMessage(CommonConstants.WARNING,AdminConstant.PROCEDURE_CATEGORY_EXIT);
					}
				}else{
					try {
						_log.info("add data in procedure category");
						Asunto asunto=new Asunto();
						asunto.setTipo(CommonConstants.APPOINTMENT_PROCEDURE);
						asunto.setName(procedureConsultation.getNameInSpanish());
						asunto.setStatus(true);
						asunto.setCitaOnline(false);
						asunto.setEspecializada(false);
						asunto.setCierrafacturaconfirmarcita(true);
						asunto.setDefectoCitaOnline(false);
						asunto.setEsPrimeraVez(true);
						asunto.setEsPyP(false);
						asunto.setEsTerapia(false);
						asunto.setId_oportunidad(id_oportunidad);
						asunto=zeusAsuntoService.persistZeus(asunto);
						procedureConsultation.setZeusCategoryId(asunto.getId());
						Category mastercategory = categoryService.persistLocal(procedureConsultation);
						if (procedureConsultation.getProcedureData().size() > 0) {
							for (Category subCategory : procedureConsultation.getProcedureData()) {
								subCategory.setType(procedureConsultation.getType());
								subCategory.setParentCategoryId(mastercategory);
								List<Category> categorysubcheck = categoryService.findAllLocalSubCategoryNameAndId(subCategory);
								if (categorysubcheck.size() > 0) {
									response = setMessage(CommonConstants.WARNING,AdminConstant.PROCEDURE_SUBCATEGORY_EXIT);
									redirectAttrs.addFlashAttribute("error",subCategory.getName() + " " + response.getMessage());
									redirectAttrs.addFlashAttribute("Message", CategoryType.PROCEDURE);
									return "redirect:" + AdminConstant.CATEGORY_CONTROLLER+ AdminConstant.VIEW_ALL_CATEGORY;
								} else {
									try {
										_log.info("add data in procedure subcategory");
										subCategory.setCreatedOn(new Date());
										subCategory.setUpdatedOn(new Date());
										subCategory.setStatus(Status.ACTIVE);
										subCategory.setCreatedBy(SessionUtil.getUserFromRequestSession(request));
										subCategory.setUpdatedBy(SessionUtil.getUserFromRequestSession(request));
										Category childcategory = categoryService.persistLocal(subCategory);
										if (subCategory.getProcedureCategoryEps().size() > 0) {
											for (CategoryEps ceps : subCategory.getProcedureCategoryEps()) {
												ceps.setCategoryId(childcategory);
												ceps.setCreatedOn(new Date());
												ceps.setUpdatedOn(new Date());
												ceps.setStatus(Status.ACTIVE);
												ceps.setCreatedBy(SessionUtil.getUserFromRequestSession(request));
												ceps.setUpdatedBy(SessionUtil.getUserFromRequestSession(request));
												try {
													categoryEpsService.persistLocal(ceps);
												} catch (Exception e) {
													_log.error("Error:--", e);
													response = setMessage(CommonConstants.ERROR,AdminConstant.PROCEDURE_SUBCATEGORY_EPS_EXCEPTION);
													redirectAttrs.addFlashAttribute("error", response.getMessage());
													redirectAttrs.addFlashAttribute("Message", CategoryType.PROCEDURE);
													return "redirect:" + AdminConstant.CATEGORY_CONTROLLER+ AdminConstant.VIEW_ALL_CATEGORY;
												}
											}
										}
									} catch (Exception e) {
										_log.error("Error:--", e);
										response = setMessage(CommonConstants.ERROR,AdminConstant.PROCEDURE_SUBCATEGORY_EXCEPTION);
										redirectAttrs.addFlashAttribute("error", response.getMessage());
										redirectAttrs.addFlashAttribute("Message", CategoryType.PROCEDURE);
										return "redirect:" + AdminConstant.CATEGORY_CONTROLLER+ AdminConstant.VIEW_ALL_CATEGORY;
									}
								}
							}
						}
						response = setMessage(CommonConstants.SUCCESS, AdminConstant.PROCEDURE_CATEGORY_SUCCESS);
					} catch (Exception e) {
						_log.error("Error:--", e);
						response = setMessage(CommonConstants.ERROR, AdminConstant.PROCEDURE_CATEGORY_EXCEPTION);
						model.addAttribute("error", response.getMessage());
						List<Eps> eps = epsService.findAllLocalActive();
						model.addAttribute("eps", eps);
						return ADD_PROCEDURE_CATEGORY;
					}
				}
			} else {
				response = setMessage(CommonConstants.ERROR, AdminConstant.PROCEDURE_CATEGORY_ERROR);
			}
		} else {
			response = setMessage(CommonConstants.ERROR, AdminConstant.PROCEDURE_CATEGORY_ERROR);
		}
		if (response.getStatus().equals(CommonConstants.SUCCESS)) {
			redirectAttrs.addFlashAttribute("success", response.getMessage());
		} else {
			model.addAttribute("error", response.getMessage());
			return ADD_PROCEDURE_CATEGORY;
		}
		redirectAttrs.addFlashAttribute("Message", CategoryType.PROCEDURE);
		return "redirect:" + AdminConstant.CATEGORY_CONTROLLER + AdminConstant.VIEW_ALL_CATEGORY;
	}

	@RequestMapping(value = AdminConstant.EDIT_PROCEDURE_CATEGORY_SUBBMIT, method = RequestMethod.POST)
	public String editProcedureCategory(Locale locale, RedirectAttributes redirectAttrs, Model model,
			HttpServletRequest request, @ModelAttribute("procedureCategory") Category category,
			BindingResult bindingResult) {
		User sender = SessionUtil.getUserFromRequestSession(request);
		PermissionUtil.checkPermission(sender, ActionConstant.EDIT_CATEGORY);
		Response response = new Response();
		Category procedureConsultation = categoryService.setEditProcedureData(request, category);
		Boolean isEmpty = CommonUtil.checkNull(procedureConsultation);
		String opportunity_id = request.getParameter("opportunity_id");
		Long id_oportunidad = Long.parseLong(opportunity_id);
		if (!isEmpty) {
			boolean check = validateprocedureCategory(model, category, request, bindingResult, response);
			if (check) {
				Category categoryObject = categoryService.findByIdLocal(category.getCategoryId());
				procedureConsultation.setCreatedBy(categoryObject.getCreatedBy());
				procedureConsultation.setCreatedOn(categoryObject.getCreatedOn());
				procedureConsultation.setZeusCategoryId(categoryObject.getZeusCategoryId());
				Long categorycheck = categoryService.findByAllLocalCategoryNameAndIds(procedureConsultation);
				if (categorycheck > 0) {
					response = setMessage(CommonConstants.WARNING, AdminConstant.PROCEDURE_CATEGORY_EXIT);
					model.addAttribute("error", response.getMessage());
					model.addAttribute("procedureCategory", procedureConsultation);
					List<Eps> eps = epsService.findAllLocalActive();
					model.addAttribute("eps", eps);
					return EDIT_PROCEDURE_CATEGORY;
				} else {
					Asunto aunto =zeusAsuntoService.findByIdZeus(procedureConsultation.getZeusCategoryId());
					aunto.setName(procedureConsultation.getNameInSpanish());
					aunto.setId_oportunidad(id_oportunidad);
					try {
						_log.info("update data in procedure category");
						aunto=zeusAsuntoService.mergeZeus(aunto);
						procedureConsultation.setZeusCategoryId(aunto.getId());
						Category mastercategory = categoryService.mergeLocal(procedureConsultation);
						if (procedureConsultation.getProcedureData().size() > 0) {
							for (Category subCategory : procedureConsultation.getProcedureData()) {
								subCategory.setParentCategoryId(mastercategory);
								subCategory.setType(procedureConsultation.getType());
								List<Category> categorysubcheck = categoryService.findAllLocalSubCategoryNameAndId(subCategory);
								if (categorysubcheck.size() > 0) {
									response = setMessage(CommonConstants.WARNING,AdminConstant.PROCEDURE_SUBCATEGORY_EXIT);
									redirectAttrs.addFlashAttribute("error",subCategory.getName() + " " + response.getMessage());
									redirectAttrs.addFlashAttribute("Message", CategoryType.PROCEDURE);
									return "redirect:" + AdminConstant.CATEGORY_CONTROLLER+ AdminConstant.VIEW_ALL_CATEGORY;
								} else {
									try {
										Category childcategory = new Category();
										_log.info("add or edit data in procedure subcategory");
										subCategory.setUpdatedOn(new Date());
										subCategory.setStatus(Status.ACTIVE);
										subCategory.setUpdatedBy(SessionUtil.getUserFromRequestSession(request));
										if (subCategory.getCategoryId() == null	|| subCategory.getCategoryId().equals(0L)) {
											subCategory.setCreatedOn(new Date());
											subCategory.setCreatedBy(SessionUtil.getUserFromRequestSession(request));
										} else {
											Category subCategorydata = categoryService.findByIdLocal(subCategory.getCategoryId());
											subCategory.setCreatedOn(subCategorydata.getCreatedOn());
											subCategory.setCreatedBy(subCategorydata.getCreatedBy());
										}
										if (subCategory.getCategoryId() == null	|| subCategory.getCategoryId().equals(0L)) {
											childcategory = categoryService.persistLocal(subCategory);
										} else {
											childcategory = categoryService.mergeLocal(subCategory);
										}
										if (subCategory.getProcedureCategoryEps().size() > 0) {
											for (CategoryEps ceps : subCategory.getProcedureCategoryEps()) {
												ceps.setCategoryId(childcategory);
												if (ceps.getCategoryEpsId() == null	|| ceps.getCategoryEpsId().equals(0L)) {
													List<CategoryEps> categoryEps = categoryEpsService.findAllLocalCategoryEps(ceps);
													if (categoryEps.size() > 0) {
														response = setMessage(CommonConstants.WARNING,AdminConstant.PROCEDURE_SUBCATEGORY_EPS_EXIT);
														redirectAttrs.addFlashAttribute("error",subCategory.getName() + " In "+ ceps.getEpsId().getEps() + " "
																		+ response.getMessage());
														redirectAttrs.addFlashAttribute("Message",CategoryType.PROCEDURE);
														return "redirect:" + AdminConstant.CATEGORY_CONTROLLER+ AdminConstant.VIEW_ALL_CATEGORY;
													} else {
														ceps.setCreatedOn(new Date());
														ceps.setUpdatedOn(new Date());
														ceps.setStatus(Status.ACTIVE);
														ceps.setCreatedBy(SessionUtil.getUserFromRequestSession(request));
														ceps.setUpdatedBy(SessionUtil.getUserFromRequestSession(request));
													}
												} else {
													List<CategoryEps> categoryEps = categoryEpsService.findAllLocalCategoryEps(ceps);
													if (categoryEps.size() > 0) {
														response = setMessage(CommonConstants.WARNING,AdminConstant.PROCEDURE_SUBCATEGORY_EPS_EXIT);
														redirectAttrs.addFlashAttribute("error",subCategory.getName() + " In "+ ceps.getEpsId().getEps() + " "
																		+ response.getMessage());
														redirectAttrs.addFlashAttribute("Message",CategoryType.PROCEDURE);
														return "redirect:" + AdminConstant.CATEGORY_CONTROLLER+ AdminConstant.VIEW_ALL_CATEGORY;
													} else {
														CategoryEps ces = categoryEpsService.findByIdLocal(ceps.getCategoryEpsId());
														ceps.setCreatedOn(ces.getCreatedOn());
														ceps.setUpdatedOn(new Date());
														ceps.setStatus(Status.ACTIVE);
														ceps.setCreatedBy(ces.getCreatedBy());
														ceps.setUpdatedBy(SessionUtil.getUserFromRequestSession(request));
													}
												}
												try {
													categoryEpsService.persistLocal(ceps);
												} catch (Exception e) {
													_log.error("Error:--", e);
													response = setMessage(CommonConstants.ERROR,AdminConstant.PROCEDURE_SUBCATEGORY_EPS_EXCEPTION);
													redirectAttrs.addFlashAttribute("error", response.getMessage());
													redirectAttrs.addFlashAttribute("Message", CategoryType.PROCEDURE);
													return "redirect:" + AdminConstant.CATEGORY_CONTROLLER+ AdminConstant.VIEW_ALL_CATEGORY;
												}
											}
										}
									} catch (Exception e) {
										_log.error("Error:--", e);
										response = setMessage(CommonConstants.ERROR,AdminConstant.PROCEDURE_SUBCATEGORY_EXCEPTION);
										redirectAttrs.addFlashAttribute("error", response.getMessage());
										redirectAttrs.addFlashAttribute("Message", CategoryType.PROCEDURE);
										return "redirect:" + AdminConstant.CATEGORY_CONTROLLER+ AdminConstant.VIEW_ALL_CATEGORY;
									}
								}
							}
						}
						response = setMessage(CommonConstants.SUCCESS, AdminConstant.PROCEDURE_CATEGORY_UPDATE);
					} catch (Exception e) {
						_log.error("Error:--", e);
						response = setMessage(CommonConstants.ERROR, AdminConstant.PROCEDURE_CATEGORY_EXCEPTION);
						List<Eps> eps = epsService.findAllLocalActive();
						model.addAttribute("procedureCategory", procedureConsultation);
						model.addAttribute("eps", eps);
						return EDIT_PROCEDURE_CATEGORY;
					}
				}
			} else {
				List<Eps> eps = epsService.findAllLocalActive();
				model.addAttribute("procedureCategory", procedureConsultation);
				model.addAttribute("eps", eps);
				return EDIT_PROCEDURE_CATEGORY;
			}
		} else {
			response = setMessage(CommonConstants.ERROR, AdminConstant.PROCEDURE_CATEGORY_ERROR);
		}
		if (response.getStatus().equals(CommonConstants.SUCCESS)) {
			redirectAttrs.addFlashAttribute("success", response.getMessage());
		} else {
			model.addAttribute("error", response.getMessage());
			model.addAttribute("procedureCategory", procedureConsultation);
			List<Eps> eps = epsService.findAllLocalActive();
			model.addAttribute("eps", eps);
			return EDIT_PROCEDURE_CATEGORY;
		}
		redirectAttrs.addFlashAttribute("Message", CategoryType.PROCEDURE);
		return "redirect:" + AdminConstant.CATEGORY_CONTROLLER + AdminConstant.VIEW_ALL_CATEGORY;
	}

	@RequestMapping(value = AdminConstant.REMOVE_CONSULTATION_CATEGORY, method = RequestMethod.POST)
	public String deleteConsultationCategory(Locale locale, Model model, RedirectAttributes redirectAttrs,
			@ModelAttribute("consultationCategory") Category category, HttpSession session,
			HttpServletRequest request) {
		User sender = SessionUtil.getUserFromRequestSession(request);
		PermissionUtil.checkPermission(sender, ActionConstant.DELETE_CATEGORY);
		Response response = new Response();
		Category categoryData = categoryService.findByIdLocal(category.getCategoryId());
		categoryData.setStatus(Status.DELETED);
		categoryData.setUpdatedBy(SessionUtil.getUserFromRequestSession(request));
		categoryData.setUpdatedOn(new Date());
		try {
			_log.info("remove data in consultation category ");
			Asunto aunto =zeusAsuntoService.findByIdZeus(categoryData.getZeusCategoryId());
			aunto.setStatus(false);
			zeusAsuntoService.deleteZeus(aunto);
			categoryService.deleteLocal(categoryData);
			response = setMessage(CommonConstants.SUCCESS, AdminConstant.CONSULTATION_CATEGORY_DELETE);
		} catch (Exception e) {
			_log.error("Error:--", e);
			response = setMessage(CommonConstants.ERROR, AdminConstant.CONSULTATION_CATEGORY_EXCEPTION);
		}
		if (response.getStatus().equals(CommonConstants.SUCCESS)) {
			redirectAttrs.addFlashAttribute("success", response.getMessage());
		} else {
			redirectAttrs.addFlashAttribute("error", response.getMessage());
		}
		redirectAttrs.addFlashAttribute("Message", CategoryType.CONSULTATION);
		return "redirect:" + AdminConstant.CATEGORY_CONTROLLER + AdminConstant.VIEW_ALL_CATEGORY;

	}

	@RequestMapping(value = AdminConstant.REMOVE_PROCEDURE_CATEGORY, method = RequestMethod.POST)
	public String deleteProcedureCategory(Locale locale, Model model, RedirectAttributes redirectAttrs,
			@ModelAttribute("procedureCategory") Category category, HttpSession session, HttpServletRequest request) {
		User sender = SessionUtil.getUserFromRequestSession(request);
		PermissionUtil.checkPermission(sender, ActionConstant.DELETE_CATEGORY);
		Response response = new Response();
		_log.info("remove data in procedure category ");
		Category categoryData = categoryService.findByIdLocal(category.getCategoryId());
		categoryData.setStatus(Status.DELETED);
		categoryData.setUpdatedBy(SessionUtil.getUserFromRequestSession(request));
		categoryData.setUpdatedOn(new Date());
		try {
			_log.info("remove data in procedure category ");
			Asunto aunto =zeusAsuntoService.findByIdZeus(categoryData.getZeusCategoryId());
			aunto.setStatus(false);
			zeusAsuntoService.deleteZeus(aunto);
			categoryService.deleteLocal(categoryData);
			response = setMessage(CommonConstants.SUCCESS, AdminConstant.PROCEDURE_CATEGORY_DELETE);
		} catch (Exception e) {
			_log.error("Error:--", e);
			response = setMessage(CommonConstants.ERROR, AdminConstant.PROCEDURE_CATEGORY_EXCEPTION);
		}
		if (response.getStatus().equals(CommonConstants.SUCCESS)) {
			redirectAttrs.addFlashAttribute("success", response.getMessage());
		} else {
			redirectAttrs.addFlashAttribute("error", response.getMessage());
		}
		redirectAttrs.addFlashAttribute("Message", CategoryType.PROCEDURE);
		return "redirect:" + AdminConstant.CATEGORY_CONTROLLER + AdminConstant.VIEW_ALL_CATEGORY;

	}

	private boolean validateConsultationCategory(Model model, Category category, HttpSession session,
			HttpServletRequest request, BindingResult bindingResult, Response response) {
		boolean validated = true;
		if (category.getCategoryId() == null || category.getCategoryId().equals(0L)) {
			consultationcategoryValidator.validate(category, bindingResult);
			if (bindingResult.hasErrors()) {
				List<FieldError> errors = bindingResult.getFieldErrors();
				StringBuffer message = new StringBuffer();
				for (FieldError error : errors) {
					message.append(error.getDefaultMessage() + CommonConstants.MESSAGE);
				}
				response = setErrorValidate(CommonConstants.ERROR, message);
				model.addAttribute("error", response.getMessage());
				validated = false;
			}
			category.setCreatedOn(new Date());
			category.setUpdatedOn(new Date());
			category.setCreatedBy(SessionUtil.getUserFromRequestSession(request));
			category.setUpdatedBy(SessionUtil.getUserFromRequestSession(request));
			category.setStatus(Status.ACTIVE);
		} else {
			consultationcategoryValidator.validate(category, bindingResult);
			if (bindingResult.hasErrors()) {
				List<FieldError> errors = bindingResult.getFieldErrors();
				StringBuffer message = new StringBuffer();
				for (FieldError error : errors) {
					message.append(error.getDefaultMessage() + CommonConstants.MESSAGE);
				}
				response = setErrorValidate(CommonConstants.ERROR, message);
				model.addAttribute("error", response.getMessage());
				validated = false;
			}
			category.setStatus(Status.ACTIVE);
			category.setUpdatedOn(new Date());
			category.setUpdatedBy(SessionUtil.getUserFromRequestSession(request));
		}
		return validated;
	}

	private boolean validateprocedureCategory(Model model, Category category, HttpServletRequest request,
			BindingResult bindingResult, Response response) {
		boolean validated = true;
		if (category.getCategoryId() == null || category.getCategoryId().equals(0L)) {
			procedureCategoryValidator.validate(category, bindingResult);
			if (bindingResult.hasErrors()) {
				List<FieldError> errors = bindingResult.getFieldErrors();
				StringBuffer message = new StringBuffer();
				for (FieldError error : errors) {
					message.append(error.getDefaultMessage() + CommonConstants.MESSAGE);
				}
				response = setErrorValidate(CommonConstants.ERROR, message);
				model.addAttribute("error", response.getMessage());
				validated = false;
			}
			category.setCreatedOn(new Date());
			category.setUpdatedOn(new Date());
			category.setCreatedBy(SessionUtil.getUserFromRequestSession(request));
			category.setUpdatedBy(SessionUtil.getUserFromRequestSession(request));
			category.setStatus(Status.ACTIVE);
		} else {
			procedureCategoryValidator.validate(category, bindingResult);
			if (bindingResult.hasErrors()) {
				List<FieldError> errors = bindingResult.getFieldErrors();
				StringBuffer message = new StringBuffer();
				for (FieldError error : errors) {
					message.append(error.getDefaultMessage() + CommonConstants.MESSAGE);
				}
				response = setErrorValidate(CommonConstants.ERROR, message);
				model.addAttribute("error", response.getMessage());
				validated = false;
			}
			category.setStatus(Status.ACTIVE);
			category.setUpdatedOn(new Date());
			category.setUpdatedBy(SessionUtil.getUserFromRequestSession(request));
		}
		return validated;
	}

	private Response setErrorValidate(String type, StringBuffer message) {
		Response response = new Response();
		response.setStatus(type);
		response.setMessage(message.toString().substring(0, message.length() - 5));
		return response;
	}

	private Response setMessage(String type, String message) {
		Response response = new Response();
		response.setStatus(type);
		response.setMessage(messageByLocaleService.getMessage(message));
		return response;
	}

	@RequestMapping(AdminConstant.FETCH_CATEGORIES_EPS_CONSULTANT)
	@ResponseBody
	public ResponseEntity<Object> fetchCategoriesEpsConsultant(HttpServletRequest request) {
		String epsIdSting = request.getParameter("epsId");
		Long epsId = 0L;
		if (StringUtils.isNotBlank(epsIdSting) && StringUtils.isNumeric(epsIdSting)) {
			epsId = Long.parseLong(epsIdSting);
		}
		List<Category> categoryList = categoryService.categoryEPSandConsulatant(epsId);
		return new ResponseEntity<>(getCategoryArray(categoryList, false).toString(), HttpStatus.OK);
	}

	@RequestMapping(AdminConstant.FETCH_SUBCATEGORIES)
	@ResponseBody
	public ResponseEntity<Object> fetchSubCategories(HttpServletRequest request) {
		String epsIdSting = request.getParameter("epsId");
		String categoryIdSting = request.getParameter("categoryId");
		String userId = request.getParameter("userId");
		User user = null;
		Long epsId = 0L;
		Long categoryId = 0L;
		if (StringUtils.isNotBlank(epsIdSting) && StringUtils.isNumeric(epsIdSting)) {
			epsId = Long.parseLong(epsIdSting);
		}
		if (StringUtils.isNotBlank(categoryIdSting) && StringUtils.isNumeric(categoryIdSting)) {
			categoryId = Long.parseLong(categoryIdSting);
		}
		if (StringUtils.isNotBlank(userId) && StringUtils.isNumeric(userId)) {
			user = userService.findByIdLocal(Long.parseLong(userId));
		}

		JSONObject childCategories = categoryService.getChildCategories(user, categoryId, epsId, false);
		return new ResponseEntity<>(childCategories.toString(), HttpStatus.OK);
	}

	public JSONArray getCategoryArray(List<Category> categoryList, boolean spanish) {
		JSONArray jsonArray = new JSONArray();
		for (Category category : categoryList) {
			jsonArray.put(getCategoryObject(category, spanish));
		}
		return jsonArray;
	}

	public JSONObject getCategoryObject(Category category, boolean spanish) {
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("categoryId", category.getCategoryId());
		if (spanish) {
			jsonObject.put("name", category.getNameInSpanish());
		} else {
			jsonObject.put("name", category.getName());
		}
		return jsonObject;
	}
	@RequestMapping(value = AdminConstant.EXPORT_CATEGORY, method = RequestMethod.POST)
	public void exportEps(Model model, HttpServletRequest request, HttpServletResponse response) throws IOException {

		List<Category> listCategory = categoryService.findAllCategoryExport();
		net.sf.json.JSONObject jsonObject = new net.sf.json.JSONObject();
		net.sf.json.JSONObject jsonColumn = new net.sf.json.JSONObject();
		net.sf.json.JSONArray columnArray = new net.sf.json.JSONArray();
		List<String> colList = new ArrayList<String>(0);
		colList.add("Category");
		colList.add("Category In Spanish");
		colList.add("Laterality");
		colList.add("SubCategory");
		colList.add("SubCategory In Spanish");
		colList.add("SubCategory Laterality");
		colList.add("SubCategory Eps");
		colList.add("SubCategory Cost");
		colList.add("Categry Type");
		colList.add("Status");

		for (int i = 0; i < colList.size(); i++) {
			net.sf.json.JSONObject jsonColData = new net.sf.json.JSONObject();
			jsonColData.put("key", colList.get(i));
			columnArray.add(jsonColData);
		}
		jsonColumn.put("col_data", columnArray);
		net.sf.json.JSONObject jsonObjData = new net.sf.json.JSONObject();
		net.sf.json.JSONArray rowArray = new net.sf.json.JSONArray();
		for (Category category : listCategory) {
			StringBuffer message = new StringBuffer();
			StringBuffer messages = new StringBuffer();
			Category foundCategory = categoryService.findByIdById(category);
			net.sf.json.JSONObject cellCol = new net.sf.json.JSONObject();
			net.sf.json.JSONArray cell = new net.sf.json.JSONArray();
			for (String colName : colList) {
				switch (colName) {
				case "Category":
					net.sf.json.JSONObject jsonRowData = new net.sf.json.JSONObject();
					jsonRowData.put("key", colName);
					if(foundCategory.getName()!=null){
						jsonRowData.put("value", foundCategory.getName());
					}else{
						jsonRowData.put("value", "");
					}
					cell.add(jsonRowData);
					break;
				case "Category In Spanish":
					net.sf.json.JSONObject jsonRowData1 = new net.sf.json.JSONObject();
					jsonRowData1.put("key", colName);
					if(foundCategory.getNameInSpanish()!=null){
						jsonRowData1.put("value", foundCategory.getNameInSpanish());
					}else{
						jsonRowData1.put("value", "");
					}
					cell.add(jsonRowData1);
					break;
				case "Laterality":
					net.sf.json.JSONObject jsonRowData2 = new net.sf.json.JSONObject();
					jsonRowData2.put("key", colName);
					jsonRowData2.put("value", foundCategory.getLaterality());
					cell.add(jsonRowData2);
					break;
				case "SubCategory":
					net.sf.json.JSONObject jsonRowData3 = new net.sf.json.JSONObject();
					jsonRowData3.put("key", colName);
					message = new StringBuffer();
					if (foundCategory.getType().equals(CategoryType.CONSULTATION)) {
						for (Category categoryConsul : foundCategory.getConsultationData()) {
							message.append(categoryConsul.getName() + ",");
						}
						if (message.toString().length() > 0) {
							jsonRowData3.put("value", message.toString().substring(0, message.length() - 1));
						} else {
							jsonRowData3.put("value", "");
						}
						cell.add(jsonRowData3);
					}else{
						for (Category categoryProce : foundCategory.getProcedureData()) {
							message.append(categoryProce.getName() + ",");
						}
						if (message.toString().length() > 0) {
							jsonRowData3.put("value", message.toString().substring(0, message.length() - 1));
						} else {
							jsonRowData3.put("value", "");
						}
						cell.add(jsonRowData3);
					}
					break;
				case "SubCategory In Spanish":
					net.sf.json.JSONObject jsonRowData4 = new net.sf.json.JSONObject();
					jsonRowData4.put("key", colName);
					message = new StringBuffer();
					if (foundCategory.getType().equals(CategoryType.CONSULTATION)) {
						for (Category categoryConsul : foundCategory.getConsultationData()) {
							message.append(categoryConsul.getNameInSpanish() + ",");
						}
						if (message.toString().length() > 0) {
							jsonRowData4.put("value", message.toString().substring(0, message.length() - 1));
						} else {
							jsonRowData4.put("value", "");
						}
						cell.add(jsonRowData4);
					}else{
						for (Category categoryProce : foundCategory.getProcedureData()) {
							message.append(categoryProce.getNameInSpanish() + ",");
						}
						if (message.toString().length() > 0) {
							jsonRowData4.put("value", message.toString().substring(0, message.length() - 1));
						} else {
							jsonRowData4.put("value", "");
						}
						cell.add(jsonRowData4);
					}
					break;
				case "SubCategory Laterality":
					net.sf.json.JSONObject jsonRowData5 = new net.sf.json.JSONObject();
					jsonRowData5.put("key", colName);
					message = new StringBuffer();
					if (foundCategory.getType().equals(CategoryType.CONSULTATION)) {
						for (Category categoryConsul : foundCategory.getConsultationData()) {
							message.append(categoryConsul.getLaterality() + ",");
						}
						if (message.toString().length() > 0) {
							jsonRowData5.put("value", message.toString().substring(0, message.length() - 1));
						} else {
							jsonRowData5.put("value", "");
						}
						cell.add(jsonRowData5);
					}else{
						for (Category categoryProce : foundCategory.getProcedureData()) {
							message.append(categoryProce.getLaterality() + ",");
						}
						if (message.toString().length() > 0) {
							jsonRowData5.put("value", message.toString().substring(0, message.length() - 1));
						} else {
							jsonRowData5.put("value", "");
						}
						cell.add(jsonRowData5);
					}
					break;
				case "SubCategory Eps":
					net.sf.json.JSONObject jsonRowData6 = new net.sf.json.JSONObject();
					jsonRowData6.put("key", colName);
					messages = new StringBuffer();
					if (foundCategory.getType().equals(CategoryType.PROCEDURE)) {
						for (Category categoryProce : foundCategory.getProcedureData()) {
							message = new StringBuffer();
							for(CategoryEps categoryEps:categoryProce.getProcedureCategoryEps()){
								message.append(categoryEps.getEpsId().getEpsCode() + ",");	
							}
							String me=message.toString().substring(0, message.length() - 1);
							messages.append(me);
							messages.append(";");
						}
						if (message.toString().length() > 0) {
							jsonRowData6.put("value", messages.toString().substring(0, messages.length() - 1));
						} else {
							jsonRowData6.put("value", "");
						}
					}else{
						jsonRowData6.put("value", "");
					}
					cell.add(jsonRowData6);
					break;
				case "SubCategory Cost":
					net.sf.json.JSONObject jsonRowData7 = new net.sf.json.JSONObject();
					jsonRowData7.put("key", colName);
					message = new StringBuffer();
					messages = new StringBuffer();
					if (foundCategory.getType().equals(CategoryType.PROCEDURE)) {
						for (Category categoryProce : foundCategory.getProcedureData()) {
							message = new StringBuffer();
							for(CategoryEps categoryEps:categoryProce.getProcedureCategoryEps()){
								message.append(categoryEps.getCost() + ",");	
							}
							String me=message.toString().substring(0, message.length() - 1);
							messages.append(me);
							messages.append(";");
						}
						if (message.toString().length() > 0) {
							jsonRowData7.put("value", messages.toString().substring(0, messages.length() - 1));
						} else {
							jsonRowData7.put("value", "");
						}
					}else{
						jsonRowData7.put("value", "");
					}
					cell.add(jsonRowData7);
					break;
				case "Categry Type":
					net.sf.json.JSONObject jsonRowData8 = new net.sf.json.JSONObject();
					jsonRowData8.put("key", colName);
					if(foundCategory.getType()!=null){
						jsonRowData8.put("value", foundCategory.getType());
					}else{
						jsonRowData8.put("value", "");
					}
					cell.add(jsonRowData8);
					break;
				case "Status":
					net.sf.json.JSONObject jsonRowData9= new net.sf.json.JSONObject();
					jsonRowData9.put("key", colName);
					jsonRowData9.put("value", foundCategory.getStatus());
					cell.add(jsonRowData9);
					break;
				default:
					break;
				}
				cellCol.put("cell", cell);
			}
			rowArray.add(cellCol);
			jsonObjData.put("row", rowArray);
		}
		jsonObject.put("col", jsonColumn);
		jsonObject.put("data", jsonObjData);

		DownloadFile.downloadFile(AdminConstant.CATEGORY_MODULE_NAME, AdminConstant.EXPORT_EXTENSION, jsonObject, request,
				response);
	}
	
	@RequestMapping(value = AdminConstant.IMPORT_CATEGORY, method = RequestMethod.POST)
	public String importEps(@RequestParam("categoryFile") MultipartFile file, Model model, RedirectAttributes redirectAttrs,
			HttpServletRequest request,HttpServletResponse response) throws IOException {
		Response responseStatus = new Response();
		User sender = SessionUtil.getUserFromRequestSession(request);
		PermissionUtil.checkPermission(sender, ActionConstant.ADD_NEW_CMS);
		try {
			File file1 = new File(file.getOriginalFilename());
			file.transferTo(file1);
			Workbook workbook = WorkbookFactory.create(file1);
			Sheet sheet = workbook.getSheetAt(0);
			Category category = new Category();
			List<Category> categoryList = new ArrayList<Category>();
			Iterator<Row> itr = sheet.iterator();
			while (itr.hasNext()) {
				Row row = itr.next();
				if(row.getRowNum() != 0){
					category = categoryService.assignCategory(row,request);
					if(category !=null){
						categoryList.add(category);
					}
				}
			}
			boolean importCategory = categoryService.importCategory(categoryList,request);
			if (importCategory) {
				responseStatus = setMessage(CommonConstants.SUCCESS, AdminConstant.CATEGORY_IMPORTS);
			} else {
				responseStatus = setMessage(CommonConstants.ERROR, AdminConstant.CATEGORY_IMPORT_FAIL);
			}
			workbook.close();
		} catch (Exception e) {
			e.printStackTrace();
			responseStatus = setMessage(CommonConstants.ERROR, AdminConstant.CATEGORY_IMPORT_FAIL);
		}
		if (responseStatus.getStatus().equals(CommonConstants.SUCCESS)) {
			redirectAttrs.addFlashAttribute("success", responseStatus.getMessage());
		} else {
			redirectAttrs.addFlashAttribute("error", responseStatus.getMessage());
		}
		return "redirect:" + AdminConstant.CATEGORY_CONTROLLER + AdminConstant.VIEW_ALL_CATEGORY;
	}

}