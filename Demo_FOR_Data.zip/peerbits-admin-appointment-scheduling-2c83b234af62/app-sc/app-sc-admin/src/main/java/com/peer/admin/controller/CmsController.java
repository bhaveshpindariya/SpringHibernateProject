package com.peer.admin.controller;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.peer.admin.constant.AdminConstant;
import com.peer.admin.util.PermissionUtil;
import com.peer.admin.validate.CmsValidator;
import com.peer.constant.ActionConstant;
import com.peer.constant.CommonConstants;
import com.peer.enm.Particulars;
import com.peer.enm.Status;
import com.peer.enm.UserVisibilityForCMS;
import com.peer.scenity.entity.local.Cms;
import com.peer.scenity.entity.local.User;
import com.peer.scenity.entity.pojo.Response;
import com.peer.scenity.service.intf.ICmsService;
import com.peer.scenity.service.intf.MessageByLocaleService;
import com.peer.scenity.util.SessionUtil;
import com.peer.util.CommonUtil;
import com.peer.util.DateUtil;
import com.peer.util.DownloadFile;

@Controller
@RequestMapping(AdminConstant.CMS_CONTROLLER)
public class CmsController {
	private static Logger _log = Logger.getLogger(CmsController.class);

	private static final String ADD_CMS_PAGE = "cms/addCms";
	private static final String CMS_TNC_PAGE = "cms/viewtnc";
	private static final String VIEW_CMS_PAGE = "cms/viewCms";
	private static final String EDIT_CMS_PAGE = "cms/editCms";

	@Autowired
	private ICmsService cmsService;

	@Autowired
	private CmsValidator cmsValidator;

	@Autowired
	private MessageByLocaleService messageByLocaleService;

	@RequestMapping(AdminConstant.VIEW_ALL_CMS_MAPPING)
	public String viewAllCmsPage(Locale locale, Model model, HttpServletRequest request) {
		User sender = SessionUtil.getUserFromRequestSession(request);
		PermissionUtil.checkPermission(sender, ActionConstant.VIEW_CMS);
		_log.info("inside landing cms page ");
		return VIEW_CMS_PAGE;
	}

	@RequestMapping(AdminConstant.FETCH_CMS)
	@ResponseBody
	public ResponseEntity<Object> fetchCancel(Locale locale, Model model, HttpServletRequest request) {
		String start = request.getParameter("start");
		String length = request.getParameter("length");
		String draw = request.getParameter("draw");
		String cmsStatus = request.getParameter("cmsStatus");
		String cmsRole = request.getParameter("cmsRole");
		int startI = 0;
		int lengthI = 10;
		int status = -1;
		if (StringUtils.isNotEmpty(cmsStatus) && StringUtils.isNumeric(cmsStatus)) {
			status = Integer.parseInt(cmsStatus);
		}
		if (StringUtils.isNotBlank(start) && StringUtils.isNumeric(start)) {
			startI = Integer.parseInt(start);
		}
		if (StringUtils.isNotBlank(length) && StringUtils.isNumeric(length)) {
			lengthI = Integer.parseInt(length);
		}
		JSONArray jsonArray = cmsService.paginateCms(startI, lengthI, status, cmsRole);
		Long totalCms = cmsService.paginateCmsCount(startI, lengthI, status, cmsRole);
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("data", jsonArray);
		jsonObject.put("draw", draw);
		jsonObject.put("recordsTotal", totalCms);
		jsonObject.put("recordsFiltered", totalCms);
		return new ResponseEntity<Object>(jsonObject.toString(), HttpStatus.OK);
	}

	@RequestMapping(AdminConstant.EDIT_CMS_MAPPING)
	public String editPage(Locale locale, Model model, HttpServletRequest request, @ModelAttribute("cms") Cms cms) {
		User sender = SessionUtil.getUserFromRequestSession(request);
		PermissionUtil.checkPermission(sender, ActionConstant.EDIT_CMS);
		_log.info("inside landing edit cms page ");
		model.addAttribute("rolesList", UserVisibilityForCMS.getUserVisibilityForCMS());
		model.addAttribute("particulars", Arrays.asList(Particulars.values()));
		Cms foundCms = cmsService.findByIdLocal(cms.getId());
		model.addAttribute("cms", foundCms);
		return EDIT_CMS_PAGE;
	}

	@RequestMapping(AdminConstant.ADD_CMS_MAPPING)
	public String addCmsPage(Locale locale, Model model, HttpServletRequest request) {
		User sender = SessionUtil.getUserFromRequestSession(request);
		PermissionUtil.checkPermission(sender, ActionConstant.ADD_NEW_CMS);
		_log.info("inside landing add cms page ");
		model.addAttribute("rolesList", UserVisibilityForCMS.getUserVisibilityForCMS());
		model.addAttribute("particulars", Arrays.asList(Particulars.values()));
		model.addAttribute("cms", new Cms());
		return ADD_CMS_PAGE;
	}

	@RequestMapping(value = AdminConstant.ADD_OR_EDIT_CMS, method = RequestMethod.POST)
	public String addOrEditCms(RedirectAttributes redirectAttrs, Model model, Locale locale, HttpSession session,
			HttpServletRequest request, @ModelAttribute("cms") Cms cms, BindingResult bindingResult) {
		Response response = new Response();
		Boolean isEmpty = CommonUtil.checkNull(cms);
		if (!isEmpty) {
			try {
				boolean check = validateCms(model, cms, session, request, bindingResult, response);
				if (check) {
					if (cms.getId() == null || cms.getId().equals(0L)) {
						User sender = SessionUtil.getUserFromRequestSession(request);
						PermissionUtil.checkPermission(sender, ActionConstant.ADD_NEW_CMS);
						List<Cms> cmscheck = cmsService.findByCmsByNameAndPerticuler(cms);
						if (cmscheck.size() > 0) {
							response = setMessage(CommonConstants.WARNING, AdminConstant.CMS_EXIT);
						} else {
							try {
								_log.info("add data in Cms");
								cmsService.persistLocal(cms);
								response = setMessage(CommonConstants.SUCCESS, AdminConstant.CMS_SUCCESS);
							} catch (Exception e) {
								_log.error("Error:--", e);
								response = setMessage(CommonConstants.ERROR, AdminConstant.CMS_ERROR);
							}
						}
					} else {
						User sender = SessionUtil.getUserFromRequestSession(request);
						PermissionUtil.checkPermission(sender, ActionConstant.EDIT_CMS);
						List<Cms> cmscheck = cmsService.findByCmsByNameAndPerticulerId(cms);
						if (cmscheck.size() > 0) {
							response = setMessage(CommonConstants.WARNING, AdminConstant.CMS_DUBLICATE);
						} else {
							Cms cmsObject = cmsService.findByIdLocal(cms.getId());
							cms.setCreatedBy(cmsObject.getCreatedBy());
							cms.setCreatedOn(cmsObject.getCreatedOn());
							try {
								_log.info("update data in Cms");
								cmsService.mergeLocal(cms);
								response = setMessage(CommonConstants.SUCCESS, AdminConstant.CMS_UPDATE);
							} catch (Exception e) {
								_log.error("Error:--", e);
								response = setMessage(CommonConstants.ERROR, AdminConstant.CMS_ERROR);
							}
						}
					}
				} else {
					if (cms.getId() == null || cms.getId().equals(0L)) {
						model.addAttribute("rolesList", UserVisibilityForCMS.getUserVisibilityForCMS());
						model.addAttribute("particulars", Arrays.asList(Particulars.values()));
						model.addAttribute("cms", cms);
						return ADD_CMS_PAGE;
					} else {
						model.addAttribute("rolesList", UserVisibilityForCMS.getUserVisibilityForCMS());
						model.addAttribute("particulars", Arrays.asList(Particulars.values()));
						model.addAttribute("cms", cms);
						return EDIT_CMS_PAGE;
					}
				}
			} catch (Exception e) {
				_log.error("Error:--", e);
				response = setMessage(CommonConstants.ERROR, AdminConstant.CMS_ERROR);
			}
		} else {
			response = setMessage(CommonConstants.ERROR, AdminConstant.CMS_EXCEPTION);
		}
		if (response.getStatus().equals(CommonConstants.SUCCESS)) {
			redirectAttrs.addFlashAttribute("success", response.getMessage());
		} else {
			model.addAttribute("error", response.getMessage());
			if (cms.getId() == null || cms.getId().equals(0L)) {
				model.addAttribute("rolesList", UserVisibilityForCMS.getUserVisibilityForCMS());
				model.addAttribute("particulars", Arrays.asList(Particulars.values()));
				model.addAttribute("cms", cms);
				return ADD_CMS_PAGE;
			} else {
				model.addAttribute("rolesList", UserVisibilityForCMS.getUserVisibilityForCMS());
				model.addAttribute("particulars", Arrays.asList(Particulars.values()));
				model.addAttribute("cms", cms);
				return EDIT_CMS_PAGE;
			}
		}
		return "redirect:" + AdminConstant.CMS_CONTROLLER + AdminConstant.VIEW_ALL_CMS_MAPPING;

	}

	private boolean validateCms(Model model, Cms cms, HttpSession session, HttpServletRequest request,
			BindingResult bindingResult, Response response) {
		boolean validated = true;
		if (cms.getId() == null || cms.getId().equals(0L)) {
			cmsValidator.validate(cms, bindingResult);
			if (bindingResult.hasErrors()) {
				List<FieldError> errors = bindingResult.getFieldErrors();
				StringBuffer message = new StringBuffer();
				for (FieldError error : errors) {
					message.append(error.getDefaultMessage() + CommonConstants.MESSAGE);
				}
				response = setErrorValidate(CommonConstants.ERROR, message);
				model.addAttribute("error", response.getMessage());
				validated = false;
			}
			cms.setCreatedOn(new Date());
			cms.setUpdatedOn(new Date());
			cms.setCreatedBy(SessionUtil.getUserFromRequestSession(request));
			cms.setUpdatedBy(SessionUtil.getUserFromRequestSession(request));
			cms.setStatus(Status.ACTIVE);
		} else {
			cmsValidator.validate(cms, bindingResult);
			if (bindingResult.hasErrors()) {
				List<FieldError> errors = bindingResult.getFieldErrors();
				StringBuffer message = new StringBuffer();
				for (FieldError error : errors) {
					message.append(error.getDefaultMessage() + CommonConstants.MESSAGE);
				}
				response = setErrorValidate(CommonConstants.ERROR, message);
				model.addAttribute("error", response.getMessage());
				validated = false;
			}
			cms.setStatus(Status.ACTIVE);
			cms.setUpdatedOn(new Date());
			cms.setUpdatedBy(SessionUtil.getUserFromRequestSession(request));
		}
		return validated;
	}

	@RequestMapping(value = AdminConstant.VIEW_CMS_MAPPING, method = RequestMethod.POST)
	public String editCmsPage(Locale locale, Model model, HttpServletRequest request, @ModelAttribute("cms") Cms cms) {
		User sender = SessionUtil.getUserFromRequestSession(request);
		PermissionUtil.checkPermission(sender, ActionConstant.VIEW_CMS);
		_log.info("inside landing view cms ");
		Cms foundCms = cmsService.findByIdLocal(cms.getId());
		model.addAttribute("cms", foundCms);
		return CMS_TNC_PAGE;
	}

	@RequestMapping(value = AdminConstant.REMOVE_CMS, method = RequestMethod.POST)
	public String deleteUser(Locale locale, Model model, RedirectAttributes redirectAttrs, HttpServletRequest request,
			@ModelAttribute("role") Cms cms) {
		User sender = SessionUtil.getUserFromRequestSession(request);
		PermissionUtil.checkPermission(sender, ActionConstant.REMOVE_CMS);
		Response response = new Response();
		Cms foundCancel = cmsService.findByIdLocal(cms.getId());
		foundCancel.setStatus(Status.DELETED);
		foundCancel.setUpdatedBy(SessionUtil.getUserFromRequestSession(request));
		foundCancel.setUpdatedOn(new Date());
		try {
			_log.info("remove data in cms");
			cmsService.deleteLocal(foundCancel);
			response = setMessage(CommonConstants.SUCCESS, AdminConstant.CMS_DELETE);
		} catch (Exception e) {
			_log.error("Error:--", e);
			response = setMessage(CommonConstants.ERROR, AdminConstant.CMS_EXCEPTION);
		}
		if (response.getStatus().equals(CommonConstants.SUCCESS)) {
			redirectAttrs.addFlashAttribute("success", response.getMessage());
		} else {
			redirectAttrs.addFlashAttribute("error", response.getMessage());
		}
		return "redirect:" + AdminConstant.CMS_CONTROLLER + AdminConstant.VIEW_ALL_CMS_MAPPING;
	}

	private Response setErrorValidate(String type, StringBuffer message) {
		Response response = new Response();
		response.setStatus(type);
		response.setMessage(message.toString().substring(0, message.length() - 5));
		return response;
	}

	private Response setMessage(String type, String message) {
		Response response = new Response();
		response.setStatus(type);
		response.setMessage(messageByLocaleService.getMessage(message));
		return response;
	}

	@RequestMapping(value = AdminConstant.EXPORT_CMS, method = RequestMethod.POST)
	public void exportLocations(Model model, HttpServletRequest request, HttpServletResponse response)
			throws IOException {

		List<Cms> listCms = cmsService.findAllCmsData();
		net.sf.json.JSONObject jsonObject = new net.sf.json.JSONObject();
		net.sf.json.JSONObject jsonColumn = new net.sf.json.JSONObject();
		net.sf.json.JSONArray columnArray = new net.sf.json.JSONArray();
		List<String> colList = new ArrayList<String>(0);
		colList.add("Particular");
		colList.add("Role");
		colList.add("Content");
		colList.add("Content In Spanish");
		colList.add("Status");
		colList.add("Last Modified");
		for (int i = 0; i < colList.size(); i++) {
			net.sf.json.JSONObject jsonColData = new net.sf.json.JSONObject();
			jsonColData.put("key", colList.get(i));
			columnArray.add(jsonColData);
		}
		jsonColumn.put("col_data", columnArray);
		net.sf.json.JSONObject jsonObjData = new net.sf.json.JSONObject();
		net.sf.json.JSONArray rowArray = new net.sf.json.JSONArray();
		for (Cms cms : listCms) {
			net.sf.json.JSONObject cellCol = new net.sf.json.JSONObject();
			net.sf.json.JSONArray cell = new net.sf.json.JSONArray();
			for (String colName : colList) {
				switch (colName) {
					case "Particular":
						net.sf.json.JSONObject jsonRowData = new net.sf.json.JSONObject();
						jsonRowData.put("key", colName);
						if(cms.getParticular()!=null){
							jsonRowData.put("value", cms.getParticular());
						}else{
							jsonRowData.put("value", "");
						}
						cell.add(jsonRowData);
						break;
					case "Role":
						net.sf.json.JSONObject jsonRowData1 = new net.sf.json.JSONObject();
						jsonRowData1.put("key", colName);
						if(cms.getRole()!=null){
							jsonRowData1.put("value", cms.getRole());
						}else{
							jsonRowData1.put("value", "");
						}
						cell.add(jsonRowData1);
						break;
					case "Content":
						net.sf.json.JSONObject jsonRowData3 = new net.sf.json.JSONObject();
						jsonRowData3.put("key", colName);
						if(cms.getContent()!=null){
							jsonRowData3.put("value", cms.getContent());
						}else{
							jsonRowData3.put("value", "");
						}
						cell.add(jsonRowData3);
						break;
					case "Content In Spanish":
						net.sf.json.JSONObject jsonRowData4 = new net.sf.json.JSONObject();
						jsonRowData4.put("key", colName);
						if(cms.getContentInSpanish()!=null){
							jsonRowData4.put("value", cms.getContentInSpanish());
						}else{
							jsonRowData4.put("value", "");
						}
						cell.add(jsonRowData4);
						break;
					case "Status":
						net.sf.json.JSONObject jsonRowData5 = new net.sf.json.JSONObject();
						jsonRowData5.put("key", colName);
						jsonRowData5.put("value", cms.getStatus().name());
						cell.add(jsonRowData5);
						break;
					case "Last Modified":
						net.sf.json.JSONObject jsonRowData2 = new net.sf.json.JSONObject();
						jsonRowData2.put("key", colName);
						if(cms.getUpdatedOn()!=null){
							jsonRowData2.put("value", DateUtil.getFormatterDate(cms.getUpdatedOn()));
						}else{
							jsonRowData2.put("value", "");
						}
						cell.add(jsonRowData2);
						break;
					default:
						break;
				}
				cellCol.put("cell", cell);
			}
			rowArray.add(cellCol);
			jsonObjData.put("row", rowArray);
		}
		jsonObject.put("col", jsonColumn);
		jsonObject.put("data", jsonObjData);
		DownloadFile.downloadFile(AdminConstant.CMS_MODULENAME, AdminConstant.EXPORT_EXTENSION, jsonObject, request,
				response);
	}

	@RequestMapping(value = AdminConstant.IMPORT_CMS, method = RequestMethod.POST)
	public String importLocation(@RequestParam("cmsFile") MultipartFile file, Model model,RedirectAttributes redirectAttrs,HttpServletRequest request,
			HttpServletResponse response) throws IOException {
		User sender = SessionUtil.getUserFromRequestSession(request);
		PermissionUtil.checkPermission(sender, ActionConstant.ADD_NEW_CMS);
		Response responseStatus = new Response();
		try {
			File file1 = new File(file.getOriginalFilename());
			file.transferTo(file1);
			Workbook workbook = WorkbookFactory.create(file1);
			Sheet sheet = workbook.getSheetAt(0);
			Cms cms = new Cms();
			List<Cms> cmsList = new ArrayList<Cms>();
			Iterator<Row> itr = sheet.iterator();
			while (itr.hasNext()) {
				Row row = itr.next();
				if(row.getRowNum() != 0){
					cms = assignCms(row,request);
					if(cms !=null){
						cmsList.add(cms);
					}
				}
			}
			boolean importCms=cmsService.importCms(cmsList);
			if(importCms){
				responseStatus=setMessage(CommonConstants.SUCCESS,AdminConstant.CMS_IMPORTS);
			}else{
				responseStatus=setMessage(CommonConstants.ERROR,AdminConstant.CMS_IMPORT_FAIL);
			}
			workbook.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		if(responseStatus.getStatus().equals(CommonConstants.SUCCESS)){
			redirectAttrs.addFlashAttribute("success", responseStatus.getMessage());
		}else{
			redirectAttrs.addFlashAttribute("error", responseStatus.getMessage());
		}
		return "redirect:" + AdminConstant.CMS_CONTROLLER + AdminConstant.VIEW_ALL_CMS_MAPPING;
	}

	private Cms assignCms(Row row,HttpServletRequest request) {
		if(row.getCell(0) !=null && row.getCell(1) !=null && row.getCell(2) !=null && row.getCell(3) !=null){
			if ((!row.getCell(0).toString().trim().equalsIgnoreCase("null") && !row.getCell(0).toString().trim().equals(""))
					&& (!row.getCell(1).toString().trim().equalsIgnoreCase("null")
							&& !row.getCell(1).toString().trim().equals(""))
					&& (!row.getCell(2).toString().trim().equalsIgnoreCase("null")
							&& !row.getCell(2).toString().trim().equals(""))
					&& (!row.getCell(3).toString().trim().equalsIgnoreCase("null")
							&& !row.getCell(3).toString().trim().equals(""))) {
				Cms cms = new Cms();
				cms.setParticular(Particulars.getParticularsByString(row.getCell(0).toString()));
				cms.setRole(UserVisibilityForCMS.parse(row.getCell(1).toString()));
				cms.setUpdatedOn(new Date());
				cms.setContent(row.getCell(2).toString());
				cms.setContentInSpanish(row.getCell(3).toString());
				cms.setCreatedOn(new Date());
				cms.setCreatedBy(SessionUtil.getUserFromRequestSession(request));
				cms.setUpdatedBy(SessionUtil.getUserFromRequestSession(request));
				cms.setStatus(Status.ACTIVE);
				return cms;
			}else{
				return null;
			}
		}else{
			return null;
		}
	}
}