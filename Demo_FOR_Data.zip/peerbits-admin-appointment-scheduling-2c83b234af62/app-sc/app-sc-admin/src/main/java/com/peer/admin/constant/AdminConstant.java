package com.peer.admin.constant;

public class AdminConstant {

	private AdminConstant() {
	}

	public static final String COMMON = "common.message";

	// Login & Logout
	public static final String LOGIN_USER = "/validate";
	public static final String LOGIN = "/login";
	public static final String LOGOUT_USER = "/logout";
	public static final String FORGOT_PASSWORD = "/login/forgot-password";
	public static final String RESET_PASSWORD_ADMIN = "/login/resetpassword";
	public static final String UPDATE_PASSWORD_ADMIN = "/login/updatepassword";
	public static final String NEW_PASSWORD = "/login/update-password";
	public static final String LOGIN_RESET = "login.reset";
	public static final String LOGIN_SUCCESS = "login.success";
	public static final String LOGIN_LINK = "login.link";

	// DashBoard

	public static final String DASHBOARD_CONTROLLER = "/dashboard";
	public static final String DASHBOARD_INDEX = "/index";

	// Eps
	public static final String EPS_CONTROLLER = "/eps";
	public static final String FETCH_EPS = "/fetchEps";
	public static final String VIEW_EPS = "/view/all";
	public static final String ADD_OR_EDIT_EPS_URL = "/addOrEditEps";
	public static final String REMOVE_EPS = "/removeEps";
	public static final String EXPORT_EPS = "/exportEps";
	public static final String IMPORT_EPS = "/importEps";
	public static final String EPSMODULE_NAME = "EPS";
	public static final String EXPORT_EXTENSION = ".xlsx";

	public static final String EPS_IMPORTS = "eps.imports";
	public static final String EPS_IMPORT_FAIL = "eps.importfail";
	public static final String EPS_SUCCESS = "eps.success";
	public static final String EPS_UPDATE = "eps.update";
	public static final String EPS_DELETE = "eps.delete";
	public static final String EPS_EXIT = "eps.exit";
	public static final String EPS_DUBLICATE = "eps.duplicated";
	public static final String EPS_ERROR = "eps.error";
	public static final String EPS_EXCEPTION = "eps.exception";

	// Category
	
	public static final String CATEGORY_IMPORTS = "category.imports";
	public static final String CATEGORY_IMPORT_FAIL = "category.importfail";
	
	public static final String CATEGORY_CONTROLLER = "/category";
	public static final String VIEW_ALL_CATEGORY = "/view/all";
	public static final String VIEW_ALL_CONSULTATION = "/view/allConsultation";
	public static final String VIEW_ALL_PROCEDURE = "/view/allProcedure";
	public static final String FETCH_CONSULTATION = "/fetchConsultation";
	public static final String FETCH_PROCEDURE = "/fetchProcedures";

	public static final String ADD_CONSULTATION_CATEGORY = "/addConsultation";
	public static final String EDIT_CONSULTATION_CATEGORY = "/editConsultation";
	public static final String VIEW_CONSULTATION_CATEGORY = "/viewConsultation";
	public static final String ADD_CONSULTATION_CATEGORY_SUBMIT = "/addConsultationCategory";
	public static final String EDIT_CONSULTATION_CATEGORY_SUBMIT = "/editConsultationCategory";
	public static final String REMOVE_CONSULTATION_CATEGORY = "/removeConsultationCategory";

	public static final String ADD_PROCEDURE_CATEGORY = "/addProcedure";
	public static final String VIEW_PROCEDURE_CATEGORY = "/viewProcedure";
	public static final String EDIT_PROCEDURE_CATEGORY = "/editProcedure";
	public static final String ADD_PROCEDURE_CATEGORY_SUBBMIT = "/addProcedureCategory";
	public static final String EDIT_PROCEDURE_CATEGORY_SUBBMIT = "/editProcedureCategory";
	public static final String REMOVE_PROCEDURE_CATEGORY = "/removeProcedureCategory";
	public static final String FETCH_CATEGORIES_EPS_CONSULTANT = "/fetchCategoriesEpsConsultant";
	public static final String FETCH_SUBCATEGORIES = "/fetchSubCategories";

	public static final String PROCEDURE_CATEGORY_SUCCESS = "procedureCategory.success";
	public static final String PROCEDURE_CATEGORY_UPDATE = "procedureCategory.update";
	public static final String PROCEDURE_CATEGORY_EXIT = "procedureCategory.exit";
	public static final String PROCEDURE_CATEGORY_DUBLICATE = "procedureCategory.duplicated";
	public static final String PROCEDURE_CATEGORY_ERROR = "procedureCategory.error";
	public static final String PROCEDURE_CATEGORY_EXCEPTION = "procedureCategory.exception";
	public static final String PROCEDURE_CATEGORY_DELETE = "procedureCategory.delete";
	public static final String PROCEDURE_SUBCATEGORY_EXCEPTION = "procedureSubcategory.exception";
	public static final String PROCEDURE_SUBCATEGORY_EXIT = "procedureSubcategory.exit";
	public static final String PROCEDURE_SUBCATEGORY_DUBLICATE = "procedureSubcategory.duplicated";
	public static final String PROCEDURE_SUBCATEGORY_ERROR = "procedureSubcategory.error";

	public static final String PROCEDURE_SUBCATEGORY_EPS_EXIT = "procedureSubcategory.eps.exit";
	public static final String PROCEDURE_SUBCATEGORY_EPS_ERROR = "procedureSubcategory.eps.error";
	public static final String PROCEDURE_SUBCATEGORY_EPS_EXCEPTION = "procedureSubcategory.eps.exception";

	public static final String CONSULTATION_CATEGORY_SUCCESS = "consultationCategory.success";
	public static final String CONSULTATION_CATEGORY_UPDATE = "consultationCategory.update";
	public static final String CONSULTATION_CATEGORY_EXIT = "consultationCategory.exit";
	public static final String CONSULTATION_CATEGORY_ERROR = "consultationCategory.error";
	public static final String CONSULTATION_CATEGORY_DUBLICATE = "consultationCategory.duplicated";
	public static final String CONSULTATION_CATEGORY_EXCEPTION = "consultationCategory.exception";
	public static final String CONSULTATION_CATEGORY_DELETE = "consultationCategory.delete";
	public static final String CONSULTATION_SUBCATEGORY_EXIT = "consultationSubcategory.exit";
	public static final String CONSULTATION_SUBCATEGORY_EXCEPTION = "consultationSubcategory.exception";
	public static final String CONSULTATION_SUBCATEGORY_DUBLICATE = "consultationSubcategory.duplicated";
	public static final String CONSULTATION_SUBCATEGORY_ERROR = "consultationSubcategory.error";
	
	
	public static final String IMPORT_CATEGORY = "/importCategories";
	public static final String EXPORT_CATEGORY = "/exportCategories";
	public static final String CATEGORY_MODULE_NAME = "categories";

	// subject
	public static final String SUBJECT_CONTROLLER = "/subject";
	public static final String FETCH_SUBJECT = "/fetchSubject";
	public static final String VIEW_SUBJECTS = "/view/all";
	public static final String ADD_OR_EDIT_SUBJECT = "/addOrEditSubject";
	public static final String REMOVE_SUBJECT = "/remove";

	public static final String SUBJECT_SUCCESS = "subject.success";
	public static final String SUBJECT_UPDATE = "subject.update";
	public static final String SUBJECT_DELETE = "subject.delete";
	public static final String SUBJECT_EXIT = "subject.exit";
	public static final String SUBJECT_DUBLICATE = "subject.duplicated";
	public static final String SUBJECT_ERROR = "subject.error";
	public static final String SUBJECT_EXCEPTION = "subject.exception";

	// cancel
	public static final String CANCEL_CONTROLLER = "/cancel";
	public static final String FETCH_CANCEL = "/fetchCancel";
	public static final String VIEW_ALL_CANCEL_MAPPING = "/view/all";
	public static final String ADD_OR_EDIT_CANCEL = "/addOrEditCancel";
	public static final String REMOVE_CANCELLATION = "/remove";
	public static final String UPDATE_HOURS = "/hours";

	public static final String CANCEL_SUCCESS = "cancel.success";
	public static final String CANCEL_UPDATE = "cancel.update";
	public static final String CANCEL_DELETE = "cancel.delete";
	public static final String CANCEL_EXIT = "cancel.exit";
	public static final String CANCEL_DUBLICATE = "cancel.duplicated";
	public static final String CANCEL_ERROR = "cancel.error";
	public static final String CANCEL_EXCEPTION = "cancel.exception";

	// location
	public static final String LOCATION_CONTROLLER = "/location";
	public static final String FETCH_LOCATION = "/fetchLocation";
	public static final String VIEW_ALL_LOCATION_MAPPING = "/view/all";
	public static final String ADD_OR_EDIT_LOCATION = "addOrEditLocation";
	public static final String REMOVE_LOCATION = "/remove";

	public static final String LOCATION_IMPORTS = "location.imports";
	public static final String LOCATION_IMPORT_FAIL = "location.importfail";
	public static final String LOCATION_SUCCESS = "location.success";
	public static final String LOCATION_UPDATE = "location.update";
	public static final String LOCATION_DELETE = "location.delete";
	public static final String LOCATION_EXIT = "location.exit";
	public static final String LOCATION_DUBLICATE = "location.duplicated";
	public static final String LOCATION_ERROR = "location.error";
	public static final String LOCATION_EXCEPTION = "location.exception";
	
	public static final String IMPORT_LOCATION = "/importlocation";
	public static final String EXPORT_LOCATION = "/exportlocation";
	public static final String LOCATION_MODULENAME = "Location";

	// user
	public static final String USER_CONTROLLER = "/user";
	public static final String USER_FETCH = "/fetchSubAdmins";
	public static final String ADD_USER_MAPPING = "/addUser";
	public static final String VIEW_USER_MAPPING = "/viewUser";
	public static final String VIEW_ALL_USER_MAPPING = "/view/all";
	public static final String VIEW_DETAIL_MAPPING = "/viewdetail";
	public static final String ADD_OR_EDIT_USER = "/addOrEditUser";
	public static final String REMOVE_USER = "/remove";
	public static final String FETCH_USER_TYPE = "/fetchUsersByType";
	public static final String CHANGE_PASSWORD = "/changepassword";
	public static final String UPDATE_PASSWORD = "/updatepassword";
	public static final String RESET_PASSWORD_USER = "/resetPasswordUser";
	public static final String PROFILE = "/profile";

	public static final String USER_SUCCESS = "user.success";
	public static final String USER_UPDATE = "user.update";
	public static final String USER_DELETE = "user.delete";
	public static final String USER_EXIT = "user.exit";
	public static final String USER_DUBLICATE = "user.duplicated";
	public static final String USER_ERROR = "user.error";
	public static final String USER_EXCEPTION = "user.exception";
	
	public static final String USER_EXPORT = "/export";
	public static final String USER_MODULE_NAME = "Administrator";

	// cms
	public static final String CMS_CONTROLLER = "/cms";
	public static final String FETCH_CMS = "/fetchCms";
	public static final String ADD_CMS_MAPPING = "/addCms";
	public static final String VIEW_ALL_CMS_MAPPING = "/view/all";
	public static final String ADD_OR_EDIT_CMS = "/addOrEditCms";
	public static final String VIEW_CMS_MAPPING = "/viewCms";
	public static final String REMOVE_CMS = "/remove";
	public static final String EDIT_CMS_MAPPING = "/editCms";

	public static final String CMS_IMPORTS = "cms.imports";
	public static final String CMS_IMPORT_FAIL = "cms.importfail";
	public static final String CMS_SUCCESS = "cms.success";
	public static final String CMS_UPDATE = "cms.update";
	public static final String CMS_DELETE = "cms.delete";
	public static final String CMS_EXIT = "cms.exit";
	public static final String CMS_DUBLICATE = "cms.duplicated";
	public static final String CMS_ERROR = "cms.error";
	public static final String CMS_EXCEPTION = "cms.exception";
	
	public static final String EXPORT_CMS = "/export";
	public static final String IMPORT_CMS = "/import";
	public static final String CMS_MODULENAME = "CMS";

	// doctor
	public static final String DOCTOR_CONTROLLER = "/doctor";
	public static final String FETCH_DOCTOR = "/fetchDoctor";
	public static final String VIEW_ALL_DOCTOR_MAPPING = "/view/all";
	public static final String ADD_DOCTOR_MAPPING = "/addDoctor";
	public static final String RESET_PASSWORD = "/resetPassword";
	public static final String VIEW_DOCTOR = "/viewDoctorUser";
	public static final String VIEW_DOCTOR_MAPPING = "/viewDoctor";
	public static final String EDIT_DOCTOR_MAPPING = "/editDoctor";
	public static final String ADD_OR_EDIT_DOCTOR = "/addOrEditDoctor";
	public static final String REMOVE_DOCTOR = "/remove";
	
	public static final String REJECT_REQUESTS_DOCTOR = "/rejectDoctor";
	public static final String VIEW_DOCTOR_APPOINTMENT = "/viewDoctorAppointment";

	public static final String DOCTOR_SUCCESS = "doctor.success";
	public static final String DOCTOR_UPDATE = "doctor.update";
	public static final String DOCTOR_DELETE = "doctor.delete";
	public static final String DOCTOR_EXIT = "doctor.exit";
	public static final String DOCTOR_DUBLICATE = "doctor.duplicated";
	public static final String DOCTOR_ERROR = "doctor.error";
	public static final String DOCTOR_ERRORS = "doctor.errors";
	public static final String DOCTOR_EXCEPTION = "doctor.exception";

	public static final String PASSWORD_SUCCESS = "password.success";
	public static final String PASSWORD_ERROR = "password.error";
	public static final String PASSWORD_EXCEPTION = "password.exception";

	public static final String APPOINTMENT_DOCTOR = "/getAppointmentDoctor";
	public static final String EXPORT_DOCTOR = "/export";
	public static final String DOCTOR_MODULE_NAME = "Doctor";
	public static final String DOCTOR_APPOINTMENT_MODULE_NAME = "DoctorAppointment";
	public static final String DOCTOR_APPOINTMENT_SCHEDULE_NAME = "DoctorSchedule";
	public static final String EXPORT_DOCTOR_APPOINTMENT = "/exportDoctorAppointment";
	public static final String EXPORT_DOCTOR_SEDULER = "/exportDoctorSeduler";
	public static final String SEDULER_DOCTOR = "/getDoctorSchedules";
	public static final String MANAGE_SCHEDULE_DOCTOR_CANCEL_ACTION = "/doctorCancelSchedule";
	public static final String VIEW_DOCTOR_SEDULER = "/doctorViewSchedule";
	
	// affiliates
	public static final String AFFILIATES_CONTROLLER = "/affiliates";
	public static final String FETCH_AFFILIATES = "/fetchAffiliates";
	public static final String RESET_PASSWORD_AFFILIATES = "/resetPasswordAffiliates";
	public static final String VIEW_ALL_AFFILIATES_MAPPING = "/view/all";
	public static final String VIEW_AFFILIATES_MAPPING = "/viewAffiliates";
	public static final String VIEW_AFFILIATES = "/viewAffiliatesUser";
	public static final String EDIT_AFFILIATES = "/editAffiliates";
	public static final String WAITING_AFFILIATES = "/userWaitlists/view";
	public static final String REMOVE_AFFILIATES = "/remove";
	public static final String GET_APPOINTMENTS_USER = "/getAppointmentUsers";
	public static final String REJECT_REQUESTS_USER = "/rejectUser";
	public static final String VIEW_APPOINTMENT_AFFILIATES = "/viewAppointment";
	public static final String AFFILIATES_UPDATE = "affiliates.update";
	public static final String AFFILIATES_DELETE = "affiliates.delete";
	public static final String AFFILIATES_DUBLICATE = "affiliates.duplicated";
	public static final String AFFILIATES_ERROR = "affiliates.error";
	public static final String AFFILIATES_EXCEPTION = "affiliates.exception";
	
	public static final String EXPORT_AFFILIATES = "/exportAffiliates";
	public static final String AFFILIATES_MODULE_NAME = "Affiliates";

	// faq
	public static final String FAQ_CONTROLLER = "/faq";
	public static final String VIEW_ALL_FAQ_MAPPING = "/view/all";
	public static final String VIEW_FAQ_MAPPING = "/viewFaq";
	public static final String ADD_FAQ_MAPPING = "/addFaq";
	public static final String ADD_OR_EDIT_FAQ = "/addOrEditFaq";
	public static final String EDIT_FAQ_MAPPING = "/editfaq";
	public static final String FETCH_FAQ = "/fetchFaq";

	public static final String FAQ_SUCCESS = "faq.success";
	public static final String FAQ_UPDATE = "faq.update";
	public static final String FAQ_DELETE = "faq.delete";
	public static final String FAQ_EXIT = "faq.exit";
	public static final String FAQ_DUPLICATE = "faq.duplicated";
	public static final String FAQ_ERROR = "faq.error";
	public static final String FAQ_EXCEPTION = "faq.exception";

	// costing
	public static final String COSTING_CONTROLLER = "/costing";
	public static final String COSTING_ADD = "/addCosting";
	public static final String COSTING_VIEW_ALL = "/view/all";
	public static final String COSTING_EDIT = "/editCosting";
	public static final String COSTING_REMOVE = "/removeCosting";
	public static final String COSTING_UPDATE_WAGE = "/updateWage";
	public static final String COSTING_UPDATE = "/update";

	// Role
	public static final String ROLE_CONTROLLER = "/role";
	public static final String VIEW_ALL_ROLE_MAPPING = "/view/all";
	public static final String ADD_ROLE_MAPPING = "/addRole";
	public static final String ADD_EDIT_ROLE = "/addUpdateRole";
	public static final String VIEW_ROLE_MAPPING = "/viewRole";
	public static final String EDIT_ROLE_MAPPING = "/editRole";
	public static final String REMOVE_ROLE = "/remove";
	public static final String FETCH_Role = "/fetchRoles";

	// Password
	public static final String PASSWORD_VALIDATION = "password.validation";
	public static final String PASSWORD_CURRENT = "password.current";
	public static final String PASSWORD_PASSWORD = "password.password";
	public static final String PASSWORD_MATCH = "password.match";
	public static final String PASSWORD_SIZE = "password.size";

	// notifications
	public static final String NOTIFICATIONS_CONTROLLER = "/notifications";
	public static final String NOTIFICATIONS_VIEW_ALL = "/view/all";
	public static final String NOTIFICATIONS_SEND = "/sendNotifications";
	public static final String NOTIFICATIONS_HAS = "/hasNotifications";
	public static final String NOTIFICATIONS_FETCH = "/fetchNotifications";
	public static final String NOTIFICATIONS_MARK = "/markReadNotifications";
	public static final String NOTIFICATIONS_CLEAR = "/clearNotifications";
	public static final String SEND = "/send";
	public static final String REMOTE = "/remote";

	// Profile
	public static final String PROFILE_CONTROLLER = "/profile";
	public static final String VIEW_PROFILE_MAPPING = "/viewprofile";
	public static final String EDIT_PROFILE_MAPPING = "/editadminprofile";
	public static final String EDIT_PROFILE = "/editprofile";
	public static final String VERIFYEMAILMAPPING = "/verifyemail";

	public static final String PROFILE_EMAIL_ERROR = "userprofile.email";
	public static final String PROFILE_UPDATE = "userprofile.update";
	public static final String PROFILE_ERROR = "userprofile.error";

	// Appointment
	public static final String APPOINTMENT_CONTROLLER = "/appointments";
	public static final String APPOINTMENTS = "/appointments";
	public static final String GET_APPOINTMENTS = "/getAppointments";
	public static final String APPOINTMENT_REQUESTS = "/requests";
	public static final String VIEW_REQUESTS = "/view/request";
	public static final String VIEW_APPOINTMENT = "/view";
	public static final String ACCEPT_REQUESTS = "/accept/request";
	public static final String REJECT_REQUESTS = "/reject/request";
	public static final String GET_APPOINTMENT_REQUESTS = "/getRequests";
	public static final String SCHEDULE_APPOINTMENT = "/schedule";
	public static final String RE_SCHEDULE_APPOINTMENT = "/re-schedule";
	public static final String AVAILABLE_DATES_IN_MONTH = "/getAvailableDatesInMonth";
	public static final String AVAILABLE_DOCTORS = "/getAvailableDoctors";
	public static final String AVAILABLE_SLOTS = "/getAvailableSlots";
	public static final String VALIDATE_USER = "/validateUser";
	public static final String BOOK_APPOINTMENT = "/bookAppointment";
	public static final String UPLOAD_APPOINTMENT_FILES = "/uploadAppointmentFiles";
	
	public static final String EXPORT_APPOINTMENT = "/exportAppointment";
	public static final String APPOINTMENT_FILENAME = "Appointment";
	//public static final String IMPORT_APPOINTMENT = "/importAppointment";
	//public static final String APPOINTMENT_MODULE_NAME = "/importAppointment";

	// Appointment Scheduling
	public static final String APPOINTMENT_SCHEDULING_CONTROLLER = "/appointment-scheduling";
	public static final String APPOINTMENT_SCHEDULE_VIEW_ALL = "/view/all";
	public static final String NEW_APPOINTMENT_SCHEDULE = "/addSchedule";
	public static final String APPOINTMENT_SCHEDULE_VIEW_ACTION = "/view";
	public static final String APPOINTMENT_SCHEDULE_APPROVE_ACTION = "/approve";
	public static final String APPOINTMENT_SCHEDULE_CANCEL_ACTION = "/cancelSchedule";
	public static final String APPOINTMENT_SCHEDULE_GET_ACTIVE_EPS = "/getActiveEPS";
	public static final String APPOINTMENT_SCHEDULE_GET_CANCELLATION_REASONS = "/getCancelReasons";
	public static final String APPOINTMENT_SCHEDULE_DETAIL_SCHEDULE = "/detailSchedule";

	public static final String SCHEDULE_REQUEST_CANCEL_SUCCESS = "schedule.request.cancel.success";
	public static final String SCHEDULE_CANCEL_SUCCESS = "schedule.cancel.success";
	public static final String SCHEDULE_MODIFY_SUCCESS="schedule.modify.success";
	public static final String SCHEDULE_REQ_MODIFY_SUCCESS="schedule.request.modify.success";
	public static final String SCHEUDULE_MODIFY_ERROR="schedule.modify.issue";

	// Manage Schedule
	public static final String MANAGE_SCHEDULE_CONTROLLER = "/manageschedule";
	public static final String VIEW_ALL_SCHEDULE = "/viewall";
	public static final String VIEW_SCHEDULE = "/view";
	public static final String MANAGE_SCHEDULE_APPROVE_ACTION = "/modifySchedule";
	public static final String MANAGE_SCHEDULE_GET_ACTIVE_EPS = "/getActiveEPS";
	public static final String MANAGE_SCHEDULE_CANCEL_ACTION = "/cancelSchedule";
	public static final String MANAGE_SCHEDULE_GET_CANCELLATION_REASONS = "/getCancelReasons";
	public static final String EXPORT_SCHEDULE = "/exportSchedule";

	public static final String ADD_SCHEDULING_CONTROLLER = "/add-schedule";
	public static final String ADD_NEW_APPOINTMENT_SCHEDULE = "/addNewSchedule";
	public static final String SCHEDULE_ADD_ERROR = "addSchedule.error";
	public static final String SCHEDULE_ADD_SUCCESS = "addSchedule.sucsess";
	
	public static final String SCHEDULE_NAME = "Schedule";
}
