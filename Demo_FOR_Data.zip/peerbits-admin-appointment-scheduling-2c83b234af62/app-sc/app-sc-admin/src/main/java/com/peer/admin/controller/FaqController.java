package com.peer.admin.controller;


import java.util.Date;
import java.util.List;
import java.util.Locale;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import com.peer.admin.constant.AdminConstant;
import com.peer.admin.util.PermissionUtil;
import com.peer.admin.validate.FaqValidator;
import com.peer.constant.ActionConstant;
import com.peer.constant.CommonConstants;
import com.peer.enm.Status;
import com.peer.scenity.entity.local.Faq;
import com.peer.scenity.entity.local.User;
import com.peer.scenity.entity.pojo.Response;
import com.peer.scenity.service.intf.IFaqService;
import com.peer.scenity.service.intf.MessageByLocaleService;
import com.peer.scenity.util.SessionUtil;
import com.peer.util.CommonUtil;


@Controller
@RequestMapping(AdminConstant.FAQ_CONTROLLER)
public class FaqController {

private static Logger _log = Logger.getLogger(FaqController.class);
	
	private static final String ADD_FAQ_PAGE = "faq/addFaq";
	private static final String VIEW_ALL_FAQ_PAGE = "faq/viewAllFaq";
	private static final String EDIT_FAQ_PAGE = "faq/editFaq";
	private static final String VIEW_FAQ_PAGE = "faq/viewFaq";
	
	@Autowired
	private IFaqService faqService;
	
	@Autowired
	private FaqValidator faqValidator;
	
	@Autowired
	private MessageByLocaleService messageByLocaleService;

	@RequestMapping(AdminConstant.VIEW_ALL_FAQ_MAPPING)
	public String viewAllFaqPage(Locale locale, Model model,HttpServletRequest request) {
		User sender = SessionUtil.getUserFromRequestSession(request);
		PermissionUtil.checkPermission(sender, ActionConstant.VIEW_FAQ);
		_log.info("inside landing faq page ");
		return VIEW_ALL_FAQ_PAGE;
	}
	
	@RequestMapping(AdminConstant.FETCH_FAQ)
	@ResponseBody
	public ResponseEntity<Object> fetchFaq(Locale locale, Model model,HttpServletRequest request) {
		String start = request.getParameter("start");
		String length = request.getParameter("length");
		String draw = request.getParameter("draw");
		String faqStatus = request.getParameter("faqStatus");
		int startI = 0;
		int lengthI = 10;
		int status = -1;
		if (StringUtils.isNotEmpty(faqStatus) && StringUtils.isNumeric(faqStatus)) {
			status = Integer.parseInt(faqStatus);
		}
		if (StringUtils.isNotBlank(start) && StringUtils.isNumeric(start)) {
			startI = Integer.parseInt(start);
		}
		if (StringUtils.isNotBlank(length) && StringUtils.isNumeric(length)) {
			lengthI = Integer.parseInt(length);
		}
		JSONArray jsonArray = faqService.paginateFaq(startI, lengthI,status);
		Long totalFaq = faqService.paginateFaqCount(startI, lengthI, status);
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("data", jsonArray);
		jsonObject.put("draw", draw);
		jsonObject.put("recordsTotal", totalFaq);
		jsonObject.put("recordsFiltered", totalFaq);
		return new ResponseEntity<Object>(jsonObject.toString(), HttpStatus.OK);
	}
	
	@RequestMapping(value=AdminConstant.EDIT_FAQ_MAPPING, method = RequestMethod.POST)
	public String editFaqPage(Locale locale, Model model,HttpServletRequest request,@ModelAttribute("faq") Faq faq) {
		User sender = SessionUtil.getUserFromRequestSession(request);
		PermissionUtil.checkPermission(sender, ActionConstant.EDIT_FAQ);
		_log.info("inside landing edit faq page ");
		Faq foundFaq = faqService.findByIdLocal(faq.getFaqId());
		model.addAttribute("faq", foundFaq);
		return EDIT_FAQ_PAGE;
	}
	
	@RequestMapping(value=AdminConstant.VIEW_FAQ_MAPPING, method = RequestMethod.POST)
	public String viewFaqPage(Locale locale, Model model,HttpServletRequest request,@ModelAttribute("faq") Faq faq) {
		User sender = SessionUtil.getUserFromRequestSession(request);
		PermissionUtil.checkPermission(sender, ActionConstant.VIEW_FAQ);
		_log.info("inside landing selected faq page ");
		Faq foundFaq = faqService.findByIdLocal(faq.getFaqId());
		model.addAttribute("faq", foundFaq);
		return VIEW_FAQ_PAGE;
	}
	
	@RequestMapping(AdminConstant.ADD_FAQ_MAPPING)
	public String addFaqPage(Locale locale, Model model,HttpServletRequest request) {
		User sender = SessionUtil.getUserFromRequestSession(request);
		PermissionUtil.checkPermission(sender, ActionConstant.ADD_NEW_FAQ);
		_log.info("inside landing add FAQ page ");
		model.addAttribute("faq", new Faq());
		return ADD_FAQ_PAGE;
	}
	
	@RequestMapping(value = AdminConstant.ADD_OR_EDIT_FAQ, method = RequestMethod.POST)
	public String addOrEditFaq(RedirectAttributes redirectAttrs, Model model, Locale locale, HttpSession session,
			HttpServletRequest request, @ModelAttribute("faq") Faq faq, BindingResult bindingResult) {
		Response response = new Response();
		Boolean isEmpty = CommonUtil.checkNull(faq);
		if (!isEmpty) {
			try {
				boolean check = validateFaq(model, faq, session, request, bindingResult, response);
				if (check) {
					if (faq.getFaqId() == null || faq.getFaqId().equals(0L)) {
						User sender = SessionUtil.getUserFromRequestSession(request);
						PermissionUtil.checkPermission(sender, ActionConstant.ADD_NEW_FAQ);
						List<Faq> faqcheck = faqService.findByFaqByQuestion(faq);
						if (faqcheck.size() > 0) {
							response = setMessage(CommonConstants.WARNING, AdminConstant.FAQ_EXIT);
						} else {
							try {
								_log.info("add data in FAQ");
								faqService.persistLocal(faq);
								response = setMessage(CommonConstants.SUCCESS, AdminConstant.FAQ_SUCCESS);
							} catch (Exception e) {
								_log.error("Error:--", e);
								response = setMessage(CommonConstants.ERROR, AdminConstant.FAQ_ERROR);
							}
						}
					} else {
						User sender = SessionUtil.getUserFromRequestSession(request);
						PermissionUtil.checkPermission(sender, ActionConstant.EDIT_FAQ);
						List<Faq> faqcheck = faqService.findByFaqByQuestionId(faq);
						if (faqcheck.size() > 0) {
							response = setMessage(CommonConstants.WARNING, AdminConstant.FAQ_DUPLICATE);
						} else {
							Faq faqObject = faqService.findByIdLocal(faq.getFaqId());
							faq.setCreatedBy(faqObject.getCreatedBy());
							faq.setCreatedOn(faqObject.getCreatedOn());
							try {
								_log.info("update data in faq");
								faqService.mergeLocal(faq);
								response = setMessage(CommonConstants.SUCCESS, AdminConstant.FAQ_UPDATE);
							} catch (Exception e) {
								_log.error("Error:--", e);
								response = setMessage(CommonConstants.ERROR, AdminConstant.FAQ_ERROR);
							}
						}
					}
				} else {
					if (faq.getFaqId() == null || faq.getFaqId().equals(0L)) {
						model.addAttribute("faq", faq);
						return ADD_FAQ_PAGE;
					} else {
						model.addAttribute("faq", faq);
						return EDIT_FAQ_PAGE;
					}
				}
			} catch (Exception e) {
				_log.error("Error:--", e);
				response = setMessage(CommonConstants.ERROR, AdminConstant.FAQ_ERROR);
			}
		} else {
			response = setMessage(CommonConstants.ERROR, AdminConstant.FAQ_EXCEPTION);
		}
		if (response.getStatus().equals(CommonConstants.SUCCESS)) {
			redirectAttrs.addFlashAttribute("success", response.getMessage());
		} else {
			model.addAttribute("error", response.getMessage());
			if (faq.getFaqId() == null || faq.getFaqId().equals(0L)) {
				model.addAttribute("faq", faq);
				return ADD_FAQ_PAGE;
			} else {
				model.addAttribute("faq", faq);
				return EDIT_FAQ_PAGE;
			}
		}
		return "redirect:" + AdminConstant.FAQ_CONTROLLER + AdminConstant.VIEW_ALL_FAQ_MAPPING;
	}
	
	private boolean validateFaq(Model model,Faq faq, HttpSession session,HttpServletRequest request,BindingResult bindingResult,Response response) {
        boolean validated = true;
        if (faq.getFaqId() == null || faq.getFaqId().equals(0L)) {
        	faqValidator.validate(faq, bindingResult);
            if (bindingResult.hasErrors()) {
                List<FieldError> errors = bindingResult.getFieldErrors();
                StringBuffer message = new StringBuffer();
                for (FieldError error : errors) {
                    message.append(error.getDefaultMessage() + CommonConstants.MESSAGE);
                }
                response=setErrorValidate(CommonConstants.ERROR,message);
                model.addAttribute("error", response.getMessage());
                validated = false;
            }
            faq.setCreatedOn(new Date());
            faq.setUpdatedOn(new Date());
            faq.setCreatedBy(SessionUtil.getUserFromRequestSession(request));
            faq.setUpdatedBy(SessionUtil.getUserFromRequestSession(request));
            faq.setStatus(Status.ACTIVE);
        } else {
        	faqValidator.validate(faq, bindingResult);
        	_log.info("INSIDE VALIDATE: "+bindingResult.hasErrors());
            if (bindingResult.hasErrors()) {
                List<FieldError> errors = bindingResult.getFieldErrors();
                StringBuffer message = new StringBuffer();
                for (FieldError error : errors) {
                    message.append(error.getDefaultMessage() + CommonConstants.MESSAGE);
                }
                response=setErrorValidate(CommonConstants.ERROR,message);
                model.addAttribute("error", response.getMessage());
                validated = false;
            }
            faq.setStatus(Status.ACTIVE);
            faq.setUpdatedOn(new Date());
            faq.setUpdatedBy(SessionUtil.getUserFromRequestSession(request));
        }
        return validated;
    }
	
	private Response setErrorValidate(String type,StringBuffer message) {
		Response response = new Response();
		response.setStatus(type);
		response.setMessage(message.toString().substring(0, message.length() - 5));
		return response;
	}
	
	private Response setMessage(String type,String message) {
		Response response = new Response();
		response.setStatus(type);
		response.setMessage(messageByLocaleService.getMessage(message));
		return response;
	}
	
	
}
