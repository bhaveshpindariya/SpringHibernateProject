package com.peer.admin.controller;

import java.io.IOException;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.peer.admin.constant.AdminConstant;
import com.peer.admin.util.PermissionUtil;
import com.peer.admin.validate.DoctorEditValidator;
import com.peer.admin.validate.DoctorValidator;
import com.peer.admin.validate.PasswordValidator;
import com.peer.constant.ActionConstant;
import com.peer.constant.CommonConstants;
import com.peer.enm.AcessType;
import com.peer.enm.Action;
import com.peer.enm.CountryCode;
import com.peer.enm.Status;
import com.peer.enm.UserType;
import com.peer.scenity.entity.local.Appointments;
import com.peer.scenity.entity.local.Cancellation;
import com.peer.scenity.entity.local.Category;
import com.peer.scenity.entity.local.Eps;
import com.peer.scenity.entity.local.Locations;
import com.peer.scenity.entity.local.Schedule;
import com.peer.scenity.entity.local.ScheduleSlot;
import com.peer.scenity.entity.local.User;
import com.peer.scenity.entity.pojo.AppointmentDTO;
import com.peer.scenity.entity.pojo.FilesDTO;
import com.peer.scenity.entity.pojo.Response;
import com.peer.scenity.entity.pojo.ScheduleDTO;
import com.peer.scenity.entity.zeus.Medi;
import com.peer.scenity.entity.zeus.Programacion;
import com.peer.scenity.entity.zeus.ProgramacionMediRelacion;
import com.peer.scenity.entity.zeus.ProgramacionMedico;
import com.peer.scenity.service.intf.IAppointmentFilesService;
import com.peer.scenity.service.intf.IAppointmentsService;
import com.peer.scenity.service.intf.ICancellationService;
import com.peer.scenity.service.intf.ICategoryService;
import com.peer.scenity.service.intf.IEpsService;
import com.peer.scenity.service.intf.IFilesService;
import com.peer.scenity.service.intf.ILocationService;
import com.peer.scenity.service.intf.IScheduleService;
import com.peer.scenity.service.intf.IScheduleSlotService;
import com.peer.scenity.service.intf.ISettingsService;
import com.peer.scenity.service.intf.IUserService;
import com.peer.scenity.service.intf.MessageByLocaleService;
import com.peer.scenity.service.intf.ProgrammacionMedicoDetalleService;
import com.peer.scenity.service.intf.ZeusMediAsuntoService;
import com.peer.scenity.service.intf.ZeusMediService;
import com.peer.scenity.service.intf.ZeusProgramacionMediRelacionService;
import com.peer.scenity.service.intf.ZeusProgramacionService;
import com.peer.scenity.service.intf.ZeusProgrammacionMedicoService;
import com.peer.scenity.util.EncryptionUtil;
import com.peer.scenity.util.ServiceUtils;
import com.peer.scenity.util.SessionUtil;
import com.peer.util.CommonUtil;
import com.peer.util.DateUtil;
import com.peer.util.DownloadFile;

@Controller
@RequestMapping(AdminConstant.DOCTOR_CONTROLLER)
public class DoctorController {

	private static Logger _log = Logger.getLogger(DoctorController.class);

	@Autowired
	private IUserService userService;

	@Autowired
	private IFilesService fileService;

	@Autowired
	private ILocationService locationService;

	@Autowired
	private IScheduleSlotService scheduleSlotService;

	@Autowired
	private ZeusProgrammacionMedicoService programmacionService;

	@Autowired
	private ISettingsService settingService;

	@Autowired
	private IAppointmentFilesService appointmentFilesService;

	@Autowired
	private IScheduleService scheduleService;

	@Autowired
	private IEpsService epsService;

	@Autowired
	private ICancellationService cancellationService;

	@Autowired
	private DoctorValidator doctorValidator;

	@Autowired
	private PasswordValidator passwordValidator;

	@Autowired
	private ZeusProgramacionService zeusProgramacionService;

	@Autowired
	private ZeusProgramacionMediRelacionService zeusProgramacionMediRelacionService;

	@Autowired
	private DoctorEditValidator doctorEditValidator;

	@Autowired
	private MessageByLocaleService messageByLocaleService;

	@Autowired
	private ICategoryService categoryService;

	@Autowired
	private ZeusMediService zeusMediService;

	@Autowired
	private ZeusMediAsuntoService zeusMediAsuntoService;

	@Autowired
	private IAppointmentsService appointmentService;

	@Autowired
	private ProgrammacionMedicoDetalleService programmacionMedicoDetalleService;

	private static final String VIEW_ALL_DOCTOR_PAGE = "doctor/doctor";
	private static final String ADD_DOCTOR_PAGE = "doctor/addDoctor";
	private static final String EDIT_DOCTOR_PAGE = "doctor/editDoctor";
	private static final String VIEW_DOCTOR_PAGE = "doctor/viewDoctor";
	private static final String VIEW_DOCTOR_APPOINTMENT = "doctor/viewDoctorAppointment";
	private static final String VIEW_DOCTOR_SEDULERS = "doctor/viewDoctorSchedule";

	@RequestMapping(AdminConstant.VIEW_ALL_DOCTOR_MAPPING)
	public String doctorPage(Locale locale, Model model, HttpServletRequest request) {
		User sender = SessionUtil.getUserFromRequestSession(request);
		PermissionUtil.checkPermission(sender, ActionConstant.VIEW_DOCTOR);
		_log.info("inside landing Doctor page");
		return VIEW_ALL_DOCTOR_PAGE;
	}

	@RequestMapping(AdminConstant.FETCH_DOCTOR)
	@ResponseBody
	public ResponseEntity<Object> fetchDoctor(Locale locale, Model model, HttpServletRequest request) {
		String start = request.getParameter("start");
		String length = request.getParameter("length");
		String draw = request.getParameter("draw");
		String doctorStatus = request.getParameter("doctorStatus");
		String doctorAcess = request.getParameter("doctorAcess");
		int startI = 0;
		int lengthI = 10;
		int status = -1;
		int acessType = -1;
		if (StringUtils.isNotEmpty(doctorStatus) && StringUtils.isNumeric(doctorStatus)) {
			status = Integer.parseInt(doctorStatus);
		}
		if (StringUtils.isNotEmpty(doctorAcess) && StringUtils.isNumeric(doctorAcess)) {
			acessType = Integer.parseInt(doctorAcess);
		}
		if (StringUtils.isNotBlank(start) && StringUtils.isNumeric(start)) {
			startI = Integer.parseInt(start);
		}
		if (StringUtils.isNotBlank(length) && StringUtils.isNumeric(length)) {
			lengthI = Integer.parseInt(length);
		}
		JSONArray jsonArray = userService.paginateDoctor(startI, lengthI, status, acessType);
		Long totalDoctor = userService.paginateDoctorCount(startI, lengthI, status, acessType);
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("data", jsonArray);
		jsonObject.put("draw", draw);
		jsonObject.put("recordsTotal", totalDoctor);
		jsonObject.put("recordsFiltered", totalDoctor);
		return new ResponseEntity<Object>(jsonObject.toString(), HttpStatus.OK);
	}

	@RequestMapping(AdminConstant.ADD_DOCTOR_MAPPING)
	public String addDoctorPage(Locale locale, Model model, HttpServletRequest request) {
		User sender = SessionUtil.getUserFromRequestSession(request);
		PermissionUtil.checkPermission(sender, ActionConstant.ADD_NEW_DOCTOR);
		_log.info("inside landing add Doctor");
		model.addAttribute("doctor", new User());
		List<Eps> epsList = epsService.findAllLocalActive();
		model.addAttribute("epsList", epsList);
		List<Category> categoryList = categoryService.findAllCategory();
		model.addAttribute("categoryList", categoryList);
		model.addAttribute("acessType", Arrays.asList(AcessType.values()));
		return ADD_DOCTOR_PAGE;
	}

	@RequestMapping(value = AdminConstant.ADD_OR_EDIT_DOCTOR, method = RequestMethod.POST)
	public String addOrEidtDoctor(RedirectAttributes redirectAttrs, Model model, Locale locale, HttpSession session,
			HttpServletRequest request, @ModelAttribute("doctor") User doctor, BindingResult bindingResult) {
		Response response = new Response();
		String eps[] = request.getParameterValues("eps");
		String category[] = request.getParameterValues("duallistbox_demo2");
		if (eps != null) {
			if (eps.length > 0) {
				Set<Eps> epsSet = new HashSet<Eps>();
				for (String epsId : eps) {
					if (StringUtils.isNotEmpty(epsId)) {
						Eps epsdata = epsService.findByIdLocal(Long.parseLong(epsId));
						epsSet.add(epsdata);
					}
				}
				doctor.setEpsSet(epsSet);
			}
		}
		if (category != null) {
			if (category.length > 0) {
				Set<Category> categorySet = new HashSet<Category>();
				for (String categoryId : category) {
					if (StringUtils.isNotEmpty(categoryId)) {
						Category ca = categoryService.findByIdLocal(Long.parseLong(categoryId));
						categorySet.add(ca);
					}
				}
				doctor.setCategorySet(categorySet);
			}
		}
		Boolean isEmpty = CommonUtil.checkNull(doctor);
		if (!isEmpty) {
			try {
				boolean check = validateDoctor(model, doctor, session, request, bindingResult, response);
				if (check) {
					String enteredPassword = EncryptionUtil.encrypt(doctor.getPassword());
					doctor.setPassword(enteredPassword);
					if (doctor.getUserId() == null || doctor.getUserId().equals(0L)) {
						User sender = SessionUtil.getUserFromRequestSession(request);
						PermissionUtil.checkPermission(sender, ActionConstant.ADD_NEW_DOCTOR);
						Programacion pr = userService.getProgramacionId(doctor.getFullName());
						if (pr != null) {
							if (pr.isActivo()) {
								try {
									_log.info("add data in doctor user");
									List<Medi> medi = zeusMediService.findName(doctor.getFullName());
									if (medi.size() == 1) {
										medi.get(0).setTelefono(doctor.getContactNo());
										medi.get(0).setIdentificationcard(doctor.getIdentificationcard());
										medi.get(0).setRegistro(doctor.getRegistro());
										Medi medis = zeusMediService.mergeZeus(medi.get(0));
										zeusMediAsuntoService.delete(medis.getId());
										for (Category ca : doctor.getCategorySet()) {
											try {
												zeusMediAsuntoService.insert(medis.getId(), ca.getZeusCategoryId());
											} catch (Exception e) {
												_log.error("Error:--", e);
												response = setMessage(CommonConstants.ERROR,
														AdminConstant.DOCTOR_ERRORS);
											}
										}
										doctor.setProgramacionId(pr.getId());
										doctor.setZeusUserId(medis.getId());
										userService.persistLocal(doctor);
										response = setMessage(CommonConstants.SUCCESS, AdminConstant.DOCTOR_SUCCESS);
									} else {
										response = setMessage(CommonConstants.WARNING, AdminConstant.DOCTOR_EXIT);
									}

								} catch (Exception e) {
									_log.error("Error:--", e);
									response = setMessage(CommonConstants.ERROR, AdminConstant.DOCTOR_ERROR);
								}
							} else {
								response = setMessage(CommonConstants.WARNING, AdminConstant.DOCTOR_EXIT);
							}
						} else {
							try {
								_log.info("add data in doctor user");
								List<Medi> medis = zeusMediService.findName(doctor.getFullName());
								if (medis.size() == 0) {
									Medi medi = new Medi();
									medi.setEsMedico(true);
									medi.setApartaCita(false);
									medi.setCitaExterna(false);
									medi.setLeyendaConfirmarMedico(false);
									medi.setName(doctor.getFullName());
									medi.setTelefono(doctor.getContactNo());
									medi.setIdentificationcard(doctor.getIdentificationcard());
									medi.setRegistro(doctor.getRegistro());
									medi = zeusMediService.persistZeus(medi);
									for (Category ca : doctor.getCategorySet()) {
										try {
											zeusMediAsuntoService.insert(medi.getId(), ca.getZeusCategoryId());
										} catch (Exception e) {
											_log.error("Error:--", e);
											response = setMessage(CommonConstants.ERROR, AdminConstant.DOCTOR_ERRORS);
										}
									}
									Programacion programacion = new Programacion();
									programacion.setNombre(medi.getName());
									programacion.setActivo(true);
									try {
										programacion = zeusProgramacionService.persistZeus(programacion);
									} catch (Exception e) {
										_log.error("Error:--", e);
										response = setMessage(CommonConstants.ERROR, AdminConstant.DOCTOR_ERRORS);
									}
									ProgramacionMediRelacion programacionMediRelacion = new ProgramacionMediRelacion();
									programacionMediRelacion.setMediId(medi.getId());
									programacionMediRelacion.setProgramacionId(programacion.getId());
									programacionMediRelacion.setSedeId(2);
									try {
										programacionMediRelacion = zeusProgramacionMediRelacionService
												.persistZeus(programacionMediRelacion);
									} catch (Exception e) {
										_log.error("Error:--", e);
										response = setMessage(CommonConstants.ERROR, AdminConstant.DOCTOR_ERRORS);
									}
									doctor.setProgramacionId(programacion.getId());
									doctor.setZeusUserId(medi.getId());
									userService.persistLocal(doctor);
									response = setMessage(CommonConstants.SUCCESS, AdminConstant.DOCTOR_SUCCESS);
								} else {
									response = setMessage(CommonConstants.WARNING, AdminConstant.DOCTOR_EXIT);
								}
							} catch (Exception e) {
								_log.error("Error:--", e);
								response = setMessage(CommonConstants.ERROR, AdminConstant.DOCTOR_ERROR);
							}
						}
					} else {
						User sender = SessionUtil.getUserFromRequestSession(request);
						PermissionUtil.checkPermission(sender, ActionConstant.EDIT_DOCTOR);
						List<User> doctorcheck = userService.findAllDoctorsByEmail(doctor);
						if (doctorcheck.size() > 0) {
							response = setMessage(CommonConstants.WARNING, AdminConstant.DOCTOR_DUBLICATE);
						} else {
							User docObject = userService.findByIdLocal(doctor.getUserId());
							doctor.setCreatedBy(docObject.getCreatedBy());
							doctor.setCreatedOn(docObject.getCreatedOn());
							doctor.setProgramacionId(docObject.getProgramacionId());
							doctor.setZeusUserId(docObject.getZeusUserId());
							Long i = zeusMediService.findByDoctorNameAndId(doctor);
							if (i > 0) {
								response = setMessage(CommonConstants.WARNING, AdminConstant.DOCTOR_DUBLICATE);
							} else {
								try {
									_log.info("update data in doctor user");
									Medi medi = new Medi();
									medi.setId(docObject.getZeusUserId());
									medi.setEsMedico(true);
									medi.setApartaCita(false);
									medi.setCitaExterna(false);
									medi.setLeyendaConfirmarMedico(false);
									medi.setName(doctor.getFullName());
									medi.setTelefono(doctor.getContactNo());
									medi.setIdentificationcard(doctor.getIdentificationcard());
									medi.setRegistro(doctor.getRegistro());
									medi = zeusMediService.mergeZeus(medi);
									zeusMediAsuntoService.delete(medi.getId());
									for (Category ca : doctor.getCategorySet()) {
										try {
											zeusMediAsuntoService.insert(medi.getId(), ca.getZeusCategoryId());
										} catch (Exception e) {
											_log.error("Error:--", e);
											response = setMessage(CommonConstants.ERROR, AdminConstant.DOCTOR_ERRORS);
										}
									}
									Programacion programacion = new Programacion();
									programacion.setId(docObject.getProgramacionId());
									programacion.setNombre(medi.getName());
									programacion.setActivo(true);
									programacion = zeusProgramacionService.mergeZeus(programacion);
									userService.mergeLocal(doctor);
									response = setMessage(CommonConstants.SUCCESS, AdminConstant.DOCTOR_UPDATE);
								} catch (Exception e) {
									_log.error("Error:--", e);
									response = setMessage(CommonConstants.ERROR, AdminConstant.DOCTOR_ERROR);
								}
							}
						}
					}
				} else {
					if (doctor.getUserId() == null || doctor.getUserId().equals(0L)) {
						if (doctor.getPassword() != null) {
							String enteredPassword = EncryptionUtil.decrypt(doctor.getPassword());
							doctor.setPassword(enteredPassword);
						}
						model.addAttribute("doctor", doctor);
						List<Eps> epsList = epsService.findAllLocalActive();
						model.addAttribute("epsList", epsList);
						List<Category> categoryList = categoryService.findAllCategory();
						model.addAttribute("categoryList", categoryList);
						model.addAttribute("acessType", Arrays.asList(AcessType.values()));
						return ADD_DOCTOR_PAGE;
					} else {
						User foundUser = userService.findByIdLocal(doctor.getUserId());
						if (foundUser.getPassword() != null) {
							String enteredPassword = EncryptionUtil.decrypt(foundUser.getPassword());
							foundUser.setPassword(enteredPassword);
						}
						model.addAttribute("doctor", foundUser);
						List<Eps> epsList = epsService.findAllEpsForId(new ArrayList<Eps>(foundUser.getEpsSet()));
						model.addAttribute("epsList", epsList);
						List<Category> categoryList = categoryService
								.findAllCategoryForId(new ArrayList<Category>(foundUser.getCategorySet()));
						model.addAttribute("categoryList", categoryList);
						model.addAttribute("acessType", Arrays.asList(AcessType.values()));
						return EDIT_DOCTOR_PAGE;
					}
				}
			} catch (Exception e) {
				_log.error("Error:--", e);
				response = setMessage(CommonConstants.ERROR, AdminConstant.DOCTOR_ERROR);
			}
		} else {
			response = setMessage(CommonConstants.ERROR, AdminConstant.DOCTOR_EXCEPTION);
		}
		if (response.getStatus().equals(CommonConstants.SUCCESS)) {
			redirectAttrs.addFlashAttribute("success", response.getMessage());
		} else {
			model.addAttribute("error", response.getMessage());
			if (doctor.getUserId() == null || doctor.getUserId().equals(0L)) {
				if (doctor.getPassword() != null) {
					String enteredPassword = EncryptionUtil.decrypt(doctor.getPassword());
					doctor.setPassword(enteredPassword);
				}
				model.addAttribute("doctor", doctor);
				List<Eps> epsList = epsService.findAllLocalActive();
				model.addAttribute("epsList", epsList);
				List<Category> categoryList = categoryService.findAllCategory();
				model.addAttribute("categoryList", categoryList);
				model.addAttribute("acessType", Arrays.asList(AcessType.values()));
				return ADD_DOCTOR_PAGE;
			} else {
				User foundUser = userService.findByIdLocal(doctor.getUserId());
				if (foundUser.getPassword() != null) {
					String enteredPassword = EncryptionUtil.decrypt(foundUser.getPassword());
					foundUser.setPassword(enteredPassword);
				}
				model.addAttribute("doctor", foundUser);
				List<Eps> epsList = epsService.findAllEpsForId(new ArrayList<Eps>(foundUser.getEpsSet()));
				model.addAttribute("epsList", epsList);
				List<Category> categoryList = categoryService
						.findAllCategoryForId(new ArrayList<Category>(foundUser.getCategorySet()));
				model.addAttribute("categoryList", categoryList);
				model.addAttribute("acessType", Arrays.asList(AcessType.values()));
				return EDIT_DOCTOR_PAGE;
			}
		}
		return "redirect:" + AdminConstant.DOCTOR_CONTROLLER + AdminConstant.VIEW_ALL_DOCTOR_MAPPING;

	}

	@RequestMapping(value = AdminConstant.EDIT_DOCTOR_MAPPING, method = RequestMethod.POST)
	public String editDoctorPage(Locale locale, Model model, HttpServletRequest request,
			@ModelAttribute("doctor") User doctor) {
		User sender = SessionUtil.getUserFromRequestSession(request);
		PermissionUtil.checkPermission(sender, ActionConstant.EDIT_DOCTOR);
		_log.info("inside landing edit Doctor");
		User foundUser = userService.findByIdLocal(doctor.getUserId());
		if (foundUser.getPassword() != null) {
			String enteredPassword = EncryptionUtil.decrypt(foundUser.getPassword());
			foundUser.setPassword(enteredPassword);
		}
		model.addAttribute("doctor", foundUser);
		List<Eps> epsList = epsService.findAllEpsForId(new ArrayList<Eps>(foundUser.getEpsSet()));
		model.addAttribute("epsList", epsList);
		List<Category> categoryList = categoryService
				.findAllCategoryForId(new ArrayList<Category>(foundUser.getCategorySet()));
		model.addAttribute("categoryList", categoryList);
		model.addAttribute("acessType", Arrays.asList(AcessType.values()));
		return EDIT_DOCTOR_PAGE;
	}

	@RequestMapping(value = AdminConstant.RESET_PASSWORD, method = RequestMethod.POST)
	public String resetPassword(RedirectAttributes redirectAttrs, Model model, Locale locale, HttpSession session,
			HttpServletRequest request, @ModelAttribute("doctor") User doctor, BindingResult bindingResult) {
		User sender = SessionUtil.getUserFromRequestSession(request);
		PermissionUtil.checkPermission(sender, ActionConstant.CHANGE_PASSWORD_DOCTOR);
		Response response = new Response();
		Boolean isEmpty = CommonUtil.checkNull(doctor);
		User docObject = userService.findByIdLocal(doctor.getUserId());
		if (!isEmpty) {
			try {
				boolean check = validatePassword(doctor, session, request, bindingResult, response);
				if (check) {
					String enteredPassword = EncryptionUtil.encrypt(doctor.getPassword());
					docObject.setPassword(enteredPassword);
					docObject.setStatus(Status.ACTIVE);
					docObject.setUpdatedOn(new Date());
					docObject.setUpdatedBy(SessionUtil.getUserFromRequestSession(request));
					try {
						_log.info("update data in doctor user");
						userService.mergeLocal(docObject);
						response = setMessage(CommonConstants.SUCCESS, AdminConstant.PASSWORD_SUCCESS);
					} catch (Exception e) {
						_log.error("Error:--", e);
						response = setMessage(CommonConstants.ERROR, AdminConstant.PASSWORD_ERROR);
					}
				} else {
					redirectAttrs.addFlashAttribute("error", response.getMessage());
					redirectAttrs.addFlashAttribute("doctor", docObject);
				}
			} catch (Exception e) {
				_log.error("Error:--", e);
				response = setMessage(CommonConstants.ERROR, AdminConstant.PASSWORD_ERROR);
			}
		} else {
			response = setMessage(CommonConstants.ERROR, AdminConstant.PASSWORD_EXCEPTION);
		}
		if (response.getStatus().equals(CommonConstants.SUCCESS)) {
			redirectAttrs.addFlashAttribute("successPassword", response.getMessage());
		} else {
			redirectAttrs.addFlashAttribute("errorPassword", response.getMessage());
		}
		return "redirect:" + AdminConstant.DOCTOR_CONTROLLER + AdminConstant.VIEW_DOCTOR + "?userIds="
				+ doctor.getUserId();

	}

	@RequestMapping(value = AdminConstant.VIEW_DOCTOR_MAPPING, method = RequestMethod.POST)
	public String viewDoctorPage(Locale locale, Model model, HttpServletRequest request,
			@ModelAttribute("doctor") User doctor) {
		User sender = SessionUtil.getUserFromRequestSession(request);
		PermissionUtil.checkPermission(sender, ActionConstant.VIEW_DOCTOR);
		_log.info("inside landing view Doctor");
		User foundUser = userService.findByIdLocal(doctor.getUserId());
		model.addAttribute("doctor", foundUser);
		List<Locations> locationData = locationService.findAllLocal();
		model.addAttribute("locationList", locationData);
		List<Eps> epsList = epsService.findAllLocalActive();
		model.addAttribute("epsList", epsList);
		List<Cancellation> cancellationList = cancellationService.findByUserType(UserType.Admin);
		model.addAttribute("cancellationList", cancellationList);
		return VIEW_DOCTOR_PAGE;
	}

	@RequestMapping(AdminConstant.VIEW_DOCTOR)
	public String viewDoctorUser(Locale locale, Model model,
			@RequestParam(value = "userIds", required = true) Long userIds, HttpServletRequest request) {
		User sender = SessionUtil.getUserFromRequestSession(request);
		PermissionUtil.checkPermission(sender, ActionConstant.VIEW_DOCTOR);
		_log.info("inside landing view Doctor");
		User foundUser = userService.findByIdLocal(userIds);
		model.addAttribute("doctor", foundUser);
		List<Locations> locationData = locationService.findAllLocal();
		model.addAttribute("locationList", locationData);
		List<Eps> epsList = epsService.findAllLocalActive();
		model.addAttribute("epsList", epsList);
		List<Cancellation> cancellationList = cancellationService.findByUserType(UserType.Admin);
		model.addAttribute("cancellationList", cancellationList);
		return VIEW_DOCTOR_PAGE;
	}

	@RequestMapping(value = AdminConstant.REMOVE_DOCTOR, method = RequestMethod.POST)
	public String deleteUser(Locale locale, Model model, RedirectAttributes redirectAttrs, HttpServletRequest request,
			@ModelAttribute("doctor") User doctor) {
		User sender = SessionUtil.getUserFromRequestSession(request);
		PermissionUtil.checkPermission(sender, ActionConstant.DELETE_DOCTOR);
		Response response = new Response();
		User foundUser = userService.findByIdLocal(doctor.getUserId());
		foundUser.setStatus(Status.DELETED);
		foundUser.setUpdatedOn(new Date());
		foundUser.setUpdatedBy(SessionUtil.getUserFromRequestSession(request));
		try {
			_log.info("remove data in Doctor");
			userService.deleteLocal(foundUser);
			response = setMessage(CommonConstants.SUCCESS, AdminConstant.DOCTOR_DELETE);
		} catch (Exception e) {
			_log.error("Error:--", e);
			response = setMessage(CommonConstants.ERROR, AdminConstant.DOCTOR_EXCEPTION);
		}
		if (response.getStatus().equals(CommonConstants.SUCCESS)) {
			redirectAttrs.addFlashAttribute("success", response.getMessage());
		} else {
			redirectAttrs.addFlashAttribute("error", response.getMessage());
		}
		return "redirect:" + AdminConstant.DOCTOR_CONTROLLER + AdminConstant.VIEW_ALL_DOCTOR_MAPPING;
	}

	private boolean validateDoctor(Model model, User doctor, HttpSession session, HttpServletRequest request,
			BindingResult bindingResult, Response response) {
		boolean validated = true;
		if (doctor.getUserId() == null || doctor.getUserId().equals(0L)) {
			doctorValidator.validate(doctor, bindingResult);
			if (bindingResult.hasErrors()) {
				List<FieldError> errors = bindingResult.getFieldErrors();
				StringBuffer message = new StringBuffer();
				for (FieldError error : errors) {
					message.append(error.getDefaultMessage() + CommonConstants.MESSAGE);
				}
				response = setErrorValidate(CommonConstants.ERROR, message);
				model.addAttribute("error", response.getMessage());
				validated = false;
			}
			doctor.setAgreedToTerms(validated);
			doctor.setCountryCode(CountryCode.FIVESEVEN);
			doctor.setPrefferedLanguage(CommonConstants.LANGUAGE_ENGLISH);
			doctor.setUserType(UserType.Doctor);
			doctor.setCreatedOn(new Date());
			doctor.setUpdatedOn(new Date());
			doctor.setCreatedBy(SessionUtil.getUserFromRequestSession(request));
			doctor.setUpdatedBy(SessionUtil.getUserFromRequestSession(request));
			doctor.setStatus(Status.ACTIVE);
		} else {
			doctorEditValidator.validate(doctor, bindingResult);
			if (bindingResult.hasErrors()) {
				List<FieldError> errors = bindingResult.getFieldErrors();
				StringBuffer message = new StringBuffer();
				for (FieldError error : errors) {
					message.append(error.getDefaultMessage() + CommonConstants.MESSAGE);
				}
				response = setErrorValidate(CommonConstants.ERROR, message);
				model.addAttribute("error", response.getMessage());
				validated = false;
			}
			doctor.setAgreedToTerms(validated);
			doctor.setCountryCode(CountryCode.FIVESEVEN);
			doctor.setUserType(UserType.Doctor);
			doctor.setPrefferedLanguage(CommonConstants.LANGUAGE_ENGLISH);
			doctor.setStatus(Status.ACTIVE);
			doctor.setUpdatedOn(new Date());
			doctor.setUpdatedBy(SessionUtil.getUserFromRequestSession(request));
		}
		return validated;
	}

	private boolean validatePassword(User doctor, HttpSession session, HttpServletRequest request,
			BindingResult bindingResult, Response response) {
		boolean validated = true;
		passwordValidator.validate(doctor, bindingResult);
		if (bindingResult.hasErrors()) {
			List<FieldError> errors = bindingResult.getFieldErrors();
			StringBuffer message = new StringBuffer();
			for (FieldError error : errors) {
				message.append(error.getDefaultMessage() + CommonConstants.MESSAGE);
			}
			response = setErrorValidate(CommonConstants.ERROR, message);
			validated = false;
		}
		return validated;
	}

	private Response setErrorValidate(String type, StringBuffer message) {
		Response response = new Response();
		response.setStatus(type);
		response.setMessage(message.toString().substring(0, message.length() - 5));
		return response;
	}

	private Response setMessage(String type, String message) {
		Response response = new Response();
		response.setStatus(type);
		response.setMessage(messageByLocaleService.getMessage(message));
		return response;
	}

	@RequestMapping(value = AdminConstant.EXPORT_DOCTOR, method = RequestMethod.POST)
	public void exportEps(Model model, HttpServletRequest request, HttpServletResponse response) throws IOException {

		List<User> listUsers = userService.findAllLocal();
		net.sf.json.JSONObject jsonObject = new net.sf.json.JSONObject();
		net.sf.json.JSONObject jsonColumn = new net.sf.json.JSONObject();
		net.sf.json.JSONArray columnArray = new net.sf.json.JSONArray();
		List<String> colList = new ArrayList<String>(0);
		colList.add("Name");
		colList.add("Contact Number");
		colList.add("Email");
		colList.add("Privacy");
		colList.add("EPS");
		colList.add("Category");
		colList.add("Status");
		for (int i = 0; i < colList.size(); i++) {
			net.sf.json.JSONObject jsonColData = new net.sf.json.JSONObject();
			jsonColData.put("key", colList.get(i));
			columnArray.add(jsonColData);
		}
		jsonColumn.put("col_data", columnArray);
		net.sf.json.JSONObject jsonObjData = new net.sf.json.JSONObject();
		net.sf.json.JSONArray rowArray = new net.sf.json.JSONArray();
		for (User user : listUsers) {
			net.sf.json.JSONObject cellCol = new net.sf.json.JSONObject();
			net.sf.json.JSONArray cell = new net.sf.json.JSONArray();
			if (user.getUserType().name().equals(CommonConstants.USERTYPE_DOCTOR)) {
				for (String colName : colList) {
					switch (colName) {
					case "Name":
						net.sf.json.JSONObject jsonRowData = new net.sf.json.JSONObject();
						jsonRowData.put("key", colName);
						if (user.getFullName() != null) {
							jsonRowData.put("value", user.getFullName());
						} else {
							jsonRowData.put("value", "");
						}
						cell.add(jsonRowData);
						break;
					case "Contact Number":
						net.sf.json.JSONObject jsonRowData1 = new net.sf.json.JSONObject();
						jsonRowData1.put("key", colName);
						if (user.getContactNo() != null) {
							jsonRowData1.put("value", user.getContactNo());
						} else {
							jsonRowData1.put("value", "");
						}
						cell.add(jsonRowData1);
						break;
					case "Email":
						net.sf.json.JSONObject jsonRowData2 = new net.sf.json.JSONObject();
						jsonRowData2.put("key", colName);
						if (user.getEmailAddress() != null) {
							jsonRowData2.put("value", user.getEmailAddress());
						} else {
							jsonRowData2.put("value", "");
						}
						cell.add(jsonRowData2);
						break;
					case "Privacy":
						net.sf.json.JSONObject jsonRowData3 = new net.sf.json.JSONObject();
						jsonRowData3.put("key", colName);
						jsonRowData3.put("value", user.getPrivacy());
						cell.add(jsonRowData3);
						break;
					case "EPS":
						net.sf.json.JSONObject jsonRowData4 = new net.sf.json.JSONObject();
						jsonRowData4.put("key", colName);
						StringBuffer message = new StringBuffer();
						for (Eps eps : user.getEpsSet()) {
							message.append(eps.getEps() + ",");
						}
						if (message.toString().length() > 0) {
							jsonRowData4.put("value", message.toString().substring(0, message.length() - 1));
						} else {
							jsonRowData4.put("value", "");
						}
						cell.add(jsonRowData4);
						break;
					case "Category":
						net.sf.json.JSONObject jsonRowData5 = new net.sf.json.JSONObject();
						jsonRowData5.put("key", colName);
						message = new StringBuffer();
						for (Category category : user.getCategorySet()) {
							message.append(category.getName() + ",");
						}
						if (message.toString().length() > 0) {
							jsonRowData5.put("value", message.toString().substring(0, message.length() - 1));
						} else {
							jsonRowData5.put("value", "");
						}
						cell.add(jsonRowData5);
						break;
					case "Status":
						net.sf.json.JSONObject jsonRowData6 = new net.sf.json.JSONObject();
						jsonRowData6.put("key", colName);
						jsonRowData6.put("value", user.getStatus().name());
						cell.add(jsonRowData6);
						break;
					default:
						break;
					}
					cellCol.put("cell", cell);
				}
				rowArray.add(cellCol);
				jsonObjData.put("row", rowArray);
			}
		}
		jsonObject.put("col", jsonColumn);
		jsonObject.put("data", jsonObjData);

		DownloadFile.downloadFile(AdminConstant.DOCTOR_MODULE_NAME, AdminConstant.EXPORT_EXTENSION, jsonObject, request,
				response);
	}

	@RequestMapping(value = AdminConstant.EXPORT_DOCTOR_APPOINTMENT, method = RequestMethod.POST)
	public void exportDoctorAppointment(Model model, HttpServletRequest request, HttpServletResponse response,
			@ModelAttribute("doctor") User doctor) throws IOException {

		List<Appointments> appoinmentData = appointmentService.findDoctorsAppointmentsAll(doctor.getUserId(), null,
				null, 0, 0);
		net.sf.json.JSONObject jsonObject = new net.sf.json.JSONObject();
		net.sf.json.JSONObject jsonColumn = new net.sf.json.JSONObject();
		net.sf.json.JSONArray columnArray = new net.sf.json.JSONArray();
		List<String> colList = new ArrayList<String>(0);
		colList.add("User");
		colList.add("Doctor");
		colList.add("Appointment Date");
		colList.add("Time Slot");
		colList.add("Location");
		colList.add("Status");
		for (int i = 0; i < colList.size(); i++) {
			net.sf.json.JSONObject jsonColData = new net.sf.json.JSONObject();
			jsonColData.put("key", colList.get(i));
			columnArray.add(jsonColData);
		}
		jsonColumn.put("col_data", columnArray);
		net.sf.json.JSONObject jsonObjData = new net.sf.json.JSONObject();
		net.sf.json.JSONArray rowArray = new net.sf.json.JSONArray();
		for (Appointments appoinment : appoinmentData) {
			net.sf.json.JSONObject cellCol = new net.sf.json.JSONObject();
			net.sf.json.JSONArray cell = new net.sf.json.JSONArray();
			for (String colName : colList) {
				switch (colName) {
				case "User":
					net.sf.json.JSONObject jsonRowData = new net.sf.json.JSONObject();
					jsonRowData.put("key", colName);
					User user = appoinment.getUser();
					jsonRowData.put("value", user.getFullName());
					cell.add(jsonRowData);
					break;
				case "Doctor":
					net.sf.json.JSONObject jsonRowDatas = new net.sf.json.JSONObject();
					jsonRowDatas.put("key", colName);
					User users = appoinment.getDoctor();
					if (users != null) {
						jsonRowDatas.put("value", users.getFullName());
					} else {
						jsonRowDatas.put("value", "");
					}
					cell.add(jsonRowDatas);
					break;
				case "Appointment Date":
					net.sf.json.JSONObject jsonRowData1 = new net.sf.json.JSONObject();
					jsonRowData1.put("key", colName);
					if (null != appoinment.getAppointmentDate()) {
						jsonRowData1.put("value", DateUtil.getFormatterDate(appoinment.getAppointmentDate()));
					} else {
						jsonRowData1.put("value", "");
					}
					cell.add(jsonRowData1);
					break;
				case "Time Slot":
					net.sf.json.JSONObject jsonRowData2 = new net.sf.json.JSONObject();
					jsonRowData2.put("key", colName);
					ScheduleSlot slot = appoinment.getSlot();
					if (null != slot) {
						String timeSlot = DateUtil.concatDate(slot.getStartDate(), slot.getEndDate(),
								DateUtil.HH_MM_AM_PM);
						jsonRowData2.put("value", timeSlot);
					} else {
						jsonRowData2.put("value", "");
					}
					cell.add(jsonRowData2);
					break;
				case "Location":
					net.sf.json.JSONObject jsonRowData3 = new net.sf.json.JSONObject();
					jsonRowData3.put("key", colName);
					if (null != appoinment.getLocation()) {
						jsonRowData3.put("value", appoinment.getLocation().getLocation());
					} else {
						jsonRowData3.put("value", "");
					}
					cell.add(jsonRowData3);
					break;
				case "Status":
					net.sf.json.JSONObject jsonRowData4 = new net.sf.json.JSONObject();
					jsonRowData4.put("key", colName);
					jsonRowData4.put("value", ServiceUtils.getStatus(appoinment.getStatus().getStatusCode()));
					cell.add(jsonRowData4);
					break;
				default:
					break;
				}
				cellCol.put("cell", cell);
			}
			rowArray.add(cellCol);
			jsonObjData.put("row", rowArray);
		}
		jsonObject.put("col", jsonColumn);
		jsonObject.put("data", jsonObjData);

		DownloadFile.downloadFile(AdminConstant.DOCTOR_APPOINTMENT_MODULE_NAME, AdminConstant.EXPORT_EXTENSION,
				jsonObject, request, response);
	}

	@RequestMapping(value = AdminConstant.EXPORT_DOCTOR_SEDULER, method = RequestMethod.POST)
	public void exportDoctorSeduler(Model model, HttpServletRequest request, HttpServletResponse response,
			@ModelAttribute("doctor") User doctor) throws IOException {

		List<Schedule> listSchedule = scheduleService.getRequiredSchedules(null, -1, 0, 0, CommonConstants.ZERO);
		net.sf.json.JSONObject jsonObject = new net.sf.json.JSONObject();
		net.sf.json.JSONObject jsonColumn = new net.sf.json.JSONObject();
		net.sf.json.JSONArray columnArray = new net.sf.json.JSONArray();
		List<String> colList = new ArrayList<String>(0);
		colList.add("Start Date");
		colList.add("End Date");
		colList.add("Start Time");
		colList.add("End Time");
		colList.add("Doctor Name");
		colList.add("Location");
		colList.add("Appts. Booked");
		colList.add("Appts. To Be token");
		colList.add("Status");
		for (int i = 0; i < colList.size(); i++) {
			net.sf.json.JSONObject jsonColData = new net.sf.json.JSONObject();
			jsonColData.put("key", colList.get(i));
			columnArray.add(jsonColData);
		}
		jsonColumn.put("col_data", columnArray);
		net.sf.json.JSONObject jsonObjData = new net.sf.json.JSONObject();
		net.sf.json.JSONArray rowArray = new net.sf.json.JSONArray();
		for (Schedule sc : listSchedule) {
			net.sf.json.JSONObject cellCol = new net.sf.json.JSONObject();
			net.sf.json.JSONArray cell = new net.sf.json.JSONArray();
			if (sc.getDoctor().getUserId().equals(doctor.getUserId())) {
				for (String colName : colList) {
					switch (colName) {
					case "Start Date":
						net.sf.json.JSONObject jsonRowData10 = new net.sf.json.JSONObject();
						jsonRowData10.put("key", colName);
						if (sc.getStartDate() != null) {
							jsonRowData10.put("value", CommonConstants.FORMAT2.format(sc.getStartDate()));
						} else {
							jsonRowData10.put("value", "");
						}
						cell.add(jsonRowData10);
						break;
					case "End Date":
						net.sf.json.JSONObject jsonRowData11 = new net.sf.json.JSONObject();
						jsonRowData11.put("key", colName);
						if (sc.getEndDate() != null) {
							jsonRowData11.put("value", CommonConstants.FORMAT2.format(sc.getEndDate()));
						} else {
							jsonRowData11.put("value", "");
						}
						cell.add(jsonRowData11);
						break;
					case "Start Time":
						net.sf.json.JSONObject jsonRowData12 = new net.sf.json.JSONObject();
						jsonRowData12.put("key", colName);
						if (sc.getStartTime() != null) {
							jsonRowData12.put("value", sc.getStartTime());
						} else {
							jsonRowData12.put("value", "");
						}
						cell.add(jsonRowData12);
						break;
					case "End Time":
						net.sf.json.JSONObject jsonRowData13 = new net.sf.json.JSONObject();
						jsonRowData13.put("key", colName);
						if (sc.getEndTime() != null) {
							jsonRowData13.put("value", sc.getEndTime());
						} else {
							jsonRowData13.put("value", "");
						}
						cell.add(jsonRowData13);
						break;
					case "Doctor Name":
						net.sf.json.JSONObject jsonRowData14 = new net.sf.json.JSONObject();
						jsonRowData14.put("key", colName);
						if (sc.getDoctor().getFullName() != null) {
							jsonRowData14.put("value", sc.getDoctor().getFullName());
						} else {
							jsonRowData14.put("value", "");
						}
						cell.add(jsonRowData14);
						break;
					case "Location":
						net.sf.json.JSONObject jsonRowData1 = new net.sf.json.JSONObject();
						jsonRowData1.put("key", colName);
						if (sc.getLocation().getLocation() != null) {
							jsonRowData1.put("value", sc.getLocation().getLocation());
						} else {
							jsonRowData1.put("value", "");
						}
						cell.add(jsonRowData1);
						break;
					case "Appts. Booked":
						net.sf.json.JSONObject jsonRowData2 = new net.sf.json.JSONObject();
						jsonRowData2.put("key", colName);
						if (null != sc.getMaxAppointments() && sc.getMaxAppointments() != 0L) {
							jsonRowData2.put("value", sc.getMaxAppointments());
						} else {
							jsonRowData2.put("value", 0);
						}
						cell.add(jsonRowData2);
						break;
					case "Appts. To Be token":
						net.sf.json.JSONObject jsonRowData3 = new net.sf.json.JSONObject();
						jsonRowData3.put("key", colName);
						jsonRowData3.put("value",
								appointmentService.findScheduleAppointmentCount(Status.APPROVED, sc.getScheduleId()));
						cell.add(jsonRowData3);
						break;
					case "Status":
						net.sf.json.JSONObject jsonRowData6 = new net.sf.json.JSONObject();
						jsonRowData6.put("key", colName);
						jsonRowData6.put("value", ServiceUtils.getStatus(sc.getStatus().getStatusCode()));
						cell.add(jsonRowData6);
						break;
					default:
						break;
					}
					cellCol.put("cell", cell);
				}
				rowArray.add(cellCol);
				jsonObjData.put("row", rowArray);
			}
		}
		jsonObject.put("col", jsonColumn);
		jsonObject.put("data", jsonObjData);

		DownloadFile.downloadFile(AdminConstant.SCHEDULE_NAME, AdminConstant.EXPORT_EXTENSION, jsonObject, request,
				response);
	}

	@RequestMapping(AdminConstant.APPOINTMENT_DOCTOR)
	@ResponseBody
	public ResponseEntity<Object> filterAppointments(HttpServletRequest request) {
		Long doctor = CommonUtil.getLongValue(request, "userName");
		int start = CommonUtil.getIntValue(request, "start");
		String draw = request.getParameter("draw");
		int max = CommonUtil.getIntValue(request, "max");
		int statusValue = CommonUtil.getIntValue(request, "status");
		int pastStatusValue = 0;
		Set<Long> categorySet = new HashSet<Long>();
		Set<Long> childCategorySet = new HashSet<Long>();
		Date startDate = null;
		Date endDate = null;
		Date currentSlotTime = null;
		if (CommonUtil.getDateValue(request, "appointmentDate", DateUtil.DD_MM_YYYY) == null) {
			startDate = null;
			endDate = null;
			currentSlotTime = null;
		} else {
			startDate = DateUtil
					.getStartDateOfDay(CommonUtil.getDateValue(request, "appointmentDate", DateUtil.DD_MM_YYYY));
			endDate = DateUtil
					.getEndDateOfDay(CommonUtil.getDateValue(request, "appointmentDate", DateUtil.DD_MM_YYYY));
			currentSlotTime = null;
		}
		List<Status> statusList = ServiceUtils.getDoctorFilterStatus(statusValue, pastStatusValue);
		if (statusValue == -2) {
			currentSlotTime = new Date();
		}
		boolean hasModifyPermission = PermissionUtil.hasPermission(request, ActionConstant.MODIFY_APPOINTMENTS);

		JSONArray jsonArray = appointmentService.findDoctorsAppointmentsForDoctor(doctor, statusList, categorySet,
				childCategorySet, startDate, endDate, currentSlotTime, "", true, start, max, hasModifyPermission);

		Long count = appointmentService.filterDoctorsAppointmentsCount(doctor, statusList, categorySet,
				childCategorySet, startDate, endDate, currentSlotTime, "");

		JSONObject jsonObject = new JSONObject();
		jsonObject.put("data", jsonArray);
		jsonObject.put("draw", draw);
		jsonObject.put("recordsTotal", count);
		jsonObject.put("recordsFiltered", count);
		return new ResponseEntity<Object>(jsonObject.toString(), HttpStatus.OK);
	}

	@RequestMapping(AdminConstant.REJECT_REQUESTS_DOCTOR)
	public String rejectDoctor(HttpServletRequest request, Model model, RedirectAttributes redirectAttributes) {
		boolean isCancellable = true;
		User currentUser = SessionUtil.getUserFromRequestSession(request);
		Long appointmentsId = CommonUtil.getLongValue(request, "appointmentsId");
		Long userId = CommonUtil.getLongValue(request, "userIdForUsers");
		int statusCode = CommonUtil.getIntValue(request, "status");
		String reason = request.getParameter("cancellationReason");
		if (StringUtils.isNotBlank(reason) && "-1".equals(reason)) {
			reason = request.getParameter("otherReasonText");
		}
		try {
			Status status = Status.parse(statusCode);
			if (Status.CANCELLED.equals(status)) {
				Appointments appointments = appointmentService.findByIdLocal(appointmentsId);
				isCancellable = settingService.isAppointmentCancellable(appointments.getAppointmentDate(),
						appointments.getAppointmentTime(), appointments.getMedian());
			}
			if (isCancellable) {
				appointmentService.rejectRequest(currentUser, appointmentsId, reason, status);
				redirectAttributes.addFlashAttribute("success", CommonConstants.SUCCESS);
			} else {
				redirectAttributes.addFlashAttribute("error",
						messageByLocaleService.getMessage(CommonConstants.CANCELLATION_TIME_ERROR));
			}
		} catch (Exception e) {
			_log.error("", e);
			redirectAttributes.addFlashAttribute("error", CommonConstants.ERROR);
		}
		return "redirect:" + AdminConstant.DOCTOR_CONTROLLER + AdminConstant.VIEW_DOCTOR + "?userIds=" + userId;
	}

	@RequestMapping(AdminConstant.VIEW_DOCTOR_APPOINTMENT)
	public String viewDoctorAppointment(HttpServletRequest request, Model model) {
		PermissionUtil.checkPermission(request, ActionConstant.VIEW_APPOINTMENT);
		Long appointmentsId = CommonUtil.getLongValue(request, "appointmentsId");
		String userName = request.getParameter("userName");
		String date = request.getParameter("appointmentDate");
		int statusCode = CommonUtil.getIntValue(request, "statusCode");
		Appointments appointments = appointmentService.findByIdLocal(appointmentsId);

		if (null != appointments) {
			AppointmentDTO appointmentObject = appointmentService.getAppointmentDTO(appointments);
			List<FilesDTO> appointmentFiles = appointmentFilesService
					.getAppointmentFiles(appointments.getAppointmentsId());
			List<Cancellation> cancellationList = cancellationService.findByUserType(UserType.Admin);
			model.addAttribute("appointments", appointments);
			model.addAttribute("appointmentObject", appointmentObject);
			model.addAttribute("appointmentFiles", appointmentFiles);
			model.addAttribute("cancellationList", cancellationList);
			model.addAttribute("userName", userName);
			model.addAttribute("appointmentDate", date);
			model.addAttribute("statusCode", statusCode);
			model.addAttribute("appointmentStatus", ServiceUtils.getStatus(appointments.getStatus().getStatusCode()));
			model.addAttribute("placedOn",
					DateUtil.formateDate(appointments.getCreatedOn(), DateUtil.DD_MMM_YYYY_AM_PM));
			String cancelledDate = "";
			boolean cancellable = false;
			boolean cancelled = false;
			if (Status.CANCELLED.equals(appointments.getStatus())) {
				cancelled = true;
				cancelledDate = DateUtil.formateDate(appointments.getUpdatedOn(), DateUtil.DD_MMM_YYYY_AM_PM);
			} else {
				cancellable = settingService.isAppointmentCancellable(appointments.getAppointmentDate(),
						appointments.getAppointmentTime(), appointments.getMedian());
			}
			model.addAttribute("cancelled", cancelled);
			model.addAttribute("cancellable", cancellable);
			model.addAttribute("cancelledDate", cancelledDate);
		}
		return VIEW_DOCTOR_APPOINTMENT;
	}

	@RequestMapping(AdminConstant.SEDULER_DOCTOR)
	@ResponseBody
	public ResponseEntity<Object> getDoctorSchedules(HttpServletRequest request) {
		_log.info("get doctor schedules..");
		String dateStr = request.getParameter("filterDate");
		Long location = Long.parseLong(request.getParameter("filterLocation"));
		Integer status = Integer.parseInt(request.getParameter("filterStatus"));
		Long eps = Long.parseLong(request.getParameter("filterEps"));
		Long selectedDoctorId = Long.parseLong(request.getParameter("selectedDoctorId"));
		User loggedInDoctor = userService.findByIdLocal(selectedDoctorId);

		_log.info("filter doctor schedules -- " + dateStr + " -- location: " + location + " -- status: " + status
				+ " -- eps: " + eps);

		Date scheduleDate = new Date();
		List<Schedule> returnSc = new ArrayList<>();

		if (dateStr != null && !dateStr.equals("")) {
			LocalDate date = LocalDate.parse(dateStr, CommonConstants.FORMATTER);
			scheduleDate = Date.from(date.atStartOfDay().atZone(ZoneId.systemDefault()).toInstant());
		}
		if (location > 0 || status > 0 || eps > 0) {
			returnSc = scheduleService.filterAllDoctorSchedulesForDate(loggedInDoctor.getUserId(), scheduleDate,
					location, eps, status);
		} else {
			returnSc = scheduleService.getAllDoctorSchedulesForDate(loggedInDoctor.getUserId(), scheduleDate);
		}
		JSONArray returnArr = scheduleService.getArrayFromListWithViewDoctorScheduleActionBtns(returnSc);
		return new ResponseEntity<>(returnArr != null ? returnArr.toString() : "", HttpStatus.OK);
	}

	@RequestMapping(AdminConstant.MANAGE_SCHEDULE_DOCTOR_CANCEL_ACTION)
	public String doctorCancelSchedule(HttpServletRequest request, RedirectAttributes redirectAttributes) {
		Long cancelScheduleId = Long.parseLong(request.getParameter("scheduleId"));
		String cancelReason = request.getParameter("cancellationReasonScedule");
		if (cancelReason.equalsIgnoreCase("other")) {
			cancelReason = request.getParameter("otherReasonText");
		}
		Long userId = CommonUtil.getLongValue(request, "userIdForUserData");
		Schedule schedule = scheduleService.findByIdLocal(cancelScheduleId);
		schedule.setCancelReason(cancelReason);
		schedule.setStatus(Status.CANCELLED);
		schedule.setUpdatedBy(SessionUtil.getUserFromRequestSession(request));
		schedule.setUpdatedOn(new Date());
		schedule = scheduleService.mergeLocal(schedule);
		inactiveSlots(cancelScheduleId);
		ProgramacionMedico zeusSchedule = programmacionService.findByIdZeus(schedule.getZeusScheduleId());
		zeusSchedule.setActivo(false);
		moveAllAppointmentstoWaitlist(schedule.getScheduleId());
		programmacionMedicoDetalleService.deleteDetalle(schedule.getZeusScheduleId());

		redirectAttributes.addFlashAttribute(CommonConstants.SUCCESS, AdminConstant.SCHEDULE_CANCEL_SUCCESS);
		scheduleService.sendNotification(schedule, Action.CANCELLED);

		return "redirect:" + AdminConstant.DOCTOR_CONTROLLER + AdminConstant.VIEW_DOCTOR + "?userIds=" + userId;
	}

	private void inactiveSlots(long scheduleId) {
		List<ScheduleSlot> slots = scheduleSlotService.getBySlotsByScheduleId(scheduleId);
		for (ScheduleSlot scheduleSlot : slots) {
			scheduleSlot.setStatus(Status.CANCELLED);
			scheduleSlotService.mergeLocal(scheduleSlot);
		}
	}

	private void moveAllAppointmentstoWaitlist(long scheduleId) {
		List<Appointments> appointments = appointmentService.getAllScheduleAppointment(Status.APPROVED, scheduleId);
		for (Appointments appointment : appointments) {
			appointment.setSlot(null);
			appointment.setStatus(Status.WAITING);
			appointmentService.mergeLocal(appointment);
		}
	}

	@RequestMapping(AdminConstant.VIEW_DOCTOR_SEDULER)
	public String doctorViewSchedule(Model model, @ModelAttribute("schedule") Schedule schedule,
			HttpServletRequest request) {
		User user = SessionUtil.getUserFromRequestSession(request);
		Schedule schedule2 = scheduleService.findByIdLocal(schedule.getScheduleId());
		ScheduleDTO dto = scheduleService.convertScheduleToScheduleDTO(schedule2);
		model.addAttribute("selectedSchedule", dto);
		List<Schedule> lst = scheduleService.getRequiredSchedules(schedule2.getStartDate(), -1, 0, 0,
				schedule2.getScheduleId());
		String profileImagePath = fileService.getFilePath(user.getProfileImg());
		model.addAttribute("profileImagePath", profileImagePath);
		model.addAttribute("schedulelist", lst);
		return VIEW_DOCTOR_SEDULERS;
	}

}
