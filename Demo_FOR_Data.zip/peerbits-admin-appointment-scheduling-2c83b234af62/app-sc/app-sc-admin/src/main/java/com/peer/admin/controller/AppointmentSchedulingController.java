package com.peer.admin.controller;

import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Objects;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.peer.admin.constant.AdminConstant;
import com.peer.constant.CommonConstants;
import com.peer.enm.Action;
import com.peer.enm.Status;
import com.peer.scenity.entity.local.Appointments;
import com.peer.scenity.entity.local.Eps;
import com.peer.scenity.entity.local.Schedule;
import com.peer.scenity.entity.local.ScheduleSlot;
import com.peer.scenity.entity.pojo.Response;
import com.peer.scenity.entity.pojo.ScheduleDTO;
import com.peer.scenity.entity.zeus.ProgramacionMedico;
import com.peer.scenity.entity.zeus.PuntoAtencion;
import com.peer.scenity.service.intf.IAppointmentsService;
import com.peer.scenity.service.intf.ICancellationService;
import com.peer.scenity.service.intf.IEpsService;
import com.peer.scenity.service.intf.IScheduleService;
import com.peer.scenity.service.intf.IScheduleSlotService;
import com.peer.scenity.service.intf.MessageByLocaleService;
import com.peer.scenity.service.intf.ProgrammacionMedicoDetalleService;
import com.peer.scenity.service.intf.ZeusProgrammacionMedicoService;
import com.peer.scenity.service.intf.ZeusPuntoAtencionService;
import com.peer.scenity.util.SessionUtil;

@Controller
@RequestMapping(AdminConstant.APPOINTMENT_SCHEDULING_CONTROLLER)
public class AppointmentSchedulingController {

	public static Logger _log = Logger.getLogger(AppointmentSchedulingController.class);
	public static final String NEW_SCHEDULE_FORM = "schedule/add";
	public static final String SCHEDULE_LIST = "schedule/list";
	public static final String SCHEDULE_VIEW = "schedule/view";

	@Autowired
	private IScheduleSlotService scheduleSlotService;

	@Autowired
	private IScheduleService scheduleService;

	@Autowired
	private MessageByLocaleService messageByLocaleService;

	@Autowired
	private ZeusProgrammacionMedicoService programmacionService;

	@Autowired
	private IEpsService epsService;

	@Autowired
	private ICancellationService cancellationService;

	@Autowired
	private IAppointmentsService appointmentService;

	@Autowired
	private ProgrammacionMedicoDetalleService programmacionMedicoDetalleService;
	
	@Autowired
	private ZeusPuntoAtencionService zeusPuntoAtencionService;

	@RequestMapping(AdminConstant.APPOINTMENT_SCHEDULE_VIEW_ALL)
	public String viewAllScheduleRequests(Model model) {
		return SCHEDULE_LIST;
	}

	@RequestMapping(AdminConstant.NEW_APPOINTMENT_SCHEDULE)
	public String scheduleAppointment(Model model) {
		return NEW_SCHEDULE_FORM;
	}

	@RequestMapping(AdminConstant.APPOINTMENT_SCHEDULE_VIEW_ACTION)
	public String viewScheduleDetail(Locale locale, Model model, @ModelAttribute("schedule") Schedule schedule) {
		Schedule schedule2 = scheduleService.findByIdLocal(schedule.getScheduleId());
		model.addAttribute("selectedSchedule", scheduleService.convertScheduleToScheduleDTO(schedule2));
		List<Schedule> lst = null;
		if (schedule2.getStatus().equals(Status.AWAITING_CANCELLATION_APPROVAL)) {
			lst = scheduleService.getAllNotCancelledSchedules(schedule2.getStartDate(),
					schedule2.getDoctor().getUserId());
		} else {
			lst = scheduleService.getActiveSchedules(schedule2.getStartDate(), schedule2.getDoctor().getUserId());
		}
		_log.info("current dat schedules: " + lst.size());
		List<ScheduleDTO> dtoList = scheduleService.convertScheduleListToScheduleDTOList(lst);
		model.addAttribute("schedulelist", dtoList);
		return SCHEDULE_VIEW;
	}

	@RequestMapping(AdminConstant.APPOINTMENT_SCHEDULE_CANCEL_ACTION)
	public String cancelSchedule(Locale locale, Model model, HttpServletRequest request,
			RedirectAttributes redirectAttributes) {

		Response response = null;
		long scheduleId = Long.parseLong(request.getParameter("scheduleId"));
		String cancelReason = request.getParameter("cancelReasonModal");
		if (!Objects.isNull(cancelReason) && cancelReason.equals("other")) {
			cancelReason = request.getParameter("reasonOtherModal");
		}
		Schedule schedule = scheduleService.findByIdLocal(scheduleId);

		if (schedule.getStatus().equals(Status.AWAITING_CANCELLATION_APPROVAL)
				|| schedule.getStatus().equals(Status.AWAITING_MODIFICATION_APPROVAL)) {

			updateSlotsStatus(scheduleId, Status.ACTIVE);
			scheduleService.removeChildSchedule(scheduleId);
			schedule.setStatus(Status.ACTIVE);
			schedule = scheduleService.mergeLocal(schedule);
			response = setMessage(CommonConstants.SUCCESS, AdminConstant.SCHEDULE_REQUEST_CANCEL_SUCCESS);
			scheduleService.sendNotification(schedule, Action.REQUEST_CANCELLED);

		} else if (schedule.getStatus().equals(Status.AWAITING_APPROVAL)) {
			schedule.setCancelReason(cancelReason);
			schedule.setStatus(Status.CANCELLED);
			schedule = scheduleService.mergeLocal(schedule);
			response = setMessage(CommonConstants.SUCCESS, AdminConstant.SCHEDULE_REQUEST_CANCEL_SUCCESS);
			scheduleService.sendNotification(schedule, Action.REQUEST_CANCELLED);
		} else if (schedule.getStatus().equals(Status.ACTIVE)) {
			schedule.setCancelReason(cancelReason);
			moveAllAppointmentstoWaitlist(schedule.getScheduleId());
			programmacionMedicoDetalleService.deleteDetalle(schedule.getZeusScheduleId());
			scheduleSlotService.deleteAllSlotsFromDB(schedule.getScheduleId());
			ProgramacionMedico zeusSchedule = programmacionService.findByIdZeus(schedule.getZeusScheduleId());
			zeusSchedule.setActivo(false);
			programmacionService.deleteZeus(zeusSchedule);

			schedule.setStatus(Status.CANCELLED);
			schedule = scheduleService.mergeLocal(schedule);
			response = setMessage(CommonConstants.SUCCESS, AdminConstant.SCHEDULE_CANCEL_SUCCESS);
			scheduleService.sendNotification(schedule, Action.CANCELLED);
		}

		redirectAttributes.addFlashAttribute(response.getStatus(), response.getMessage());

		return "redirect:" + AdminConstant.APPOINTMENT_SCHEDULING_CONTROLLER
				+ AdminConstant.APPOINTMENT_SCHEDULE_VIEW_ALL;
	}

	@RequestMapping(AdminConstant.APPOINTMENT_SCHEDULE_APPROVE_ACTION)
	public String approveSchedule(Locale locale, Model model, HttpServletRequest request,
			@ModelAttribute("schedule") Schedule schedule, RedirectAttributes redirectAttributes) {
		Response response = null;
		Response response1 = null;
		Schedule schedule2 = scheduleService.findByIdLocal(schedule.getScheduleId());

		String fetchedStartTime = schedule.getStartTime();
		String fetchedEndTime = schedule.getEndTime();
		Eps fetchedEPS = epsService.findByIdLocal(Long.parseLong(request.getParameter("epsId")));

		if (schedule2.getStatus().equals(Status.AWAITING_APPROVAL)) {
			schedule2.setStartTime(fetchedStartTime);
			schedule2.setEndTime(fetchedEndTime);
			schedule2.setEps(fetchedEPS);
			schedule2.setMaxAppointments(schedule.getMaxAppointments());
			response1 = scheduleSlotService.scheduleValidator(schedule2);
			if (response1.getStatus().equals(CommonConstants.SUCCESS)) {
				Long programacionMedicoId = programmacionService.addScheduleZeus(schedule2);
				response1 = scheduleSlotService.addScheduleSlots(schedule2, programacionMedicoId);
				if (response1.getStatus().equals(CommonConstants.SUCCESS)) {
					if (!Objects.isNull(programacionMedicoId) && programacionMedicoId != 0) {
						schedule2.setZeusScheduleId(programacionMedicoId);
						schedule2.setUpdatedBy(SessionUtil.getUserFromRequestSession(request));
						schedule2.setUpdatedOn(new Date());
						schedule2.setStatus(Status.ACTIVE);
						schedule2 = scheduleService.mergeLocal(schedule2);
						response = setMessage(CommonConstants.SUCCESS, CommonConstants.SCHEDULE_APPROVED);
						scheduleService.sendNotification(schedule2, Action.REQUEST_APPROVED);
					}
				}
			}
		} else if (schedule2.getStatus().equals(Status.AWAITING_MODIFICATION_APPROVAL)
				|| schedule2.getStatus().equals(Status.ACTIVE)) {
			schedule2.setStartTime(fetchedStartTime);
			schedule2.setEndTime(fetchedEndTime);
			schedule2.setEps(fetchedEPS);
			schedule2.setMaxAppointments(schedule.getMaxAppointments());
			Response responseValidate = scheduleSlotService.scheduleValidator(schedule2);
			if (responseValidate.getStatus().equals(CommonConstants.ERROR)) {
				response = responseValidate;
			} else {
				try {
					moveAllAppointmentstoWaitlist(schedule2.getScheduleId());
					scheduleSlotService.deleteAllSlotsFromDB(schedule2.getScheduleId());
					response=scheduleSlotService.addScheduleSlots(schedule2, schedule2.getZeusScheduleId());
					if (response.getStatus().equals(CommonConstants.SUCCESS)) {
						programmacionMedicoDetalleService.deleteDetalle(schedule2.getZeusScheduleId());
						updateZeus(schedule2);
						if (schedule2.getStatus().equals(Status.AWAITING_MODIFICATION_APPROVAL)) {
							scheduleService.removeChildSchedule(schedule2.getScheduleId());
						}
						schedule2.setUpdatedBy(SessionUtil.getUserFromRequestSession(request));
						schedule2.setUpdatedOn(new Date());
						schedule2.setEps(fetchedEPS);
						schedule2.setMaxAppointments(schedule.getMaxAppointments());
						schedule2.setStatus(Status.ACTIVE);
						schedule2 = scheduleService.mergeLocal(schedule2);
						response = setMessage(CommonConstants.SUCCESS, CommonConstants.SCHEDULE_APPROVED);
						scheduleService.sendNotification(schedule2, Action.REQUEST_APPROVED);
					}
				} catch (Exception e) {
					e.printStackTrace();
					response = setMessage(CommonConstants.ERROR, AdminConstant.SCHEUDULE_MODIFY_ERROR);
				}
			}
		} else if (schedule2.getStatus().equals(Status.AWAITING_CANCELLATION_APPROVAL)) {
			moveAllAppointmentstoWaitlist(schedule2.getScheduleId());
			schedule2.setCancelReason(schedule2.getCancelReason());
			schedule2.setStatus(Status.CANCELLED);
			schedule2.setUpdatedBy(SessionUtil.getUserFromRequestSession(request));
			schedule2.setUpdatedOn(new Date());
			schedule2 = scheduleService.mergeLocal(schedule2);
			scheduleService.removeChildSchedule(schedule2.getScheduleId());
			programmacionMedicoDetalleService.deleteDetalle(schedule2.getZeusScheduleId());
			scheduleSlotService.deleteAllSlotsFromDB(schedule2.getScheduleId());
			ProgramacionMedico zeusSchedule = programmacionService.findByIdZeus(schedule2.getZeusScheduleId());
			zeusSchedule.setActivo(false);
			programmacionService.deleteZeus(zeusSchedule);
			response = setMessage(CommonConstants.SUCCESS, AdminConstant.SCHEDULE_CANCEL_SUCCESS);
			scheduleService.sendNotification(schedule2, Action.REQUEST_APPROVED);
		}
		if (!Objects.isNull(response)) {
			redirectAttributes.addFlashAttribute(response.getStatus(), response.getMessage());
		} else {
			redirectAttributes.addFlashAttribute(response1.getStatus(), response1.getMessage());
		}
		return "redirect:" + AdminConstant.APPOINTMENT_SCHEDULING_CONTROLLER
				+ AdminConstant.APPOINTMENT_SCHEDULE_VIEW_ALL;
	}

	private Response setMessage(String type, String message) {
		Response response = new Response();
		response.setStatus(type);
		response.setMessage(messageByLocaleService.getMessage(message));
		return response;
	}

	@RequestMapping(AdminConstant.APPOINTMENT_SCHEDULE_GET_ACTIVE_EPS)
	@ResponseBody
	public ResponseEntity<Object> getActiveEPS(HttpServletRequest request) {
		_log.info("EPS length: " + epsService.findAllLocalActive().size());
		return new ResponseEntity<>(epsService.findAllLocalActiveJSON().toString(), HttpStatus.OK);
	}

	@RequestMapping(AdminConstant.APPOINTMENT_SCHEDULE_GET_CANCELLATION_REASONS)
	@ResponseBody
	public ResponseEntity<Object> getCancellationREasons(HttpServletRequest request) {
		_log.info("cancellation reasons length: " + cancellationService.findAllLocalActive());
		return new ResponseEntity<>(cancellationService.findAllLocalActiveJSON().toString(), HttpStatus.OK);
	}

	@RequestMapping("/fetchAppointmentSchedules")
	@ResponseBody
	public ResponseEntity<Object> getAppointmentSchedules(HttpServletRequest request) {
		String start = request.getParameter("start");
		String length = request.getParameter("length");
		String draw = request.getParameter("draw");
		String scheduleStatus = request.getParameter("schStatus");
		String scheduleDateStr = request.getParameter("schDate");
		Date scheduleDate = null;
		if (StringUtils.isNotBlank(scheduleDateStr)) {
			scheduleDate = Date.from(LocalDate.parse(scheduleDateStr, CommonConstants.FORMATTER).atStartOfDay()
					.atZone(ZoneId.systemDefault()).toInstant());
		}
		int status = -1;
		int startI = 0;
		int lengthI = 10;
		if (StringUtils.isNotEmpty(scheduleStatus) && StringUtils.isNumeric(scheduleStatus)) {
			status = Integer.parseInt(scheduleStatus);
		}
		if (StringUtils.isNotBlank(start) && StringUtils.isNumeric(start)) {
			startI = Integer.parseInt(start);
		}
		if (StringUtils.isNotBlank(length) && StringUtils.isNumeric(length)) {
			lengthI = Integer.parseInt(length);
		}

		JSONArray jsonArray = scheduleService.paginateScheduleRequest(startI, lengthI, status, scheduleDate);
		Long totalScheduleRequests = scheduleService.paginateScheduleRequestCount(startI, lengthI, status,
				scheduleDate);
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("data", jsonArray);
		jsonObject.put("draw", draw);
		jsonObject.put("recordsTotal", totalScheduleRequests);
		jsonObject.put("recordsFiltered", totalScheduleRequests);
		return new ResponseEntity<>(jsonObject.toString(), HttpStatus.OK);
	}

	private void updateSlotsStatus(long scheduleId, Status status) {
		List<ScheduleSlot> slots = scheduleSlotService.getBySlotsByScheduleId(scheduleId);
		if (!slots.isEmpty()) {
			for (ScheduleSlot scheduleSlot : slots) {
				scheduleSlot.setStatus(status);
				scheduleSlotService.mergeLocal(scheduleSlot);
			}
		}
	}

	private void updateZeus(Schedule schedule) {
		String startTime = schedule.getStartTime();
		String endTime = schedule.getEndTime();
		ProgramacionMedico programacion = programmacionService.findByIdZeus(schedule.getZeusScheduleId());
		programacion.setHorainicio(startTime.split(" ")[0]);
		programacion.setMeridianoi(startTime.split(" ")[1]);
		programacion.setHorafinal(endTime.split(" ")[0]);
		programacion.setMeridianof(endTime.split(" ")[1]);
		long locationId = schedule.getLocation().getZuesLocationId();
		PuntoAtencion puntoAtencion = zeusPuntoAtencionService.findByIdZeus(locationId);
		programacion.setId_sede(puntoAtencion.getId());
		programacion.setActivo(true);
		programmacionService.mergeZeus(programacion);
	}

	private void moveAllAppointmentstoWaitlist(long scheduleId) {
		List<Appointments> appointments = appointmentService.getAllScheduleAppointment(Status.APPROVED, scheduleId);
		for (Appointments appointment : appointments) {
			appointment.setSlot(null);
			appointment.setStatus(Status.WAITING);
			appointmentService.mergeLocal(appointment);
		}
	}
}
