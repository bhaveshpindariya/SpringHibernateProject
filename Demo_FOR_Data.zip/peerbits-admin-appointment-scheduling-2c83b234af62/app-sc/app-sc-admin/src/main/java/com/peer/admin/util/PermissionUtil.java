package com.peer.admin.util;

import java.util.Set;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;

import com.peer.scenity.entity.local.Role;
import com.peer.scenity.entity.local.User;
import com.peer.scenity.service.intf.IPermissionService;
import com.peer.scenity.util.SessionUtil;

public class PermissionUtil {

	private static Logger _log = Logger.getLogger(PermissionUtil.class);
	private static IPermissionService permissionService;

	public static boolean hasPermission(HttpServletRequest request, String action) {
		User user = SessionUtil.getUserFromRequestSession(request);
		return hasPermission(user, action);
	}

	public static boolean hasPermission(User user, String action) {
		if (null != user) {
			return hasPermission(user.getRoleSet(), action);
		}
		return false;
	}

	public static boolean hasPermission(Set<Role> roles, String action) {
		boolean hasPermission = false;
		for (Role role : roles) {
			hasPermission = hasPermission(role, action);
			if (hasPermission) {
				break;
			}
		}
		return hasPermission;
	}

	public static boolean hasPermission(Role role, String action) {
		boolean hasPermission = false;
		try {
			hasPermission = permissionService.hasActionPermission(role.getRoleId(), action);
		} catch (Exception e) {
			_log.error("", e);
		}
		return hasPermission;
	}

	public static boolean checkPermission(HttpServletRequest request, String action) throws Error {
		User user = SessionUtil.getUserFromRequestSession(request);
		return checkPermission(user, action);
	}

	public static boolean checkPermission(User user, String action) throws Error {
		return checkPermission(user.getRoleSet(), action);
	}

	public static boolean checkPermission(Set<Role> roles, String action) throws Error {
		boolean hasPermission = false;
		for (Role role : roles) {
			hasPermission = checkPermission(role, action);
			if (hasPermission) {
				break;
			}
		}
		return hasPermission;
	}

	public static boolean checkPermission(Role role, String action) throws Error {
		boolean hasPermission = permissionService.hasActionPermission(role.getRoleId(), action);
		if (!hasPermission) {
			_log.error("role: " + role.getName() + " action: " + action);
			throw new Error("User Dont Have Permission to Access Resource ");
		}
		return hasPermission;
	}

	public static void setPermissionService(IPermissionService permissionService) {
		PermissionUtil.permissionService = permissionService;
	}

}