package com.peer.admin.controller;

import java.util.Date;
import java.util.List;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.peer.admin.constant.AdminConstant;
import com.peer.admin.util.PermissionUtil;
import com.peer.admin.validate.SubjectValidator;
import com.peer.constant.ActionConstant;
import com.peer.constant.CommonConstants;
import com.peer.enm.Status;
import com.peer.enm.UserType;
import com.peer.scenity.entity.local.Subject;
import com.peer.scenity.entity.local.User;
import com.peer.scenity.entity.pojo.Response;
import com.peer.scenity.service.intf.ISubjectService;
import com.peer.scenity.service.intf.MessageByLocaleService;
import com.peer.scenity.util.SessionUtil;
import com.peer.util.CommonUtil;

@Controller
@RequestMapping(AdminConstant.SUBJECT_CONTROLLER)
public class SubjectController {

	private static Logger _log = Logger.getLogger(SubjectController.class);
	
	private static final String VIEW_SUBJECT_PAGE = "subject/viewsubject";
	
	@Autowired
	private MessageByLocaleService messageByLocaleService;
	
	@Autowired
	private ISubjectService subjectService;
	
	@Autowired
	private SubjectValidator subjectValidator;
	
	@RequestMapping(AdminConstant.VIEW_SUBJECTS)
	public String subjectPage(Locale locale, Model model,HttpServletRequest request) {
		User sender = SessionUtil.getUserFromRequestSession(request);
		PermissionUtil.checkPermission(sender, ActionConstant.VIEW_SUBJECT);
		_log.info("inside landing subject page ");
		model.addAttribute("subject", new Subject());
		model.addAttribute("actorList", UserType.getAllUserType());
		return VIEW_SUBJECT_PAGE;
	}
	
	@RequestMapping(AdminConstant.FETCH_SUBJECT)
	@ResponseBody
	public ResponseEntity<Object> fetchSubject(Locale locale, Model model,HttpServletRequest request) {
		String start = request.getParameter("start");
		String length = request.getParameter("length");
		String draw = request.getParameter("draw");
		int startI = 0;
		int lengthI = 10;
		if (StringUtils.isNotBlank(start) && StringUtils.isNumeric(start)) {
			startI = Integer.parseInt(start);
		}
		if (StringUtils.isNotBlank(length) && StringUtils.isNumeric(length)) {
			lengthI = Integer.parseInt(length);
		}
		JSONArray jsonArray = subjectService.paginateSubject(startI, lengthI);
		Long totalSubject = Long.parseLong(subjectService.findAllLocalData().size()+"");
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("data", jsonArray);
		jsonObject.put("draw", draw);
		jsonObject.put("recordsTotal", totalSubject);
		jsonObject.put("recordsFiltered", totalSubject);
		return new ResponseEntity<Object>(jsonObject.toString(), HttpStatus.OK);
	}
	
	@RequestMapping(value = AdminConstant.ADD_OR_EDIT_SUBJECT, method = RequestMethod.POST)
	public String addOrEditSubject(Model model,RedirectAttributes redirectAttrs,Locale locale, @ModelAttribute("subject") Subject subject,HttpSession session, HttpServletRequest request,BindingResult bindingResult) {
		Response response = new Response();
		Boolean isEmpty = CommonUtil.checkNull(subject);
		if (!isEmpty) {
			try {
				boolean check=validateSubject(redirectAttrs,subject, session, request, bindingResult, response);
				if(check){
					if (subject.getSubjectId() == null || subject.getSubjectId().equals(0L)) {
						User sender = SessionUtil.getUserFromRequestSession(request);
						PermissionUtil.checkPermission(sender, ActionConstant.ADD_NEW_SUBJECT);
						List<Subject> subjectcheck = subjectService.findBySubject(subject.getSubject());
						if(subjectcheck.size()>0){
							response=setMessage(CommonConstants.WARNING,AdminConstant.SUBJECT_EXIT);
						}else{
							try {
								_log.info("add data in subject");
								subjectService.persistLocal(subject);
								response=setMessage(CommonConstants.SUCCESS,AdminConstant.SUBJECT_SUCCESS);
							} catch (Exception e) {
								_log.error("Error:--", e);
								response=setMessage(CommonConstants.ERROR,AdminConstant.SUBJECT_ERROR);
							}
						}
					} else {
						User sender = SessionUtil.getUserFromRequestSession(request);
						PermissionUtil.checkPermission(sender, ActionConstant.EDIT_SUBJECT);
						List<Subject> subjectcheck = subjectService.findBySubjectById(subject.getSubject(),subject.getSubjectId());
						if(subjectcheck.size()>0){
							response=setMessage(CommonConstants.WARNING,AdminConstant.SUBJECT_DUBLICATE);
						}else{
							Subject subjectobject=subjectService.findByIdLocal(subject.getSubjectId());
							subject.setCreatedBy(subjectobject.getCreatedBy());
							subject.setCreatedOn(subjectobject.getCreatedOn());
							try {
								_log.info("update data in subject");
								subjectService.mergeLocal(subject);
								response=setMessage(CommonConstants.SUCCESS,AdminConstant.SUBJECT_UPDATE);
							} catch (Exception e) {
								_log.error("Error:--", e);
								response=setMessage(CommonConstants.ERROR,AdminConstant.SUBJECT_ERROR);
							}
						}
					}
				}else{
					return "redirect:" + AdminConstant.SUBJECT_CONTROLLER +AdminConstant.VIEW_SUBJECTS;
				}
			} catch (Exception e) {
				_log.error("Error:--", e);
				response=setMessage(CommonConstants.ERROR,AdminConstant.SUBJECT_ERROR);
			}
		} else {
			response=setMessage(CommonConstants.ERROR,AdminConstant.SUBJECT_EXCEPTION);
		}
		if(response.getStatus().equals(CommonConstants.SUCCESS)){
			redirectAttrs.addFlashAttribute("success", response.getMessage());
		}else{
			redirectAttrs.addFlashAttribute("error", response.getMessage());
		}
		return "redirect:" + AdminConstant.SUBJECT_CONTROLLER +AdminConstant.VIEW_SUBJECTS;
	}
	
	@RequestMapping(value = AdminConstant.REMOVE_SUBJECT, method = RequestMethod.POST)
	public String deleteSubject(Model model,Locale locale,RedirectAttributes redirectAttrs, @ModelAttribute("subject") Subject subject,HttpSession session, HttpServletRequest request) {
		User sender = SessionUtil.getUserFromRequestSession(request);
		PermissionUtil.checkPermission(sender, ActionConstant.DELETE_SUBJECT);
		Response response = new Response();
		Subject foundSubject = subjectService.findByIdLocal(subject.getSubjectId());
		foundSubject.setStatus(Status.DELETED);
		foundSubject.setUpdatedBy(SessionUtil.getUserFromRequestSession(request));
		foundSubject.setUpdatedOn(new Date());
		try {
			_log.info("remove data in subject ");
			subjectService.deleteLocal(foundSubject);
			response=setMessage(CommonConstants.SUCCESS,AdminConstant.SUBJECT_DELETE);
		} catch (Exception e) {
			_log.error("Error:--", e);
			response=setMessage(CommonConstants.ERROR,AdminConstant.SUBJECT_EXCEPTION);
		}
		if(response.getStatus().equals(CommonConstants.SUCCESS)){
			redirectAttrs.addFlashAttribute("success", response.getMessage());
		}else{
			redirectAttrs.addFlashAttribute("error", response.getMessage());
		}
		return "redirect:" + AdminConstant.SUBJECT_CONTROLLER +AdminConstant.VIEW_SUBJECTS;
	}

	private boolean validateSubject(RedirectAttributes redirectAttrs,Subject subject, HttpSession session,HttpServletRequest request,BindingResult bindingResult,Response response) {
        boolean validated = true;
        if (subject.getSubjectId() == null || subject.getSubjectId().equals(0L)) {
			subjectValidator.validate(subject, bindingResult);
			if (bindingResult.hasErrors()) {
				List<FieldError> errors = bindingResult.getFieldErrors();
				StringBuffer message = new StringBuffer();
				for (FieldError error : errors) {
					message.append(error.getDefaultMessage() + CommonConstants.MESSAGE);
				}
				response=setErrorValidate(CommonConstants.ERROR,message);
				redirectAttrs.addFlashAttribute("error", response.getMessage());
				validated = false;
			}
			subject.setCreatedOn(new Date());
			subject.setUpdatedOn(new Date());
			subject.setCreatedBy(SessionUtil.getUserFromRequestSession(request));
			subject.setUpdatedBy(SessionUtil.getUserFromRequestSession(request));
			subject.setStatus(Status.ACTIVE);
		} else {
			subjectValidator.validate(subject, bindingResult);
			if (bindingResult.hasErrors()) {
				List<FieldError> errors = bindingResult.getFieldErrors();
				StringBuffer message = new StringBuffer();
				for (FieldError error : errors) {
					message.append(error.getDefaultMessage() + CommonConstants.MESSAGE);
				}
				response=setErrorValidate(CommonConstants.ERROR,message);
				redirectAttrs.addFlashAttribute("error", response.getMessage());
				validated = false;
			}
			subject.setStatus(Status.ACTIVE);
			subject.setUpdatedOn(new Date());
			subject.setUpdatedBy(SessionUtil.getUserFromRequestSession(request));
		}
        return validated;
    }
	
	private Response setErrorValidate(String type,StringBuffer message) {
		Response response = new Response();
		response.setStatus(type);
		response.setMessage(message.toString().substring(0, message.length() - 5));
		return response;
	}
	
	private Response setMessage(String type,String message) {
		Response response = new Response();
		response.setStatus(type);
		response.setMessage(messageByLocaleService.getMessage(message));
		return response;
	}
	
}
