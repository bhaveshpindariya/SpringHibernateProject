package com.peer.admin.validate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.peer.scenity.entity.local.Category;
import com.peer.scenity.entity.local.CategoryEps;
import com.peer.scenity.service.constant.ServiceConstant;
import com.peer.scenity.service.intf.MessageByLocaleService;

@Component
public class ProcedureCategoryValidator implements Validator {

	@Autowired
	private MessageByLocaleService messageByLocaleService;
	
	@Override
	public boolean supports(Class<?> clazz) {
		return Category.class.isAssignableFrom(clazz);
	}

	@Override
	public void validate(Object target, Errors errors) {
		
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "type", "error.field.empty",messageByLocaleService.getMessage(ServiceConstant.PROCEDURE_TYPE));
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "name", "error.field.empty",messageByLocaleService.getMessage(ServiceConstant.PROCEDURE_NAME));
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "nameInSpanish", "error.field.empty",messageByLocaleService.getMessage(ServiceConstant.PROCEDURE_NAMEINSPANISH));
		
		Category category = (Category) target;
		
		for(Category subCategory :category.getProcedureData()) {
			if(subCategory.getName() == null ){
				ValidationUtils.rejectIfEmptyOrWhitespace(errors,"name", "error.field.empty",messageByLocaleService.getMessage(ServiceConstant.PROCEDURE_SUBNAME));
			}
			if(subCategory.getNameInSpanish() == null) {
				ValidationUtils.rejectIfEmptyOrWhitespace(errors,"nameInSpanish", "error.field.empty",messageByLocaleService.getMessage(ServiceConstant.PROCEDURE_SUBNAMEINSPANISH));
			}
			for(CategoryEps ceps:subCategory.getProcedureCategoryEps()) {
				if(ceps.getEpsId().getEps() == null){
					ValidationUtils.rejectIfEmptyOrWhitespace(errors, "eps", "error.field.empty",messageByLocaleService.getMessage(ServiceConstant.PROCEDURE_SUBEPS));
				}
				if(ceps.getCost() == null){
					ValidationUtils.rejectIfEmptyOrWhitespace(errors, "cost", "error.field.empty",messageByLocaleService.getMessage(ServiceConstant.PROCEDURE_SUBCOST));
				}
			}
		}
	
	}
}