package com.peer.admin.controller;

import java.util.Collections;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.peer.admin.constant.AdminConstant;
import com.peer.constant.CommonConstants;
import com.peer.enm.Status;
import com.peer.scenity.entity.local.Appointments;
import com.peer.scenity.entity.local.Schedule;
import com.peer.scenity.entity.local.User;
import com.peer.scenity.entity.pojo.ActiveRequests;
import com.peer.scenity.entity.pojo.DashboardDTO;
import com.peer.scenity.entity.pojo.NotificationDTO;
import com.peer.scenity.service.intf.IAppointmentsService;
import com.peer.scenity.service.intf.INotificationsService;
import com.peer.scenity.service.intf.IScheduleService;
import com.peer.scenity.util.ServiceUtils;
import com.peer.scenity.util.SessionUtil;

@Controller
@RequestMapping(AdminConstant.DASHBOARD_CONTROLLER)
public class DashboardController {

	private static Logger _log = Logger.getLogger(DashboardController.class);

	@Autowired
	private IAppointmentsService appointmentService;

	@Autowired
	private INotificationsService notificationService;

	@Autowired
	private IScheduleService scheduleService;

	private static final String HOME_PAGE = "home/home";
	private static final String REDIRECT_LOGIN_PAGE = "redirect:" + AdminConstant.LOGIN;

	@RequestMapping(AdminConstant.DASHBOARD_INDEX)
	public String dashboardIndex(Model model, HttpServletRequest request) {
		User user = SessionUtil.getUserFromRequestSession(request);
		if (null == user) {
			_log.warn("redirecting to login");
			return REDIRECT_LOGIN_PAGE;
		}
		DashboardDTO dashboardDTO = appointmentService.getDashboardObject();
		List<Status> statusList = ServiceUtils.getStatusList(Status.WAITING);
		List<Appointments> prioritizedWaitlistList = appointmentService.findWaitlistsAll(0L, statusList, "", 0L,
				CommonConstants.PRIORITIZED, 0, 5);
		List<Appointments> normalWaitlistList = appointmentService.findWaitlistsAll(0L, statusList, "", 0L,
				CommonConstants.NORMAL, 0, 5);

		List<NotificationDTO> notificationList = notificationService.fetchRecentNotifications(user.getUserId(),
				CommonConstants.MAX_NOTIFICATIONS);

		model.addAttribute("dashboardDTO", dashboardDTO);
		model.addAttribute("prioritizedWaitlistList",
				appointmentService.convertWaitlistToVOList(prioritizedWaitlistList));
		model.addAttribute("normalWaitlistList", appointmentService.convertWaitlistToVOList(normalWaitlistList));
		model.addAttribute("notificationList", notificationList);
		model.addAttribute("activeRequests", getRecentActiveRequest());
		return HOME_PAGE;
	}

	public List<ActiveRequests> getRecentActiveRequest() {
		List<Status> appointmentRequestStatusList = ServiceUtils.getRequestStatusList();
		List<Appointments> appointmentRequests = appointmentService.findAppointmentsAll(appointmentRequestStatusList,
				"", null, 0L, 0, 6);
		List<ActiveRequests> activeAppointmentRequests = appointmentService
				.convertAppointmentListToRequestList(appointmentRequests);

		List<Schedule> scheduleList = scheduleService.getSchedulesRequests(0, 6);
		List<ActiveRequests> activeScheduleRequests = scheduleService.convertScheduleListToRequestList(scheduleList);

		activeAppointmentRequests.addAll(activeScheduleRequests);
		Collections.sort(activeAppointmentRequests);

		if (activeAppointmentRequests.size() > 6) {
			activeAppointmentRequests = activeAppointmentRequests.subList(0, 6);
		}

		return activeAppointmentRequests;
	}
}