package com.peer.admin.listener;

import java.io.IOException;
import java.util.List;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.peer.scenity.service.intf.IUserService;
import com.peer.scenity.util.SessionUtil;

public class PeerFilter implements Filter {

	private static Logger _log = Logger.getLogger(PeerFilter.class);

	private static List<String> allowedUrlList;

	private static List<String> notAllowedUrlList;

	private static IUserService userService;

	@Override
	public void init(FilterConfig filterConfig) throws ServletException {
		_log.debug("Filter init()");
	}

	@Override
	public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain chain)
			throws IOException, ServletException {

		HttpServletRequest request = (HttpServletRequest) servletRequest;
		HttpServletResponse response = (HttpServletResponse) servletResponse;

		String currentURL = request.getServletPath();
		boolean checkSession = true;
		if (currentURL.startsWith("/index.jsp") || currentURL.startsWith("/resources/")
				|| currentURL.startsWith("/appointment/")) {
			checkSession = false;
		}

		if (checkSession && null != allowedUrlList) {
			for (String allowedURL : allowedUrlList) {
				if (currentURL.startsWith(allowedURL)) {
					checkSession = false;
				}
			}
			if (checkSession && null != userService) {
				userService.updatePrefferedLanguage(request);
			}
		}

		if (!checkSession && null != notAllowedUrlList) {
			for (String notAllowedURL : notAllowedUrlList) {
				if (currentURL.startsWith(notAllowedURL)) {
					checkSession = true;
				}
			}
		}

		if (checkSession && !SessionUtil.checkUserInSession(request)) {
			String contextPath = request.getContextPath();
			String redirectUrl = contextPath + "/login";
			_log.info("you are accessing not allowed url : " + currentURL + " :redirecting to: " + redirectUrl);
			response.sendRedirect(redirectUrl);
		} else {
			chain.doFilter(servletRequest, servletResponse);
		}
	}

	@Override
	public void destroy() {
		_log.debug("Filter destroy()");
	}

	public static List<String> getAllowedUrlList() {
		return allowedUrlList;
	}

	public static void setAllowedUrlList(List<String> allowedUrlList) {
		PeerFilter.allowedUrlList = allowedUrlList;
	}

	public static List<String> getNotAllowedUrlList() {
		return notAllowedUrlList;
	}

	public static void setNotAllowedUrlList(List<String> notAllowedUrlList) {
		PeerFilter.notAllowedUrlList = notAllowedUrlList;
	}

	public static IUserService getUserService() {
		return userService;
	}

	public static void setUserService(IUserService userService) {
		PeerFilter.userService = userService;
	}

}
