package com.peer.admin.controller;

import java.util.Date;
import java.util.List;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.peer.admin.constant.AdminConstant;
import com.peer.admin.validate.AdminProfileValidator;
import com.peer.constant.CommonConstants;
import com.peer.scenity.entity.local.Files;
import com.peer.scenity.entity.local.User;
import com.peer.scenity.entity.pojo.Response;
import com.peer.scenity.service.constant.ServiceConstant;
import com.peer.scenity.service.intf.IFilesService;
import com.peer.scenity.service.intf.IUserService;
import com.peer.scenity.service.intf.MessageByLocaleService;
import com.peer.scenity.util.SessionUtil;
import com.peer.util.CommonUtil;

@Controller
@RequestMapping(AdminConstant.PROFILE_CONTROLLER)
public class ProfileController {

	private static Logger _log = Logger.getLogger(ProfileController.class);

	private static final String MY_PROFILE_PAGE = "profile/viewmyprofile";
	private static final String EDIT_PROFILE_PAGE = "profile/editprofile";

	@Autowired
	private IUserService userService;

	@Autowired
	private AdminProfileValidator profileValidator;

	@Autowired
	private MessageByLocaleService messageByLocaleService;

	@Autowired
	private IFilesService fileService;

	@RequestMapping(AdminConstant.VIEW_PROFILE_MAPPING)
	public String viewMyProfilePage(Model model, HttpServletRequest request) {
		_log.info("inside landing admin profile page ");
		User user = SessionUtil.getUserFromRequestSession(request);
		model.addAttribute("data", user);
		String profileImagePath = fileService.getFilePath(user.getProfileImg());
		model.addAttribute("profileImagePath", profileImagePath);
		return MY_PROFILE_PAGE;
	}

	@RequestMapping(AdminConstant.EDIT_PROFILE_MAPPING)
	public String editMyProfilePage(Locale locale, Model model, HttpServletRequest request) {
		_log.info("inside landing admin edit  page ");
		User data = SessionUtil.getUserFromRequestSession(request);
		model.addAttribute("data", data);
		String profileImagePath = fileService.getFilePath(data.getProfileImg());
		model.addAttribute("profileImagePath", profileImagePath);
		return EDIT_PROFILE_PAGE;
	}

	@RequestMapping(AdminConstant.VERIFYEMAILMAPPING)
	@ResponseBody
	public ResponseEntity<Object> verifyallemail(Locale locale, Model model, HttpServletRequest request) {
		_log.info("inside landing verify all email page ");
		String emailAddress = request.getParameter("email");
		Response response = new Response();
		JSONObject jsonObject = new JSONObject();
		User user = SessionUtil.getUserFromRequestSession(request);
		boolean flag = userService.checkUserExist(emailAddress,user.getUserId());
		if(flag == true) {
			response = setMessage(CommonConstants.ERROR, AdminConstant.PROFILE_EMAIL_ERROR);
			jsonObject.put("error", response.getMessage());
		}
		return new ResponseEntity<>(jsonObject.toString(), HttpStatus.OK);
	}
	
	@RequestMapping(value = AdminConstant.EDIT_PROFILE, method = RequestMethod.POST)
	public String addUser(@RequestParam("file") MultipartFile multipartFile, @ModelAttribute("user") User user,BindingResult bindingResult, HttpServletRequest request,  HttpSession httpsession,
			RedirectAttributes redirectAttributes,Model model,Locale local) {
		Response response = new Response();
		Boolean isEmpty = CommonUtil.checkNull(user);
		if (!isEmpty) {
			try {
				boolean check = validateProfile(model, user, httpsession, request, bindingResult, response);
				if (check) {
					_log.info("Image edit Profile");
					boolean flag = userService.checkUserExist(user.getEmailAddress(),user.getUserId());
					if(flag == true) {
						response = setMessage(CommonConstants.ERROR, AdminConstant.PROFILE_EMAIL_ERROR);
						model.addAttribute("error", response.getMessage());
						model.addAttribute("data",user);
						return EDIT_PROFILE_PAGE;
					}
					User foundUser = userService.findByIdLocal(user.getUserId());
					Files image = fileService.addFile(multipartFile.getBytes(), user.getUserId().toString(), multipartFile.getOriginalFilename());
					if(multipartFile.isEmpty()){
						foundUser.setFullName(user.getFullName());
						foundUser.setEmailAddress(user.getEmailAddress());
						foundUser.setContactNo(user.getContactNo());
						foundUser.setUpdatedOn(new Date());
						foundUser.setUpdatedBy(SessionUtil.getUserFromRequestSession(request));
					}else{
						_log.info("Image Path= "+image.getFilePath());
						foundUser.setProfileImgId(image.getFilesId());
						foundUser.setProfileImg(image.getFilePath());
						foundUser.setFullName(user.getFullName());
						foundUser.setEmailAddress(user.getEmailAddress());
						foundUser.setContactNo(user.getContactNo());
						foundUser.setUpdatedOn(new Date());
						foundUser.setUpdatedBy(SessionUtil.getUserFromRequestSession(request));
					}
					try {
						_log.info("update user profile");
						foundUser = userService.mergeLocal(foundUser);
						httpsession.setAttribute(ServiceConstant.USER, foundUser);
						httpsession.setAttribute(ServiceConstant.USER_ID, foundUser.getUserId());
						httpsession.setAttribute(ServiceConstant.USER_FULL_NAME, foundUser.getFullName());
						String profileImagePath = fileService.getFilePath(foundUser.getProfileImg());
						httpsession.setAttribute(ServiceConstant.USER_PROFILE_IMAGE, profileImagePath);
						SessionUtil.updateSessionAttribute(request, ServiceConstant.USER, foundUser);
						response = setMessage(CommonConstants.SUCCESS, AdminConstant.PROFILE_UPDATE);
					} catch (Exception e) {
						_log.error("Error:--", e);
						response = setMessage(CommonConstants.ERROR, AdminConstant.PROFILE_ERROR);
						return EDIT_PROFILE_PAGE;
					}
				}else {
					model.addAttribute("data",user);
					return EDIT_PROFILE_PAGE;
				}
			} catch (Exception e) {
				response = setMessage(CommonConstants.ERROR, AdminConstant.PROFILE_ERROR);
				model.addAttribute("error", response.getMessage());
				model.addAttribute("data",user);
				return EDIT_PROFILE_PAGE;
			}
		} else {
			response = setMessage(CommonConstants.ERROR, AdminConstant.PROFILE_ERROR);
			model.addAttribute("error", response.getMessage());
			model.addAttribute("data",user);
			return EDIT_PROFILE_PAGE;
		}
		if (response.getStatus().equals(CommonConstants.SUCCESS)) {
			redirectAttributes.addFlashAttribute("success", response.getMessage());
		} else {
			model.addAttribute("data", user);
			model.addAttribute("error", response.getMessage());
			return EDIT_PROFILE_PAGE;
		}
		return "redirect:" + AdminConstant.PROFILE_CONTROLLER + AdminConstant.VIEW_PROFILE_MAPPING;
	}

	private boolean validateProfile(Model model, User user, HttpSession httpsession, HttpServletRequest request,BindingResult bindingResult, Response response) {
		boolean validated = true;
		profileValidator.validate(user, bindingResult);
		if (bindingResult.hasErrors()) {
			List<FieldError> errors = bindingResult.getFieldErrors();
			StringBuffer message = new StringBuffer();
			for (FieldError error : errors) {
				message.append(error.getDefaultMessage() + CommonConstants.MESSAGE);
			}
			response = setErrorValidate(CommonConstants.ERROR, message);
			model.addAttribute("error", response.getMessage());
			validated = false;
		}
		return validated;
	}

	private Response setErrorValidate(String type, StringBuffer message) {
		Response response = new Response();
		response.setStatus(type);
		response.setMessage(message.toString().substring(0, message.length() - 5));
		return response;
	}

	private Response setMessage(String type, String message) {
		Response response = new Response();
		response.setStatus(type);
		response.setMessage(messageByLocaleService.getMessage(message));
		return response;
	}

}
