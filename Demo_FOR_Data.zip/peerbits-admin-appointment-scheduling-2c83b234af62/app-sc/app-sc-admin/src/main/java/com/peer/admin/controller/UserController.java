package com.peer.admin.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.peer.admin.constant.AdminConstant;
import com.peer.admin.util.PermissionUtil;
import com.peer.admin.validate.PasswordValidator;
import com.peer.admin.validate.UserEditValidator;
import com.peer.admin.validate.UserValidator;
import com.peer.constant.ActionConstant;
import com.peer.constant.CommonConstants;
import com.peer.enm.CountryCode;
import com.peer.enm.Status;
import com.peer.enm.UserType;
import com.peer.scenity.entity.local.Role;
import com.peer.scenity.entity.local.User;
import com.peer.scenity.entity.pojo.Response;
import com.peer.scenity.service.intf.IFilesService;
import com.peer.scenity.service.intf.IRoleService;
import com.peer.scenity.service.intf.IUserService;
import com.peer.scenity.service.intf.MessageByLocaleService;
import com.peer.scenity.util.EncryptionUtil;
import com.peer.scenity.util.SessionUtil;
import com.peer.util.CommonUtil;
import com.peer.util.DownloadFile;

@Controller
@RequestMapping(AdminConstant.USER_CONTROLLER)
public class UserController {

	private static Logger _log = Logger.getLogger(UserController.class);

	@Autowired
	private IUserService userService;

	@Autowired
	private IRoleService roleService;

	@Autowired
	private IFilesService fileService;

	@Autowired
	private UserValidator userValidator;

	@Autowired
	private PasswordValidator passwordValidator;

	@Autowired
	private UserEditValidator userEditValidator;

	@Autowired
	private MessageByLocaleService messageByLocaleService;

	private static final String ADD_USER_PAGE = "user/user";
	private static final String VIEW_USER_PAGE = "user/view";
	private static final String VIEW_DETAIL_PAGE = "user/viewdetail";
	private static final String CHANGE_PASSWORD = "user/changepassword";
	private static final String PROFILE_PAGE = "user/profile";

	@RequestMapping(AdminConstant.VIEW_ALL_USER_MAPPING)
	public String addViewAllPage(Locale locale, Model model, HttpServletRequest request) {
		User sender = SessionUtil.getUserFromRequestSession(request);
		PermissionUtil.checkPermission(sender, ActionConstant.VIEW_ADMINS);
		_log.info("inside landing admin user page");
		return VIEW_USER_PAGE;
	}

	@RequestMapping(AdminConstant.ADD_USER_MAPPING)
	public String addUserPage(Locale locale, Model model, HttpServletRequest request) {
		User sender = SessionUtil.getUserFromRequestSession(request);
		PermissionUtil.checkPermission(sender, ActionConstant.ADD_NEW_ADMINS);
		_log.info("inside landing add admin page ");
		model.addAttribute("user", new User());
		model.addAttribute("countryCodes", CountryCode.getAllCountryCode());
		model.addAttribute("userTypes", UserType.getAllUserTypes());
		model.addAttribute("roles", roleService.findAllLocal());
		return ADD_USER_PAGE;
	}

	@RequestMapping(value = AdminConstant.ADD_OR_EDIT_USER, method = RequestMethod.POST)
	public String addUser(RedirectAttributes redirectAttrs, @ModelAttribute("user") User user,
			HttpServletRequest request, BindingResult bindingResult, Model model, Locale locale, HttpSession session) {
		Response response = new Response();
		long roleId = Long.parseLong(request.getParameter("roleId"));
		if (roleId > 0) {
			Set<Role> roleSet = new HashSet<Role>();
			Role roledata = roleService.findByIdLocal(roleId);
			roleSet.add(roledata);
			user.setRoleSet(roleSet);
		}
		Boolean isEmpty = CommonUtil.checkNull(user);
		if (!isEmpty) {
			try {
				boolean check = validateUser(model, user, session, request, bindingResult, response);
				if (check) {
					String enteredPassword = EncryptionUtil.encrypt(user.getPassword());
					user.setPassword(enteredPassword);
					if (user.getUserId() == null || user.getUserId().equals(0L)) {
						User sender = SessionUtil.getUserFromRequestSession(request);
						PermissionUtil.checkPermission(sender, ActionConstant.ADD_NEW_ADMINS);
						try {
							_log.info("add data in admin user");
							userService.persistLocal(user);
							response = setMessage(CommonConstants.SUCCESS, AdminConstant.USER_SUCCESS);
						} catch (Exception e) {
							_log.error("Error:--", e);
							response = setMessage(CommonConstants.ERROR, AdminConstant.USER_ERROR);
						}
					} else {
						User sender = SessionUtil.getUserFromRequestSession(request);
						PermissionUtil.checkPermission(sender, ActionConstant.EDIT_ADMINS);
						List<User> usercheck = userService.findAllDoctorsByEmail(user);
						if (usercheck.size() > 0) {
							response = setMessage(CommonConstants.WARNING, AdminConstant.USER_DUBLICATE);
						} else {
							User userObject = userService.findByIdLocal(user.getUserId());
							user.setCreatedBy(userObject.getCreatedBy());
							user.setCreatedOn(userObject.getCreatedOn());
							try {
								_log.info("update data in admin user");
								userService.mergeLocal(user);
								response = setMessage(CommonConstants.SUCCESS, AdminConstant.USER_UPDATE);
							} catch (Exception e) {
								_log.error("Error:--", e);
								response = setMessage(CommonConstants.ERROR, AdminConstant.USER_ERROR);
							}
						}
					}
				} else {
					if (user.getUserId() == null || user.getUserId().equals(0L)) {
						model.addAttribute("user", user);
						model.addAttribute("countryCodes", CountryCode.getAllCountryCode());
						model.addAttribute("userTypes", UserType.getAllUserTypes());
						model.addAttribute("roles", roleService.findAllLocal());
						return ADD_USER_PAGE;
					} else {
						model.addAttribute("user", user);
						model.addAttribute("countryCodes", CountryCode.getAllCountryCode());
						model.addAttribute("userTypes", UserType.getAllUserTypes());
						model.addAttribute("roles", roleService.findAllLocal());
						return ADD_USER_PAGE;
					}
				}
			} catch (Exception e) {
				_log.error("Error:--", e);
				response = setMessage(CommonConstants.ERROR, AdminConstant.USER_ERROR);
			}
		} else {
			response = setMessage(CommonConstants.ERROR, AdminConstant.USER_EXCEPTION);
		}
		if (response.getStatus().equals(CommonConstants.SUCCESS)) {
			redirectAttrs.addFlashAttribute("success", response.getMessage());
		} else {
			model.addAttribute("error", response.getMessage());
			if (user.getUserId() == null || user.getUserId().equals(0L)) {
				model.addAttribute("user", user);
				model.addAttribute("countryCodes", CountryCode.getAllCountryCode());
				model.addAttribute("userTypes", UserType.getAllUserTypes());
				model.addAttribute("roles", roleService.findAllLocal());
				return ADD_USER_PAGE;
			} else {
				model.addAttribute("user", user);
				model.addAttribute("countryCodes", CountryCode.getAllCountryCode());
				model.addAttribute("userTypes", UserType.getAllUserTypes());
				model.addAttribute("roles", roleService.findAllLocal());
				return ADD_USER_PAGE;
			}
		}
		return "redirect:" + AdminConstant.USER_CONTROLLER + AdminConstant.VIEW_ALL_USER_MAPPING;
	}

	@RequestMapping(value = AdminConstant.VIEW_USER_MAPPING, method = RequestMethod.POST)
	public String editUserPage(Locale locale, Model model, HttpServletRequest request,
			@ModelAttribute("user") User user) {
		User sender = SessionUtil.getUserFromRequestSession(request);
		PermissionUtil.checkPermission(sender, ActionConstant.EDIT_ADMINS);
		_log.info("inside landing edit admin user page");
		User foundUser = userService.findByIdLocal(user.getUserId());
		String enteredPassword = EncryptionUtil.decrypt(foundUser.getPassword());
		foundUser.setPassword(enteredPassword);
		model.addAttribute("user", foundUser);
		model.addAttribute("countryCodes", CountryCode.getAllCountryCode());
		model.addAttribute("userTypes", UserType.getAllUserTypes());
		model.addAttribute("roles", roleService.findAllLocal());
		return ADD_USER_PAGE;
	}

	@RequestMapping(value = AdminConstant.VIEW_DETAIL_MAPPING, method = RequestMethod.POST)
	public String viewDetailPage(Locale locale, Model model, HttpServletRequest request,
			@ModelAttribute("user") User user) {
		User sender = SessionUtil.getUserFromRequestSession(request);
		PermissionUtil.checkPermission(sender, ActionConstant.VIEW_ADMINS);
		_log.info("inside landing view admin page ");
		User foundUser = userService.findByIdLocal(user.getUserId());
		String enteredPassword = EncryptionUtil.decrypt(foundUser.getPassword());
		foundUser.setPassword(enteredPassword);
		model.addAttribute("user", foundUser);
		return VIEW_DETAIL_PAGE;
	}

	@RequestMapping(value = AdminConstant.REMOVE_USER, method = RequestMethod.POST)
	public String deleteUser(Locale locale, RedirectAttributes redirectAttrs, Model model, HttpServletRequest request,
			@ModelAttribute("user") User user) {
		User sender = SessionUtil.getUserFromRequestSession(request);
		PermissionUtil.checkPermission(sender, ActionConstant.DELETE_ADMINS);
		Response response = new Response();
		User foundUser = userService.findByIdLocal(user.getUserId());
		foundUser.setStatus(Status.DELETED);
		foundUser.setUpdatedBy(SessionUtil.getUserFromRequestSession(request));
		foundUser.setUpdatedOn(new Date());
		try {
			_log.info("inside landing delete admin page ");
			userService.deleteLocal(foundUser);
			response = setMessage(CommonConstants.SUCCESS, AdminConstant.USER_DELETE);
		} catch (Exception e) {
			_log.error("Error:--", e);
			response = setMessage(CommonConstants.ERROR, AdminConstant.USER_EXCEPTION);
		}
		if (response.getStatus().equals(CommonConstants.SUCCESS)) {
			redirectAttrs.addFlashAttribute("success", response.getMessage());
		} else {
			redirectAttrs.addFlashAttribute("error", response.getMessage());
		}
		return "redirect:" + AdminConstant.USER_CONTROLLER + AdminConstant.VIEW_ALL_USER_MAPPING;

	}

	@RequestMapping(value = AdminConstant.RESET_PASSWORD_USER, method = RequestMethod.POST)
	public String resetPasswordUser(RedirectAttributes redirectAttrs, Model model, Locale locale, HttpSession session,
			HttpServletRequest request, @ModelAttribute("user") User user, BindingResult bindingResult) {
		User sender = SessionUtil.getUserFromRequestSession(request);
		PermissionUtil.checkPermission(sender, ActionConstant.CHANGE_PASSWORD_ADMINS);
		Response response = new Response();
		Boolean isEmpty = CommonUtil.checkNull(user);
		User docObject = userService.findByIdLocal(user.getUserId());
		if (!isEmpty) {
			try {
				boolean check = validatePassword(user, session, request, bindingResult, response);
				if (check) {
					String enteredPassword = EncryptionUtil.encrypt(user.getPassword());
					docObject.setPassword(enteredPassword);
					docObject.setStatus(Status.ACTIVE);
					docObject.setUpdatedOn(new Date());
					docObject.setUpdatedBy(SessionUtil.getUserFromRequestSession(request));
					try {
						_log.info("update data in doctor user");
						userService.mergeLocal(docObject);
						response = setMessage(CommonConstants.SUCCESS, AdminConstant.PASSWORD_SUCCESS);
					} catch (Exception e) {
						_log.error("Error:--", e);
						response = setMessage(CommonConstants.ERROR, AdminConstant.PASSWORD_ERROR);
					}
				} else {
					redirectAttrs.addFlashAttribute("error", response.getMessage());
					redirectAttrs.addFlashAttribute("doctor", docObject);
				}
			} catch (Exception e) {
				_log.error("Error:--", e);
				response = setMessage(CommonConstants.ERROR, AdminConstant.PASSWORD_ERROR);
			}
		} else {
			response = setMessage(CommonConstants.ERROR, AdminConstant.PASSWORD_EXCEPTION);
		}
		if (response.getStatus().equals(CommonConstants.SUCCESS)) {
			redirectAttrs.addFlashAttribute("success", response.getMessage());
		} else {
			redirectAttrs.addFlashAttribute("error", response.getMessage());
		}
		return "redirect:" + AdminConstant.USER_CONTROLLER + AdminConstant.VIEW_ALL_USER_MAPPING;

	}

	private boolean validatePassword(User user, HttpSession session, HttpServletRequest request,
			BindingResult bindingResult, Response response) {
		boolean validated = true;
		passwordValidator.validate(user, bindingResult);
		if (bindingResult.hasErrors()) {
			List<FieldError> errors = bindingResult.getFieldErrors();
			StringBuffer message = new StringBuffer();
			for (FieldError error : errors) {
				message.append(error.getDefaultMessage() + CommonConstants.MESSAGE);
			}
			response = setErrorValidate(CommonConstants.ERROR, message);
			validated = false;
		}
		return validated;
	}

	@RequestMapping(AdminConstant.USER_FETCH)
	@ResponseBody
	public ResponseEntity<Object> fetchRoles(HttpServletRequest request) {
		User user = SessionUtil.getUserFromRequestSession(request);
		String start = request.getParameter("start");
		String length = request.getParameter("length");
		String draw = request.getParameter("draw");
		String userStatus = request.getParameter("userStatus");
		String roleSearch = request.getParameter("roleSearch");
		int status = -1;
		int startI = 0;
		int lengthI = 10;
		if (StringUtils.isNotEmpty(userStatus) && StringUtils.isNumeric(userStatus)) {
			status = Integer.parseInt(userStatus);
		}
		if (StringUtils.isNotBlank(start) && StringUtils.isNumeric(start)) {
			startI = Integer.parseInt(start);
		}
		if (StringUtils.isNotBlank(length) && StringUtils.isNumeric(length)) {
			lengthI = Integer.parseInt(length);
		}

		JSONArray jsonArray = userService.paginateUser(startI, lengthI, UserType.parse(roleSearch), status, user);
		Long totalUsers = userService.paginateUserCount(startI, lengthI, UserType.parse(roleSearch), status, user);
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("data", jsonArray);
		jsonObject.put("draw", draw);
		jsonObject.put("recordsTotal", totalUsers);
		jsonObject.put("recordsFiltered", totalUsers);
		return new ResponseEntity<Object>(jsonObject.toString(), HttpStatus.OK);
	}

	private boolean validateUser(Model model, User user, HttpSession session, HttpServletRequest request,
			BindingResult bindingResult, Response response) {
		boolean validated = true;
		if (user.getUserId() == null || user.getUserId().equals(0L)) {
			userValidator.validate(user, bindingResult);
			if (bindingResult.hasErrors()) {
				List<FieldError> errors = bindingResult.getFieldErrors();
				StringBuffer message = new StringBuffer();
				for (FieldError error : errors) {
					message.append(error.getDefaultMessage() + CommonConstants.MESSAGE);
				}
				response = setErrorValidate(CommonConstants.ERROR, message);
				model.addAttribute("error", response.getMessage());
				validated = false;
			}
			user.setCreatedOn(new Date());
			user.setUpdatedOn(new Date());
			user.setCreatedBy(SessionUtil.getUserFromRequestSession(request));
			user.setUpdatedBy(SessionUtil.getUserFromRequestSession(request));
			user.setStatus(Status.ACTIVE);
		} else {
			userEditValidator.validate(user, bindingResult);
			if (bindingResult.hasErrors()) {
				List<FieldError> errors = bindingResult.getFieldErrors();
				StringBuffer message = new StringBuffer();
				for (FieldError error : errors) {
					message.append(error.getDefaultMessage() + CommonConstants.MESSAGE);
				}
				response = setErrorValidate(CommonConstants.ERROR, message);
				model.addAttribute("error", response.getMessage());
				validated = false;
			}
			user.setStatus(Status.ACTIVE);
			user.setUpdatedOn(new Date());
			user.setUpdatedBy(SessionUtil.getUserFromRequestSession(request));
		}
		return validated;
	}

	private Response setErrorValidate(String type, StringBuffer message) {
		Response response = new Response();
		response.setStatus(type);
		response.setMessage(message.toString().substring(0, message.length() - 5));
		return response;
	}

	private Response setMessage(String type, String message) {
		Response response = new Response();
		response.setStatus(type);
		response.setMessage(messageByLocaleService.getMessage(message));
		return response;
	}

	@RequestMapping(AdminConstant.FETCH_USER_TYPE)
	@ResponseBody
	public ResponseEntity<Object> fetchUsersByType(HttpServletRequest request) {
		String userT = request.getParameter("userType");
		UserType userType = null;
		if (CommonConstants.ADMIN.equals(userT)) {
			userType = UserType.Admin;
		}
		if (CommonConstants.SUB_ADMIN.equals(userT)) {
			userType = UserType.SubAdmin;
		}
		if (CommonConstants.ANALYST.equals(userT)) {
			userType = UserType.Analyst;
		}
		if (CommonConstants.DOCTORS.equals(userT)) {
			userType = UserType.Doctor;
		}
		if (CommonConstants.AFFILIATES.equals(userT)) {
			userType = UserType.Affiliate;
		}
		JSONArray jsonArray = userService.fetchUsersByType(userType);

		return new ResponseEntity<Object>(jsonArray.toString(), HttpStatus.OK);
	}

	@RequestMapping(AdminConstant.CHANGE_PASSWORD)
	public String changePassword(Locale locale, Model model, HttpServletRequest request) {
		return CHANGE_PASSWORD;
	}

	@RequestMapping(AdminConstant.UPDATE_PASSWORD)
	public String updatePassword(HttpServletRequest request, RedirectAttributes redirectAttributes) {
		User user = SessionUtil.getUserFromRequestSession(request);
		String currentPassword = request.getParameter("currentPassword");
		String newPassword = request.getParameter("newPassword");
		String confirmPassword = request.getParameter("confirmPassword");
		String message = validatePasswords(currentPassword, newPassword, confirmPassword);
		if (StringUtils.isBlank(message)) {
			User currentUser = userService.findByIdLocal(user.getUserId());
			String userPassword = currentUser.getPassword();
			String userPasswordEnc = EncryptionUtil.encrypt(currentPassword);
			if (userPassword.equals(userPasswordEnc)) {
				currentUser.setPassword(EncryptionUtil.encrypt(newPassword));
				userService.mergeLocal(currentUser);
			} else {
				message = messageByLocaleService.getMessage(AdminConstant.PASSWORD_VALIDATION);
			}
		}
		if (StringUtils.isBlank(message)) {
			redirectAttributes.addFlashAttribute("success", CommonConstants.SUCCESS);
		} else {
			redirectAttributes.addFlashAttribute("error", CommonConstants.ERROR);
			redirectAttributes.addFlashAttribute("message", message);
		}
		return "redirect:" + AdminConstant.USER_CONTROLLER + AdminConstant.CHANGE_PASSWORD;
	}

	public String validatePasswords(String currentPassword, String password1, String password2) {
		if (StringUtils.isBlank(currentPassword)) {
			return AdminConstant.PASSWORD_CURRENT;
		}
		if (StringUtils.isBlank(password1) || StringUtils.isBlank(password2)) {
			return AdminConstant.PASSWORD_PASSWORD;
		}
		if (!StringUtils.equals(password1, password2)) {
			return AdminConstant.PASSWORD_MATCH;
		}
		if (password1.length() < 6) {
			return AdminConstant.PASSWORD_SIZE;
		}
		return "";
	}

	@RequestMapping(AdminConstant.PROFILE)
	public String viewProfile(HttpServletRequest request, Model model) {
		Long userId = CommonUtil.getLongValue(request, "userId");
		String currentURL = request.getParameter("currentURL");
		if (userId > 0L) {
			User user = userService.findByIdLocal(userId);
			String profileImagePath = fileService.getFilePath(user.getProfileImg());
			model.addAttribute("profileUser", user);
			model.addAttribute("profileImagePath", profileImagePath);
			model.addAttribute("currentURL", currentURL);
		}
		return PROFILE_PAGE;
	}
	
	@RequestMapping(value = AdminConstant.USER_EXPORT, method = RequestMethod.POST)
	public void exportEps(Model model, HttpServletRequest request, HttpServletResponse response) throws IOException {

		List<User> listUsers = userService.findAllUsersData();
		net.sf.json.JSONObject jsonObject = new net.sf.json.JSONObject();
		net.sf.json.JSONObject jsonColumn = new net.sf.json.JSONObject();
		net.sf.json.JSONArray columnArray = new net.sf.json.JSONArray();
		List<String> colList = new ArrayList<String>(0);
		colList.add("Name");
		colList.add("Contact Number");
		colList.add("Email");
		colList.add("Type");
		colList.add("Role");
		colList.add("Status");
		for (int i = 0; i < colList.size(); i++) {
			net.sf.json.JSONObject jsonColData = new net.sf.json.JSONObject();
			jsonColData.put("key", colList.get(i));
			columnArray.add(jsonColData);
		}
		jsonColumn.put("col_data", columnArray);
		net.sf.json.JSONObject jsonObjData = new net.sf.json.JSONObject();
		net.sf.json.JSONArray rowArray = new net.sf.json.JSONArray();
		for (User user : listUsers) {
			net.sf.json.JSONObject cellCol = new net.sf.json.JSONObject();
			net.sf.json.JSONArray cell = new net.sf.json.JSONArray();
			if (user.getUserType().name().equals(CommonConstants.USERTYPE_SUBADMIN)
					|| user.getUserType().name().equals(CommonConstants.USERTYPE_ANALYST)
					|| user.getUserType().name().equals(CommonConstants.USERTYPE_ADMIN)) {
				for (String colName : colList) {
					switch (colName) {
					case "Name":
						net.sf.json.JSONObject jsonRowData = new net.sf.json.JSONObject();
						jsonRowData.put("key", colName);
						if(user.getFullName()!=null){
							jsonRowData.put("value", user.getFullName());
						}else{
							jsonRowData.put("value", "");
						}
						cell.add(jsonRowData);
						break;
					case "Contact Number":
						net.sf.json.JSONObject jsonRowData1 = new net.sf.json.JSONObject();
						jsonRowData1.put("key", colName);
						if(user.getContactNo()!=null){
							jsonRowData1.put("value", user.getContactNo());
						}else{
							jsonRowData1.put("value", "");
						}
						cell.add(jsonRowData1);
						break;
					case "Email":
						net.sf.json.JSONObject jsonRowData2 = new net.sf.json.JSONObject();
						jsonRowData2.put("key", colName);
						if(user.getEmailAddress()!=null){
							jsonRowData2.put("value", user.getEmailAddress());
						}else{
							jsonRowData2.put("value", "");
						}
						cell.add(jsonRowData2);
						break;
					case "Type":
						net.sf.json.JSONObject jsonRowData3 = new net.sf.json.JSONObject();
						jsonRowData3.put("key", colName);
						jsonRowData3.put("value", user.getUserType().name());
						cell.add(jsonRowData3);
						break;
					case "Role":
						net.sf.json.JSONObject jsonRowData4 = new net.sf.json.JSONObject();
						jsonRowData4.put("key", colName);
						StringBuffer message = new StringBuffer();
						for (Role role : user.getRoleSet()) {
							message.append(role.getName() + ",");
						}
						if (message.toString().length() > 0) {
							jsonRowData4.put("value", message.toString().substring(0, message.length() - 1));
						} else {
							jsonRowData4.put("value", "");
						}
						cell.add(jsonRowData4);
						break;
					case "Status":
						net.sf.json.JSONObject jsonRowData5 = new net.sf.json.JSONObject();
						jsonRowData5.put("key", colName);
						jsonRowData5.put("value", user.getStatus().name());
						cell.add(jsonRowData5);
						break;
					default:
						break;
					}
					cellCol.put("cell", cell);
				}
				rowArray.add(cellCol);
				jsonObjData.put("row", rowArray);
			}
		}
		jsonObject.put("col", jsonColumn);
		jsonObject.put("data", jsonObjData);

		DownloadFile.downloadFile(AdminConstant.USER_MODULE_NAME, AdminConstant.EXPORT_EXTENSION, jsonObject, request,
				response);
	}
	
}