package com.peer.admin.listener;

import org.apache.log4j.Logger;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextRefreshedEvent;

import com.peer.scenity.service.intf.IDefaultService;

public class ContextListener implements ApplicationListener<ContextRefreshedEvent> {

	private static Logger _log = Logger.getLogger(ContextListener.class);

	@Override
	public void onApplicationEvent(ContextRefreshedEvent event) {
		try {
			IDefaultService defaultService = (IDefaultService) event.getApplicationContext().getBean("defaultService");
			defaultService.addDefaultUser();
		} catch (Exception e) {
			_log.error("", e);
		}

	}

}