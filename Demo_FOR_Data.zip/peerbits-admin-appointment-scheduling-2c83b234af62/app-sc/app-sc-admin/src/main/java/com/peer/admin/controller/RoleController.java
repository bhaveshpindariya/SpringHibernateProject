package com.peer.admin.controller;

import java.util.Date;
import java.util.List;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.peer.admin.constant.AdminConstant;
import com.peer.admin.util.PermissionUtil;
import com.peer.constant.ActionConstant;
import com.peer.constant.CommonConstants;
import com.peer.enm.Status;
import com.peer.scenity.entity.local.Role;
import com.peer.scenity.entity.local.User;
import com.peer.scenity.service.intf.IPermissionService;
import com.peer.scenity.service.intf.IRoleService;
import com.peer.scenity.util.SessionUtil;

@Controller
@RequestMapping(AdminConstant.ROLE_CONTROLLER)
public class RoleController {

	private static Logger _log = Logger.getLogger(RoleController.class);

	@Autowired
	private IRoleService roleService;

	@Autowired
	private IPermissionService permissionService;

	private static final String VIEW_ROLE_LIST = "role/view";
	private static final String ADD_ROLE = "role/role";
	private static final String VIEW_ROLE = "role/view-role";

	@RequestMapping(AdminConstant.VIEW_ALL_ROLE_MAPPING)
	public String viewAllRole(HttpServletRequest request) {
		PermissionUtil.checkPermission(request, ActionConstant.VIEW_ROLE);
		return VIEW_ROLE_LIST;
	}

	@RequestMapping(value = AdminConstant.VIEW_ROLE_MAPPING, method = RequestMethod.POST)
	public String viewRole(@ModelAttribute("role") Role role, Model model, HttpServletRequest request) {
		PermissionUtil.checkPermission(request, ActionConstant.VIEW_ROLE);
		Role roles = roleService.findByIdLocal(role.getRoleId());
		List<Object> permissionList = permissionService.getRolePermissions(roles.getRoleId());
		model.addAttribute("role", roles);
		model.addAttribute("actionKeys", permissionList);
		model.addAttribute("actionMap", ActionConstant.getActionsMap());
		return VIEW_ROLE;
	}

	@RequestMapping(AdminConstant.FETCH_Role)
	@ResponseBody
	public ResponseEntity<Object> fetchRoles(HttpServletRequest request) {
		String start = request.getParameter("start");
		String length = request.getParameter("length");
		String draw = request.getParameter("draw");
		String roleStatus = request.getParameter("roleStatus");
		String roleSearch = request.getParameter("roleSearch");
		int status = -1;
		if (StringUtils.isNotEmpty(roleStatus) && StringUtils.isNumeric(roleStatus)) {
			status = Integer.parseInt(roleStatus);
		}

		int startI = 0;
		int lengthI = 10;
		if (StringUtils.isNotBlank(start) && StringUtils.isNumeric(start)) {
			startI = Integer.parseInt(start);
		}
		if (StringUtils.isNotBlank(length) && StringUtils.isNumeric(length)) {
			lengthI = Integer.parseInt(length);
		}

		JSONArray jsonArray = roleService.paginateRole(startI, lengthI, roleSearch, status);
		Long totalRole = roleService.paginateRoleCount(startI, lengthI, roleSearch, status);

		JSONObject jsonObject = new JSONObject();
		jsonObject.put("data", jsonArray);
		jsonObject.put("draw", draw);
		jsonObject.put("recordsTotal", totalRole);
		jsonObject.put("recordsFiltered", totalRole);
		return new ResponseEntity<Object>(jsonObject.toString(), HttpStatus.OK);
	}

	@RequestMapping(AdminConstant.ADD_ROLE_MAPPING)
	public String addRolePage(Model model, HttpServletRequest request) {
		PermissionUtil.checkPermission(request, ActionConstant.ADD_NEW_ROLE);
		model.addAttribute("role", new Role());
		model.addAttribute("actionMap", ActionConstant.getActionsMap());
		return ADD_ROLE;
	}

	@RequestMapping(value = AdminConstant.EDIT_ROLE_MAPPING, method = RequestMethod.POST)
	public String editRolePage(@ModelAttribute("role") Role role, Locale locale, Model model,
			HttpServletRequest request) {
		PermissionUtil.checkPermission(request, ActionConstant.EDIT_ROLE);
		Role roles = roleService.findByIdLocal(role.getRoleId());
		List<Object> permissionList = permissionService.getRolePermissions(roles.getRoleId());
		model.addAttribute("role", roles);
		model.addAttribute("actionKeys", permissionList);
		model.addAttribute("actionMap", ActionConstant.getActionsMap());
		if (roles.getStatus().getStatusCode() == Status.DELETED.getStatusCode()) {
			model.addAttribute("showStatus", true);
		}
		return ADD_ROLE;
	}

	@RequestMapping(value = AdminConstant.ADD_EDIT_ROLE, method = RequestMethod.POST)
	public String addUpdateRole(Model model, @ModelAttribute("role") Role role, Locale locale,
			HttpServletRequest request, RedirectAttributes redirectAttributes) {
		String message = "";
		boolean valid = validateRole(model, role, message);
		if (valid) {
			message = roleService.addUpdateRole(request, role);
		}
		if (message.equals(CommonConstants.SUCCESS)) {
			redirectAttributes.addFlashAttribute("success", message);
		} else {
			String actionKeys[] = request.getParameterValues("actionKey");
			model.addAttribute("role", role);
			model.addAttribute("actionKeys", actionKeys);
			model.addAttribute("actionMap", ActionConstant.getActionsMap());
			model.addAttribute("error", message);
			return ADD_ROLE;
		}
		return "redirect:" + AdminConstant.ROLE_CONTROLLER + AdminConstant.VIEW_ALL_ROLE_MAPPING;
	}

	public boolean validateRole(Model model, Role role, String message) {
		boolean valid = true;
		String roleName = role.getName();

		Long roleId = role.getRoleId();
		if (StringUtils.isEmpty(roleName)) {
			message = "rolename.empty";
			valid = false;
		}
		boolean isDuplicate = roleService.isDuplicateRole(roleName, roleId);
		if (isDuplicate) {
			message = "rolename.duplicate";
			valid = false;
		}
		model.addAttribute("message", message);
		return valid;
	}

	@RequestMapping(value = AdminConstant.REMOVE_ROLE, method = RequestMethod.POST)
	public String deleteRole(Locale locale, Model model, RedirectAttributes redirectAttrs,
			@ModelAttribute("role") Role role, HttpSession session, HttpServletRequest request) {
		User sender = SessionUtil.getUserFromRequestSession(request);
		PermissionUtil.checkPermission(sender, ActionConstant.DELETE_ROLE);
		String message = CommonConstants.SUCCESS;
		try {
			Role roles = roleService.findByIdLocal(role.getRoleId());
			if (!CommonConstants.DEFAULT_ROLE.equals(roles.getName())) {
				roles.setStatus(Status.DELETED);
				roles.setUpdatedOn(new Date());
				roleService.mergeLocal(roles);
			}
		} catch (Exception e) {
			_log.error("", e);
			message = CommonConstants.ERROR;
		}
		redirectAttrs.addFlashAttribute("success", message);
		return "redirect:" + AdminConstant.ROLE_CONTROLLER + AdminConstant.VIEW_ALL_ROLE_MAPPING;
	}
}
