package com.peer.admin.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.peer.admin.constant.AdminConstant;
import com.peer.admin.util.PermissionUtil;
import com.peer.admin.validate.PasswordValidator;
import com.peer.admin.validate.UserProfileValidator;
import com.peer.constant.ActionConstant;
import com.peer.constant.CommonConstants;
import com.peer.enm.Status;
import com.peer.enm.UserType;
import com.peer.scenity.entity.local.Appointments;
import com.peer.scenity.entity.local.Cancellation;
import com.peer.scenity.entity.local.Category;
import com.peer.scenity.entity.local.User;
import com.peer.scenity.entity.pojo.AppointmentDTO;
import com.peer.scenity.entity.pojo.FilesDTO;
import com.peer.scenity.entity.pojo.Response;
import com.peer.scenity.service.intf.IAppointmentFilesService;
import com.peer.scenity.service.intf.IAppointmentsService;
import com.peer.scenity.service.intf.ICancellationService;
import com.peer.scenity.service.intf.ISettingsService;
import com.peer.scenity.service.intf.IUserService;
import com.peer.scenity.service.intf.MessageByLocaleService;
import com.peer.scenity.util.EncryptionUtil;
import com.peer.scenity.util.ServiceUtils;
import com.peer.scenity.util.SessionUtil;
import com.peer.util.CommonUtil;
import com.peer.util.DateUtil;
import com.peer.util.DownloadFile;

@Controller
@RequestMapping(AdminConstant.AFFILIATES_CONTROLLER)
public class AffiliatesController {

	private static Logger _log = Logger.getLogger(AffiliatesController.class);

	@Autowired
	private IUserService userService;

	@Autowired
	private IAppointmentsService appointmentService;
	
	@Autowired
	private IAppointmentFilesService appointmentFilesService;

	@Autowired
	private PasswordValidator passwordValidator;
	
	@Autowired
	private ISettingsService settingService;
	
	@Autowired
	private MessageByLocaleService messageService;

	@Autowired
	private UserProfileValidator userProfileValidator;
	
	@Autowired
	private ICancellationService cancellationService;

	@Autowired
	private MessageByLocaleService messageByLocaleService;

	private static final String VIEW_ALL_AFFILIATES_PAGE = "affiliates/affiliates";
	private static final String VIEW_AFFILIATES = "affiliates/viewAffiliates";
	private static final String VIEW_AFFILIATES_APPOINTMENT = "affiliates/viewAppointment";
	private static final String VIEW_AFFILIATES_WAITINGLIST = "affiliates/viewWaiting";

	@RequestMapping(AdminConstant.VIEW_ALL_AFFILIATES_MAPPING)
	public String affiliatesPage(Locale locale, Model model, HttpServletRequest request) {
		User sender = SessionUtil.getUserFromRequestSession(request);
		PermissionUtil.checkPermission(sender, ActionConstant.VIEW_AFFILIATES);
		_log.info("inside landing Affiliates page");
		return VIEW_ALL_AFFILIATES_PAGE;
	}

	@RequestMapping(AdminConstant.VIEW_AFFILIATES_MAPPING)
	public String viewAffiliates(Locale locale, Model model, @ModelAttribute("user") User user,
			HttpServletRequest request) {
		User sender = SessionUtil.getUserFromRequestSession(request);
		PermissionUtil.checkPermission(sender, ActionConstant.VIEW_AFFILIATES);
		_log.info("inside landing view Affiliates page");
		User foundUser = userService.findByIdLocal(user.getUserId());
		model.addAttribute("user", foundUser);
		List<Cancellation> cancellationList = cancellationService.findByUserType(UserType.Admin);
		model.addAttribute("cancellationList", cancellationList);
		List<Category> categoryList = appointmentService.findAppointmentCategories(Status.WAITING);
		model.addAttribute("categoryList", categoryList);
		return VIEW_AFFILIATES;
	}
	
	@RequestMapping(AdminConstant.VIEW_AFFILIATES)
	public String viewAffiliatesUser(Locale locale, Model model, @RequestParam(value= "userIds",required=true) Long userIds,
			HttpServletRequest request) {
		User sender = SessionUtil.getUserFromRequestSession(request);
		PermissionUtil.checkPermission(sender, ActionConstant.VIEW_AFFILIATES);
		_log.info("inside landing view Affiliates page");
		User foundUser = userService.findByIdLocal(userIds);
		model.addAttribute("user", foundUser);
		List<Cancellation> cancellationList = cancellationService.findByUserType(UserType.Admin);
		model.addAttribute("cancellationList", cancellationList);
		List<Category> categoryList = appointmentService.findAppointmentCategories(Status.WAITING);
		model.addAttribute("categoryList", categoryList);
		return VIEW_AFFILIATES;
	}

	@RequestMapping(AdminConstant.FETCH_AFFILIATES)
	@ResponseBody
	public ResponseEntity<Object> fetchAffiliates(Locale locale, Model model, HttpServletRequest request) {
		String start = request.getParameter("start");
		String length = request.getParameter("length");
		String draw = request.getParameter("draw");
		String affiliatesStatus = request.getParameter("affiliatesStatus");
		int startI = 0;
		int lengthI = 10;
		int status = -1;
		if (StringUtils.isNotEmpty(affiliatesStatus) && StringUtils.isNumeric(affiliatesStatus)) {
			status = Integer.parseInt(affiliatesStatus);
		}
		if (StringUtils.isNotBlank(start) && StringUtils.isNumeric(start)) {
			startI = Integer.parseInt(start);
		}
		if (StringUtils.isNotBlank(length) && StringUtils.isNumeric(length)) {
			lengthI = Integer.parseInt(length);
		}
		JSONArray jsonArray = userService.paginateAffiliates(startI, lengthI, status);
		Long totalDoctor = userService.paginateAffiliatesCount(startI, lengthI, status);
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("data", jsonArray);
		jsonObject.put("draw", draw);
		jsonObject.put("recordsTotal", totalDoctor);
		jsonObject.put("recordsFiltered", totalDoctor);
		return new ResponseEntity<Object>(jsonObject.toString(), HttpStatus.OK);
	}

	@RequestMapping(AdminConstant.GET_APPOINTMENTS_USER)
	@ResponseBody
	public ResponseEntity<Object> getAppointments(HttpServletRequest request) {
		String draw = request.getParameter("draw");
		int start = CommonUtil.getIntValue(request, "start");
		int max = CommonUtil.getIntValue(request, "length");
		Long userId = CommonUtil.getLongValue(request, "userName");
		String date = request.getParameter("appointmentDate");
		List<Status> statusList = ServiceUtils.getStatusListFilterForApproved(null);
		if (max <= 0) {
			max = 10;
		}
		boolean hasModifyPermission = PermissionUtil.hasPermission(request, ActionConstant.MODIFY_APPOINTMENTS);
		Date appointmentDate = StringUtils.isNotBlank(date) ? DateUtil.parseDate(date, DateUtil.YYYY_MM_DD) : null;
		JSONArray jsonArray = appointmentService.findAppointmentsForUser(statusList, userId, appointmentDate, 0L, start,
				max, hasModifyPermission);
		Long total = appointmentService.findAppointmentsCountForUser(statusList, userId, appointmentDate, 0L);

		JSONObject jsonObject = new JSONObject();
		jsonObject.put("data", jsonArray);
		jsonObject.put("draw", draw);
		jsonObject.put("recordsTotal", total);
		jsonObject.put("recordsFiltered", total);
		return new ResponseEntity<Object>(jsonObject.toString(), HttpStatus.OK);
	}

	@RequestMapping(AdminConstant.REJECT_REQUESTS_USER)
	public String rejectRequest(HttpServletRequest request, Model model, RedirectAttributes redirectAttributes) {
		boolean isCancellable = true;
		User currentUser = SessionUtil.getUserFromRequestSession(request);
		Long appointmentsId = CommonUtil.getLongValue(request, "appointmentsId");
		Long userId = CommonUtil.getLongValue(request, "userIdForUsers");
		int statusCode = CommonUtil.getIntValue(request, "status");
		String reason = request.getParameter("cancellationReason");
		if (StringUtils.isNotBlank(reason) && "-1".equals(reason)) {
			reason = request.getParameter("customReason");
		}
		try {
			Status status = Status.parse(statusCode);
			if (Status.CANCELLED.equals(status)) {
				Appointments appointments = appointmentService.findByIdLocal(appointmentsId);
				isCancellable = settingService.isAppointmentCancellable(appointments.getAppointmentDate(),
						appointments.getAppointmentTime(), appointments.getMedian());
			}
			if (isCancellable) {
				appointmentService.rejectRequest(currentUser, appointmentsId, reason, status);
				redirectAttributes.addFlashAttribute("success", CommonConstants.SUCCESS);
			} else {
				redirectAttributes.addFlashAttribute("error",messageService.getMessage(CommonConstants.CANCELLATION_TIME_ERROR));
			}
		} catch (Exception e) {
			_log.error("", e);
			redirectAttributes.addFlashAttribute("error", CommonConstants.ERROR);
		}
		return "redirect:" + AdminConstant.AFFILIATES_CONTROLLER + AdminConstant.VIEW_AFFILIATES +"?userIds="+userId;
	}
	
	@RequestMapping(AdminConstant.VIEW_APPOINTMENT_AFFILIATES)
	public String viewAppointment(HttpServletRequest request, Model model) {
		PermissionUtil.checkPermission(request, ActionConstant.VIEW_APPOINTMENT);
		Long appointmentsId = CommonUtil.getLongValue(request, "appointmentsId");
		String userName = request.getParameter("userName");
		String date = request.getParameter("appointmentDate");
		int statusCode = CommonUtil.getIntValue(request, "statusCode");
		Appointments appointments = appointmentService.findByIdLocal(appointmentsId);

		if (null != appointments) {
			AppointmentDTO appointmentObject = appointmentService.getAppointmentDTO(appointments);
			List<FilesDTO> appointmentFiles = appointmentFilesService.getAppointmentFiles(appointments.getAppointmentsId());
			List<Cancellation> cancellationList = cancellationService.findByUserType(UserType.Admin);
			model.addAttribute("appointments", appointments);
			model.addAttribute("appointmentObject", appointmentObject);
			model.addAttribute("appointmentFiles", appointmentFiles);
			model.addAttribute("cancellationList", cancellationList);
			model.addAttribute("userName", userName);
			model.addAttribute("appointmentDate", date);
			model.addAttribute("statusCode", statusCode);
			model.addAttribute("appointmentStatus", ServiceUtils.getStatus(appointments.getStatus().getStatusCode()));
			model.addAttribute("placedOn",
					DateUtil.formateDate(appointments.getCreatedOn(), DateUtil.DD_MMM_YYYY_AM_PM));
			String cancelledDate = "";
			boolean cancellable = false;
			boolean cancelled = false;
			if (Status.CANCELLED.equals(appointments.getStatus())) {
				cancelled = true;
				cancelledDate = DateUtil.formateDate(appointments.getUpdatedOn(), DateUtil.DD_MMM_YYYY_AM_PM);
			} else {
				cancellable = settingService.isAppointmentCancellable(appointments.getAppointmentDate(),
						appointments.getAppointmentTime(), appointments.getMedian());
			}
			model.addAttribute("cancelled", cancelled);
			model.addAttribute("cancellable", cancellable);
			model.addAttribute("cancelledDate", cancelledDate);
		}
		return VIEW_AFFILIATES_APPOINTMENT;
	}
	
	@RequestMapping(value = AdminConstant.EDIT_AFFILIATES, method = RequestMethod.POST)
	public String editUser(RedirectAttributes redirectAttrs, @ModelAttribute("user") User user,
			HttpServletRequest request, BindingResult bindingResult, Model model, Locale locale,
			HttpSession httpSession) {
		Response response = new Response();
		User sender = SessionUtil.getUserFromRequestSession(request);
		PermissionUtil.checkPermission(sender, ActionConstant.EDIT_AFFILIATES);
		Boolean isEmpty = CommonUtil.checkNull(user);
		if (!isEmpty) {
			try {
				boolean check = validateProfile(redirectAttrs, user, httpSession, request, bindingResult, response);
				if (check) {
					boolean flag = userService.checkUserExist(user.getEmailAddress(), user.getUserId());
					if (flag == true) {
						response = setMessage(CommonConstants.ERROR, AdminConstant.AFFILIATES_DUBLICATE);
					} else {
						User foundUser = userService.findByIdLocal(user.getUserId());
						foundUser.setEmailAddress(user.getEmailAddress());
						foundUser.setContactNo(user.getContactNo());
						foundUser.setStatus(Status.ACTIVE);
						foundUser.setUpdatedOn(new Date());
						foundUser.setUpdatedBy(SessionUtil.getUserFromRequestSession(request));
						try {
							foundUser = userService.mergeLocal(foundUser);
							response = setMessage(CommonConstants.SUCCESS, AdminConstant.AFFILIATES_UPDATE);
						} catch (Exception e) {
							_log.error("Error:--", e);
							response = setMessage(CommonConstants.ERROR, AdminConstant.AFFILIATES_ERROR);
						}
					}
				}
			} catch (Exception e) {
				_log.error("Error:--", e);
				response = setMessage(CommonConstants.ERROR, AdminConstant.AFFILIATES_ERROR);
			}
		} else {
			response = setMessage(CommonConstants.ERROR, AdminConstant.AFFILIATES_ERROR);
		}
		if (response.getStatus().equals(CommonConstants.SUCCESS)) {
			redirectAttrs.addFlashAttribute("success", response.getMessage());
		} else {
			redirectAttrs.addFlashAttribute("error", response.getMessage());
		}
		return "redirect:" + AdminConstant.AFFILIATES_CONTROLLER + AdminConstant.VIEW_ALL_AFFILIATES_MAPPING;
	}

	private boolean validateProfile(RedirectAttributes redirectAttrs, User user, HttpSession httpsession,
			HttpServletRequest request, BindingResult bindingResult, Response response) {
		boolean validated = true;
		userProfileValidator.validate(user, bindingResult);
		if (bindingResult.hasErrors()) {
			List<FieldError> errors = bindingResult.getFieldErrors();
			StringBuffer message = new StringBuffer();
			for (FieldError error : errors) {
				message.append(error.getDefaultMessage() + CommonConstants.MESSAGE);
			}
			response = setErrorValidate(CommonConstants.ERROR, message);
			redirectAttrs.addFlashAttribute("error", response.getMessage());
			validated = false;
		}
		user.setStatus(Status.ACTIVE);
		user.setUpdatedOn(new Date());
		user.setUpdatedBy(SessionUtil.getUserFromRequestSession(request));
		return validated;
	}

	@RequestMapping(value = AdminConstant.RESET_PASSWORD, method = RequestMethod.POST)
	public String resetPassword(RedirectAttributes redirectAttrs, Model model, Locale locale, HttpSession session,
			HttpServletRequest request, @ModelAttribute("user") User user, BindingResult bindingResult) {
		User sender = SessionUtil.getUserFromRequestSession(request);
		PermissionUtil.checkPermission(sender, ActionConstant.CHANGE_PASSWORD_AFFILIATES);
		Response response = new Response();
		Boolean isEmpty = CommonUtil.checkNull(user);
		User userObject = userService.findByIdLocal(user.getUserId());
		if (!isEmpty) {
			try {
				boolean check = validatePassword(user, session, request, bindingResult, response);
				if (check) {
					String enteredPassword = EncryptionUtil.encrypt(user.getPassword());
					userObject.setPassword(enteredPassword);
					userObject.setStatus(Status.ACTIVE);
					userObject.setUpdatedOn(new Date());
					userObject.setUpdatedBy(SessionUtil.getUserFromRequestSession(request));
					try {
						_log.info("update data in Affiliates user");
						userService.mergeLocal(userObject);
						response = setMessage(CommonConstants.SUCCESS, AdminConstant.PASSWORD_SUCCESS);
					} catch (Exception e) {
						_log.error("Error:--", e);
						response = setMessage(CommonConstants.ERROR, AdminConstant.PASSWORD_ERROR);
					}
				} else {
					redirectAttrs.addFlashAttribute("errorPassword", response.getMessage());
				}
			} catch (Exception e) {
				_log.error("Error:--", e);
				response = setMessage(CommonConstants.ERROR, AdminConstant.PASSWORD_ERROR);
			}
		} else {
			response = setMessage(CommonConstants.ERROR, AdminConstant.PASSWORD_EXCEPTION);
		}
		if (response.getStatus().equals(CommonConstants.SUCCESS)) {
			redirectAttrs.addFlashAttribute("successPassword", response.getMessage());
		} else {
			redirectAttrs.addFlashAttribute("errorPassword", response.getMessage());
		}
		return "redirect:" + AdminConstant.AFFILIATES_CONTROLLER + AdminConstant.VIEW_AFFILIATES +"?userIds="+user.getUserId();

	}

	@RequestMapping(value = AdminConstant.REMOVE_DOCTOR, method = RequestMethod.POST)
	public String deleteUser(Locale locale, Model model, RedirectAttributes redirectAttrs, HttpServletRequest request,
			@ModelAttribute("user") User user) {
		User sender = SessionUtil.getUserFromRequestSession(request);
		PermissionUtil.checkPermission(sender, ActionConstant.DELETE_AFFILIATES);
		Response response = new Response();
		User foundUser = userService.findByIdLocal(user.getUserId());
		foundUser.setStatus(Status.DELETED);
		foundUser.setUpdatedOn(new Date());
		foundUser.setUpdatedBy(SessionUtil.getUserFromRequestSession(request));
		try {
			_log.info("remove data in Affiliates");
			userService.deleteLocal(foundUser);
			response = setMessage(CommonConstants.SUCCESS, AdminConstant.AFFILIATES_DELETE);
		} catch (Exception e) {
			_log.error("Error:--", e);
			response = setMessage(CommonConstants.ERROR, AdminConstant.AFFILIATES_EXCEPTION);
		}
		if (response.getStatus().equals(CommonConstants.SUCCESS)) {
			redirectAttrs.addFlashAttribute("success", response.getMessage());
		} else {
			redirectAttrs.addFlashAttribute("error", response.getMessage());
		}
		return "redirect:" + AdminConstant.AFFILIATES_CONTROLLER + AdminConstant.VIEW_ALL_AFFILIATES_MAPPING;
	}

	private boolean validatePassword(User doctor, HttpSession session, HttpServletRequest request,
			BindingResult bindingResult, Response response) {
		boolean validated = true;
		passwordValidator.validate(doctor, bindingResult);
		if (bindingResult.hasErrors()) {
			List<FieldError> errors = bindingResult.getFieldErrors();
			StringBuffer message = new StringBuffer();
			for (FieldError error : errors) {
				message.append(error.getDefaultMessage() + CommonConstants.MESSAGE);
			}
			response = setErrorValidate(CommonConstants.ERROR, message);
			validated = false;
		}
		return validated;
	}

	private Response setErrorValidate(String type, StringBuffer message) {
		Response response = new Response();
		response.setStatus(type);
		response.setMessage(message.toString().substring(0, message.length() - 5));
		return response;
	}

	private Response setMessage(String type, String message) {
		Response response = new Response();
		response.setStatus(type);
		response.setMessage(messageByLocaleService.getMessage(message));
		return response;
	}
	
	@RequestMapping(AdminConstant.WAITING_AFFILIATES)
	public String waitlistsView(HttpServletRequest request, Model model) {
		Long appointmentsId = CommonUtil.getLongValue(request, "appointmentsId");
		String userName = request.getParameter("userName");
		String waitlistType = request.getParameter("waitlistType");
		Long userIDs = CommonUtil.getLongValue(request, "userIDs");
		Long categoryId = CommonUtil.getLongValue(request, "categoryId");

		List<Status> statusList = ServiceUtils.getStatusList(Status.WAITING);
		Appointments appointments = null;
		List<Appointments> appointmentRequests = appointmentService.findWaitlistsAll(userIDs, statusList, userName,
				categoryId, waitlistType, 0, -1);
		int appointmentRequestsLength = appointmentRequests.size();
		Long previousAppointmentId = 0L;
		Long nextAppointmentId = 0L;
		for (int i = 0; i < appointmentRequestsLength; i++) {
			Appointments appointments2 = appointmentRequests.get(i);
			if (appointments2.getAppointmentsId().equals(appointmentsId)) {
				appointments = appointments2;
				if (i > 0) {
					previousAppointmentId = appointmentRequests.get(i - 1).getAppointmentsId();
				}
				if ((i + 1) < appointmentRequestsLength) {
					nextAppointmentId = appointmentRequests.get(i + 1).getAppointmentsId();
				}
			}
		}

		if (null != appointments) {
			AppointmentDTO appointmentObject = appointmentService.getAppointmentDTO(appointments);
			List<FilesDTO> appointmentFiles = appointmentFilesService
					.getAppointmentFiles(appointments.getAppointmentsId());
			model.addAttribute("appointments", appointments);
			model.addAttribute("appointmentObject", appointmentObject);
			model.addAttribute("appointmentFiles", appointmentFiles);
			model.addAttribute("previousAppointmentId", previousAppointmentId);
			model.addAttribute("nextAppointmentId", nextAppointmentId);
			model.addAttribute("userName", userName);
			model.addAttribute("waitlistType", waitlistType);
			model.addAttribute("categoryId", categoryId);
			model.addAttribute("expired", DateUtil.isWaitlistsExpired(appointments.getCreatedOn()));
			model.addAttribute("placedOn",
					DateUtil.formateDate(appointments.getCreatedOn(), DateUtil.DD_MMM_YYYY_AM_PM));
		}
		return VIEW_AFFILIATES_WAITINGLIST;
	}
	

	@RequestMapping(value = AdminConstant.EXPORT_AFFILIATES, method = RequestMethod.POST)
	public void exportEps(Model model, HttpServletRequest request, HttpServletResponse response) throws IOException {

		List<User> listUsers = userService.findAllUsersData();
		net.sf.json.JSONObject jsonObject = new net.sf.json.JSONObject();
		net.sf.json.JSONObject jsonColumn = new net.sf.json.JSONObject();
		net.sf.json.JSONArray columnArray = new net.sf.json.JSONArray();
		List<String> colList = new ArrayList<String>(0);
		colList.add("First Name");
		colList.add("Last Name");
		colList.add("Full Name");
		colList.add("ID Type");
		colList.add("ID Number");
		colList.add("Date Of Birth");
		colList.add("Contact Number");
		colList.add("Email");
		colList.add("Total Appointments Booked");
		colList.add("Status");
		for (int i = 0; i < colList.size(); i++) {
			net.sf.json.JSONObject jsonColData = new net.sf.json.JSONObject();
			jsonColData.put("key", colList.get(i));
			columnArray.add(jsonColData);
		}
		jsonColumn.put("col_data", columnArray);
		net.sf.json.JSONObject jsonObjData = new net.sf.json.JSONObject();
		net.sf.json.JSONArray rowArray = new net.sf.json.JSONArray();
		for (User user : listUsers) {
			net.sf.json.JSONObject cellCol = new net.sf.json.JSONObject();
			net.sf.json.JSONArray cell = new net.sf.json.JSONArray();
			if(user.getUserType().name().equals(CommonConstants.USERTYPE_AFFILIATE)) {
				for (String colName : colList) {
					switch (colName) {
					case "First Name":
						net.sf.json.JSONObject jsonRowData11 = new net.sf.json.JSONObject();
						jsonRowData11.put("key", colName);
						if(user.getFirstName()!=null){
							jsonRowData11.put("value", user.getFirstName());
						}else{
							jsonRowData11.put("value", "");
						}
						cell.add(jsonRowData11);
						break;
					case "Last Name":
						net.sf.json.JSONObject jsonRowData12 = new net.sf.json.JSONObject();
						jsonRowData12.put("key", colName);
						if(user.getLastName()!=null){
							jsonRowData12.put("value", user.getLastName());
						}else{
							jsonRowData12.put("value", "");
						}
						cell.add(jsonRowData12);
						break;
					case "Full Name":
						net.sf.json.JSONObject jsonRowData = new net.sf.json.JSONObject();
						jsonRowData.put("key", colName);
						if(user.getFullName()!=null){
							jsonRowData.put("value", user.getFullName());
						}else{
							jsonRowData.put("value", "");
						}
						cell.add(jsonRowData);
						break;
					case "ID Type":
						net.sf.json.JSONObject jsonRowDataType = new net.sf.json.JSONObject();
						jsonRowDataType.put("key", colName);
						if(user.getIdType()!=null){
							jsonRowDataType.put("value", user.getIdType().name());
						}else{
							jsonRowDataType.put("value", "");
						}
						cell.add(jsonRowDataType);
						break;
					case "ID Number":
						net.sf.json.JSONObject jsonRowDatanum = new net.sf.json.JSONObject();
						jsonRowDatanum.put("key", colName);
						if(user.getIdNumber()!=null){
							jsonRowDatanum.put("value", user.getIdNumber());
						}else{
							jsonRowDatanum.put("value", "");
						}
						cell.add(jsonRowDatanum);
						break;
					case "Date Of Birth":
						net.sf.json.JSONObject jsonRowDataDate = new net.sf.json.JSONObject();
						jsonRowDataDate.put("key", colName);
						if(user.getBdate()!=null){
							jsonRowDataDate.put("value", DateUtil.getFormatterDate(user.getBdate()));
						}else{
							jsonRowDataDate.put("value", "");
						}
						cell.add(jsonRowDataDate);
						break;
					case "Contact Number":
						net.sf.json.JSONObject jsonRowData1 = new net.sf.json.JSONObject();
						jsonRowData1.put("key", colName);
						if(user.getContactNo()!=null){
							jsonRowData1.put("value", user.getContactNo());
						}else{
							jsonRowData1.put("value", "");
						}
						cell.add(jsonRowData1);
						break;
					case "Email":
						net.sf.json.JSONObject jsonRowData5 = new net.sf.json.JSONObject();
						jsonRowData5.put("key", colName);
						if(user.getEmailAddress()!=null){
							jsonRowData5.put("value", user.getEmailAddress());
						}else{
							jsonRowData5.put("value", "");
						}
						cell.add(jsonRowData5);
						break;
					case "Total Appointments Booked":
						net.sf.json.JSONObject jsonRowData2 = new net.sf.json.JSONObject();
						jsonRowData2.put("key", colName);
						jsonRowData2.put("value", appointmentService.findAppointmentsCount(user.getUserId(), null, null, null, null));
						cell.add(jsonRowData2);
						break;
					case "Status":
						net.sf.json.JSONObject jsonRowData3 = new net.sf.json.JSONObject();
						jsonRowData3.put("key", colName);
						jsonRowData3.put("value", user.getStatus().name());
						cell.add(jsonRowData3);
						break;
					default:
						break;
					}
					cellCol.put("cell", cell);
				}
				rowArray.add(cellCol);
				jsonObjData.put("row", rowArray);
			}
		}
		jsonObject.put("col", jsonColumn);
		jsonObject.put("data", jsonObjData);

		DownloadFile.downloadFile(AdminConstant.AFFILIATES_MODULE_NAME, AdminConstant.EXPORT_EXTENSION, jsonObject, request,
				response);
	}


}
