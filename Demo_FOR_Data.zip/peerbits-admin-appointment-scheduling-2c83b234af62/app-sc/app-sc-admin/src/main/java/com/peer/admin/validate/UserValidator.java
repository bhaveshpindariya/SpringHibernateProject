package com.peer.admin.validate;

import java.util.regex.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.peer.scenity.entity.local.User;
import com.peer.scenity.service.constant.ServiceConstant;
import com.peer.scenity.service.intf.IUserService;
import com.peer.scenity.service.intf.MessageByLocaleService;

@Component
public class UserValidator implements Validator {

	@Autowired
	private MessageByLocaleService messageByLocaleService;

	@Autowired
	private IUserService userService;

	@Override
	public boolean supports(Class<?> clazz) {
		return User.class.isAssignableFrom(clazz);
	}

	@Override
	public void validate(Object target, Errors errors) {
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "fullName", "error.field.empty",messageByLocaleService.getMessage(ServiceConstant.USERNAME));
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "emailAddress", "error.field.empty",messageByLocaleService.getMessage(ServiceConstant.USEREMAIL));
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "contactNo", "error.field.empty",messageByLocaleService.getMessage(ServiceConstant.USERNUMBER));
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "password", "error.field.empty",messageByLocaleService.getMessage(ServiceConstant.USERPASSWORD));

		User user = (User) target;
		String email = user.getEmailAddress();
		String number = user.getContactNo();

		if (user.getRoleSet().size() < 1)
			ValidationUtils.rejectIfEmptyOrWhitespace(errors, "roleSet", "error.field.empty",messageByLocaleService.getMessage(ServiceConstant.USERROLE));
		if (email != null && userService.findUserByEmail(email) != null)
			errors.rejectValue("emailAddress", "error.emailAddress.exists",	messageByLocaleService.getMessage(ServiceConstant.USEREMAIL_EXIST));
		if (!isValid(email))
			errors.rejectValue("emailAddress", "error.emailAddress.Wrong",messageByLocaleService.getMessage(ServiceConstant.USEREMAIL_WRONG));
		if (!isValidNumber(number))
			errors.rejectValue("contactNo", "error.contactNo.Wrong",messageByLocaleService.getMessage(ServiceConstant.USENUMBER_WRONG));
	}

	public static boolean isValid(String email) {
		String emailRegex = "^[a-zA-Z0-9_+&*-]+(?:\\." + "[a-zA-Z0-9_+&*-]+)*@" + "(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,7}$";
		Pattern pat = Pattern.compile(emailRegex);
		if (email == null)
			return false;
		return pat.matcher(email).matches();
	}

	public static boolean isValidNumber(String number) {
		String regex = "^[1-9][0-9]{7,14}$";
		Pattern pat = Pattern.compile(regex);
		if (number == null)
			return false;
		return pat.matcher(number).matches();
	}
}
