package com.peer.admin.controller;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.peer.admin.constant.AdminConstant;
import com.peer.admin.util.PermissionUtil;
import com.peer.admin.validate.EpsValidator;
import com.peer.constant.ActionConstant;
import com.peer.constant.CommonConstants;
import com.peer.enm.EpsType;
import com.peer.enm.Status;
import com.peer.scenity.entity.local.Eps;
import com.peer.scenity.entity.local.User;
import com.peer.scenity.entity.pojo.Response;
import com.peer.scenity.entity.zeus.Empre;
import com.peer.scenity.service.intf.IEpsService;
import com.peer.scenity.service.intf.MessageByLocaleService;
import com.peer.scenity.service.intf.ZeusEpsService;
import com.peer.scenity.util.SessionUtil;
import com.peer.util.CommonUtil;
import com.peer.util.DownloadFile;

@Controller
@RequestMapping(AdminConstant.EPS_CONTROLLER)
public class EpsController {

	private static Logger _log = Logger.getLogger(EpsController.class);

	private static final String VIEW_EPS_PAGE = "eps/ViewEps";

	@Autowired
	private EpsValidator epsValidator;

	@Autowired
	private IEpsService epsService;

	@Autowired
	private ZeusEpsService zeusEpsService;

	@Autowired
	private MessageByLocaleService messageByLocaleService;

	@RequestMapping(AdminConstant.VIEW_EPS)
	public String viewAlleps(Locale locale, Model model, HttpServletRequest request) {
		User sender = SessionUtil.getUserFromRequestSession(request);
		PermissionUtil.checkPermission(sender, ActionConstant.VIEW_EPS);
		_log.info("inside Eps page loading");
		model.addAttribute("eps", new Eps());
		model.addAttribute("epsList", EpsType.getAllEpsTypeType());
		return VIEW_EPS_PAGE;
	}

	@RequestMapping(AdminConstant.FETCH_EPS)
	@ResponseBody
	public ResponseEntity<Object> fetchEps(Locale locale, Model model, HttpServletRequest request) {
		String start = request.getParameter("start");
		String length = request.getParameter("length");
		String draw = request.getParameter("draw");
		int startI = 0;
		int lengthI = 10;
		if (StringUtils.isNotBlank(start) && StringUtils.isNumeric(start)) {
			startI = Integer.parseInt(start);
		}
		if (StringUtils.isNotBlank(length) && StringUtils.isNumeric(length)) {
			lengthI = Integer.parseInt(length);
		}
		JSONArray jsonArray = epsService.paginateEps(startI, lengthI);
		Long totalEps = Long.parseLong(epsService.findAllLocalData().size() + "");
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("data", jsonArray);
		jsonObject.put("draw", draw);
		jsonObject.put("recordsTotal", totalEps);
		jsonObject.put("recordsFiltered", totalEps);
		return new ResponseEntity<Object>(jsonObject.toString(), HttpStatus.OK);
	}

	@RequestMapping(value = AdminConstant.ADD_OR_EDIT_EPS_URL, method = RequestMethod.POST)
	public String addOrEditEps(Model model, RedirectAttributes redirectAttrs, Locale locale, HttpSession session,
			HttpServletRequest request, @ModelAttribute("eps") Eps eps, BindingResult bindingResult) {
		Response response = new Response();
		Boolean isEmpty = CommonUtil.checkNull(eps);
		if (!isEmpty) {
			try {
				boolean check = validateEPS(redirectAttrs, eps, session, request, bindingResult, response);
				if (check) {
					if (eps.getEpsId() == null || eps.getEpsId().equals(0L)) {
						User sender = SessionUtil.getUserFromRequestSession(request);
						PermissionUtil.checkPermission(sender, ActionConstant.ADD_NEW_EPS);
						Long epscheck = epsService.findByEpsName(eps);
						if (epscheck > 0) {
							if (epscheck == 2) {
								Empre empre = zeusEpsService.findEmpre(eps);
								List<Eps> data = epsService.findByEpsNames(eps);
								if (data.size() > 0) {
									response = setMessage(CommonConstants.WARNING, AdminConstant.EPS_EXIT);
								} else {
									try {
										eps.setZuesEpsId(empre.getId());
										epsService.persistLocal(eps);
										response = setMessage(CommonConstants.SUCCESS, AdminConstant.EPS_SUCCESS);
									} catch (Exception e) {
										_log.error("Error:--", e);
										response = setMessage(CommonConstants.ERROR, AdminConstant.EPS_ERROR);
									}
								}
							} else {
								response = setMessage(CommonConstants.WARNING, AdminConstant.EPS_EXIT);
							}
						} else {
							try {
								_log.info("add data in eps");
								Double a = 0.00;
								Empre empres = new Empre();
								empres.setEpsCode(eps.getEpsCode());
								empres.setEpsName(eps.getEpsInSpanish());
								empres.setEpsType(eps.getType().name());
								empres.setImpuestoCree(CommonConstants.ZEUS_EPS_IMPUESTOCREE);
								empres.setInformeCostosPrefijoSer(true);
								empres.setPtajeRetefnte(a);
								empres.setAnticipoRetefnte(false);
								empres = zeusEpsService.persistZeus(empres);
								eps.setZuesEpsId(empres.getId());
								epsService.persistLocal(eps);
								response = setMessage(CommonConstants.SUCCESS, AdminConstant.EPS_SUCCESS);
							} catch (Exception e) {
								_log.error("Error:--", e);
								response = setMessage(CommonConstants.ERROR, AdminConstant.EPS_ERROR);
							}
						}
					} else {
						User sender = SessionUtil.getUserFromRequestSession(request);
						PermissionUtil.checkPermission(sender, ActionConstant.EDIT_EPS);
						Eps epsObject = epsService.findByIdLocal(eps.getEpsId());
						eps.setCreatedBy(epsObject.getCreatedBy());
						eps.setCreatedOn(epsObject.getCreatedOn());
						eps.setZuesEpsId(epsObject.getZuesEpsId());
						Long i = epsService.findByEpsNameAndId(eps);
						if (i > 0) {
							response = setMessage(CommonConstants.WARNING, AdminConstant.EPS_DUBLICATE);
						} else {
							Empre empre = zeusEpsService.findByIdZeus(epsObject.getZuesEpsId());
							empre.setEpsCode(eps.getEpsCode());
							empre.setEpsName(eps.getEpsInSpanish());
							empre.setEpsType(eps.getType().name());
							try {
								_log.info("update data in eps");
								empre = zeusEpsService.mergeZeus(empre);
								eps.setZuesEpsId(empre.getId());
								epsService.mergeLocal(eps);
								response = setMessage(CommonConstants.SUCCESS, AdminConstant.EPS_UPDATE);
							} catch (Exception e) {
								_log.error("Error:--", e);
								response = setMessage(CommonConstants.ERROR, AdminConstant.EPS_ERROR);
							}
						}
					}
				} else {
					return "redirect:" + AdminConstant.EPS_CONTROLLER + AdminConstant.VIEW_EPS;
				}
			} catch (Exception e) {
				_log.error("Error:--", e);
				response = setMessage(CommonConstants.ERROR, AdminConstant.EPS_ERROR);
			}
		} else {
			response = setMessage(CommonConstants.ERROR, AdminConstant.EPS_EXCEPTION);
		}
		if (response.getStatus().equals(CommonConstants.SUCCESS)) {
			redirectAttrs.addFlashAttribute("success", response.getMessage());
		} else {
			redirectAttrs.addFlashAttribute("error", response.getMessage());
		}
		return "redirect:" + AdminConstant.EPS_CONTROLLER + AdminConstant.VIEW_EPS;
	}

	@RequestMapping(value = AdminConstant.REMOVE_EPS, method = RequestMethod.POST)
	public String deleteEps(Locale locale, Model model, RedirectAttributes redirectAttrs,
			@ModelAttribute("eps") Eps eps, HttpSession session, HttpServletRequest request) {
		User sender = SessionUtil.getUserFromRequestSession(request);
		PermissionUtil.checkPermission(sender, ActionConstant.DELETE_EPS);
		Response response = new Response();
		Eps epsData = epsService.findByIdLocal(eps.getEpsId());
		epsData.setStatus(Status.DELETED);
		epsData.setUpdatedBy(SessionUtil.getUserFromRequestSession(request));
		epsData.setUpdatedOn(new Date());
		try {
			_log.info("remove data in eps ");
			epsService.deleteLocal(epsData);
			response = setMessage(CommonConstants.SUCCESS, AdminConstant.EPS_DELETE);
		} catch (Exception e) {
			_log.error("Error:--", e);
			response = setMessage(CommonConstants.ERROR, AdminConstant.EPS_EXCEPTION);
		}
		if (response.getStatus().equals(CommonConstants.SUCCESS)) {
			redirectAttrs.addFlashAttribute("success", response.getMessage());
		} else {
			redirectAttrs.addFlashAttribute("error", response.getMessage());
		}
		return "redirect:" + AdminConstant.EPS_CONTROLLER + AdminConstant.VIEW_EPS;
	}

	private boolean validateEPS(RedirectAttributes redirectAttrs, Eps eps, HttpSession session,
			HttpServletRequest request, BindingResult bindingResult, Response response) {
		boolean validated = true;
		if (eps.getEpsId() == null || eps.getEpsId().equals(0L)) {
			epsValidator.validate(eps, bindingResult);
			if (bindingResult.hasErrors()) {
				List<FieldError> errors = bindingResult.getFieldErrors();
				StringBuffer message = new StringBuffer();
				for (FieldError error : errors) {
					message.append(error.getDefaultMessage() + CommonConstants.MESSAGE);
				}
				response = setErrorValidate(CommonConstants.ERROR, message);
				redirectAttrs.addFlashAttribute("error", response.getMessage());
				validated = false;
			}
			eps.setCreatedOn(new Date());
			eps.setUpdatedOn(new Date());
			eps.setCreatedBy(SessionUtil.getUserFromRequestSession(request));
			eps.setUpdatedBy(SessionUtil.getUserFromRequestSession(request));
			eps.setStatus(Status.ACTIVE);
		} else {
			epsValidator.validate(eps, bindingResult);
			if (bindingResult.hasErrors()) {
				List<FieldError> errors = bindingResult.getFieldErrors();
				StringBuffer message = new StringBuffer();
				for (FieldError error : errors) {
					message.append(error.getDefaultMessage() + CommonConstants.MESSAGE);
				}
				response = setErrorValidate(CommonConstants.ERROR, message);
				redirectAttrs.addFlashAttribute("error", response.getMessage());
				validated = false;
			}
			eps.setStatus(Status.ACTIVE);
			eps.setUpdatedOn(new Date());
			eps.setUpdatedBy(SessionUtil.getUserFromRequestSession(request));
		}
		return validated;
	}

	private Response setErrorValidate(String type, StringBuffer message) {
		Response response = new Response();
		response.setStatus(type);
		response.setMessage(message.toString().substring(0, message.length() - 5));
		return response;
	}

	private Response setMessage(String type, String message) {
		Response response = new Response();
		response.setStatus(type);
		response.setMessage(messageByLocaleService.getMessage(message));
		return response;
	}

	@RequestMapping(value = AdminConstant.EXPORT_EPS, method = RequestMethod.POST)
	public void exportEps(Model model, HttpServletRequest request, HttpServletResponse response) throws IOException {
		List<Eps> listEps = epsService.findAllLocalData();
		net.sf.json.JSONObject jsonObject = new net.sf.json.JSONObject();
		net.sf.json.JSONObject jsonColumn = new net.sf.json.JSONObject();
		net.sf.json.JSONArray columnArray = new net.sf.json.JSONArray();
		List<String> colList = new ArrayList<String>(0);
		colList.add("Eps Code");
		colList.add("Eps");
		colList.add("Eps In Spanish");
		colList.add("Type");
		colList.add("Status");
		for (int i = 0; i < colList.size(); i++) {
			net.sf.json.JSONObject jsonColData = new net.sf.json.JSONObject();
			jsonColData.put("key", colList.get(i));
			columnArray.add(jsonColData);
		}
		jsonColumn.put("col_data", columnArray);
		net.sf.json.JSONObject jsonObjData = new net.sf.json.JSONObject();
		net.sf.json.JSONArray rowArray = new net.sf.json.JSONArray();
		for (Eps eps : listEps) {
			net.sf.json.JSONObject cellCol = new net.sf.json.JSONObject();
			net.sf.json.JSONArray cell = new net.sf.json.JSONArray();
			for (String colName : colList) {
				switch (colName) {
				case "Eps Code":
					net.sf.json.JSONObject jsonRowData = new net.sf.json.JSONObject();
					jsonRowData.put("key", colName);
					if(eps.getEpsCode()!=null){
						jsonRowData.put("value", eps.getEpsCode());
					}else{
						jsonRowData.put("value", "");
					}
					cell.add(jsonRowData);
					break;
				case "Eps":
					net.sf.json.JSONObject jsonRowData1 = new net.sf.json.JSONObject();
					jsonRowData1.put("key", colName);
					if(eps.getEps()!=null){
						jsonRowData1.put("value", eps.getEps());
					}else{
						jsonRowData1.put("value", "");
					}
					cell.add(jsonRowData1);
					break;
				case "Eps In Spanish":
					net.sf.json.JSONObject jsonRowData5 = new net.sf.json.JSONObject();
					jsonRowData5.put("key", colName);
					if(eps.getEpsInSpanish()!=null){
						jsonRowData5.put("value", eps.getEpsInSpanish());
					}else{
						jsonRowData5.put("value", "");
					}
					cell.add(jsonRowData5);
					break;
				case "Type":
					net.sf.json.JSONObject jsonRowData2 = new net.sf.json.JSONObject();
					jsonRowData2.put("key", colName);
					jsonRowData2.put("value", eps.getType().getEpsType());
					cell.add(jsonRowData2);
					break;
				case "Status":
					net.sf.json.JSONObject jsonRowData3 = new net.sf.json.JSONObject();
					jsonRowData3.put("key", colName);
					jsonRowData3.put("value", eps.getStatus().name());
					cell.add(jsonRowData3);
					break;
				default:
					break;
				}
				cellCol.put("cell", cell);
			}
			rowArray.add(cellCol);
			jsonObjData.put("row", rowArray);
		}
		jsonObject.put("col", jsonColumn);
		jsonObject.put("data", jsonObjData);
		DownloadFile.downloadFile(AdminConstant.EPSMODULE_NAME, AdminConstant.EXPORT_EXTENSION, jsonObject, request,
				response);
	}

	@RequestMapping(value = AdminConstant.IMPORT_EPS, method = RequestMethod.POST)
	public String importEps(@RequestParam("epsFile") MultipartFile file, Model model, RedirectAttributes redirectAttrs,
			HttpServletRequest request, HttpServletResponse response) throws IOException {
		Response responseStatus = new Response();
		User sender = SessionUtil.getUserFromRequestSession(request);
		PermissionUtil.checkPermission(sender, ActionConstant.ADD_NEW_EPS);
		try {
			File file1 = new File(file.getOriginalFilename());
			file.transferTo(file1);
			Workbook workbook = WorkbookFactory.create(file1);
			Sheet sheet = workbook.getSheetAt(0);
			Eps eps = new Eps();
			List<Eps> epsList = new ArrayList<Eps>();
			Iterator<Row> itr = sheet.iterator();
			while (itr.hasNext()) {
				Row row = itr.next();
				if (row.getRowNum() != 0) {
					eps = assignEps(row);
					if (eps != null) {
						epsList.add(eps);
					}
				}
			}
			boolean importEps = epsService.importEps(epsList);
			if (importEps) {
				responseStatus = setMessage(CommonConstants.SUCCESS, AdminConstant.EPS_IMPORTS);
			} else {
				responseStatus = setMessage(CommonConstants.ERROR, AdminConstant.EPS_IMPORT_FAIL);
			}
			workbook.close();
		} catch (Exception e) {
			e.printStackTrace();
			responseStatus = setMessage(CommonConstants.ERROR, AdminConstant.EPS_IMPORT_FAIL);
		}
		if (responseStatus.getStatus().equals(CommonConstants.SUCCESS)) {
			redirectAttrs.addFlashAttribute("success", responseStatus.getMessage());
		} else {
			redirectAttrs.addFlashAttribute("error", responseStatus.getMessage());
		}
		return "redirect:" + AdminConstant.EPS_CONTROLLER + AdminConstant.VIEW_EPS;
	}

	private Eps assignEps(Row row) {
		if(row.getCell(0) !=null && row.getCell(1) !=null && row.getCell(2) !=null && row.getCell(3) !=null){
			if ((!row.getCell(0).toString().trim().equalsIgnoreCase("null") || !row.getCell(0).toString().trim().equals(""))
					&& (!row.getCell(1).toString().trim().equalsIgnoreCase("null")
							|| !row.getCell(1).toString().trim().equals(""))
					&& (!row.getCell(2).toString().trim().equalsIgnoreCase("null")
							&& !row.getCell(2).toString().trim().equals(""))
					&& (!row.getCell(3).toString().trim().equalsIgnoreCase("null")
							|| !row.getCell(3).toString().trim().equals(""))) {
				Eps eps = new Eps();
				eps.setEpsCode(row.getCell(0).toString());
				eps.setEps(row.getCell(1).toString());
				eps.setEpsInSpanish(row.getCell(2).toString());
				eps.setType(EpsType.parse(row.getCell(3).toString()));
				eps.setStatus(Status.ACTIVE);
				return eps;
			} else {
				return null;
			}
		}else{
			return null;
		}
	}

}