package com.peer.admin.controller;

import java.util.Date;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.peer.admin.constant.AdminConstant;
import com.peer.constant.CommonConstants;
import com.peer.enm.Status;
import com.peer.enm.UserType;
import com.peer.scenity.entity.local.User;
import com.peer.scenity.entity.pojo.Response;
import com.peer.scenity.service.constant.ServiceConstant;
import com.peer.scenity.service.intf.IAuthTokenService;
import com.peer.scenity.service.intf.IFilesService;
import com.peer.scenity.service.intf.IUserService;
import com.peer.scenity.service.intf.MessageByLocaleService;
import com.peer.scenity.util.EmailTemplateLoader;
import com.peer.scenity.util.EncryptionUtil;
import com.peer.scenity.util.MailUtil;
import com.peer.scenity.util.SessionUtil;

@Controller
@RequestMapping("/")
public class LoginController {

	private static Logger _log = Logger.getLogger(LoginController.class);

	@Autowired
	private IUserService userService;

	@Autowired
	private IAuthTokenService authTokenService;

	@Autowired
	private MessageByLocaleService messageByLocaleService;

	@Autowired
	private IFilesService fileService;

	private static final String LOGIN_PAGE = "login/login";
	private static final String REDIRECT_DASHBOARD_PAGE = "redirect:" + AdminConstant.DASHBOARD_CONTROLLER
			+ AdminConstant.DASHBOARD_INDEX;
	private static final String PAGE_NOT_FOUND = "page/notfound";
	private static final String ERROR_PAGE = "error/error";
	private static final String LINK_EXPIRED = "login/expired";
	private static final String REDIRECT_LOGIN_PAGE = "redirect:/login";
	private static final String FORGOTPASSWORD_PAGE = "login/forgot";
	private static final String RESETPASSWORD_PAGE = "login/reset";

	@RequestMapping(AdminConstant.LOGIN)
	public String loginPage(Model model, HttpServletRequest request) {
		String redirect = LOGIN_PAGE;
		if (SessionUtil.isUserLoggedIn(request)) {
			redirect = REDIRECT_DASHBOARD_PAGE;
		} else {
			redirect = checkCookies(model, request);
		}
		return redirect;
	}

	@RequestMapping(value = AdminConstant.FORGOT_PASSWORD)
	public String forgotpasswordPage(Model model, HttpServletRequest request) {
		return FORGOTPASSWORD_PAGE;
	}

	@RequestMapping(value = AdminConstant.NEW_PASSWORD)
	public String newpasswordPage(Model model, HttpServletRequest request) {
		String emailAddress = request.getParameter("emailAddress");
		String token = request.getParameter("token");
		Boolean flag = authTokenService.verifyToken(emailAddress, token);
		if (flag == true) {
			model.addAttribute("emailAddress", emailAddress);
			return RESETPASSWORD_PAGE;
		}
		return LINK_EXPIRED;
	}

	@RequestMapping(value = AdminConstant.RESET_PASSWORD_ADMIN, method = RequestMethod.POST)
	@ResponseBody
	public ResponseEntity<Object> resetPasswordPage(Locale locale, Model model, HttpServletRequest request,
			RedirectAttributes redirectAttributes) {
		Response response = new Response();
		String emailAddress = request.getParameter("emailAddress");
		User user = userService.findUserResetPasswordlAdmin(emailAddress);
		JSONObject jsonObject = new JSONObject();
		if (user != null) {
			if (MailUtil.emailValidator(emailAddress)) {
				String token = authTokenService.createToken(emailAddress, new Date());
				String messageBody = EmailTemplateLoader.passwordResetTemplate(request, token, user);
				MailUtil.sendMail(user.getEmailAddress(), ServiceConstant.getPropertiesValue(ServiceConstant.MAIL_SUB),
						messageBody);
				response = setMessage(CommonConstants.SUCCESS, AdminConstant.LOGIN_LINK);
				jsonObject.put("success", response.getMessage());
			} else {
				response = setMessage(CommonConstants.ERROR, AdminConstant.LOGIN_RESET);
				jsonObject.put("error", response.getMessage());
			}
		} else {
			response = setMessage(CommonConstants.ERROR, AdminConstant.LOGIN_RESET);
			jsonObject.put("error", response.getMessage());
		}
		return new ResponseEntity<>(jsonObject.toString(), HttpStatus.OK);
	}

	@RequestMapping(AdminConstant.UPDATE_PASSWORD_ADMIN)
	public String updatePassword(Model model, HttpServletRequest request) {
		Response response = new Response();
		String newPassword = request.getParameter("newPassword");
		String confirmPassword = request.getParameter("confirmPassword");
		String email = request.getParameter("email");
		String message = validatePasswords(newPassword, confirmPassword);
		if (StringUtils.isBlank(message)) {
			User currentUser = userService.findUserResetPasswordlAdmin(email);
			currentUser.setPassword(EncryptionUtil.encrypt(newPassword));
			userService.mergeLocal(currentUser);
		}
		if (StringUtils.isBlank(message)) {
			response = setMessage(CommonConstants.SUCCESS, AdminConstant.LOGIN_SUCCESS);
			model.addAttribute("success", response.getMessage());
		} else {
			model.addAttribute("error", messageByLocaleService.getMessage(message));
		}
		return RESETPASSWORD_PAGE;
	}

	public String checkCookies(Model model, HttpServletRequest request) {
		String redirect = LOGIN_PAGE;
		String emailAddress = SessionUtil.findCookieValue(request, CommonConstants.SHARED_NAME);
		if (StringUtils.isNotBlank(emailAddress)) {
			User user = userService.findUserByEmail(emailAddress);
			if (null != user) {
				createSession(request, user);
				redirect = REDIRECT_DASHBOARD_PAGE;
			}
		} else {
			model.addAttribute("user", new User());
		}
		return redirect;
	}

	@RequestMapping(value = AdminConstant.LOGIN_USER, method = RequestMethod.POST)
	public String validate(@ModelAttribute("user") User user, HttpServletRequest request, HttpServletResponse response,
			Model model) {
		String redirect = LOGIN_PAGE;
		String message = "user.notexist";
		boolean fail = true;
		try {
			User user2 = userService.findUserByEmail(user.getEmailAddress());
			if (null != user2) {
				if (isValidUser(user2)) {
					if (Status.ACTIVE.equals(user2.getStatus())) {
						String password = user2.getPassword();
						String enteredPassword = EncryptionUtil.encrypt(user.getPassword());
						if (password.equals(enteredPassword)) {
							createSession(request, user2);
							updateRememberMe(user2, request, response);
							SessionUtil.updateLanguage(user2, request, response);
							fail = false;
						} else {
							message = "user.wrongpassword";
						}
					} else {
						message = "user.notactive";
					}
				} else {
					message = "user.notadmin";
				}
			}
		} catch (Exception e) {
			_log.error("", e);
		}
		if (fail) {
			model.addAttribute("error", message);
		} else {
			redirect = REDIRECT_DASHBOARD_PAGE;
		}
		return redirect;
	}

	public boolean isValidUser(User user) {
		if (null == user) {
			return false;
		}
		if (UserType.Admin.equals(user.getUserType()) || UserType.SubAdmin.equals(user.getUserType())
				|| UserType.Analyst.equals(user.getUserType())) {
			return true;
		}
		return false;
	}

	public void createSession(HttpServletRequest request, User loginUser) {
		HttpSession httpSession = request.getSession(true);
		httpSession.setAttribute(ServiceConstant.USER, loginUser);
		httpSession.setAttribute(ServiceConstant.USER_ID, loginUser.getUserId());
		httpSession.setAttribute(ServiceConstant.USER_FULL_NAME, loginUser.getFullName());
		String profileImagePath = fileService.getFilePath(loginUser.getProfileImg());
		httpSession.setAttribute(ServiceConstant.USER_PROFILE_IMAGE, profileImagePath);
	}

	public void updateRememberMe(User user, HttpServletRequest request, HttpServletResponse response) {
		String rememberMe = request.getParameter("rememberme");
		if (StringUtils.isNotBlank(rememberMe) && CommonConstants.YES.equals(rememberMe)) {
			SessionUtil.addCookie(CommonConstants.SHARED_NAME, user.getEmailAddress(), response);
		}
	}

	@RequestMapping(value = AdminConstant.LOGOUT_USER, method = RequestMethod.GET)
	public String logoutPage(HttpServletRequest request, HttpServletResponse response, HttpSession session) {
		session.invalidate();
		SessionUtil.deleteCookie(request, response, CommonConstants.SHARED_NAME);
		return REDIRECT_LOGIN_PAGE;
	}

	@RequestMapping("/success")
	public String loginSuccess() {
		return LOGIN_PAGE;
	}

	@RequestMapping("/error")
	public String loginError() {
		return ERROR_PAGE;
	}

	@RequestMapping("/404")
	public String pageNotFound(HttpServletRequest request) {
		return PAGE_NOT_FOUND;
	}

	public String validatePasswords(String password1, String password2) {
		if (StringUtils.isBlank(password1) || StringUtils.isBlank(password2)) {
			return AdminConstant.PASSWORD_PASSWORD;
		}
		if (!StringUtils.equals(password1, password2)) {
			return AdminConstant.PASSWORD_MATCH;
		}
		if (password1.length() < 6) {
			return AdminConstant.PASSWORD_SIZE;
		}
		return "";
	}

	private Response setMessage(String type, String message) {
		Response response = new Response();
		response.setStatus(type);
		response.setMessage(messageByLocaleService.getMessage(message));
		return response;
	}
}
