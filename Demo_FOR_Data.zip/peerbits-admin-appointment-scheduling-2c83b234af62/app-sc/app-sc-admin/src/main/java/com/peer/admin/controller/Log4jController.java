package com.peer.admin.controller;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Level;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping("/Log4jController")
public class Log4jController {

	private static Logger _log = Logger.getLogger(Log4jController.class);

	/**
	 * to Update LogLevel use Below Request
	 * /Log4jController/updateCategory?category=com.portal.service&level=DEBUG
	 * /Log4jController/updateCategory?rootCategory=true&level=DEBUG
	 * 
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/updateCategory", method = RequestMethod.GET)
	@ResponseBody
	public ResponseEntity<Object> updateCategory(HttpServletRequest request) {
		String categoryAdded = "true";
		String category = request.getParameter("category");
		String level = request.getParameter("level");
		String rootCategory = request.getParameter("rootCategory");
		_log.info("rootCategory: " + rootCategory);
		_log.info("category: " + category);
		_log.info("level: " + level);
		try {
			if (StringUtils.isNotBlank(category) && StringUtils.isNotBlank(level)) {
				LogManager.getLogger(category).setLevel(Level.toLevel(level));
				_log.info("log level updated for category: " + category + " :level: " + level);
			} else if (StringUtils.isNotBlank(rootCategory) && StringUtils.isNotBlank(level)) {
				LogManager.getRootLogger().setLevel(Level.toLevel(level));
				_log.info("log level updated for root category: " + rootCategory + " :level: " + level);
			}
		} catch (Exception e) {
			_log.error("", e);
			categoryAdded = "false";
		}
		JSONObject jsonObject = new JSONObject();
		try {
			jsonObject.put("categoryAdded", categoryAdded);
		} catch (JSONException e) {
			e.printStackTrace();
		}
		return new ResponseEntity<Object>(jsonObject.toString(), HttpStatus.OK);
	}

}
