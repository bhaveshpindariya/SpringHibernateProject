package com.peer.admin.validate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;
import com.peer.scenity.entity.local.Faq;
import com.peer.scenity.service.constant.ServiceConstant;
import com.peer.scenity.service.intf.MessageByLocaleService;

@Component
public class FaqValidator implements Validator{
	@Autowired
	private MessageByLocaleService messageByLocaleService;
	
	@Override
	public boolean supports(Class<?> clazz) {
		return Faq.class.isAssignableFrom(clazz);
	}

	@Override
	public void validate(Object target, Errors errors) {
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "question", "error.field.empty",messageByLocaleService.getMessage(ServiceConstant.FAQ_QUESTION));
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "answer", "error.field.empty",messageByLocaleService.getMessage(ServiceConstant.FAQ_ANSWER));
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "questionInSpanish", "error.field.empty",messageByLocaleService.getMessage(ServiceConstant.FAQ_QUESTIONSPANISH));
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "answerInSpanish", "error.field.empty",messageByLocaleService.getMessage(ServiceConstant.FAQ_ANSWERSPANISH));
	}

}
