package com.peer.admin.validate;

import java.util.regex.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.peer.scenity.entity.local.User;
import com.peer.scenity.service.constant.ServiceConstant;
import com.peer.scenity.service.intf.MessageByLocaleService;

@Component
public class DoctorEditValidator implements Validator {

	@Autowired
	private MessageByLocaleService messageByLocaleService;
	
	@Override
	public boolean supports(Class<?> clazz) {
		return User.class.isAssignableFrom(clazz);
	}

	@Override
	public void validate(Object target, Errors errors) {
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "fullName", "error.field.empty",messageByLocaleService.getMessage(ServiceConstant.DOCTORNAME));
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "emailAddress", "error.field.empty",messageByLocaleService.getMessage(ServiceConstant.DOCTOREMAIL));
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "contactNo", "error.field.empty",messageByLocaleService.getMessage(ServiceConstant.DOCTORNUMBER));
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "password", "error.field.empty",messageByLocaleService.getMessage(ServiceConstant.DOCTORPASSWORD));
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "privacy", "error.field.empty",messageByLocaleService.getMessage(ServiceConstant.DOCTORPRIVACY));
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "identificationcard", "error.field.empty",messageByLocaleService.getMessage(ServiceConstant.DOCTORPASSWORD));
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "registro", "error.field.empty",messageByLocaleService.getMessage(ServiceConstant.DOCTORPRIVACY));
		
		User user = (User) target;
		String email = user.getEmailAddress();
		String number = user.getContactNo();
		/*String identificationcard = user.getIdentificationcard();*/
		
		if(user.getEpsSet().size()<1)
			ValidationUtils.rejectIfEmptyOrWhitespace(errors, "epsSet", "error.field.empty",messageByLocaleService.getMessage(ServiceConstant.DOCTOREPS));
		if(user.getCategorySet().size()<1)
			ValidationUtils.rejectIfEmptyOrWhitespace(errors, "categorySet", "error.field.empty",messageByLocaleService.getMessage(ServiceConstant.DOCTORCATEGORY));
		if (!isValid(email))
			errors.rejectValue("emailAddress", "error.emailAddress.Wrong",messageByLocaleService.getMessage(ServiceConstant.DOCTOREMAIL_WRONG));
		if (!isValidNumber(number))
			errors.rejectValue("contactNo", "error.contactNo.Wrong",messageByLocaleService.getMessage(ServiceConstant.DOCTORNUMBER_WRONG));
		/*if (!isValidNumbers(identificationcard))
			errors.rejectValue("identificationcard", "error.identificationcard.Wrong",messageByLocaleService.getMessage(ServiceConstant.DOCTORIDENTIFICATION_WRONG));
		*/
	}
	
	public static boolean isValid(String email) {
		String emailRegex = "^[a-zA-Z0-9_+&*-]+(?:\\." + "[a-zA-Z0-9_+&*-]+)*@" + "(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,7}$";
		Pattern pat = Pattern.compile(emailRegex);
		if (email == null)
			return false;
		return pat.matcher(email).matches();
	}
	public static boolean isValidNumber(String number) {
		String regex = "^[1-9][0-9]{7,14}$";
		Pattern pat = Pattern.compile(regex);
		if (number == null)
			return false;
		return pat.matcher(number).matches();
	}
	public static boolean isValidNumbers(String number) {
		String regex = "^[0-9]{7,19}$";
		Pattern pat = Pattern.compile(regex);
		if (number == null)
			return false;
		return pat.matcher(number).matches();
	}
}
