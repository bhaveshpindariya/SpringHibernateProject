package com.peer.admin.controller;

import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Objects;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.peer.admin.constant.AdminConstant;
import com.peer.constant.CommonConstants;
import com.peer.enm.Action;
import com.peer.enm.Status;
import com.peer.scenity.entity.local.Schedule;
import com.peer.scenity.entity.local.User;
import com.peer.scenity.entity.pojo.Response;
import com.peer.scenity.service.intf.IEpsService;
import com.peer.scenity.service.intf.ILocationService;
import com.peer.scenity.service.intf.IScheduleService;
import com.peer.scenity.service.intf.IScheduleSlotService;
import com.peer.scenity.service.intf.IUserService;
import com.peer.scenity.service.intf.MessageByLocaleService;
import com.peer.scenity.service.intf.ZeusProgrammacionMedicoService;
import com.peer.scenity.util.SessionUtil;

@Controller
@RequestMapping(AdminConstant.ADD_SCHEDULING_CONTROLLER)
public class AddScheduleController {

	public static Logger _log = Logger.getLogger(AddScheduleController.class);

	public static final String NEW_SCHEDULE_FORM = "add-schedule/add";

	@Autowired
	private IScheduleSlotService scheduleSlotService;

	@Autowired
	private IUserService userService;

	@Autowired
	private IScheduleService scheduleService;

	@Autowired
	private MessageByLocaleService messageByLocaleService;

	@Autowired
	private IEpsService epsService;

	@Autowired
	private ILocationService locationService;

	@Autowired
	private ZeusProgrammacionMedicoService programacionService;

	@RequestMapping(AdminConstant.NEW_APPOINTMENT_SCHEDULE)
	public String scheduleAppointment(Model model) {
		model.addAttribute("locations", locationService.findAllLocal());
		model.addAttribute("eps", epsService.findAllLocalActive());
		List<User> doctors = userService.findAllDoctors();
		model.addAttribute("doctor", doctors);
		return NEW_SCHEDULE_FORM;
	}

	@RequestMapping(AdminConstant.ADD_NEW_APPOINTMENT_SCHEDULE)
	@ResponseBody
	public ResponseEntity<Object> addSchedule(HttpServletRequest request) {
		Schedule schedule = null;
		Response response = null;
		schedule = new Schedule();
		try {
			long doctorId = Long.parseLong(request.getParameter("doctor"));
			User doctor = userService.findByIdLocal(doctorId);
			String startDateStr = request.getParameter("startdate");
			LocalDate startDate = LocalDate.parse(startDateStr, CommonConstants.FORMATTER);
			String startTime = request.getParameter("startTime");
			String endTime = request.getParameter("endTime");
			long locationId = Long.parseLong(request.getParameter("location"));
			long epsId = Long.parseLong(request.getParameter("eps"));
			long maxAppointments = Long.parseLong(request.getParameter("maxAppointments"));
			String isCopy = request.getParameter("rdGroup1");

			schedule.setDoctor(doctor);
			schedule.setStartDate(Date.from(startDate.atStartOfDay().atZone(ZoneId.systemDefault()).toInstant()));
			schedule.setEndDate(Date.from(startDate.atStartOfDay().atZone(ZoneId.systemDefault()).toInstant()));
			schedule.setStartTime(startTime);
			schedule.setEndTime(endTime);
			schedule.setEps(epsService.findByIdLocal(epsId));
			schedule.setLocation(locationService.findByIdLocal(locationId));
			schedule.setMaxAppointments(maxAppointments);

			if (null != isCopy && (isCopy.equalsIgnoreCase(CommonConstants.YES))) {
				String[] copyDays = request.getParameterValues("q1");
				String repeatDays = Arrays.toString(copyDays);
				String endDateStr = request.getParameter("endDate");
				LocalDate endDate = LocalDate.parse(endDateStr, CommonConstants.FORMATTER);
				schedule.setRepeatDays(repeatDays);
				schedule.setEndDate(Date.from(endDate.atStartOfDay().atZone(ZoneId.systemDefault()).toInstant()));
			}

			schedule.setCreatedBy(SessionUtil.getUserFromRequestSession(request));
			schedule.setCreatedOn(new Date());
			schedule.setUpdatedBy(SessionUtil.getUserFromRequestSession(request));
			schedule.setUpdatedOn(new Date());
			schedule.setStatus(Status.AWAITING_APPROVAL);
			response = scheduleSlotService.scheduleValidator(schedule);
			if (response.getStatus().equals(CommonConstants.SUCCESS)) {
				scheduleService.persistLocal(schedule);
				Long programacionMedicoId = programacionService.addScheduleZeus(schedule);
				response = scheduleSlotService.addScheduleSlots(schedule, programacionMedicoId);
				if (response.getStatus().equals(CommonConstants.SUCCESS)) {
					if (!Objects.isNull(programacionMedicoId) && programacionMedicoId != 0) {
						schedule.setZeusScheduleId(programacionMedicoId);
						schedule.setUpdatedBy(SessionUtil.getUserFromRequestSession(request));
						schedule.setUpdatedOn(new Date());
						schedule.setStatus(Status.ACTIVE);
						schedule = scheduleService.mergeLocal(schedule);
						response = setMessage(CommonConstants.SUCCESS, AdminConstant.SCHEDULE_ADD_SUCCESS);
						scheduleService.sendNotification(schedule, Action.ADDED);
					}
				}
			}
		} catch (Exception e) {
			_log.error("Error Adding Schedule :--", e);
			response = setMessage(CommonConstants.ERROR, AdminConstant.SCHEDULE_ADD_ERROR);
		}

		JSONObject jsonObject = new JSONObject();
		jsonObject.put("status", response.getStatus());
		jsonObject.put("message", response.getMessage());
		return new ResponseEntity<>(jsonObject.toString(), HttpStatus.OK);
	}

	@RequestMapping("/scheduleaddRedirect")
	public String scheduleSuccess(HttpServletRequest request, RedirectAttributes redirectAttributes) {
		if (request.getParameter("message") != null) {
			redirectAttributes.addFlashAttribute("success", request.getParameter("message"));
		}
		return "redirect:" + AdminConstant.MANAGE_SCHEDULE_CONTROLLER + AdminConstant.VIEW_ALL_SCHEDULE;
	}

	private Response setMessage(String type, String message) {
		Response response = new Response();
		response.setStatus(type);
		response.setMessage(messageByLocaleService.getMessage(message));
		return response;
	}
}
