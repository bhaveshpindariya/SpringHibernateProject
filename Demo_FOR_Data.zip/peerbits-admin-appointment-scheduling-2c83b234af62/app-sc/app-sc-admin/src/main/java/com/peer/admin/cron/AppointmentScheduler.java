package com.peer.admin.cron;

import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.peer.enm.Status;
import com.peer.scenity.entity.local.Appointments;
import com.peer.scenity.service.constant.ServiceConstant;
import com.peer.scenity.service.intf.IAppointmentsService;
import com.peer.scenity.util.ServiceUtils;
import com.peer.util.DateUtil;

@Component("appointmentScheduler")
public class AppointmentScheduler {

	private static Logger _log = Logger.getLogger(AppointmentScheduler.class);

	public static Date jobDate = null;

	private static IAppointmentsService appointmentsService;

	@Scheduled(cron = "0 0 11 * * *")
	public void appointmentScheduler() {
		try {
			_log.info("scheduler job started for appointment reminder");
			List<Status> statusList = ServiceUtils.getStatusList(Status.APPROVED);
			Date tomorrowDate = DateUtil.getDateOffset(1);
			String apptDate = DateUtil.formateDate(tomorrowDate, DateUtil.DD_MM_YYYY);
			Date appointmentDate = DateUtil.parseDate(apptDate, DateUtil.DD_MM_YYYY);

			// Spring Scheduler running twice at the moment so added below logic to overcome
			boolean jobDone = false;
			if (null != jobDate && jobDate.equals(appointmentDate)) {
				jobDone = true;
			} else {
				jobDate = appointmentDate;
			}
			if (!jobDone) {
				List<Appointments> appointmentsList = appointmentsService.findAppointmentsAll(statusList, "",
						appointmentDate, 0l, 0, -1);
				_log.info("Total appointment for date " + apptDate + " : " + appointmentsList.size());
				for (Appointments appointments : appointmentsList) {
					ServiceUtils.sendSMS(appointments, ServiceConstant.APPT_REMINDER);
				}
			}
			_log.info("scheduler job ended for appointment reminder");
		} catch (Exception e) {
			_log.error("", e);
		}
	}

	public static IAppointmentsService getAppointmentsService() {
		return appointmentsService;
	}

	public static void setAppointmentsService(IAppointmentsService appointmentsService) {
		AppointmentScheduler.appointmentsService = appointmentsService;
	}

}