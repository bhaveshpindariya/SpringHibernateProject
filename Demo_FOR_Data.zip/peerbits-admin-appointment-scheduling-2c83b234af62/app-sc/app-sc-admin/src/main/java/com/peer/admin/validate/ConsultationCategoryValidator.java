package com.peer.admin.validate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.peer.scenity.entity.local.Category;
import com.peer.scenity.service.constant.ServiceConstant;
import com.peer.scenity.service.intf.MessageByLocaleService;

@Component
public class ConsultationCategoryValidator implements Validator {

	@Autowired
	private MessageByLocaleService messageByLocaleService;
	
	@Override
	public boolean supports(Class<?> clazz) {
		return Category.class.isAssignableFrom(clazz);
	}

	@Override
	public void validate(Object target, Errors errors) {
		
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "type", "error.field.empty",messageByLocaleService.getMessage(ServiceConstant.CONSULTATION_TYPE));
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "name", "error.field.empty",messageByLocaleService.getMessage(ServiceConstant.CONSULTATION_NAME));
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "nameInSpanish", "error.field.empty",messageByLocaleService.getMessage(ServiceConstant.CONSULTATION_NAMEINSPANISH));
	}

}
