package com.peer.admin.controller;

import java.util.Date;
import java.util.List;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.peer.admin.constant.AdminConstant;
import com.peer.admin.util.PermissionUtil;
import com.peer.admin.validate.CancellationValidator;
import com.peer.constant.ActionConstant;
import com.peer.constant.CommonConstants;
import com.peer.enm.Status;
import com.peer.enm.UserType;
import com.peer.scenity.entity.local.Cancellation;
import com.peer.scenity.entity.local.Settings;
import com.peer.scenity.entity.local.User;
import com.peer.scenity.entity.pojo.Response;
import com.peer.scenity.service.intf.ICancellationService;
import com.peer.scenity.service.intf.ISettingsService;
import com.peer.scenity.service.intf.MessageByLocaleService;
import com.peer.scenity.util.SessionUtil;
import com.peer.util.CommonUtil;

@Controller
@RequestMapping(AdminConstant.CANCEL_CONTROLLER)
public class CancellationController {
	
	private static Logger _log = Logger.getLogger(CancellationController.class);
	
	private static final String VIEW_CANCEL_PAGE = "cancel/viewCancel";
	
	@Autowired
	private ICancellationService cancelService;
	
	@Autowired
	private CancellationValidator cancellationValidator;
	
	@Autowired
	private ISettingsService setService;
	
	@Autowired
	private MessageByLocaleService messageByLocaleService;

	@RequestMapping(AdminConstant.VIEW_ALL_CANCEL_MAPPING)
	public String viewAllCancel(Locale locale, Model model,HttpServletRequest request) {
		User sender = SessionUtil.getUserFromRequestSession(request);
		PermissionUtil.checkPermission(sender, ActionConstant.VIEW_CANCELLATION);
		_log.info("inside landing cancel page ");
		Settings settings = setService.findLatestTypeSetting(CommonConstants.SETTING_TYPE_CANCELLATION_HOURS);
		model.addAttribute("cancellation", new Cancellation());
		model.addAttribute("actorList", UserType.getAllUserType());
		model.addAttribute("Settings", settings);
		return VIEW_CANCEL_PAGE;
		
	}
	
	@RequestMapping(AdminConstant.FETCH_CANCEL)
	@ResponseBody
	public ResponseEntity<Object> fetchCancel(Locale locale, Model model,HttpServletRequest request) {
		String start = request.getParameter("start");
		String length = request.getParameter("length");
		String draw = request.getParameter("draw");
		int startI = 0;
		int lengthI = 10;
		if (StringUtils.isNotBlank(start) && StringUtils.isNumeric(start)) {
			startI = Integer.parseInt(start);
		}
		if (StringUtils.isNotBlank(length) && StringUtils.isNumeric(length)) {
			lengthI = Integer.parseInt(length);
		}
		JSONArray jsonArray = cancelService.paginateCancellation(startI, lengthI);
		Long totalCancel = Long.parseLong(cancelService.findAllLocalData().size()+"");
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("data", jsonArray);
		jsonObject.put("draw", draw);
		jsonObject.put("recordsTotal", totalCancel);
		jsonObject.put("recordsFiltered", totalCancel);
		return new ResponseEntity<Object>(jsonObject.toString(), HttpStatus.OK);
	}
	
	@RequestMapping(value = AdminConstant.UPDATE_HOURS, method = RequestMethod.POST)
	public String updatehours(Locale locale,Model model,RedirectAttributes redirectAttrs,HttpServletRequest request) {
		User sender = SessionUtil.getUserFromRequestSession(request);
		PermissionUtil.checkPermission(sender, ActionConstant.UPDATE_HOURS);
		String value = request.getParameter("value");
		_log.info("add or update  data in cancellation hours");
		Settings settings = setService.findLatestTypeSetting(CommonConstants.SETTING_TYPE_CANCELLATION_HOURS);
		if(null == settings) {
			settings = new Settings();
			settings.setStatus(Status.ACTIVE);
			settings.setType(CommonConstants.SETTING_TYPE_CANCELLATION_HOURS);
			settings.setValue(value);
			settings.setCreatedOn(new Date());
			settings.setUpdatedOn(new Date());
			settings.setCreatedBy(SessionUtil.getUserFromRequestSession(request));
			settings.setUpdatedBy(SessionUtil.getUserFromRequestSession(request));
			setService.persistLocal(settings);
		}else {
			settings.setValue(value);
			settings.setUpdatedBy(SessionUtil.getUserFromRequestSession(request));
			settings.setUpdatedOn(new Date());
			setService.mergeLocal(settings);
		}
		return "redirect:" + AdminConstant.CANCEL_CONTROLLER +AdminConstant.VIEW_ALL_CANCEL_MAPPING;

	}
	@RequestMapping(value = AdminConstant.ADD_OR_EDIT_CANCEL, method = RequestMethod.POST)
	public String addOrEditCancel(Model model,RedirectAttributes redirectAttrs,Locale locale,HttpSession session, HttpServletRequest request,@ModelAttribute("cancellation") Cancellation cancel,BindingResult bindingResult) {
		Response response = new Response();
		Boolean isEmpty = CommonUtil.checkNull(cancel);
		if (!isEmpty) {
			try {
				boolean check=validateCancel(redirectAttrs,cancel, session, request, bindingResult, response);
				if(check){
					if (cancel.getId() == null || cancel.getId().equals(0L)) {
						User sender = SessionUtil.getUserFromRequestSession(request);
						PermissionUtil.checkPermission(sender, ActionConstant.ADD_NEW_CANCELLATION);
						
						List<Cancellation> cancelcheck=cancelService.findByCancellationByNameAndActor(cancel);
						if(cancelcheck.size()>0){
							response=setMessage(CommonConstants.WARNING,AdminConstant.CANCEL_EXIT);
						}else{
							try {
								_log.info("add data in cancellation");
								cancelService.persistLocal(cancel);
								response=setMessage(CommonConstants.SUCCESS,AdminConstant.CANCEL_SUCCESS);
							} catch (Exception e) {
								_log.error("Error:--", e);
								response=setMessage(CommonConstants.ERROR,AdminConstant.CANCEL_ERROR);
							}
						}
					}else{
						User sender = SessionUtil.getUserFromRequestSession(request);
						PermissionUtil.checkPermission(sender, ActionConstant.EDIT_CANCELLATION);
						
						List<Cancellation> cancelcheck = cancelService.findByCancellationByNameAndActorById(cancel);
						if(cancelcheck.size()>0){
							response=setMessage(CommonConstants.WARNING,AdminConstant.CANCEL_DUBLICATE);
						}else{
							Cancellation cancelObject=cancelService.findByIdLocal(cancel.getId());
							cancel.setCreatedBy(cancelObject.getCreatedBy());
							cancel.setCreatedOn(cancelObject.getCreatedOn());
							try {
								_log.info("update data in eps");
								cancelService.mergeLocal(cancel);
								response=setMessage(CommonConstants.SUCCESS,AdminConstant.CANCEL_UPDATE);
							} catch (Exception e) {
								_log.error("Error:--", e);
								response=setMessage(CommonConstants.ERROR,AdminConstant.CANCEL_ERROR);
							}
						}
					}
				}else{
					return "redirect:" + AdminConstant.CANCEL_CONTROLLER +AdminConstant.VIEW_ALL_CANCEL_MAPPING;
				}
			} catch (Exception e) {
				_log.error("Error:--", e);
				response=setMessage(CommonConstants.ERROR,AdminConstant.CANCEL_ERROR);
			}
		} else {
			response=setMessage(CommonConstants.ERROR,AdminConstant.CANCEL_EXCEPTION);
		}
		if(response.getStatus().equals(CommonConstants.SUCCESS)){
			redirectAttrs.addFlashAttribute("success", response.getMessage());
		}else{
			redirectAttrs.addFlashAttribute("error", response.getMessage());
		}
		return "redirect:" + AdminConstant.CANCEL_CONTROLLER +AdminConstant.VIEW_ALL_CANCEL_MAPPING;
		
	}
	
	@RequestMapping(value = AdminConstant.REMOVE_CANCELLATION, method = RequestMethod.POST)
	public String deleteCancel(Locale locale,Model model,RedirectAttributes redirectAttrs, @ModelAttribute("cancellation") Cancellation cancel,HttpSession session, HttpServletRequest request) {
		User sender = SessionUtil.getUserFromRequestSession(request);
		PermissionUtil.checkPermission(sender, ActionConstant.DELETE_CANCELLATION);
		
		Response response = new Response();
		Cancellation foundCancel = cancelService.findByIdLocal(cancel.getId());
		foundCancel.setStatus(Status.DELETED);
		foundCancel.setUpdatedBy(SessionUtil.getUserFromRequestSession(request));
		foundCancel.setUpdatedOn(new Date());
		try {
			_log.info("remove data in Cancel ");
			cancelService.deleteLocal(foundCancel);
			response=setMessage(CommonConstants.SUCCESS,AdminConstant.CANCEL_DELETE);
		} catch (Exception e) {
			_log.error("Error:--", e);
			response=setMessage(CommonConstants.ERROR,AdminConstant.CANCEL_EXCEPTION);
		}
		if(response.getStatus().equals(CommonConstants.SUCCESS)){
			redirectAttrs.addFlashAttribute("success", response.getMessage());
		}else{
			redirectAttrs.addFlashAttribute("error", response.getMessage());
		}
		return "redirect:" + AdminConstant.CANCEL_CONTROLLER +AdminConstant.VIEW_ALL_CANCEL_MAPPING;
		
	}
	
	private boolean validateCancel(RedirectAttributes redirectAttrs,Cancellation cancel, HttpSession session,HttpServletRequest request,BindingResult bindingResult,Response response) {
        boolean validated = true;
        if (cancel.getId() == null || cancel.getId().equals(0L)) {
        	cancellationValidator.validate(cancel, bindingResult);
            if (bindingResult.hasErrors()) {
                List<FieldError> errors = bindingResult.getFieldErrors();
                StringBuffer message = new StringBuffer();
                for (FieldError error : errors) {
                    message.append(error.getDefaultMessage() + CommonConstants.MESSAGE);
                }
                response=setErrorValidate(CommonConstants.ERROR,message);
                redirectAttrs.addFlashAttribute("error", response.getMessage());
                validated = false;
            }
            cancel.setCreatedOn(new Date());
            cancel.setUpdatedOn(new Date());
            cancel.setCreatedBy(SessionUtil.getUserFromRequestSession(request));
            cancel.setUpdatedBy(SessionUtil.getUserFromRequestSession(request));
            cancel.setStatus(Status.ACTIVE);
        } else {
        	cancellationValidator.validate(cancel, bindingResult);
            if (bindingResult.hasErrors()) {
                List<FieldError> errors = bindingResult.getFieldErrors();
                StringBuffer message = new StringBuffer();
                for (FieldError error : errors) {
                    message.append(error.getDefaultMessage() + CommonConstants.MESSAGE);
                }
                response=setErrorValidate(CommonConstants.ERROR,message);
                redirectAttrs.addFlashAttribute("error", response.getMessage());
                validated = false;
            }
            cancel.setStatus(Status.ACTIVE);
            cancel.setUpdatedOn(new Date());
            cancel.setUpdatedBy(SessionUtil.getUserFromRequestSession(request));
        }
        return validated;
    }
	
	private Response setErrorValidate(String type,StringBuffer message) {
		Response response = new Response();
		response.setStatus(type);
		response.setMessage(message.toString().substring(0, message.length() - 5));
		return response;
	}
	
	private Response setMessage(String type,String message) {
		Response response = new Response();
		response.setStatus(type);
		response.setMessage(messageByLocaleService.getMessage(message));
		return response;
	}

}
