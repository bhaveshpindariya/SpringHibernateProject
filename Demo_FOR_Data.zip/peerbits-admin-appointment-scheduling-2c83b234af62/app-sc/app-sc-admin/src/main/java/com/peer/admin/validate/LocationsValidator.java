package com.peer.admin.validate;

import java.util.regex.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.peer.scenity.entity.local.Locations;
import com.peer.scenity.service.constant.ServiceConstant;
import com.peer.scenity.service.intf.MessageByLocaleService;

@Component
public class LocationsValidator implements Validator {

	@Autowired
	private MessageByLocaleService messageByLocaleService;
	
	@Override
	public boolean supports(Class<?> clazz) {
		return Locations.class.isAssignableFrom(clazz);
	}

	@Override
	public void validate(Object target, Errors errors) {
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "location", "error.field.empty",messageByLocaleService.getMessage(ServiceConstant.LOCATION));
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "locationInSpanish", "error.field.empty",messageByLocaleService.getMessage(ServiceConstant.LOCATIONINSPANISH));
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "zuesLocationCode", "error.field.empty",messageByLocaleService.getMessage(ServiceConstant.LOCATIONCODE));
		
		Locations locations = (Locations) target;
		String number = locations.getZuesLocationCode();
		
		if (!isValidNumber(number))
			errors.rejectValue("zuesLocationCode", "error.zuesLocationCode.Wrong",messageByLocaleService.getMessage(ServiceConstant.LOCATIONCODE_WRONG));
	}
	
	public static boolean isValidNumber(String number) {
		String regex = "[0-9]+";
		Pattern pat = Pattern.compile(regex);
		if (number == null)
			return false;
		return pat.matcher(number).matches();
	}

}
