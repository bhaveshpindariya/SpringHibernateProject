package com.peer.admin.validate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.peer.scenity.entity.local.Cancellation;
import com.peer.scenity.service.constant.ServiceConstant;
import com.peer.scenity.service.intf.MessageByLocaleService;

@Component
public class CancellationValidator implements Validator {

	@Autowired
	private MessageByLocaleService messageByLocaleService;
	
	@Override
	public boolean supports(Class<?> clazz) {
		return Cancellation.class.isAssignableFrom(clazz);
	}

	@Override
	public void validate(Object target, Errors errors) {
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "reason", "error.field.empty",messageByLocaleService.getMessage(ServiceConstant.CANCEL_REASON));
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "reasonInSpanish", "error.field.empty",messageByLocaleService.getMessage(ServiceConstant.CANCEL_REASON_SPANISH));
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "actor", "error.field.empty",messageByLocaleService.getMessage(ServiceConstant.CANCEL_ACTOR));
	}
	
}
