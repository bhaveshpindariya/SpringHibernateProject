package com.peer.admin.controller;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.peer.admin.constant.AdminConstant;
import com.peer.admin.util.PermissionUtil;
import com.peer.admin.validate.LocationsValidator;
import com.peer.constant.ActionConstant;
import com.peer.constant.CommonConstants;
import com.peer.enm.Status;
import com.peer.scenity.entity.local.Locations;
import com.peer.scenity.entity.local.User;
import com.peer.scenity.entity.pojo.Response;
import com.peer.scenity.entity.zeus.PuntoAtencion;
import com.peer.scenity.service.intf.ILocationService;
import com.peer.scenity.service.intf.MessageByLocaleService;
import com.peer.scenity.service.intf.ZeusPuntoAtencionService;
import com.peer.scenity.util.SessionUtil;
import com.peer.util.CommonUtil;
import com.peer.util.DownloadFile;

@Controller
@RequestMapping(AdminConstant.LOCATION_CONTROLLER)
public class LocationController {
	
	private static Logger _log = Logger.getLogger(LocationController.class);
	
	@Autowired
	private ILocationService locationService;
	
	@Autowired
	private LocationsValidator locationsValidator;
	
	@Autowired
	private ZeusPuntoAtencionService zeusPuntoAtencionService;
	
	@Autowired
	private MessageByLocaleService messageByLocaleService;
	
	private static final String VIEW_LOCATION_PAGE = "location/viewlocation";
	
	@RequestMapping(AdminConstant.VIEW_ALL_LOCATION_MAPPING)
	public String viewAllLocationPage(Locale locale, Model model,HttpServletRequest request) {
		User sender = SessionUtil.getUserFromRequestSession(request);
		PermissionUtil.checkPermission(sender, ActionConstant.VIEW_LOCATION);
		_log.info("inside landing Locations page ");
		model.addAttribute("location", new Locations());
		return VIEW_LOCATION_PAGE;
	}
	
	@RequestMapping(AdminConstant.FETCH_LOCATION)
	@ResponseBody
	public ResponseEntity<Object> fetchLocation(Locale locale, Model model,HttpServletRequest request) {
		String start = request.getParameter("start");
		String length = request.getParameter("length");
		String draw = request.getParameter("draw");
		String locationStatus = request.getParameter("locationStatus");
		int startI = 0;
		int lengthI = 10;
		int status = -1;
		if (StringUtils.isNotEmpty(locationStatus) && StringUtils.isNumeric(locationStatus)) {
			status = Integer.parseInt(locationStatus);
		}
		if (StringUtils.isNotBlank(start) && StringUtils.isNumeric(start)) {
			startI = Integer.parseInt(start);
		}
		if (StringUtils.isNotBlank(length) && StringUtils.isNumeric(length)) {
			lengthI = Integer.parseInt(length);
		}
		JSONArray jsonArray = locationService.paginateLocation(startI, lengthI,status);
		Long totalLocation = locationService.paginateLocationCount(startI, lengthI, status);
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("data", jsonArray);
		jsonObject.put("draw", draw);
		jsonObject.put("recordsTotal", totalLocation);
		jsonObject.put("recordsFiltered", totalLocation);
		return new ResponseEntity<Object>(jsonObject.toString(), HttpStatus.OK);
	}
	
	@RequestMapping(value = AdminConstant.ADD_OR_EDIT_LOCATION, method = RequestMethod.POST)
	public String addLocations(Model model,RedirectAttributes redirectAttrs,Locale locale,HttpSession session, HttpServletRequest request,@ModelAttribute("location") Locations location,BindingResult bindingResult) {
		Response response = new Response();
		Boolean isEmpty = CommonUtil.checkNull(location);
		String department = request.getParameter("department");
		String municipio = request.getParameter("municipality");
		int  sede = Integer.parseInt(request.getParameter("headquarters"));
		if (!isEmpty) {
			try {
				boolean check=validateLocation(redirectAttrs,location, session, request, bindingResult, response);
				if(check){
					if (location.getLocationId() == null || location.getLocationId().equals(0L)) {
						User sender = SessionUtil.getUserFromRequestSession(request);
						PermissionUtil.checkPermission(sender, ActionConstant.ADD_NEW_LOCATION);
						Long locationcheck = locationService.findByLocationName(location);
						if(locationcheck>0){
							if(locationcheck == 2){
								PuntoAtencion puntoAtencion=zeusPuntoAtencionService.findPuntoAtencion(location);
								List<Locations> data=locationService.findByLocationNames(location);
								if(data.size()>0){
									response=setMessage(CommonConstants.WARNING,AdminConstant.LOCATION_EXIT);
								}else{
									try {
										puntoAtencion.setCode(location.getZuesLocationCode());
										puntoAtencion=zeusPuntoAtencionService.mergeZeus(puntoAtencion);
										location.setZuesLocationCode(puntoAtencion.getCode());
										location.setZuesLocationId(puntoAtencion.getId());
										locationService.persistLocal(location);
										response=setMessage(CommonConstants.SUCCESS,AdminConstant.LOCATION_SUCCESS);
									} catch (Exception e) {
										_log.error("Error:--", e);
										response=setMessage(CommonConstants.ERROR,AdminConstant.LOCATION_ERROR);
									}
								}
							}else{
								response=setMessage(CommonConstants.WARNING,AdminConstant.LOCATION_EXIT);
							}
						}else{
							try {
								_log.info("add data in location");
								PuntoAtencion puntoAtencion=new PuntoAtencion();
								puntoAtencion.setCode(location.getZuesLocationCode());
								puntoAtencion.setName(location.getLocationInSpanish());
								puntoAtencion.setStatus(true);
								puntoAtencion.setGeneratePlan(false);
								puntoAtencion.setIsProvider(false);
								puntoAtencion.setAuthorizeRecipes(false);
								puntoAtencion.setDepartament(department);
								puntoAtencion.setMunicipality(municipio);
								puntoAtencion.setHeadquarters(sede);
								puntoAtencion=zeusPuntoAtencionService.persistZeus(puntoAtencion);
								location.setZuesLocationId(puntoAtencion.getId());
								location.setZuesLocationCode(puntoAtencion.getCode());
								locationService.persistLocal(location);
								response=setMessage(CommonConstants.SUCCESS,AdminConstant.LOCATION_SUCCESS);
							} catch (Exception e) {
								_log.error("Error:--", e);
								response=setMessage(CommonConstants.ERROR,AdminConstant.LOCATION_ERROR);
							}
						}
					}else{
						User sender = SessionUtil.getUserFromRequestSession(request);
						PermissionUtil.checkPermission(sender, ActionConstant.EDIT_LOCATION);
						Locations locationObject=locationService.findByIdLocal(location.getLocationId());
						location.setCreatedBy(locationObject.getCreatedBy());
						location.setCreatedOn(locationObject.getCreatedOn());
						Long i = locationService.findByLocationNameAndId(location);
						if(i>0){
							response=setMessage(CommonConstants.WARNING,AdminConstant.LOCATION_DUBLICATE);
						}else{
							try {
								_log.info("update data in location");
								PuntoAtencion puntoAtencion=zeusPuntoAtencionService.findByIdZeus(locationObject.getZuesLocationId());
								puntoAtencion.setCode(location.getZuesLocationCode());
								puntoAtencion.setName(location.getLocationInSpanish());
								puntoAtencion.setStatus(true);
								puntoAtencion.setGeneratePlan(false);
								puntoAtencion.setIsProvider(false);
								puntoAtencion.setAuthorizeRecipes(false);
								puntoAtencion.setDepartament(department);
								puntoAtencion.setMunicipality(municipio);
								puntoAtencion.setHeadquarters(sede);
								puntoAtencion=zeusPuntoAtencionService.mergeZeus(puntoAtencion);
								location.setZuesLocationId(puntoAtencion.getId());
								locationService.mergeLocal(location);
								response=setMessage(CommonConstants.SUCCESS,AdminConstant.LOCATION_UPDATE);
							} catch (Exception e) {
								_log.error("Error:--", e);
								response=setMessage(CommonConstants.ERROR,AdminConstant.LOCATION_ERROR);
							}
						}
					}
				}else{
					return "redirect:" + AdminConstant.LOCATION_CONTROLLER +AdminConstant.VIEW_ALL_LOCATION_MAPPING;
				}
			} catch (Exception e) {
				_log.error("Error:--", e);
				response=setMessage(CommonConstants.ERROR,AdminConstant.LOCATION_ERROR);
			}
		} else {
			response=setMessage(CommonConstants.ERROR,AdminConstant.LOCATION_EXCEPTION);
		}
		if(response.getStatus().equals(CommonConstants.SUCCESS)){
			redirectAttrs.addFlashAttribute("success", response.getMessage());
		}else{
			redirectAttrs.addFlashAttribute("error", response.getMessage());
		}
		return "redirect:" + AdminConstant.LOCATION_CONTROLLER +AdminConstant.VIEW_ALL_LOCATION_MAPPING;
	}
	
	private boolean validateLocation(RedirectAttributes redirectAttrs,Locations locations, HttpSession session,HttpServletRequest request,BindingResult bindingResult,Response response) {
        boolean validated = true;
        if (locations.getLocationId() == null || locations.getLocationId().equals(0L)) {
        	locationsValidator.validate(locations, bindingResult);
            if (bindingResult.hasErrors()) {
                List<FieldError> errors = bindingResult.getFieldErrors();
                StringBuffer message = new StringBuffer();
                for (FieldError error : errors) {
                    message.append(error.getDefaultMessage() + CommonConstants.MESSAGE);
                }
                response=setErrorValidate(CommonConstants.ERROR,message);
                redirectAttrs.addFlashAttribute("error", response.getMessage());
                validated = false;
            }
            locations.setCreatedOn(new Date());
            locations.setUpdatedOn(new Date());
            locations.setCreatedBy(SessionUtil.getUserFromRequestSession(request));
            locations.setUpdatedBy(SessionUtil.getUserFromRequestSession(request));
            locations.setStatus(Status.ACTIVE);
        } else {
        	locationsValidator.validate(locations, bindingResult);
            if (bindingResult.hasErrors()) {
                List<FieldError> errors = bindingResult.getFieldErrors();
                StringBuffer message = new StringBuffer();
                for (FieldError error : errors) {
                    message.append(error.getDefaultMessage() + CommonConstants.MESSAGE);
                }
                response=setErrorValidate(CommonConstants.ERROR,message);
                redirectAttrs.addFlashAttribute("error", response.getMessage());
                validated = false;
            }
            locations.setStatus(Status.ACTIVE);
            locations.setUpdatedOn(new Date());
            locations.setUpdatedBy(SessionUtil.getUserFromRequestSession(request));
        }
        return validated;
    }
	
	@RequestMapping(value = AdminConstant.REMOVE_LOCATION, method = RequestMethod.POST)
	public String deleteUser(Model model,RedirectAttributes redirectAttrs,@ModelAttribute("location") Locations location,HttpSession session, HttpServletRequest request) {
		User sender = SessionUtil.getUserFromRequestSession(request);
		PermissionUtil.checkPermission(sender, ActionConstant.DELETE_LOCATION);
		Response response = new Response();
		Locations locationFound = locationService.findByIdLocal(location.getLocationId());
		locationFound.setStatus(Status.DELETED);
		locationFound.setUpdatedBy(SessionUtil.getUserFromRequestSession(request));
		locationFound.setUpdatedOn(new Date());
		try {
			_log.info("remove data in location ");
			locationService.deleteLocal(locationFound);
			PuntoAtencion puntoAtencion=zeusPuntoAtencionService.findByIdZeus(locationFound.getZuesLocationId());
			puntoAtencion.setStatus(false);
			zeusPuntoAtencionService.deleteZeus(puntoAtencion);
			response=setMessage(CommonConstants.SUCCESS,AdminConstant.LOCATION_DELETE);
		} catch (Exception e) {
			_log.error("Error:--", e);
			response=setMessage(CommonConstants.ERROR,AdminConstant.LOCATION_EXCEPTION);
		}
		if(response.getStatus().equals(CommonConstants.SUCCESS)){
			redirectAttrs.addFlashAttribute("success", response.getMessage());
		}else{
			redirectAttrs.addFlashAttribute("error", response.getMessage());
		}
		return "redirect:" + AdminConstant.LOCATION_CONTROLLER +AdminConstant.VIEW_ALL_LOCATION_MAPPING;
	}
	
	private Response setErrorValidate(String type,StringBuffer message) {
		Response response = new Response();
		response.setStatus(type);
		response.setMessage(message.toString().substring(0, message.length() - 5));
		return response;
	}
	
	private Response setMessage(String type,String message) {
		Response response = new Response();
		response.setStatus(type);
		response.setMessage(messageByLocaleService.getMessage(message));
		return response;
	}
	@RequestMapping(value = AdminConstant.EXPORT_LOCATION, method = RequestMethod.POST)
	public void exportLocations(Model model, HttpServletRequest request, HttpServletResponse response) throws IOException {

		List<Locations> listLocations = locationService.findAllLocalActive();
		net.sf.json.JSONObject jsonObject = new net.sf.json.JSONObject();
		net.sf.json.JSONObject jsonColumn = new net.sf.json.JSONObject();
		net.sf.json.JSONArray columnArray = new net.sf.json.JSONArray();
		List<String> colList = new ArrayList<String>(0);
		colList.add("Clinic Location Code");
		colList.add("Clinic Location");
		colList.add("Clinic Location In Spanish");
		colList.add("Status");
		for (int i = 0; i < colList.size(); i++) {
			net.sf.json.JSONObject jsonColData = new net.sf.json.JSONObject();
			jsonColData.put("key", colList.get(i));
			columnArray.add(jsonColData);
		}
		jsonColumn.put("col_data", columnArray);
		net.sf.json.JSONObject jsonObjData = new net.sf.json.JSONObject();
		net.sf.json.JSONArray rowArray = new net.sf.json.JSONArray();
		for (Locations location : listLocations) {
			net.sf.json.JSONObject cellCol = new net.sf.json.JSONObject();
			net.sf.json.JSONArray cell = new net.sf.json.JSONArray();
			for (String colName : colList) {
				switch (colName) {
				case "Clinic Location Code":
					net.sf.json.JSONObject jsonRowData = new net.sf.json.JSONObject();
					jsonRowData.put("key", colName);
					if(location.getZuesLocationCode()!=null){
						jsonRowData.put("value", location.getZuesLocationCode());
					}else{
						jsonRowData.put("value", "");
					}
					cell.add(jsonRowData);
					break;
				case "Clinic Location":
					net.sf.json.JSONObject jsonRowData1 = new net.sf.json.JSONObject();
					jsonRowData1.put("key", colName);
					if(location.getLocation()!=null){
						jsonRowData1.put("value", location.getLocation());
					}else{
						jsonRowData1.put("value", "");
					}
					cell.add(jsonRowData1);
					break;
				case "Clinic Location In Spanish":
					net.sf.json.JSONObject jsonRowData5 = new net.sf.json.JSONObject();
					jsonRowData5.put("key", colName);
					if(location.getLocationInSpanish()!=null){
						jsonRowData5.put("value", location.getLocationInSpanish());
					}else{
						jsonRowData5.put("value", "");
					}
					cell.add(jsonRowData5);
					break;
				case "Status":
					net.sf.json.JSONObject jsonRowData2 = new net.sf.json.JSONObject();
					jsonRowData2.put("key", colName);
					jsonRowData2.put("value", location.getStatus().name());
					cell.add(jsonRowData2);
					break;
				default:
					break;
				}
				cellCol.put("cell", cell);
			}
			rowArray.add(cellCol);
			jsonObjData.put("row", rowArray);
		}
		jsonObject.put("col", jsonColumn);
		jsonObject.put("data", jsonObjData);

		DownloadFile.downloadFile(AdminConstant.LOCATION_MODULENAME, AdminConstant.EXPORT_EXTENSION, jsonObject, request,
				response);
	}
	
	@RequestMapping(value = AdminConstant.IMPORT_LOCATION, method = RequestMethod.POST)
	public String importLocation(@RequestParam("locationFile") MultipartFile file, Model model,RedirectAttributes redirectAttrs, HttpServletRequest request,
			HttpServletResponse response) throws IOException {
		Response responseStatus = new Response();
		User sender = SessionUtil.getUserFromRequestSession(request);
		PermissionUtil.checkPermission(sender, ActionConstant.ADD_NEW_LOCATION);
		try {
			File file1 = new File(file.getOriginalFilename());
			file.transferTo(file1);
			Workbook workbook = WorkbookFactory.create(file1);
			Sheet sheet = workbook.getSheetAt(0);
			Locations locations = new Locations();
			List<Locations> locationList = new ArrayList<Locations>();
			Iterator<Row> itr = sheet.iterator();
			while (itr.hasNext()) {
				Row row = itr.next();
				if(row.getRowNum() != 0){
					locations = assignLocation(row);
					if(locations !=null){
						locationList.add(locations);
					}
				}
			}
			boolean importCms=locationService.importLocations(locationList);
			if(importCms){
				responseStatus=setMessage(CommonConstants.SUCCESS,AdminConstant.LOCATION_IMPORTS);
			}else{
				responseStatus=setMessage(CommonConstants.ERROR,AdminConstant.LOCATION_IMPORT_FAIL);
			}
			workbook.close();

		} catch (Exception e) {
			e.printStackTrace();
		}
		if(responseStatus.getStatus().equals(CommonConstants.SUCCESS)){
			redirectAttrs.addFlashAttribute("success", responseStatus.getMessage());
		}else{
			redirectAttrs.addFlashAttribute("error", responseStatus.getMessage());
		}
		return "redirect:" + AdminConstant.LOCATION_CONTROLLER +AdminConstant.VIEW_ALL_LOCATION_MAPPING;
	}

	private Locations assignLocation(Row row) {
		if(row.getCell(0) !=null && row.getCell(1) !=null && row.getCell(2) !=null){
			if ((!row.getCell(0).toString().trim().equalsIgnoreCase("null") && !row.getCell(0).toString().trim().equals(""))
					&& (!row.getCell(1).toString().trim().equalsIgnoreCase("null")
							&& !row.getCell(1).toString().trim().equals(""))
					&& (!row.getCell(2).toString().trim().equalsIgnoreCase("null")
							&& !row.getCell(2).toString().trim().equals(""))) {
				Locations locations = new Locations();
				locations.setZuesLocationCode(row.getCell(0).toString());
				locations.setLocation(row.getCell(1).toString());
				locations.setLocationInSpanish(row.getCell(2).toString());
				locations.setStatus(Status.ACTIVE);
				return locations;
			}else{
				return null;
			}
		}else{
			return null;
		}
	}
	
	@RequestMapping("/fetchloc")
	@ResponseBody
	public ResponseEntity<Object> fetchLoc(@RequestParam("LocationId") Long LocationId,Locale locale, Model model,HttpServletRequest request) {
		Locations locations = locationService.findByIdLocal(LocationId);
		PuntoAtencion puntoAtencion =zeusPuntoAtencionService.findByIdZeus(locations.getZuesLocationId());
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("department", puntoAtencion.getDepartament());
		jsonObject.put("municipality", puntoAtencion.getMunicipality());
		jsonObject.put("headquarters", puntoAtencion.getHeadquarters());
		return new ResponseEntity<Object>(jsonObject.toString(), HttpStatus.OK);
	}
}