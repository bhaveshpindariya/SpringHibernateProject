package com.peer.admin.controller;

import java.util.List;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import com.peer.admin.constant.AdminConstant;
import com.peer.admin.util.PermissionUtil;
import com.peer.constant.ActionConstant;
import com.peer.constant.CommonConstants;
import com.peer.scenity.entity.local.Costing;
import com.peer.scenity.entity.local.User;
import com.peer.scenity.entity.local.Wage;
import com.peer.scenity.service.intf.ICostingService;
import com.peer.scenity.service.intf.IWageService;
import com.peer.scenity.util.SessionUtil;

@Controller
@RequestMapping(AdminConstant.COSTING_CONTROLLER)
public class CostingController {

	private static final Logger _log = Logger.getLogger(CostingController.class);
	public static final String COSTING_LIST = "costing/list";
	public static final String ADD_COSTING = "costing/add";

	@Autowired
	private IWageService wageService;

	@Autowired
	private ICostingService costingService;

	@RequestMapping(AdminConstant.COSTING_VIEW_ALL)
	public String listCosting(Model model, HttpServletRequest request) {
		User sender = SessionUtil.getUserFromRequestSession(request);
		PermissionUtil.checkPermission(sender, ActionConstant.VIEW_COSTING);
		Wage wage = wageService.findLatestWage();
		List<Costing> costingList = costingService.findAllCosting();
		model.addAttribute("dailyMinimumLegalWage", wage.getDailyMinimumLegalWage());
		model.addAttribute("monthlyMinimumLegalWage", wage.getMonthlyMinimumLegalWage());
		model.addAttribute("costingList", costingList);
		return COSTING_LIST;
	}

	@RequestMapping(AdminConstant.COSTING_ADD)
	public String addCosting(Model model, HttpServletRequest request) {
		User sender = SessionUtil.getUserFromRequestSession(request);
		PermissionUtil.checkPermission(sender, ActionConstant.ADD_COSTING);
		Wage wage = wageService.findLatestWage();
		model.addAttribute("wage", wage);
		return ADD_COSTING;
	}

	@RequestMapping(value = AdminConstant.COSTING_EDIT, method = RequestMethod.POST)
	public String editCosting(Locale locale, Model model, HttpServletRequest request,
			@ModelAttribute("costing") Costing costing) {
		User sender = SessionUtil.getUserFromRequestSession(request);
		PermissionUtil.checkPermission(sender, ActionConstant.EDIT_COSTING);
		Wage wage = wageService.findLatestWage();
		Costing costingData = costingService.findByIdLocal(costing.getCostingId());
		model.addAttribute("wage", wage);
		model.addAttribute("costing", costingData);
		return ADD_COSTING;
	}

	@RequestMapping(value = AdminConstant.COSTING_REMOVE, method = RequestMethod.POST)
	public String removeCosting(@ModelAttribute("costing") Costing costing, HttpServletRequest request,
			RedirectAttributes redirectAttributes) {
		User sender = SessionUtil.getUserFromRequestSession(request);
		PermissionUtil.checkPermission(sender, ActionConstant.DELETE_COSTING);
		User user = SessionUtil.getUserFromRequestSession(request);
		try {
			costingService.markDeleted(user, costing.getCostingId());
			redirectAttributes.addFlashAttribute("success", CommonConstants.SUCCESS);
		} catch (Exception e) {
			redirectAttributes.addFlashAttribute("error", CommonConstants.ERROR);
			_log.error("", e);
		}
		return "redirect:" + AdminConstant.COSTING_CONTROLLER + AdminConstant.COSTING_VIEW_ALL;
	}

	@RequestMapping(AdminConstant.COSTING_UPDATE_WAGE)
	@ResponseBody
	public ResponseEntity<Object> updateWage(HttpServletRequest request) {
		User sender = SessionUtil.getUserFromRequestSession(request);
		PermissionUtil.checkPermission(sender, ActionConstant.UPDATE_WAGE);
		JSONObject jsonObject = wageService.updateWage(request);
		return new ResponseEntity<Object>(jsonObject.toString(), HttpStatus.OK);
	}

	@RequestMapping(value = AdminConstant.COSTING_UPDATE, method = RequestMethod.POST)
	public String updateCosting(Model model, HttpServletRequest request, RedirectAttributes redirectAttributes) {
		try {
			List<String> messageList = costingService.updateCosting(request);
			redirectAttributes.addFlashAttribute("messageList", messageList);
			if (messageList.isEmpty()) {
				redirectAttributes.addFlashAttribute("success", CommonConstants.SUCCESS);
			}
		} catch (Exception e) {
			_log.error("", e);
			redirectAttributes.addFlashAttribute("error", CommonConstants.ERROR);
		}
		return "redirect:" + AdminConstant.COSTING_CONTROLLER + AdminConstant.COSTING_VIEW_ALL;
	}
}
