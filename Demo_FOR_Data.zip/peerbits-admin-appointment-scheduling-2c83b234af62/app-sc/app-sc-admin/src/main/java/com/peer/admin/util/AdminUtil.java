package com.peer.admin.util;

public class AdminUtil {
	
}
