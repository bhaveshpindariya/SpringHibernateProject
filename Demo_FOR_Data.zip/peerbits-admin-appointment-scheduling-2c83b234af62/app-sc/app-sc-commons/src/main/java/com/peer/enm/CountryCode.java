package com.peer.enm;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import com.peer.constant.CommonConstants;

public enum CountryCode {

	ONE("+1"), NINEONE("+91"), FIVESEVEN("+57");

	private String countryCode;

	CountryCode(String countryCode) {
		this.countryCode = countryCode;
	}

	public String getCountryCode() {
		return countryCode;
	}

	public static CountryCode parse(String countryCode) {
		CountryCode countryCodes = null; // Default
		for (CountryCode item : CountryCode.values()) {
			if (item.getCountryCode().equals(countryCode)) {
				countryCodes = item;
				break;
			}
		}
		return countryCodes;
	}

	public static String getValue(String countryCode) {
		for (CountryCode item : CountryCode.values()) {
			if (item.countryCode.equals(countryCode)) {
				return item.getCountryCode();
			}
		}
		return CommonConstants.BLANK;
	}

	public static List<String> getAllCountryCodes() {
		CountryCode[] values = CountryCode.values();
		List<String> list = new ArrayList<>();
		for (CountryCode value : values) {
			list.add(value.countryCode);
		}
		return list;
	}

	public static List<CountryCode> getAllCountryCode() {
		return Arrays.stream(CountryCode.values()).collect(Collectors.toList());
	}

}
