package com.peer.enm;

public enum Action {

	ADDED("Added"), MODIFIED("Modified"), DELETED("Deleted"), APPROVED("Approved"), REJECTED("Rejected"), 
	CANCELLED("Cancelled"), CANCEL_REQUESTED("Cancel Requested"), NEW_REQUEST("New Request"),
	MODIFICATION_REQUESTED("Modification Requested"), REQUEST_CANCELLED("Request Cancelled"), 
	REQUEST_APPROVED("Request Approved"), NOTIFICATION("Notification");

	private final String actionCode;

	Action(String actionCode) {
		this.actionCode = actionCode;
	}

	public String getActionCode() {
		return actionCode;
	}
}
