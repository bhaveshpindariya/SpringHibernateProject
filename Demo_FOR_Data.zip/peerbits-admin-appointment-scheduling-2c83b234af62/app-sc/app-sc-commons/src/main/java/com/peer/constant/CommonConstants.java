package com.peer.constant;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

public class CommonConstants {

	public static final String ROLE = "-1";
	public static final long ZERO = 0L;
	public static final String BLANK = "";
	public static final String SPACE = " ";
	public static final String TRUE = "true";
	public static final String FALSE = "false";
	public static final String MESSAGE = " And ";
	public static final String ZEUS_EPS_IMPUESTOCREE = "N";

	public static final String APPOINTMENT_CONSULTATION = "AC";
	public static final String APPOINTMENT_PROCEDURE = "AP";

	public static final String SUCCESS = "success";
	public static final String EMAILPOPUP = "emailpopup";
	public static final String VERIFYEMAILPOPUP = "VerifyyourEmailData";
	public static final String ERROR = "error";
	public static final String WARNING = "warning";

	public static final String CONTENT_TYPE_APPLICATION_JSON = "content-type=application/json";
	public static final String APPLICATION_JSON = "application/json";

	public static final String USER_LOCALE = "userLocale";
	public static final String LANGUAGE_ENGLISH = "en_US";
	public static final String LANGUAGE_SPANISH = "es_ES";
	public static final String LANGUAGE_SPANISH_LOCALE = "es-ES";

	public static final String USERTYPE_AFFILIATE = "Affiliate";
	public static final String USERTYPE_DOCTOR = "Doctor";
	public static final String USERTYPE_ANALYST = "Analyst";
	public static final String USERTYPE_SUBADMIN = "SubAdmin";
	public static final String USERTYPE_ADMIN = "Admin";

	public static final String DAILY_MINIMUM_LEGAL_WAGE = "dailyMinimumLegalWage";
	public static final String MONTHLY_MINIMUM_LEGAL_WAGE = "monthlyMinimumLegalWage";
	public static final String USD = "USD";

	public static final String SETTING_TYPE_CANCELLATION_HOURS = "CANCELLATION_HOURS";

	public static final String NOTIFY_TO_ALL = "all";
	public static final String NOTIFY_TO_ALL_AFFILIATES = "all-affiliates";
	public static final String NOTIFY_TO_ALL_DOCTORS = "all-doctors";
	public static final String NOTIFY_TO_ALL_SUBADMIN = "all-subadmin";
	public static final String NOTIFY_TO_ALL_ADMIN = "all-admin";
	public static final String NOTIFY_TO_ALL_ANALYST = "all-analyst";

	public static final int MAX_NOTIFICATIONS = 5;

	public static final String USER_IMAGE = "resources/images/avatars/profile.jpg";
	public static final String USER_IMAGE_FOLDER_PATH = "/resources/user_images/";
	public static final String PDF_ICON_PATH = "/resources/pdf_icon.png";

	public static final String SENT = "sent";
	public static final String RECEIVED = "received";

	public static final String ADMIN = "admin";
	public static final String ANALYST = "analyst";
	public static final String SUB_ADMIN = "subadmin";
	public static final String DOCTORS = "doctors";
	public static final String AFFILIATES = "affiliates";

	public static final String DEFAULT_ROLE = "Administrator";
	public static final String DEFAULT_EMAIL = "admin@appointmentbooking.com";
	public static final String DEFAULT_NAME = "Default User";

	public static final String UTF8 = "UTF-8";
	public static final String YES = "yes";
	public static final String SHARED_NAME = "shared_name";
	public static final int COOKIE_MAX_AGE = 15552000;

	public static final DateTimeFormatter FORMATTERA = DateTimeFormatter.ofPattern("MM/dd/yyyy");
	public static final DateTimeFormatter FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd");
	public static final DateTimeFormatter FORMATTER1 = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
	public static final DateTimeFormatter FORMATTER2 = DateTimeFormatter.ofPattern("yyyy-MM-dd hh:mm a");
	public static final DateFormat FORMAT1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.ENGLISH);
	public static final DateFormat FORMAT2 = new SimpleDateFormat("MM-dd-yyyy", Locale.ENGLISH);
	public static final DateFormat FORMAT3 = new SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH);

	public static final String PENDING = "Pending";
	public static final String CURRENT_SLOT = "Current Slot";
	public static final String UPCOMING = "Upcoming";
	public static final String CANCELLED = "Cancelled";
	public static final String COMPLETED = "Completed";
	public static final String NO_SHOW = "No-Show";
	public static final String WAITLISTS = "Waitlists";
	public static final String REJECTED = "Rejected";
	public static final String AWAITING_CANCELLATION = "Awaiting Cancellation";
	public static final String ACTIVE = "Active";
	public static final String AWAITING_CANCELLATION_APPROVAL = "Awaiting Cancellation Approval";
	public static final String AWAITING_MODIFICATION_APPROVAL = "Awaiting Modification Approval";
	public static final String AWAITING_APPROVAL = "Pending";
	
	// OLD Zeus Status
	/*public static final String PENDING_ZEUS = "P";
	public static final String UPCOMING_ZEUS = "CC";
	public static final String CANCELLED_ZEUS = "C";
	public static final String COMPLETED_ZEUS = "A";
	public static final String NO_SHOW_ZEUS = "NS";*/
	
	public static final String PENDING_ZEUS = "X";
	public static final String UPCOMING_ZEUS = "P";
	public static final String CANCELLED_ZEUS = "C";
	public static final String COMPLETED_ZEUS = "CC";
	public static final String NO_SHOW_ZEUS = "A";

	public static final String CANCELLATION_TIME_ERROR = "cancellation.time.error";
	public static final String SCHEDULE_APPROVED = "schedule.approve.success";
	public static final String SCHEDULE_APPROVE_ERROR = "schedule.approve.error";
	public static final String SCHEDULE_DATE_ERROR = "schedule.date.error";
	public static final String SCHEDULE_APPROVE_PREVDATES_ERROR = "schedule.approve.previousdates.error";
	public static final String SCHEDULE_DATE_RANGE_ERROR = "scheduleslot.error.daterange";
	public static final String SCHEDULE_SLOT_TIME_COFLICT = "scheduleslot.conflict.time";
	
	public static final int OTP_LENGTH = 4;
	public static final String OTP_NUMBERS = "0123456789";

	public static final String ACTIVE_TAB = "activeTab";
	public static final String SCHEDULE_TAB = "schedule";
	public static final String UPCOMING_TAB = "upcoming";
	public static final String WAITLISTS_TAB = "waitlists";
	public static final String SCHEDULE_PAGE = "schedule.jsp";

	public static final String DASHBOARD_TAB = "dashboard";
	public static final String SCHEDULES_TAB = "manage-schedule";
	public static final String APPOINTMENT_TAB = "manage-appointment";
	public static final String DASHBOARD_PAGE = "dashboard.jsp";

	public static final String FILTER_TYPE_UPCOMING = "upcoming";

	public static final String PRIORITIZED = "prioritized";
	public static final String NORMAL = "normal";
	public static final String EXPIRED = "expired";

	public static final int WAITLIST_EXPIRED_OFFSET = -45;
	public static final int WAITLIST_EXPIRED_DAYS = 45;

	public static final String ITEM_APPOINTMENT = "appointment";
	public static final String CANCEL_REQUEST = "cancel";
	public static final String ADD_REQUEST = "add";
	public static final String MODIFY_REQUEST = "modify";
	
	public static final String ITEM_SCHEDULE = "schedule";
}
