package com.peer.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.IOUtils;
import org.apache.log4j.Logger;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

public class DownloadFile {

	private static Logger _log = Logger.getLogger(DownloadFile.class);
	
	public static String downloadFile(String moduleName, String fileExtension, JSONObject data,
			HttpServletRequest request, HttpServletResponse response) throws IOException {
		JSONObject col = data.getJSONObject("col");
		Workbook workbook = new XSSFWorkbook();
		Sheet sheet = workbook.createSheet(moduleName);
		Font headerFont = workbook.createFont();
		headerFont.setBold(true);
		headerFont.setFontHeightInPoints((short) 12);
		CellStyle headerCellStyle = workbook.createCellStyle();
		headerCellStyle.setFont(headerFont);
	
		JSONArray col_data = col.getJSONArray("col_data");
		Row headerRow = sheet.createRow(0);
		for (int i = 0; i < col_data.size(); i++) {

			Cell cell = headerRow.createCell(i);
			cell.setCellValue(col_data.getJSONObject(i).get("key").toString());
			cell.setCellStyle(headerCellStyle);
			sheet.autoSizeColumn(i);
		}
		JSONObject jsonData = new JSONObject(); 
		JSONArray jsonRowArray = new JSONArray();
		try {
			jsonData = data.getJSONObject("data");
			jsonRowArray = jsonData.getJSONArray("row");
		}
		catch (Exception e) {
		}
		int rowNum = 1;

		for (int i = 0; i < jsonRowArray.size(); i++) {
			Row row = sheet.createRow(rowNum++);
			JSONObject colCell = jsonRowArray.getJSONObject(i);
			JSONArray cellList = colCell.getJSONArray("cell");
			for (int j = 0; j < cellList.size(); j++) {
				try{
					row.createCell(j).setCellValue(cellList.getJSONObject(j).getString("value"));
				}catch(Exception e){
					_log.error("Error:--", e);
				}
			}
		}
		FileOutputStream fileOut = new FileOutputStream(moduleName + fileExtension);
		workbook.write(fileOut);
		File tempFile = new File(moduleName + fileExtension);
		try {
			InputStream inputStream = new FileInputStream(moduleName + fileExtension);
			response.setContentType("application/force-download");
			response.setHeader("Content-Disposition", "attachment; filename=" + moduleName + fileExtension);
			IOUtils.copy(inputStream, response.getOutputStream());
			response.flushBuffer();
			inputStream.close();
		} catch (Exception e) {

			e.printStackTrace();
		}
		tempFile.delete();
		fileOut.close();
		workbook.close();
		return "success";
	}
}