package com.peer.enm;

import java.util.ArrayList;
import java.util.List;

public enum UserIdType {

	CC("CC"), CE("CE"), MS("MS"), NIT("NIT"), NUI("NUI"), PA("PA"), RC("RC"), TI("TI"), AS("AS");

	private String userIdType;

	UserIdType(String userIdType) {
		this.userIdType = userIdType;
	}

	public String getUserIdType() {
		return userIdType;
	}

	public static UserIdType parse(String userIdType) {
		UserIdType userIdTypes = null; // Default
		for (UserIdType item : UserIdType.values()) {
			if (item.getUserIdType().equals(userIdType)) {
				userIdTypes = item;
				break;
			}
		}
		return userIdTypes;
	}

	public static String getValue(String userIdType) {
		for (UserIdType item : UserIdType.values()) {
			if (item.name().equals(userIdType)) {
				return item.getUserIdType();
			}
		}
		return null;
	}

	public static UserIdType getIdType(String userIdType) {
		for (UserIdType item : UserIdType.values()) {
			if (item.name().equals(userIdType)) {
				return item;
			}
		}
		return null;
	}

	public static List<String> getAllUserIdType() {
		UserIdType[] values = UserIdType.values();
		List<String> list = new ArrayList<>();
		for (UserIdType value : values) {
			list.add(value.name());
		}
		return list;
	}
}
