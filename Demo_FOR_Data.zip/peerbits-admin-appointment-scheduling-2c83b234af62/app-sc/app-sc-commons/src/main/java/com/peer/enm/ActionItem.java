package com.peer.enm;

public enum ActionItem {

	APPOINTMENT("Appointment"), SCHEDULE("Schedule"), GENERAL("General");

	private final String actionItemCode;

	ActionItem(String actionItemCode) {
		this.actionItemCode = actionItemCode;
	}

	public String getActionItemCode() {
		return actionItemCode;
	}

}
