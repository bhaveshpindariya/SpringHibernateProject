package com.peer.enm;

import java.util.ArrayList;
import java.util.List;

public enum CategoryType {

	CONSULTATION("CONSULTATION"),
	PROCEDURE("PROCEDURE");

	private String id;

	CategoryType(String id) {
        this.id = id;
    }

    public String getId() {
        return id;
    }

    public static CategoryType parse(String id) {
    	CategoryType currencyType = null; // Default
        for (CategoryType item : CategoryType.values()) {
        	if (item.getId().equals(id)) {
            	currencyType = item;
                break;
            }
        }
        return currencyType;
    }
    
    public static String getValue(String id) {
    	 for (CategoryType item : CategoryType.values()) {
            if (item.name() == id) {
            		return item.getId();
            }
        }
        return null;
    }
    
    public static List<String> getAllCategoryType() {
    	CategoryType[] values = CategoryType.values();
        List<String> list = new ArrayList<>();
        for (CategoryType value : values) {
            list.add(value.name());
        }
        return list;
    }

}
