package com.peer.enm;

public enum Particulars {

	TERMSANDCONDITIONS(0), ABOUTUS(1), PRIVACYPOLICY(2);

	private final int particularCode;


	Particulars(int particularCode) {
		this.particularCode = particularCode;
	}

	public int getParticularCode() {
		return particularCode;
	}

	public static Particulars parse(int particularCode) {
		Particulars particulars = null; // Default
		for (Particulars item : Particulars.values()) {
			if (item.getParticularCode()==particularCode) {
				particulars = item;
				break;
			}
		}
		return particulars;
	}
	
	
	public static Particulars getParticularsByString(String particular) {
		Particulars particulars = null; // Default
		for (Particulars item : Particulars.values()) {
			if (item.name().equals(particular)) {
				particulars = item;
				break;
			}
		}
		return particulars;
	}
	

	public static int getValue(int particularCode) {
		for (Particulars item : Particulars.values()) {
			if (item.getParticularCode() == particularCode) {
				return item.getParticularCode();
			}
		}
		return 0;
	}

}
