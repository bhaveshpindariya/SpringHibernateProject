package com.peer.util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.util.Base64;
import java.util.Date;
import java.util.Random;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.RandomStringUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;

import com.peer.constant.CommonConstants;

public class CommonUtil {

	private static Logger _log = Logger.getLogger(CommonUtil.class);
	private static DecimalFormat decimalFormat = new DecimalFormat(".##");
	private static final String CONTACT_REGEX = "[(-+.^:, /)-/]";

	public static String randomPassword() {
		return RandomStringUtils.randomAlphanumeric(9);
	}

	public static String randomPassword(int count) {
		return RandomStringUtils.randomAlphanumeric(count);
	}

	public static Boolean checkNull(Object obj) {
		if (obj != null) {
			return false;
		} else {
			return true;
		}
	}

	public static Double getPercentageAmount(String percentage, String totalAmount) {
		double percentageAmount = 0.0d;
		try {
			double percent = Double.parseDouble(percentage);
			double total = Double.parseDouble(totalAmount);
			percentageAmount = (total * percent) / 100;
		} catch (Exception e) {
			_log.error("percentage: " + percentage + " :totalAmount: " + totalAmount);
			_log.error(e);
		}
		return percentageAmount;
	}

	public static Double getPercentageAmount(String percentage, double totalAmount) {
		double percentageAmount = 0.0d;
		try {
			double percent = Double.parseDouble(percentage);
			percentageAmount = (totalAmount * percent) / 100;
		} catch (Exception e) {
			_log.error("percentage: " + percentage + " :totalAmount: " + totalAmount);
			_log.error(e);
		}
		return percentageAmount;
	}

	public static Double getPercentageAmountRound(String percentage, String totalAmount) {
		double percentageAmount = 0.0d;
		try {
			double percent = Double.parseDouble(percentage);
			double total = Double.parseDouble(totalAmount);
			percentageAmount = (total * percent) / 100;
			percentageAmount = Math.round(percentageAmount);
		} catch (Exception e) {
			_log.error("percentage: " + percentage + " :totalAmount: " + totalAmount);
			_log.error(e);
		}
		return percentageAmount;
	}

	public static String getPercentageAmountS(String percentage, String totalAmount) {
		return String.valueOf(getPercentageAmount(percentage, totalAmount));
	}

	public static String getPercentageAmountRoundS(String percentage, String totalAmount) {
		return String.valueOf(getPercentageAmountRound(percentage, totalAmount));
	}

	public static String getPortalURL(HttpServletRequest request) {
		return request.getScheme() + "://" + request.getServerName() + ":" + request.getServerPort()
				+ request.getContextPath();
	}

	public static String encodeToString(String stringToEncode) {
		String encodedString = "";
		try {
			byte[] encodedBytes = Base64.getEncoder().encode(stringToEncode.getBytes(CommonConstants.UTF8));
			encodedString = new String(encodedBytes);
		} catch (UnsupportedEncodingException e) {
			_log.error("Encoding problem with String: " + stringToEncode, e);
		}
		return encodedString;
	}

	/**
	 * 
	 * @param stringToDecode
	 * @return
	 */
	public static String decodeToString(String stringToDecode) {
		String decodedString = "";
		try {
			byte[] encodedBytes = stringToDecode.getBytes(CommonConstants.UTF8);
			byte[] decodedBytes = Base64.getDecoder().decode(encodedBytes);
			decodedString = new String(decodedBytes);
		} catch (UnsupportedEncodingException e) {
			_log.error("Decoding problem with String: " + stringToDecode, e);
		}
		return decodedString;
	}

	public static String generateToken() {
		String tokenString = UUID.randomUUID().toString().toUpperCase();
		String token = Base64.getEncoder().encodeToString(tokenString.getBytes());
		return token;
	}

	public static String generateOTP() {
		String numbers = CommonConstants.OTP_NUMBERS;
		Random rndm = new Random();
		char[] otp = new char[CommonConstants.OTP_LENGTH];

		for (int i = 0; i < CommonConstants.OTP_LENGTH; i++) {
			otp[i] = numbers.charAt(rndm.nextInt(numbers.length()));
		}
		return new String(otp);
	}

	public static double roundHalf(double number) {
		double diff = number - (int) number;
		if (diff < 0.25)
			return (int) number;
		else if (diff < 0.75)
			return (int) number + 0.5;
		else
			return (int) number + 1;
	}

	public static String callService(String serviceURL) {
		String responseData = "";
		try {
			URL url = new URL(serviceURL);
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.setDoOutput(true);
			conn.setRequestMethod("POST");
			conn.setRequestProperty("Content-Type", "application/json");
			OutputStream os = conn.getOutputStream();

			String data = "";
			os.write(data.getBytes());
			os.flush();
			if (conn.getResponseCode() != HttpURLConnection.HTTP_OK) {
				_log.warn("service sent warning with status code :" + conn.getResponseCode());
			}
			BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()));
			String output;
			while ((output = br.readLine()) != null) {
				responseData = output;
			}
			conn.disconnect();
		} catch (IOException e) {
			_log.error(e.getMessage());
			_log.debug("", e);
		}
		return responseData;
	}

	public static String callService(String serviceURL, String jsonData) {
		String responseData = "";
		try {
			URL url = new URL(serviceURL);
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.setDoOutput(true);
			conn.setRequestMethod("POST");
			conn.setRequestProperty("Content-Type", "application/json");
			OutputStream os = conn.getOutputStream();
			os.write(jsonData.getBytes());
			os.flush();
			if (conn.getResponseCode() != HttpURLConnection.HTTP_OK) {
				_log.warn("service sent warning with status code :" + conn.getResponseCode());
			}
			BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()));
			String output;
			while ((output = br.readLine()) != null) {
				responseData = output;
			}
			conn.disconnect();
		} catch (IOException e) {
			_log.error(e.getMessage());
			_log.debug("", e);
		}
		return responseData;
	}

	public static String callServiceSimple(String serviceURL, String query) {
		String responseData = "";
		try {
			URL url = new URL(serviceURL);
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.setDoOutput(true);
			conn.setRequestMethod("GET");
			conn.setRequestProperty("Content-type", "application/json");
			OutputStream os = conn.getOutputStream();
			os.write(query.getBytes());
			os.flush();

			if (conn.getResponseCode() != HttpURLConnection.HTTP_OK) {
				_log.warn("service sent warning with status code :" + conn.getResponseCode());
			}
			BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()));
			String output;
			while ((output = br.readLine()) != null) {
				responseData = output;
			}
			os.close();
			br.close();
			conn.disconnect();
		} catch (IOException e) {
			_log.error(e.getMessage());
			_log.debug("", e);
		}
		return responseData;
	}

	public static int getIntValue(HttpServletRequest request, String parameterName) {
		int value;
		try {
			value = Integer.parseInt(request.getParameter(parameterName));
		} catch (Exception e) {
			value = 0;
		}
		return value;
	}

	public static Long getLongValue(HttpServletRequest request, String parameterName) {
		Long value;
		try {
			value = Long.parseLong(request.getParameter(parameterName));
		} catch (Exception e) {
			value = 0l;
		}
		return value;
	}

	public static Long getLongValue(String sValue) {
		Long value;
		try {
			value = Long.parseLong(sValue);
		} catch (Exception e) {
			value = 0l;
		}
		return value;
	}

	public static boolean getBooleanValue(HttpServletRequest request, String parameterName) {
		boolean value = false;
		try {
			value = Boolean.parseBoolean(request.getParameter(parameterName));
		} catch (Exception e) {
			value = false;
		}
		return value;
	}

	public static Date getDateValue(HttpServletRequest request, String parameterName, DateFormat dateFormat) {
		Date date = null;
		try {
			String dateS = request.getParameter(parameterName);
			if (StringUtils.isNotBlank(dateS)) {
				date = DateUtil.parseDate(dateS, dateFormat);
			}
		} catch (Exception e) {
			date = null;
		}
		return date;
	}

	public static String getMimeType(String name) {
		String mimeType = "";
		try {
			mimeType = Files.probeContentType(Paths.get(name));
			if (_log.isDebugEnabled()) {
				_log.debug("fileName: " + name + " :mimeType: " + mimeType);
			}
		} catch (IOException e) {
			_log.error("", e);
		}
		if (StringUtils.isBlank(mimeType)) {
			mimeType = "";
		}
		return mimeType;
	}

	public static String getCurrentTab(String activeTab) {
		if (StringUtils.isBlank(activeTab)) {
			return CommonConstants.SCHEDULE_TAB;
		}
		return activeTab;
	}

	public static String getCurrentTab(HttpServletRequest request) {
		String activeTab = (String) request.getAttribute(CommonConstants.ACTIVE_TAB);
		return getCurrentTab(activeTab);
	}

	public static String getCurrentPage(HttpServletRequest request) {
		String currentPage = getCurrentTab(request);
		return getCurrentPage(currentPage);
	}

	public static String getCurrentPage(String currentPage) {
		String currentPageTab = CommonConstants.SCHEDULE_PAGE;
		if (StringUtils.isNotBlank(currentPage)) {
			currentPageTab = currentPage.trim() + ".jsp";
		}
		return currentPageTab;
	}

	public static String getCurrentTabDoctor(String activeTab) {
		if (StringUtils.isBlank(activeTab)) {
			return CommonConstants.DASHBOARD_TAB;
		}
		return activeTab;
	}

	public static String getCurrentTabDoctor(HttpServletRequest request) {
		String activeTab = (String) request.getAttribute(CommonConstants.ACTIVE_TAB);
		return getCurrentTabDoctor(activeTab);
	}

	public static String getCurrentPageDoctor(HttpServletRequest request) {
		String currentPage = getCurrentTabDoctor(request);
		return getCurrentPageDoctor(currentPage);
	}

	public static String getCurrentPageDoctor(String currentPage) {
		String currentPageTab = CommonConstants.DASHBOARD_PAGE;
		if (StringUtils.isNotBlank(currentPage)) {
			currentPageTab = currentPage.trim() + ".jsp";
		}
		return currentPageTab;
	}

	public static boolean isImageFile(String mimeType) {
		if (StringUtils.isNotBlank(mimeType) && mimeType.startsWith("image")) {
			return true;
		}
		return false;
	}

	public static double getCost(double cost) {
		double newCost = 0.0;
		try {
			newCost = Double.parseDouble(decimalFormat.format(cost));
		} catch (Exception e) {
			newCost = cost;
		}
		return newCost;
	}

	public static String encode(String url) {
		String encodeURL = "";
		try {
			encodeURL = URLEncoder.encode(url, "UTF-8");
		} catch (Exception e) {
			_log.error("", e);
		}
		return encodeURL;
	}

	public static String decode(String url) {
		String decodeURL = url;
		try {
			decodeURL = URLDecoder.decode(url, "UTF-8");
		} catch (Exception e) {
			_log.error("", e);
		}
		return decodeURL;
	}

	public static String removeSpecialCharacters(String contactNumber) {
		String result = "";
		if (null != contactNumber) {
			result = contactNumber.replaceAll(CONTACT_REGEX, "");
		}
		return result;
	}

	public static void main(String args[]) {
		System.out.println(removeSpecialCharacters(" "));
	}
}