package com.peer.enm;

public enum Status {

	PENDING(0), APPROVED(1), REJECTED(2), NOSHOW(3), COMPLETED(4), ACTIVE(5), INACTIVE(6), DELETED(7),
	AWAITING_APPROVAL(8), AWAITING_CANCELLATION_APPROVAL(9),
	AWAITING_MODIFICATION_APPROVAL(10), CANCELLED(11), WAITING(12);

	private final int statusCode;

	Status(int statusCode) {
		this.statusCode = statusCode;
	}

	public int getStatusCode() {
		return statusCode;
	}

	public static Status parse(int statusCode) {
		Status status = null; // Default
		for (Status item : Status.values()) {
			if (item.getStatusCode() == statusCode) {
				status = item;
				break;
			}
		}
		return status;
	}

	public static int getValue(int statusCode) {
		for (Status item : Status.values()) {
			if (item.getStatusCode() == statusCode) {
				return item.getStatusCode();
			}
		}
		return 0;
	}
}
