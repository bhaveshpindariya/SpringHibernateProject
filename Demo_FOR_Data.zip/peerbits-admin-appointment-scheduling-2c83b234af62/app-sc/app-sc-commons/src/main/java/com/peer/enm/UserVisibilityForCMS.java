package com.peer.enm;

import java.util.ArrayList;
import java.util.List;

import com.peer.constant.CommonConstants;

public enum UserVisibilityForCMS {
	
	All("All"),
	Affiliate(CommonConstants.USERTYPE_AFFILIATE), 
	Doctor(CommonConstants.USERTYPE_DOCTOR), 
	Analyst(CommonConstants.USERTYPE_ANALYST),
	SubAdmin(CommonConstants.USERTYPE_SUBADMIN),
	Admin(CommonConstants.USERTYPE_ADMIN);
	
	private String userType;

	UserVisibilityForCMS(String userType) {
		this.userType = userType;
	}

	public String getUserType() {
		return userType;
	}
	
	public static UserVisibilityForCMS parse(String userType) {
		UserVisibilityForCMS userTypes = null; 
        for (UserVisibilityForCMS item : UserVisibilityForCMS.values()) {
        	if (item.getUserType().equals(userType)) {
        		userTypes = item;
                break;
            }
        }
        return userTypes;
    }
    
    public static String getValue(String userType) {
    	 for (UserVisibilityForCMS item : UserVisibilityForCMS.values()) {
            if (item.name() == userType) {
            		return item.getUserType();
            }
        }
        return null;
    }
    
    public static List<String> getUserVisibilityForCMS() {
    	UserVisibilityForCMS[] values = UserVisibilityForCMS.values();
        List<String> list = new ArrayList<>();
        for (UserVisibilityForCMS value : values) {
            list.add(value.name());
        }
        return list;
    }

}
