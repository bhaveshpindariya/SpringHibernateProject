package com.peer.enm;

public enum AcessType {

	Public(1),
	Private(2);

	private final int acessType;

	AcessType(int acessType) {
        this.acessType = acessType;
    }

    public int getAcessType() {
        return acessType;
    }

    public static AcessType parse(int acessType) {
    	AcessType currencyType = null; // Default
        for (AcessType item : AcessType.values()) {
        	if (item.getAcessType()==acessType) {
            	currencyType = item;
                break;
            }
        }
        return currencyType;
    }
    
    public static int getValue(int acessType) {
		for (AcessType item : AcessType.values()) {
			if (item.getAcessType() == acessType) {
				return item.getAcessType();
			}
		}
		return 0;
	}

}
