package com.peer.enm;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import com.peer.constant.CommonConstants;

public enum UserType {
	
	Affiliate(CommonConstants.USERTYPE_AFFILIATE), 
	Doctor(CommonConstants.USERTYPE_DOCTOR), 
	Analyst(CommonConstants.USERTYPE_ANALYST),
	SubAdmin(CommonConstants.USERTYPE_SUBADMIN),
	Admin(CommonConstants.USERTYPE_ADMIN);

	private String userType;

	UserType(String userType) {
		this.userType = userType;
	}

	public String getUserType() {
		return userType;
	}
	
	public static UserType parse(String userType) {
		UserType userTypes = null; // Default
        for (UserType item : UserType.values()) {
        	if (item.getUserType().equals(userType)) {
        		userTypes = item;
                break;
            }
        }
        return userTypes;
    }
    
    public static String getValue(String userType) {
    	 for (UserType item : UserType.values()) {
            if (item.name() == userType) {
            		return item.getUserType();
            }
        }
        return null;
    }
    
    public static List<String> getAllUserType() {
    	UserType[] values = UserType.values();
        List<String> list = new ArrayList<>();
        for (UserType value : values) {
            list.add(value.name());
        }
        return list;
    }
    
    public static List<UserType> getAllUserTypes() {
    	List<UserType> adminUserTypes = Arrays.stream(UserType.values()).collect(Collectors.toList());
    	adminUserTypes.remove(parse(CommonConstants.USERTYPE_AFFILIATE));
    	adminUserTypes.remove(parse(CommonConstants.USERTYPE_DOCTOR));
		return adminUserTypes;
	}
}
