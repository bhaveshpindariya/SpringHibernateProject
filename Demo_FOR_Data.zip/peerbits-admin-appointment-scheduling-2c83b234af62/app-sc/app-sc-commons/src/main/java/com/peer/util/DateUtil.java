package com.peer.util;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.apache.log4j.Logger;
import org.joda.time.DateTime;
import org.joda.time.Days;
import org.joda.time.Hours;
import org.joda.time.Minutes;
import org.joda.time.Months;
import org.joda.time.Years;

import com.peer.constant.CommonConstants;

public class DateUtil {

	private static Logger _log = Logger.getLogger(DateUtil.class);
	public static final DateFormat DD_MMM_YYYY_AM_PM = new SimpleDateFormat("dd MMM yyyy  hh:mm a");

	public static final DateFormat DD_MMMM_YYYY = new SimpleDateFormat("dd MMMM yyyy");

	public static final DateFormat MMM_DD_YYYY = new SimpleDateFormat("MMM dd, yyyy");

	public static final DateFormat MMMM_DD = new SimpleDateFormat("MMMM dd");

	public static final DateFormat MMM = new SimpleDateFormat("MMM");

	public static final DateFormat DD_MM_YYYY = new SimpleDateFormat("dd/MM/yyyy");
	public static final DateFormat YYYY_MM_DD = new SimpleDateFormat("yyyy-MM-dd");
	public static final DateFormat YYYY_MM_DD_HH_MM_A = new SimpleDateFormat("yyyy-MM-dd hh:mm a");
	public static final DateFormat MM_DD_YYYY = new SimpleDateFormat("MM-dd-yyyy");

	public static final DateFormat HH_MM_AM_PM = new SimpleDateFormat("hh:mm a");
	public static final DateFormat HH_MM = new SimpleDateFormat("hh:mm");
	public static final DateFormat AM_PM = new SimpleDateFormat("a");

	public static String getTimeDiff(Date date) {
		DateTime dateTime = new DateTime(date.getTime());
		return getTimeDiff(dateTime, new DateTime());
	}

	public static String getTimeDiff(DateTime dt1, DateTime dt2) {
		String timeDiff;
		long diff = Years.yearsBetween(dt1, dt2).getYears();
		if (diff >= 1) {
			timeDiff = diff + " year ago";
		} else {
			diff = Months.monthsBetween(dt1, dt2).getMonths();
			if (diff >= 1) {
				timeDiff = diff + " month ago";
			} else {
				diff = Days.daysBetween(dt1, dt2).getDays();
				if (diff >= 1) {
					timeDiff = diff + " day ago";
				} else {
					diff = Hours.hoursBetween(dt1, dt2).getHours();
					if (diff >= 1) {
						timeDiff = diff + " hour ago";
					} else {
						diff = Minutes.minutesBetween(dt1, dt2).getMinutes();
						if (diff >= 1) {
							timeDiff = diff + " minute ago";
						} else {
							timeDiff = "Just Now";
						}
					}
				}
			}
		}
		return timeDiff;
	}

	public static String getFormatterDate(Date date) {
		return DD_MMM_YYYY_AM_PM.format(date);
	}

	public static String getFormatterDateForCMS(Date date) {
		return DD_MMMM_YYYY.format(date);
	}

	public static Date getStartDateOfDay(Date date) {
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		calendar.set(Calendar.HOUR, 0);
		calendar.set(Calendar.MINUTE, 0);
		calendar.set(Calendar.SECOND, 0);
		return calendar.getTime();
	}

	public static Date getEndDateOfDay(Date date) {
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		calendar.set(Calendar.HOUR, 23);
		calendar.set(Calendar.MINUTE, 59);
		calendar.set(Calendar.SECOND, 59);
		return calendar.getTime();
	}

	public static Date getFirstDateOfMonth(Date date) {
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		calendar.set(Calendar.DATE, calendar.getActualMinimum(Calendar.DATE));
		return calendar.getTime();
	}

	public static Date getLastDateOfMonth(Date date) {
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		calendar.set(Calendar.HOUR_OF_DAY, 23);
		calendar.set(Calendar.MINUTE, 59);
		calendar.set(Calendar.DATE, calendar.getActualMaximum(Calendar.DATE));
		return calendar.getTime();
	}

	public static Date getFirstDateOfYear(Date date) {
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		calendar.set(Calendar.DATE, 1);
		calendar.set(Calendar.MONTH, calendar.getActualMinimum(Calendar.MONTH));
		return calendar.getTime();
	}

	public static Date getLastDateOfYear(Date date) {
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		calendar.set(Calendar.DATE, 31);
		calendar.set(Calendar.MONTH, calendar.getActualMaximum(Calendar.MONTH));
		return calendar.getTime();
	}

	public static String formateDate(Date date, DateFormat dateFormat) {
		return dateFormat.format(date);
	}

	public static String formateDateNullSafe(Date date, DateFormat dateFormat) {
		if (null != date) {
			return dateFormat.format(date);
		}
		return "";
	}

	public static Date parseDate(String date, DateFormat dateFormat) {
		try {
			return dateFormat.parse(date);
		} catch (ParseException e) {
			_log.error(e);
		}
		return null;
	}

	public static Date parseDate(Date date, DateFormat dateFormat) {
		try {
			return dateFormat.parse(dateFormat.format(date));
		} catch (ParseException e) {
			_log.error(e);
		}
		return date;
	}

	public static String formateDate(String date, DateFormat dateFormat) {
		return dateFormat.format(date);
	}

	public static String concatDate(Date startDate, Date endDate, DateFormat dateFormat) {
		return dateFormat.format(startDate) + " - " + dateFormat.format(endDate);
	}

	public static long dateDifferenceInHoursWithNow(Date date1) {
		return dateDifferenceInHours(date1, new Date());
	}

	public static long dateDifferenceInHours(Date date1, Date date2) {
		long diff = date1.getTime() - date2.getTime();
		return diff / (60 * 60 * 1000);
	}

	public static long dateDifferenceInDays(Date date1, Date date2) {
		long diff = date1.getTime() - date2.getTime();
		return diff / (60 * 60 * 24 * 1000);
	}

	public static String formatDate(Date date, String time, String median) {
		try {
			if (null != date) {
				Date date1 = parseDate(date, time, median);
				return YYYY_MM_DD_HH_MM_A.format(date1);
			}
		} catch (Exception e) {
			_log.error(e);
		}
		return "";
	}

	public static Date parseDate(Date date, String time, String median) {
		try {
			String dateS = YYYY_MM_DD.format(date);
			String finalDate = dateS + " " + time + " " + median;
			return YYYY_MM_DD_HH_MM_A.parse(finalDate);
		} catch (Exception e) {
			_log.error(e);
		}
		return null;
	}

	public static Date getDateOffset(int offsetDays) {
		Calendar calendar = Calendar.getInstance();
		calendar.add(Calendar.DATE, offsetDays);
		return calendar.getTime();
	}

	public static boolean isWaitlistsExpired(Date createdOn) {
		long days = dateDifferenceInDays(new Date(), createdOn);
		if (days > CommonConstants.WAITLIST_EXPIRED_DAYS) {
			return true;
		}
		return false;
	}

	public static long getDaysRemainForExpire(Date createdOn) {
		long days = dateDifferenceInDays(new Date(), createdOn);
		return CommonConstants.WAITLIST_EXPIRED_DAYS - days;
	}
}