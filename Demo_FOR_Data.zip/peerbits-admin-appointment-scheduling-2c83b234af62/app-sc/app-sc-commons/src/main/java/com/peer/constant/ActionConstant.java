package com.peer.constant;

import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;

public class ActionConstant {

	private static final Logger _log = Logger.getLogger(ActionConstant.class);

	//Appointment
	
	public static final String VIEW_UPCOMING_APPOINTMENT = "VIEW_UPCOMING_APPOINTMENT";
	public static final String VIEW_SCHEDULE = "VIEW_SCHEDULE";
	public static final String MODIFY_SCHEDULE = "MODIFY_SCHEDULE";
	public static final String CREATE_NEW_APPOINTMENT = "CREATE_NEW_APPOINTMENT";
	public static final String VIEW_APPOINTMENT = "VIEW_APPOINTMENT";
	public static final String CANCEL_APPOINTMENT = "CANCEL_APPOINTMENT";
	public static final String CREATE_NEW_SCHEDULE = "CREATE_NEW_SCHEDULE";
	public static final String VIEW_APPOINTMENT_CANCELLATIONS = "VIEW_APPOINTMENT_CANCELLATIONS";
	public static final String MODIFY_APPOINTMENTS = "MODIFY_APPOINTMENTS";
	
	//Waitlists
	public static final String VIEW_WAITLISTS = "VIEW_WAITLISTS";
	
	//Affiliates
	public static final String VIEW_AFFILIATES = "VIEW_AFFILIATES";
	public static final String EDIT_AFFILIATES = "EDIT_AFFILIATES";
	public static final String DELETE_AFFILIATES = "DELETE_AFFILIATES";
	public static final String CHANGE_PASSWORD_AFFILIATES = "CHANGE_PASSWORD_AFFILIATES";
	
	//Doctor
	public static final String ADD_NEW_DOCTOR = "ADD_NEW_DOCTOR";
	public static final String VIEW_DOCTOR = "VIEW_DOCTOR";
	public static final String EDIT_DOCTOR = "EDIT_DOCTOR";
	public static final String DELETE_DOCTOR = "DELETE_DOCTOR";
	public static final String CHANGE_PASSWORD_DOCTOR = "CHANGE_PASSWORD_DOCTOR";
	
	//Admin
	public static final String ADD_NEW_ADMINS = "ADD_NEW_ADMINS";
	public static final String VIEW_ADMINS = "VIEW_ADMINS";
	public static final String EDIT_ADMINS = "EDIT_ADMINS";
	public static final String DELETE_ADMINS = "DELETE_ADMINS";
	public static final String CHANGE_PASSWORD_ADMINS = "CHANGE_PASSWORD_ADMINS";
	
	//Cancellation 
	public static final String ADD_NEW_CANCELLATION = "ADD_NEW_CANCELLATION";
	public static final String DELETE_CANCELLATION = "DELETE_CANCELLATION";
	public static final String EDIT_CANCELLATION = "EDIT_CANCELLATION";
	public static final String VIEW_CANCELLATION="VIEW_CANCELLATION";
	public static final String UPDATE_HOURS="UPDATE_HOURS";
	
	//Subject
	public static final String ADD_NEW_SUBJECT = "ADD_NEW_SUBJECT";
	public static final String DELETE_SUBJECT = "DELETE_SUBJECT";
	public static final String EDIT_SUBJECT = "EDIT_SUBJECT";
	public static final String VIEW_SUBJECT = "VIEW_SUBJECT";
	
	//Role
	public static final String ADD_NEW_ROLE = "ADD_NEW_ROLE";
	public static final String DELETE_ROLE = "DELETE_ROLE";
	public static final String EDIT_ROLE = "EDIT_ROLE";
	public static final String VIEW_ROLE = "VIEW_ROLE";
	
	//Location
	public static final String ADD_NEW_LOCATION = "ADD_NEW_LOCATION";
	public static final String DELETE_LOCATION = "DELETE_LOCATION";
	public static final String EDIT_LOCATION = "EDIT_LOCATION";
	public static final String VIEW_LOCATION = "VIEW_LOCATION";
	
	//Eps
	public static final String ADD_NEW_EPS = "ADD_NEW_EPS";
	public static final String DELETE_EPS = "DELETE_EPS";
	public static final String EDIT_EPS = "EDIT_EPS";
	public static final String VIEW_EPS = "VIEW_EPS";
	
	//Category
	public static final String ADD_NEW_CATEGORY = "ADD_NEW_CATEGORY";
	public static final String VIEW_CATEGORY = "VIEW_CATEGORY";
	public static final String DELETE_CATEGORY = "DELETE_CATEGORY";
	public static final String EDIT_CATEGORY = "EDIT_CATEGORY";
	
	//Cms
	public static final String ADD_NEW_CMS = "ADD_NEW_CMS";
	public static final String VIEW_CMS = "VIEW_CMS";
	public static final String EDIT_CMS = "EDIT_CMS";
	public static final String REMOVE_CMS = "REMOVE_CMS";
	
	//Faq
	public static final String ADD_NEW_FAQ = "ADD_NEW_FAQ";
	public static final String VIEW_FAQ = "VIEW_FAQ";
	public static final String EDIT_FAQ = "EDIT_FAQ";
	
	//Costing
	public static final String VIEW_COSTING = "VIEW_COSTING";
	public static final String ADD_COSTING = "ADD_COSTING";
	public static final String DELETE_COSTING = "DELETE_COSTING";
	public static final String UPDATE_WAGE = "UPDATE_WAGE";
	public static final String EDIT_COSTING = "EDIT_COSTING";
	
	public static final String VIEW_DASHBOARD = "VIEW_DASHBOARD";
	public static final String PUSH_NOTIFICATIONS = "PUSH_NOTIFICATIONS";
	
	public static final String ADD_DOCTOR_CONTACT = "ADD_DOCTOR_CONTACT";

	public static Map<String, String> getActionsMap() {
		Map<String, String> actionMap = new HashMap<>(0);
		
		//Appointment
		actionMap.put(VIEW_APPOINTMENT, "View Appointment");
		actionMap.put(VIEW_SCHEDULE, "View Schedule");
		actionMap.put(MODIFY_SCHEDULE, "Modify Schedule");
		actionMap.put(CREATE_NEW_APPOINTMENT, "Create New Appointment");
		actionMap.put(CANCEL_APPOINTMENT, "Cancel Appointment");
		actionMap.put(CREATE_NEW_SCHEDULE, "Create New Schedule");
		actionMap.put(VIEW_UPCOMING_APPOINTMENT, "View Upcoming Appointment");
		actionMap.put(VIEW_APPOINTMENT_CANCELLATIONS, "View Appointment Cancellations");
		actionMap.put(MODIFY_APPOINTMENTS, "Modify Appointment");
		
		//Waitlists
		actionMap.put(VIEW_WAITLISTS, "View Waitlists");
		
		//Affiliates
		actionMap.put(VIEW_AFFILIATES, "View Affiliates");
		actionMap.put(EDIT_AFFILIATES, "Edit Affiliates");
		actionMap.put(DELETE_AFFILIATES, "Delete Affiliates");
		actionMap.put(CHANGE_PASSWORD_AFFILIATES, "Change Affiliates Password");
		
		//Doctor
		actionMap.put(ADD_NEW_DOCTOR, "Add New Doctor");
		actionMap.put(VIEW_DOCTOR, "View Doctor");
		actionMap.put(EDIT_DOCTOR, "Edit Doctor");
		actionMap.put(DELETE_DOCTOR, "Delete Doctor");
		actionMap.put(CHANGE_PASSWORD_DOCTOR, "Change Doctor Password");
		
		//Admin
		actionMap.put(ADD_NEW_ADMINS, "Add New Admins");
		actionMap.put(VIEW_ADMINS, "View Admins");
		actionMap.put(EDIT_ADMINS, "Edit Admins");
		actionMap.put(DELETE_ADMINS, "Delete Admins");
		actionMap.put(CHANGE_PASSWORD_ADMINS, "Change Admin Password");
		
		
		//Cancellation 
		actionMap.put(ADD_NEW_CANCELLATION, "Add New Cancellation");
		actionMap.put(DELETE_CANCELLATION, "Delete Cancellation");
		actionMap.put(EDIT_CANCELLATION, "Edit Cancellation");
		actionMap.put(VIEW_CANCELLATION, "View Cancellation");
		actionMap.put(UPDATE_HOURS, "Update Cancellation hours");
		
		//Subject
		actionMap.put(ADD_NEW_SUBJECT, "Add New Subject");
		actionMap.put(DELETE_SUBJECT, "Delete Subject");
		actionMap.put(EDIT_SUBJECT, "Edit Subject");
		actionMap.put(VIEW_SUBJECT, "View Subject");
		
		//Role
		actionMap.put(ADD_NEW_ROLE, "Add New Role");
		actionMap.put(DELETE_ROLE, "Delete Role");
		actionMap.put(EDIT_ROLE, "Edit Role");
		actionMap.put(VIEW_ROLE, "View Role");
		
		//Location
		actionMap.put(ADD_NEW_LOCATION, "Add New Location");
		actionMap.put(DELETE_LOCATION, "Delete Location");
		actionMap.put(EDIT_LOCATION, "Edit Location");
		actionMap.put(VIEW_LOCATION, "View Location");
		
		//Eps
		actionMap.put(ADD_NEW_EPS, "Add New Eps");
		actionMap.put(DELETE_EPS, "Delete Eps");
		actionMap.put(EDIT_EPS, "Edit Eps");
		actionMap.put(VIEW_EPS, "View Eps");
		
		//Category
		actionMap.put(ADD_NEW_CATEGORY, "Add New Category");
		actionMap.put(DELETE_CATEGORY, "Delete Category");
		actionMap.put(EDIT_CATEGORY, "Edit Category");
		actionMap.put(VIEW_CATEGORY, "View Category");
		
		//Cms
		actionMap.put(ADD_NEW_CMS, "Add New Cms");
		actionMap.put(VIEW_CMS, "View Cms");
		actionMap.put(EDIT_CMS, "Edit Cms");
		actionMap.put(REMOVE_CMS, "Remove Cms");
		
		//Costing
		actionMap.put(ADD_COSTING, "Add Costing");
		actionMap.put(VIEW_COSTING, "View Costing");
		actionMap.put(EDIT_COSTING, "Edit Costing");
		actionMap.put(DELETE_COSTING, "Delete Costing");
		actionMap.put(UPDATE_WAGE, "Update Wage");
		
		
		//Faq
		actionMap.put(ADD_NEW_FAQ, "Add Faq");
		actionMap.put(VIEW_FAQ, "View Faq");
		actionMap.put(EDIT_FAQ, "Edit Faq");
		
		actionMap.put(VIEW_DASHBOARD, "View Dashboard");
		actionMap.put(PUSH_NOTIFICATIONS, "Push Notifications");
		
		actionMap.put(ADD_DOCTOR_CONTACT, "Add Doctor Contact");
		
		if (_log.isDebugEnabled()) {
			_log.debug("keySet");
			_log.debug(actionMap.keySet());
		}
		return actionMap;
	}

	private ActionConstant() {
		super();
	}
	
	public static final String MENU_MAP = "MENU_MAP";
	public static final String MANAGE_REQUESTS = "MANAGE_REQUESTS";
}