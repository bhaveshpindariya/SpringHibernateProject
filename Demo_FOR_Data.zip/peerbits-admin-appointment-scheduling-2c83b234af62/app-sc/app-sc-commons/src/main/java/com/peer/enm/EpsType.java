package com.peer.enm;

import java.util.ArrayList;
import java.util.List;

public enum EpsType {

	EPS("EPS"),
	IPS("IPS");

	private String epsType;
	EpsType(String epsType) {
		this.epsType = epsType;
	}

	public String getEpsType() {
		return epsType;
	}

	public static EpsType parse(String epsType) {
		EpsType epsTypes = null; // Default
		for (EpsType item : EpsType.values()) {
			if (item.getEpsType().equals(epsType)) {
				epsTypes = item;
				break;
			}
		}
		return epsTypes;
	}

	public static String getValue(String epsType) {
		for (EpsType item : EpsType.values()) {
			if (item.name() == epsType) {
				return item.getEpsType();
			}
		}
		return null;
	}

	public static EpsType getEpsTypeData(String epsType) {
		for (EpsType item : EpsType.values()) {
			if (item.name() == epsType) {
				return item;
			}
		}
		return null;
	}

	public static List<String> getAllEpsTypeType() {
		EpsType[] values = EpsType.values();
		List<String> list = new ArrayList<>();
		for (EpsType value : values) {
			list.add(value.name());
		}
		return list;
	}

}
