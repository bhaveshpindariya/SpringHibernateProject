$(function(){
	var datePickerOptions = {format: 'dd/mm/yyyy',todayHighlight: true,language: currentLanguage};
	$('#dashboardCalendar').datepicker(datePickerOptions).on("changeDate", function(e) {
		var selectedDate = e.format();
		getAvailableAppointments(selectedDate);
    });
	var selectedDate = getCurrentDate();
	$('#dashboardCalendar').datepicker('update', selectedDate);
	getAvailableAppointments(selectedDate);
});

function getAvailableAppointments(selectedDate){
	fetchDoctorsAppointments(selectedDate);
}

function fetchDoctorsAppointments(selectedDate){
	var fetchDoctorsAppointmentsURL = baseUrl+"/dashboard/getAppointments";
	$.ajax({
		url:fetchDoctorsAppointmentsURL,
		data:{appointmentDate:selectedDate},
		success:function(rdata){
			var data = JSON.parse(rdata);	
			processAppointments(data);
		},error:function(){
			console.error("service is unavailable");
		}
	});
}

function processAppointments(data){
	$("#appointmentList").html('');
	$("#appointmentDisplayDate").text(data.dateFormatted);
	if(data.items.length <= 0){
		$("#appointmentList").text($("#noAppointmentMessage").text());
	}
	data.items.forEach(function(currentValue, index, arr){
		var appointmentTemplate = $("#appointmentTemplate").html();
		var userImage = '<img class="rounded-circle mr-3" src="'+baseUrl+currentValue.userProfileImg+'" width="40px">';
		appointmentTemplate = replaceAll(appointmentTemplate, "USER_IMAGE", userImage);
		appointmentTemplate = replaceAll(appointmentTemplate, "USER_NAME", currentValue.userName);
		appointmentTemplate = replaceAll(appointmentTemplate, "CATEGORY_NAME", currentValue.categoryName);
		appointmentTemplate = replaceAll(appointmentTemplate, "APPOINTMENT_DATE", currentValue.appointmentDate);
		appointmentTemplate = replaceAll(appointmentTemplate, "TIME_SLOT", currentValue.timeSlot);
		appointmentTemplate = replaceAll(appointmentTemplate, "LOCATION", currentValue.location);
		$("#appointmentList").append(appointmentTemplate);
	});
}