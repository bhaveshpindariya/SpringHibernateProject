function checkPasswordRules(){
	if($("#password").val() != $("#cpassword").val()){
		$("#message").text("Password you entered did not match");
		$("#data").modal("show");
		return false;
	}else if($("#password").val().length < 6){
		$("#message").text("Please Enter Atleast 6 letter");
		$("#data").modal("show");
		return false;
	}else{
		$("#resetPasswordForm").submit();
	}
}