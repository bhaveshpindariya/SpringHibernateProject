function editprofile(userId) {
	console.log("Called");
	$("#profileid").val(userId);
	$("#editProfileForm").submit();
}

