function replaceAll(str, term, replacement) {
	return str.replace(new RegExp(escapeRegExp(term), 'g'), replacement);
}
function escapeRegExp(string){
    return string.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}
function calculatePercentage(total, percentage){
	var percentageAmount = 0.0;
	if(total && percentage){
		percentageAmount = (total * percentage) / 100;
	}
	return percentageAmount;
}

function startLoader(cssClass){
	$("."+cssClass).addClass("loading-item");
	$(".portal-loader").removeClass("d-none");
}
function stopLoader(cssClass){
	$("."+cssClass).removeClass("loading-item");
	$(".portal-loader").addClass("d-none");
}
function getCurrentDate(){
	var date = new Date();
	var month = date.getMonth()+1;
	return date.getDate()+"/"+month+"/"+date.getFullYear();
}