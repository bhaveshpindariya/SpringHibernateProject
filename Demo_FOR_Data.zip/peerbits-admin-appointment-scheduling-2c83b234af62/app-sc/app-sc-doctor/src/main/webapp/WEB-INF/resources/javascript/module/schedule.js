/*var docScTable;*/

var months = ["January","Febrary","March","April","May","June","July","August","September","October","November","December"];

$(function(){
	var datePickerOptions = {format: 'mm/dd/yyyy',todayHighlight: true,language: currentLanguage};
	$('#schedulePicker').datepicker(datePickerOptions).on('changeDate', function (ev) {
        var startdate = $('#schedulePicker').datepicker('getFormattedDate'); 
        var sdate = new Date(startdate);
    	var edate = new Date();
    	if(sdate<edate) {
    		$('#sc-add').hide();
    	} else {
    		$('#sc-add').show();
    	}
   		scChange(startdate);
    });
	getDoctorSchedules();
});


/*$(function() {
	if($("#doctorScheduleTable").length){
		var schViewButton = 'abc';
		var schAcceptButton = 'aaa';
		var schRejectButton = 'rrr';

		docScTable = $("#doctorScheduleTable").DataTable( {
			"lengthMenu": [[10, 25, 50], [10, 25, 50]],
			"columnDefs": [ {"targets": 6, "orderable": false} ],
			"processing": true,
			"serverSide": true,
			"autoWidth": false,
			"ordering": false,
			"searching": false,
			"ajax": {
				url:fetchDoctorSchedules,
				data: function(data) {
				     data.filterDate = $('#datetimepicker13').datepicker('getFormattedDate');
				     data.filterLocation = $("#filterLoc").val();
				     data.filterStatus = $("#filterStatus").val();
				     data.filterEps = $("#filterEPS").val();
			    }
			},
			"columns": [
	            { "data": "startTime" },
	            { "data": "endTime" },
	            { "data": "locationEnglish" },
	            { "data": "maxAppointments" },
	            { "data": "maxAppointments" },
	            { "data": "status" },
	            { "data": "" ,"sClass":"align-middle text-center actions-btn"}
	        ],
	        "columnDefs": [{
	            "targets": 5,
	            "createdCell": function(td, cellData, rowData, row, col) {
	                switch(cellData) {
	                case "ACTIVE":
	                    $(td).addClass('text-success');
	                    break;
	                case "DELETED":
	                    $(td).addClass('text-danger');
	                    break;
	                }
	            }
	        },{
	            "targets": -1,
	            "data": null,
	            "defaultContent": schViewButton+schAcceptButton+schRejectButton
	        } ]
		});		
	}
});*/



$('#sc-add').click(function(){
	var startdate = $('#schedulePicker').datepicker('getFormattedDate');
	$('#startdate').val(startdate);
	var enddate = $('#endDate').datepicker('getFormattedDate');
	submitSchedule();
});

$('input[name="iscopy"]').change(function(){
	var copyval = $(this).val();
	if(copyval == "yes") {
		$('#endDate').attr("required", "required");
	} else {
		$('#endDate').removeAttr("required");
	}
});

var weekDays = ["sunday", "monday", "tuesday", "wednesday", "friday", "saturday"];

function submitSchedule() {
	var startdate = $('#startdate').val();
	var enddate = $('#endDate').val();
	var starttime = $('#startTime').val();
	var endtime = $('#endTime').val();
	var location = $('#location').val();
	var iscopy = $('input[name="iscopy"]:checked').val();
	var days = $('input[type="checkbox"][name="q1"]:checked').length;
	var isvalidfm = false;
	var messageErr = $(".request-not-completed").text();
	
	if(startdate && starttime && endtime && location){
		if(iscopy && iscopy=="yes") {
			var sdate = new Date(startdate);
			var edate = new Date(enddate);
			if(days && enddate){
				if(edate>sdate) {
					var repeatDays = [];
				     $.each($("input[type='checkbox'][name='q1']:checked"), function(){            
				    	 repeatDays.push($(this).val());
				     });
					var isDaySelected = false;
					for(var d=sdate; d<=edate; d.setDate(d.getDate()+1)) {
						if(repeatDays.indexOf(weekDays[d.getDay()])>-1) {
							isDaySelected = true;
						}
					}
					if(isDaySelected) {
						if(timeCompare(starttime, endtime) == "true"){
							isvalidfm = true;
						} else {
							messageErr = $(".end-time-smaller").text();
						}
					} else {
						messageErr = $(".repeat-days-within-range").text();
					}
				}else{
					messageErr = $(".end-date-smaller").text();
				}
			} else {
				messageErr = $(".end-date-required").text();
			}
		} else {
			if(timeCompare(starttime, endtime) == "true"){
				isvalidfm = true;
			} else {
				messageErr = $(".end-time-smaller").text();
			}
		}
	} else {
		messageErr = $(".fill-all-required").text();
	}
	if(isvalidfm) {
		var addScheduleUrl = baseUrl+"/dashboard/add-schedule";
		var formData = $('#availability-fm').serialize();
		$.ajax({
			url:addScheduleUrl,
			data:formData,
			success:function(rdata){
				var data = JSON.parse(rdata);
				if(data.status=="success"){
					$('#message').val(data.message);
					$('#availability-success').submit();
				} else {
					$('.submit-err').html(data.message);
					$('.submit-err').show();
					$('html, body').animate({
					       scrollTop: $(".submit-err").offset().top
					}, 500);
				}
			},error:function(){
				console.error("schedule add service is unavailable");
			}
		});
	} else {
		$('.submit-err').html(messageErr);
		$('.submit-err').show();
	}
}

function convertTime12to24(time12h) {
	  const [time, modifier] = time12h.split(' ');

	  let [hours, minutes] = time.split(':');

	  if (hours === '12') {
	    hours = '00';
	  }

	  if (modifier === 'PM') {
	    hours = parseInt(hours, 10) + 12;
	  }

	  return hours + ':' + minutes;
}

function timeCompare(startTime, endTime) {
	var startTime24 = convertTime12to24(startTime);
	var endTime24 = convertTime12to24(endTime);
	let [hoursStart, minutesStart] = startTime24.split(':');
	let [hoursEnd, minutesEnd] = endTime24.split(':');
	if(parseInt(hoursEnd,10) < parseInt(hoursStart,10)){
		return "false";
	} else if(parseInt(hoursEnd,10) == parseInt(hoursStart,10)) {
		if(parseInt(minutesEnd,10) <= parseInt(minutesStart,10)) {
			return "false";
		} else {
			return "true";
		}
	} else {
		return "true";
	}
}


function scChange(selectedDate) {
	getDoctorSchedules();
}

function getDoctorSchedules() {
	
	var filterDate = $('#schedulePicker').datepicker('getFormattedDate');
    var filterLocation = $("#filterLoc").val();
    var filterStatus = $("#filterStatus").val();
    var filterEps = $("#filterEPS").val();
    
    var dt = dateToday;
    
    if(filterDate) {
	    dt = new Date(filterDate);
    }
	
    var month = months[dt.getMonth()];
	var date = dt.getDate();
	var year = dt.getFullYear();
	
	var dateHtml = dateConstant.replace("MONTH",month).replace("DATE",date).replace("YEAR",year);
	$('.schDateClass').html(dateHtml);
    
	$.ajax({
		url:fetchDoctorSchedules,
		data:{
			"filterDate":filterDate,
			"filterLocation":filterLocation,
			"filterStatus":filterStatus,
			"filterEps":filterEps
		},
		success:function(rdata){
			$("#doctorScheduleTable tbody").html('');
			var data = JSON.parse(rdata);
			var rowData = "";
			for(var i=0; i<data.length; i++){
				var schedule = data[i];
				rowData += '<tr>';
				rowData += '<td>'+schedule.startTime+'</td>';
				rowData += '<td>'+schedule.endTime+'</td>';
				rowData += '<td>'+schedule.locationEnglish+'</td>';
				rowData += '<td>'+schedule.maxAppointments+'</td>';
				rowData += '<td>'+schedule.appointmentsBooked+'</td>';
				rowData += '<td><span class="badge badge-success">'+schedule.status+'</span></td>';
				rowData += '<td>';
				rowData += schedule.actionBtns;
				rowData += '</td>';
				rowData += '</tr>';
				rowData += '<tr id="sc_'+schedule.scheduleId+'" style="display:none"><td>'+JSON.stringify(schedule)+'</td></tr>'
			}
			$("#doctorScheduleTable tbody").append(rowData);
			$('.doctorCancelSchBtn').off('click').click(function(){
				var scId = $(this).data('scid');
				$('.cancelerr').html('');
				$('#docCancelSchId').val(scId);
				populateCancelReasons();
			});
			$('.doctorModifyBtn').off('click').click(function(){
				$('.modify-sub-err').html('');
				var scId = $(this).data('scid');
				var scjson = $('#sc_'+scId).children("td:first").text();
				var scJson = JSON.parse(scjson);
				var stime = scJson.startTime;
				var etime = scJson.endTime;
				var loc = scJson.locationId;
				$('#docLocationModal').val(loc);
				$('#docEtimeModal').val(etime);
				$('#docStimeModal').val(stime);
				$('#docModifySchId').val(scId);
				populateLocations(loc);
				
			});
			
			$('.doctorViewReqBtn').off('click').click(function(){
				$.ajax({
					url:fetchChildScheduleUrl,
					success:function(childSch){
						childSch = JSON.parse(childSch);
						
					},error:function(){
						console.error("get ChildSchedule Service is unavailable");
					}
				});
			});	
			
		},error:function(){
			console.error("doctor schedule get service is unavailable");
		}
	});
}
function modalDocModify() {
	var validfm = validateModifyModalForm();
	if(validfm) {
		$('#modify-sc-fm').submit();
	} 
}

function populateCancelReasons() {
	$('#docCancelReason').empty();
	$.ajax({
		url:fetchCancelReasonsUrl,
		success:function(cancelReasons){
			cancelReasons = JSON.parse(cancelReasons);
			var options = "";
			console.log("cancelReason.length: "+cancelReasons.length);
			for(var i=0; i<cancelReasons.length; i++) {
				var data = cancelReasons[i];
				options += '<option value="'+data.reason+'">'+data.reason+'</option>';
			}
			options += '<option value="other">Other</option>';
			$('#docCancelReason').append(options);
			showHideOtherReason();
		},error:function(){
			console.error("get all active local cancelReason service is unavailable");
		}
	});
}


function populateLocations(selectedLoc) {
	$('#docLocationModal').empty();
	$.ajax({
		url:fetchLocationsUrl,
		success:function(locations){
			locations = JSON.parse(locations);
			var options = "";
			console.log("locations.length: "+locations.length);
			for(var i=0; i<locations.length; i++) {
				var data = locations[i];
				options += '<option value="'+data.locationId+'">'+data.location+'</option>';
			}
			$('#docLocationModal').append(options);
			$('#docLocationModal').val(selectedLoc);
		},error:function(){
			console.error("get all active local locations service is unavailable");
		}
	});
}

function showHideOtherReason() {
	var selectedReason = $('#docCancelReason').val();
	if(!selectedReason || selectedReason == "other") {
		$('#reasonOtherModal').val('');
		$('.othereason').show();
	} else {
		$('.othereason').hide();
	}
}

$('#docCancelReason').change(function(){
	showHideOtherReason();
	$('.cancelerr').html('');
});

$(document).off('click').on('click','#docCancelSub',function(e){
	var scid = $('#docCancelSchId').val();
	var reason = $('#docCancelReason').val();
	if(scid && reason) {
		if(reason == "other") {
			var otherreason = $('#reasonOtherModal').val();
			if(otherreason) {
				$('#cancel-sc-fm').submit();
			} else {
				e.preventDefault();
				$('.cancelerr').html(errDiv.replace("ERRMESSAGE",$(".all-required").text()));
			}
		} else {
			$('#cancel-sc-fm').submit();
		}
	}
});

/*$(document).on('click','.doctorViewReqBtn',function(){
	alert("view click..");
});*/

function validateModifyModalForm() {
	var errMessage = "";
	isvalid = true;
	var scId = $('#docModifySchId').val();
	var sTime = $('#docStimeModal').val();
	var eTime = $('#docEtimeModal').val();
	var locatn = $('#docLocationModal').val();
	if(scId && sTime && eTime && locatn) {
		if(timeCompare(sTime, eTime) != "true") {
			isvalid = false;
			errMessage = $(".start-time-error").text();
		}
	} else {
		isvalid = false;
		errMessage = $(".all-required").text();
	}
	if(!isvalid) {
		$('.modify-sub-err').html(errDiv.replace("ERRMESSAGE",errMessage));
	}
	return isvalid;
}

function timeCompare(startTime, endTime) {
	var startTime24 = convertTime12to24(startTime);
	var endTime24 = convertTime12to24(endTime);
	let [hoursStart, minutesStart] = startTime24.split(':');
	let [hoursEnd, minutesEnd] = endTime24.split(':');
	if(parseInt(hoursEnd,10) < parseInt(hoursStart,10)){
		return "false";
	} else if(parseInt(hoursEnd,10) == parseInt(hoursStart,10)) {
		if(parseInt(minutesEnd,10) <= parseInt(minutesStart,10)) {
			return "false";
		} else {
			return "true";
		}
	} else {
		return "true";
	}
}

function convertTime12to24(time12h) {
	  const [time, modifier] = time12h.split(' ');

	  let [hours, minutes] = time.split(':');

	  if (hours === '12') {
	    hours = '00';
	  }

	  if (modifier === 'PM') {
	    hours = parseInt(hours, 10) + 12;
	  }

	  return hours + ':' + minutes;
}


function filterDoctorSchedules() {
	getDoctorSchedules();
}

function resetDoctorSchedules() {
	$("#filterLoc").val('-1');
    $("#filterStatus").val('-1');
    $("#filterEPS").val('-1');
    getDoctorSchedules();
}

function addschedulebutton(){
	var currentTime = new Date();
	var starttime = $('#startTime').val().split(":");
	if(starttime[0] < 10)
	{
		starttime[0] = "0" + starttime[0];
	}
	var new_starttime = starttime[0]+":"+starttime[1];
	var startMinutes = starttime[1].split(" ");
	var hours = parseInt(starttime[0]) 
	var minutes =	parseInt(startMinutes[0]);
	var timeType = startMinutes[1];
	console.log(startMinutes[1]);
	if(hours != 12 && timeType == 'PM'){
		hours = hours + 12;
	} else if(hours == 12 && timeType == 'AM'){
		hours = 00;
	}
	
	console.log("hours:"+hours);
	console.log("minutes:"+minutes);
	var startdate = $('#schedulePicker').datepicker('getDate'),
	day  = startdate.getDate(),month = startdate.getMonth(), year =  startdate.getFullYear();
	console.log(startdate);
	var newDateForComp = new Date(year,month,day,hours,minutes,0);
	console.log(newDateForComp);	
	
	let currentTimeINEpoch =  Math.round(currentTime.getTime()/1000);
	let selectedDateInEpoch = Math.round(newDateForComp.getTime()/1000);
	if(currentTimeINEpoch <= selectedDateInEpoch){
		$('#sc-add').show();
	} else {
		$('#sc-add').hide();
	}
}

function disabledays(show){
	if(show){
		$("#enddiv").removeClass("d-none");
	}else{
		$("#enddiv").addClass("d-none");
	}
}