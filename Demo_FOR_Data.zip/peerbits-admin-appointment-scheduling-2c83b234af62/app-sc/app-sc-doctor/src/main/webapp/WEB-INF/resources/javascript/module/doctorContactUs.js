/*function changeSubject(){
	
	console.log("called");
	
	var sendTo = $("#sendto").val();
	console.log(sendTo);
	var baseUrl = $('#contextPathHolder').attr('data-contextPath');
	console.log(baseUrl);
	$.ajax({
	type : "POST",
	url: changeurl,
	data : {
	"sendTo" : sendTo
	},
	dataType : "text",
	success : function(result) {
	}
	});
}*/

function changeSubject() {

			console.log("called");
			var sendTo = $("#usertype").val();
			console.log(sendTo);
			$
					.ajax({
						type : "POST",
						url : subjectchangeUrl,
						data : {
							"sendTo" : sendTo
						},
						dataType : "text",
						success : function(result) {
							console.log(result);
							var data = JSON.parse(result);
							 $.each(data,function(key,val){
								 $("#subject").html("");
								 for (var i = 0; i < val.length; i++) {
								 console.log(val[i].subject);
								 $("#subject").append(
											"<option value="+ val[i].subject +">"
													+ val[i].subject
													+ "</option>");
								 }
							 });
						}
					});
		}