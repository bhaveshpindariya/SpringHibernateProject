$(function(){
	max = parseInt($("#max").val());
	filterResult(true);
});

var start = 0;
var max = 0;
var noApp = $("#noAppointmentMessage").text();

function clearCategoriesFilter(){
	$("#filterForm [type=checkbox]").removeAttr("checked");
}

function clearDateRange(){
	$("#startDate").val('');
	$("#endDate").val('');
}

function clearStatus(){
	$("#statusAll").prop("checked",true);
	$("#pastStatusList [type=radio]").prop("checked", false)
}

function selectChild(ths,categoryId){
	if($(ths).is(":checked")){
		$("[data-parent-id="+categoryId+"]").prop("checked",true);
	}else{
		$("[data-parent-id="+categoryId+"]").removeAttr("checked");
	}
}

function selectParent(ths,categoryId){
	if($(ths).is(":checked")){
		var notChecked = $("[data-parent-id="+categoryId+"]").not(":checked").length;
		if(notChecked <= 0){
			$("[data-category-id="+categoryId+"]").prop("checked",true);
		}
	}else{
		$("[data-category-id="+categoryId+"]").removeAttr("checked");
	}
}

function selectStatus(ths, past){
	if(past){
		$("#pastAll").prop("checked",true);
	}else{
		$("#pastStatusList [type=radio]").prop("checked", false)
	}
}

function selectPastStatus(ths){
	$("#pastStatus").prop("checked",true);
}

function changeOrder(asc){
	if(asc){
		$("#appointmentOrder").val("true");
		$("#appointmentOrderIcon").addClass("fa-sort-amount-asc");
		$("#appointmentOrderIcon").removeClass("fa-sort-amount-desc");
	}else{
		var ascending = $("#appointmentOrder").val();
		if(ascending === "true"){
			$("#appointmentOrder").val("false");
			$("#appointmentOrderIcon").removeClass("fa-sort-amount-asc");
			$("#appointmentOrderIcon").addClass("fa-sort-amount-desc");
		}else{
			$("#appointmentOrder").val("true");
			$("#appointmentOrderIcon").addClass("fa-sort-amount-asc");
			$("#appointmentOrderIcon").removeClass("fa-sort-amount-desc");
		}		
	}
	getFilteredAppointments();
}

function resetFilter(){
	clearCategoriesFilter();
	clearDateRange();
	clearStatus();
	changeOrder(true);
	$("#searchAppointments").val('');
}

function filterResult(clear){
	if(clear){
		resetFilter();
	}
	start = 0;
	$("#start").val(start);
	getFilteredAppointments();
}

function getFilteredAppointments(){
	var appointmentFilterURL = baseUrl.concat("/dashboard/filterAppointments");
	var data = $("#filterForm").serialize();
	startLoader("tab-content")
	$.ajax({
		url:appointmentFilterURL,
		data:data,
		success:function(rdata){
			var data = JSON.parse(rdata);
			var total = data.total;
			var items = data.items;
			console.log(total);
			console.log(items);
			processAppointments(items);
			updateButtons(total);
			stopLoader("tab-content");
		},error:function(){
			stopLoader("tab-content");
			console.error("service is unavailable");
		}
	});
}

function processAppointments(items){
	$("#appointmentList").html('');
	if(items.length <=0 ){
		$("#appointmentList").append(noApp);
	}
	items.forEach(function(currentValue, index, arr){
		var appointmentTemplate = $("#appointmentTemplate").html();
		var userImage = '<img class="rounded-circle mr-3" src="'+baseUrl+currentValue.userProfileImg+'" width="40px">';
		appointmentTemplate = replaceAll(appointmentTemplate, "RAW_INDEX", currentValue.appointmentsId);
		appointmentTemplate = replaceAll(appointmentTemplate, "USER_IMAGE", userImage);
		appointmentTemplate = replaceAll(appointmentTemplate, "USER_NAME", currentValue.userName);
		appointmentTemplate = replaceAll(appointmentTemplate, "CATEGORY_NAME", currentValue.categoryName);
		appointmentTemplate = replaceAll(appointmentTemplate, "APPOINTMENT_DATE", currentValue.appointmentDate);
		appointmentTemplate = replaceAll(appointmentTemplate, "TIME_SLOT", currentValue.timeSlot);
		appointmentTemplate = replaceAll(appointmentTemplate, "LOCATION", currentValue.location);
		appointmentTemplate = replaceAll(appointmentTemplate, "HAS_DOCS", currentValue.hasDocs);
		appointmentTemplate = replaceAll(appointmentTemplate, "AMOUNT", currentValue.cost);
		appointmentTemplate = replaceAll(appointmentTemplate, "STATUS_BUTTONS", currentValue.status);
		if(currentValue.cancellable){
			var cancelTemplate = $("#cancelButtonTemplate").html();
			cancelTemplate = replaceAll(cancelTemplate, "RAW_INDEX", currentValue.appointmentsId);
			appointmentTemplate = replaceAll(appointmentTemplate, "CANCEL_BUTTON", cancelTemplate);
		}else{
			appointmentTemplate = replaceAll(appointmentTemplate, "CANCEL_BUTTON", "");
		}
		appointmentTemplate = replaceAll(appointmentTemplate, "LEGAL_DOCS", getAppointmentsFiles(currentValue.files));
		$("#appointmentList").append(appointmentTemplate);
	});
}

function getAppointmentsFiles(items){
	var filePath = "";
	items.forEach(function(currentValue, index, arr){
		filePath+= '<a target="_blank" href="'+baseUrl+currentValue.filePath+'"><img class="mr-3" src="'+baseUrl+currentValue.displayPath+'" width="60px"></a>';
	});
	return filePath;
}

function updateButtons(total){
	var nextStart = start+max;
	
	if(nextStart > max){
		$(".btn-previous").removeClass("d-none")
	}else{
		$(".btn-previous").addClass("d-none")
	}
	
	if(nextStart < total){
		$(".btn-next").removeClass("d-none")
	}else{
		$(".btn-next").addClass("d-none")
	}
}

function nextItems(next){
	if(next){
		start+=max;
	}else{
		start-=max;
	}
	$("#start").val(start);
	getFilteredAppointments();
}

function cancelAppointment(appointmentId){
	$("#appointmentsIdReject").val(appointmentId);
	$("#cancelAppointmentModal").modal("show");
}

function validateReason(){
	var cancellationReason = $("#cancellationReason").val();
	if(cancellationReason === "-1"){
		$("#customReasonInput").attr("required","required");
		$("#customReason").removeClass("d-none");
	}else{
		$("#customReasonInput").removeAttr("required");
		$("#customReason").addClass("d-none");
	}
}