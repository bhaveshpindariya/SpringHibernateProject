package com.peer.doctor.controller;

import java.text.ParseException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.peer.constant.CommonConstants;
import com.peer.doctor.constants.DoctorConstants;
import com.peer.enm.Action;
import com.peer.enm.Status;
import com.peer.enm.UserType;
import com.peer.scenity.entity.local.Appointments;
import com.peer.scenity.entity.local.Cancellation;
import com.peer.scenity.entity.local.Schedule;
import com.peer.scenity.entity.local.ScheduleSlot;
import com.peer.scenity.entity.local.User;
import com.peer.scenity.entity.pojo.CategoryDTO;
import com.peer.scenity.entity.pojo.DashboardDTO;
import com.peer.scenity.entity.pojo.NotificationDTO;
import com.peer.scenity.entity.pojo.Response;
import com.peer.scenity.entity.zeus.ProgramacionMedico;
import com.peer.scenity.entity.zeus.PuntoAtencion;
import com.peer.scenity.service.intf.IAppointmentsService;
import com.peer.scenity.service.intf.ICancellationService;
import com.peer.scenity.service.intf.IEpsService;
import com.peer.scenity.service.intf.ILocationService;
import com.peer.scenity.service.intf.INotificationsService;
import com.peer.scenity.service.intf.IScheduleService;
import com.peer.scenity.service.intf.IScheduleSlotService;
import com.peer.scenity.service.intf.ISettingsService;
import com.peer.scenity.service.intf.MessageByLocaleService;
import com.peer.scenity.service.intf.ProgrammacionMedicoDetalleService;
import com.peer.scenity.service.intf.ZeusProgrammacionMedicoService;
import com.peer.scenity.service.intf.ZeusPuntoAtencionService;
import com.peer.scenity.util.ServiceUtils;
import com.peer.scenity.util.SessionUtil;
import com.peer.util.CommonUtil;
import com.peer.util.DateUtil;

@Controller
@RequestMapping(DoctorConstants.DASHBOARD_CONTROLLER)
public class DashboardController {

	private static Logger _log = Logger.getLogger(DashboardController.class);

	private static final String DASHBOARD_PAGE = "home/dashboard";
	private static final String SCHEDULES_PAGE = "home/schedules";
	private static final String APPOINTMENT_PAGE = "home/appointment";

	@Autowired
	private ILocationService locationService;

	@Autowired
	private IScheduleService scheduleService;

	@Autowired
	private IScheduleSlotService scheduleSlotService;

	@Autowired
	private MessageByLocaleService messageByLocaleService;

	@Autowired
	private ZeusProgrammacionMedicoService programmacionService;

	@Autowired
	private ICancellationService cancellationService;

	@Autowired
	private IAppointmentsService appointmentService;

	@Autowired
	private IEpsService epsService;

	@Autowired
	private INotificationsService notificationService;

	@Autowired
	private ISettingsService settingService;

	@Autowired
	private MessageByLocaleService messageService;

	@Autowired
	private ProgrammacionMedicoDetalleService programmacionMedicoDetalleService;

	@Autowired
	private ZeusPuntoAtencionService zeusPuntoAtencionService;

	@RequestMapping(DoctorConstants.DASHBOARD_INDEX)
	public String dashboardIndex(Model model, HttpServletRequest request) {
		User doctor = SessionUtil.getUserFromRequestSession(request);

		DashboardDTO dashboardDTO = appointmentService.getDoctorDashboard(doctor);
		List<NotificationDTO> notificationList = notificationService.fetchRecentNotifications(doctor.getUserId(),
				CommonConstants.MAX_NOTIFICATIONS);

		model.addAttribute("dashboardDTO", dashboardDTO);
		model.addAttribute("notificationList", notificationList);
		request.setAttribute(CommonConstants.ACTIVE_TAB, CommonConstants.DASHBOARD_TAB);
		return DASHBOARD_PAGE;
	}

	@RequestMapping("/getAppointments")
	@ResponseBody
	public ResponseEntity<Object> getAppointments(HttpServletRequest request) {
		User doctor = SessionUtil.getUserFromRequestSession(request);
		String date = request.getParameter("appointmentDate");
		Date appointmentDate = StringUtils.isNotBlank(date) ? DateUtil.parseDate(date, DateUtil.DD_MM_YYYY) : null;
		List<Status> statusList = ServiceUtils.getStatusList(Status.APPROVED);
		JSONArray jsonArray = appointmentService.findDoctorsAppointments(doctor.getUserId(), statusList,
				appointmentDate, 0, -1);
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("date", date);
		jsonObject.put("dateFormatted", DateUtil.formateDate(appointmentDate, DateUtil.MMM_DD_YYYY));
		jsonObject.put("items", jsonArray);
		return new ResponseEntity<>(jsonObject.toString(), HttpStatus.OK);
	}

	@RequestMapping("/schedules")
	public String schedules(Locale locale, Model model, HttpServletRequest request,
			RedirectAttributes redirectAttributes) {
		model.addAttribute("locations", locationService.findAllLocal());
		model.addAttribute("alleps", epsService.findAllLocalActive());
		request.setAttribute(CommonConstants.ACTIVE_TAB, CommonConstants.SCHEDULES_TAB);
		return SCHEDULES_PAGE;
	}

	@RequestMapping("/appointment")
	public String appointment(Model model, HttpServletRequest request) {
		User doctor = SessionUtil.getUserFromRequestSession(request);
		appointmentService.processPastAppointments(0L, doctor.getUserId());
		List<CategoryDTO> categoryDTOList = appointmentService.findUpcomingAppointmentCategories(request, 0L,
				doctor.getUserId());
		List<Cancellation> cancellationList = cancellationService.findByUserType(UserType.Doctor);
		model.addAttribute("cancellationList", cancellationList);
		model.addAttribute("categoryDTOList", categoryDTOList);
		request.setAttribute(CommonConstants.ACTIVE_TAB, CommonConstants.APPOINTMENT_TAB);
		return APPOINTMENT_PAGE;
	}

	@RequestMapping("/cancelAppointment")
	public String cancelAppointment(Model model, HttpServletRequest request, RedirectAttributes redirectAttributes) {
		boolean isCancellable = true;
		User currentUser = SessionUtil.getUserFromRequestSession(request);
		Long appointmentsId = CommonUtil.getLongValue(request, "appointmentsId");
		int statusCode = CommonUtil.getIntValue(request, "status");
		String reason = request.getParameter("cancellationReason");
		if (StringUtils.isNotBlank(reason) && "-1".equals(reason)) {
			reason = request.getParameter("customReason");
		}
		try {
			Status status = Status.parse(statusCode);
			Appointments appointments = appointmentService.findByIdLocal(appointmentsId);
			isCancellable = settingService.isAppointmentCancellable(appointments.getAppointmentDate(),
					appointments.getAppointmentTime(), appointments.getMedian());
			if (isCancellable) {
				appointmentService.rejectRequest(currentUser, appointmentsId, reason, status);
				redirectAttributes.addFlashAttribute("message", messageService.getMessage("cancel.requested"));
			} else {
				redirectAttributes.addFlashAttribute("message",
						messageService.getMessage(CommonConstants.CANCELLATION_TIME_ERROR));
			}
		} catch (Exception e) {
			_log.error("", e);
			redirectAttributes.addFlashAttribute("error", CommonConstants.ERROR);
		}
		return "redirect:/dashboard/appointment";
	}

	@RequestMapping("/filterAppointments")
	@ResponseBody
	public ResponseEntity<Object> filterAppointments(HttpServletRequest request) {
		User doctor = SessionUtil.getUserFromRequestSession(request);
		int start = CommonUtil.getIntValue(request, "start");
		int max = CommonUtil.getIntValue(request, "max");
		int statusValue = CommonUtil.getIntValue(request, "status");
		int pastStatusValue = CommonUtil.getIntValue(request, "pastStatus");

		String search = request.getParameter("search");
		boolean asc = CommonUtil.getBooleanValue(request, "asc");
		String[] categoryIds = request.getParameterValues("categoryId");
		String[] subCategoryIds = request.getParameterValues("subCategoryId");
		Set<Long> categorySet = ServiceUtils.getLongSetFromArray(categoryIds);
		Set<Long> childCategorySet = ServiceUtils.getLongSetFromArray(subCategoryIds);
		Date startDate = CommonUtil.getDateValue(request, "startDate", DateUtil.DD_MM_YYYY);
		Date endDate = CommonUtil.getDateValue(request, "endDate", DateUtil.DD_MM_YYYY);
		Date currentSlotTime = null;
		List<Status> statusList = ServiceUtils.getDoctorFilterStatus(statusValue, pastStatusValue);
		if (statusValue == -2) {
			currentSlotTime = new Date();
		}

		JSONArray jsonArray = appointmentService.findDoctorsAppointments(doctor.getUserId(), statusList, categorySet,
				childCategorySet, startDate, endDate, currentSlotTime, search, asc, start, max);

		Long count = appointmentService.filterDoctorsAppointmentsCount(doctor.getUserId(), statusList, categorySet,
				childCategorySet, startDate, endDate, currentSlotTime, search);

		JSONObject jsonObject = new JSONObject();
		jsonObject.put("items", jsonArray);
		jsonObject.put("total", count);
		return new ResponseEntity<>(jsonObject.toString(), HttpStatus.OK);
	}

	@RequestMapping("/scheduleadd")
	public String scheduleSuccess(HttpServletRequest request, RedirectAttributes redirectAttributes) {
		if (request.getParameter("message") != null) {
			redirectAttributes.addFlashAttribute("success", request.getParameter("message"));
		}
		return "redirect:" + DoctorConstants.DASHBOARD_CONTROLLER + "/schedules";
	}

	@RequestMapping("/getSchedules")
	@ResponseBody
	public ResponseEntity<Object> getDoctorSchedules(HttpServletRequest request) throws ParseException {
		String dateStr = request.getParameter("filterDate");
		long location = Long.parseLong(request.getParameter("filterLocation"));
		int status = Integer.parseInt(request.getParameter("filterStatus"));
		long eps = Long.parseLong(request.getParameter("filterEps"));
		Date scheduleDate = new Date();
		List<Schedule> returnSc = new ArrayList<>();
		if (dateStr != null && !dateStr.equals("")) {
			LocalDate date = LocalDate.parse(dateStr, CommonConstants.FORMATTERA);
			scheduleDate = Date.from(date.atStartOfDay().atZone(ZoneId.systemDefault()).toInstant());
		}
		User loggedInDoctor = SessionUtil.getUserFromRequestSession(request);
		if (location > 0 || status > 0 || eps > 0) {
			returnSc = scheduleService.filterAllDoctorSchedulesForDate(loggedInDoctor.getUserId(), scheduleDate,
					location, eps, status);
		} else {
			returnSc = scheduleService.getAllDoctorSchedulesForDate(loggedInDoctor.getUserId(), scheduleDate);

		}
		JSONArray returnArr = scheduleService.getArrayFromListWithDoctorActionBtns(returnSc);
		return new ResponseEntity<>(returnArr != null ? returnArr.toString() : "", HttpStatus.OK);
	}

	@RequestMapping(DoctorConstants.DASHBOARD_ADD_SCHDEULE)
	@ResponseBody
	public ResponseEntity<Object> addSchedule(HttpServletRequest request) {
		Schedule schedule = null;
		User doctor = SessionUtil.getUserFromRequestSession(request);
		Response response = null;
		if (doctor != null) {
			schedule = new Schedule();
			try {
				String startDateStr = request.getParameter("startdate");
				LocalDate startDate = LocalDate.parse(startDateStr, CommonConstants.FORMATTERA);
				String startTime = request.getParameter("startTime");
				String endTime = request.getParameter("endTime");
				long locationId = Long.parseLong(request.getParameter("location"));
				String isCopy = request.getParameter("iscopy");
				schedule.setDoctor(doctor);
				schedule.setStartDate(Date.from(startDate.atStartOfDay().atZone(ZoneId.systemDefault()).toInstant()));
				schedule.setEndDate(Date.from(startDate.atStartOfDay().atZone(ZoneId.systemDefault()).toInstant()));
				schedule.setStartTime(startTime);
				schedule.setEndTime(endTime);
				schedule.setLocation(locationService.findByIdLocal(locationId));

				if (null != isCopy && (isCopy.equalsIgnoreCase(CommonConstants.YES))) {
					String[] copyDays = request.getParameterValues("q1");
					String repeatDays = Arrays.toString(copyDays);
					String endDateStr = request.getParameter("endDate");
					LocalDate endDate = LocalDate.parse(endDateStr, CommonConstants.FORMATTER);

					schedule.setRepeatDays(repeatDays);
					schedule.setEndDate(Date.from(endDate.atStartOfDay().atZone(ZoneId.systemDefault()).toInstant()));
				}

				schedule.setCreatedBy(doctor);
				schedule.setCreatedOn(new Date());
				schedule.setUpdatedBy(doctor);
				schedule.setUpdatedOn(new Date());
				schedule.setStatus(Status.AWAITING_APPROVAL);
				response = scheduleValidator(schedule);
				if (response.getStatus().equals(CommonConstants.SUCCESS)) {
					schedule = scheduleService.persistLocal(schedule);
					response = setMessage(CommonConstants.SUCCESS, DoctorConstants.SCHEDULE_ADD_SUCCESS);
				}
			} catch (Exception e) {
				_log.error("Error Adding Schedule :--", e);
				response = setMessage(CommonConstants.ERROR, DoctorConstants.SCHEDULE_ADD_ERROR);
			}
		} else {
			response = setMessage(CommonConstants.ERROR, "not login");
		}

		if (schedule != null && schedule.getScheduleId() != null
				&& response.getStatus().equals(CommonConstants.SUCCESS))
			scheduleService.sendNotification(schedule, Action.NEW_REQUEST);

		JSONObject jsonObject = new JSONObject();
		jsonObject.put("status", response.getStatus());
		jsonObject.put("message", response.getMessage());
		return new ResponseEntity<>(jsonObject.toString(), HttpStatus.OK);
	}

	private Response setMessage(String type, String message) {
		Response response = new Response();
		response.setStatus(type);
		response.setMessage(messageByLocaleService.getMessage(message));
		return response;
	}

	private Response scheduleValidator(Schedule schedule) {
		Response response = new Response(CommonConstants.SUCCESS, CommonConstants.SUCCESS);
		Date startDate = schedule.getStartDate();
		Date endDate = schedule.getEndDate();
		String startTime = schedule.getStartTime();
		String endTime = schedule.getEndTime();

		// If days range is selected i.e., schedule copied for other days
		if (schedule.getRepeatDays() != null && !schedule.getRepeatDays().trim().equals(CommonConstants.BLANK)) {
			if (endDate.equals(startDate) || endDate.before(startDate)) {
				response = setMessage(CommonConstants.ERROR, DoctorConstants.SCHEDULE_DATE_RANGE_ERROR);
			}
			if (endDate.after(startDate)) {
				LocalDate startDateLocal = LocalDate.parse(CommonConstants.FORMAT1.format(startDate),
						CommonConstants.FORMATTER1);
				LocalDate endDateLocal = LocalDate.parse(CommonConstants.FORMAT1.format(endDate),
						CommonConstants.FORMATTER1);

				long numOfDaysBetween = ChronoUnit.DAYS.between(startDateLocal, endDateLocal);
				List<LocalDate> lstDates = IntStream.iterate(0, i -> i + 1).limit(numOfDaysBetween + 1)
						.mapToObj(i -> startDateLocal.plusDays(i)).collect(Collectors.toList());
				try {
					for (LocalDate localDate : lstDates) {
						String startDateTimeStr = localDate.toString() + CommonConstants.SPACE + startTime;
						String startDateTimeFormatted = LocalDateTime
								.parse(startDateTimeStr, CommonConstants.FORMATTER2).format(CommonConstants.FORMATTER1);
						Date startDateTime = CommonConstants.FORMAT1.parse(startDateTimeFormatted);

						String endDateTimeStr = localDate.toString() + CommonConstants.SPACE + endTime;
						String endDateTimeFormatted = LocalDateTime.parse(endDateTimeStr, CommonConstants.FORMATTER2)
								.format(CommonConstants.FORMATTER1);
						Date endDateTime = CommonConstants.FORMAT1.parse(endDateTimeFormatted);

						List<ScheduleSlot> slots = null;

						if (schedule.getScheduleId() != null && !Objects.isNull(schedule.getScheduleId())) {
							slots = scheduleSlotService.findByDateTimeScheduleId(startDateTime, endDateTime,
									schedule.getDoctor().getUserId(), schedule.getScheduleId());
						} else {
							slots = scheduleSlotService.findByDateTime(startDateTime, endDateTime,
									schedule.getDoctor().getUserId());
						}
						if (!slots.isEmpty()) {
							response = setMessage(CommonConstants.ERROR, DoctorConstants.SCHEDULE_SLOT_TIME_COFLICT);
							break;
						}
					}
				} catch (Exception e) {
					_log.error("Error validating Schedule: ", e);
					response = setMessage(CommonConstants.ERROR, DoctorConstants.SCHEDULE_ADD_ERROR);
				}
			}
		}
		// If single day schedule selected to be added
		else {
			try {
				LocalDate startDateLocal = LocalDate.parse(CommonConstants.FORMAT1.format(startDate),
						CommonConstants.FORMATTER1);

				String startDateTimeStr = startDateLocal.toString() + CommonConstants.SPACE + startTime;
				String startDateTimeFormatted = LocalDateTime.parse(startDateTimeStr, CommonConstants.FORMATTER2)
						.format(CommonConstants.FORMATTER1);
				Date startDateTime = CommonConstants.FORMAT1.parse(startDateTimeFormatted);

				String endDateTimeStr = startDateLocal.toString() + CommonConstants.SPACE + endTime;
				String endDateTimeFormatted = LocalDateTime.parse(endDateTimeStr, CommonConstants.FORMATTER2)
						.format(CommonConstants.FORMATTER1);
				Date endDateTime = CommonConstants.FORMAT1.parse(endDateTimeFormatted);

				List<ScheduleSlot> slots = null;
				if (schedule.getScheduleId() != null && !Objects.isNull(schedule.getScheduleId())) {
					slots = scheduleSlotService.findByDateTimeScheduleId(startDateTime, endDateTime,
							schedule.getDoctor().getUserId(), schedule.getScheduleId());
				} else {
					slots = scheduleSlotService.findByDateTime(startDateTime, endDateTime,
							schedule.getDoctor().getUserId());
				}
				if (!slots.isEmpty()) {
					response = setMessage(CommonConstants.ERROR, DoctorConstants.SCHEDULE_SLOT_TIME_COFLICT);
				}
			} catch (ParseException e) {
				_log.error("Error validating Schedule: ", e);
				response = setMessage(CommonConstants.ERROR, DoctorConstants.SCHEDULE_ADD_ERROR);
			}
		}
		return response;
	}

	@RequestMapping("/cancelSchedule")
	public String cancelSchedule(HttpServletRequest request, RedirectAttributes redirectAttributes) {
		Response response = null;
		long scheduleId = Long.parseLong(request.getParameter("docCancelSchId"));
		String cancelReason = request.getParameter("docCancelReason");
		if (!Objects.isNull(cancelReason) && cancelReason.equals("other")) {
			cancelReason = request.getParameter("reasonOtherModal");
		}
		Schedule schedule = scheduleService.findByIdLocal(scheduleId);
		if (schedule.getStatus().equals(Status.AWAITING_APPROVAL)) {
			schedule.setCancelReason(cancelReason);
			schedule.setStatus(Status.CANCELLED);
			schedule.setUpdatedBy(SessionUtil.getUserFromRequestSession(request));
			schedule.setUpdatedOn(new Date());
			scheduleService.mergeLocal(schedule);
			response = setMessage(CommonConstants.SUCCESS, DoctorConstants.SCHEDULE_MODIFICATION_REQ_CANEL_SUCCESS);
		} else if (schedule.getStatus().equals(Status.AWAITING_MODIFICATION_APPROVAL)
				|| schedule.getStatus().equals(Status.AWAITING_CANCELLATION_APPROVAL)) {
			scheduleService.removeChildSchedule(scheduleId);
			schedule.setCancelReason(cancelReason);
			schedule.setStatus(Status.ACTIVE);
			schedule.setUpdatedBy(SessionUtil.getUserFromRequestSession(request));
			schedule.setUpdatedOn(new Date());
			scheduleService.mergeLocal(schedule);
			response = setMessage(CommonConstants.SUCCESS, DoctorConstants.SCHEDULE_MODIFICATION_REQ_CANEL_SUCCESS);
		} else if (schedule.getStatus().equals(Status.ACTIVE)) {
			long appointmentCount = appointmentService.findScheduleAppointmentCount(Status.APPROVED, scheduleId);
			if (appointmentCount > 0) {
				schedule.setCancelReason(cancelReason);
				schedule.setStatus(Status.AWAITING_CANCELLATION_APPROVAL);
				schedule.setUpdatedBy(SessionUtil.getUserFromRequestSession(request));
				schedule.setUpdatedOn(new Date());
				createCancelScheduleChildEntry(schedule, request);
				schedule = scheduleService.mergeLocal(schedule);
				response = setMessage(CommonConstants.SUCCESS, DoctorConstants.SCHEUDULE_CANCEL_ADMIN_REQ);
				if (Objects.nonNull(schedule) && schedule.getScheduleId() != null)
					scheduleService.sendNotification(schedule, Action.CANCEL_REQUESTED);
			} else {
				schedule.setCancelReason(cancelReason);
				schedule.setStatus(Status.CANCELLED);
				schedule.setUpdatedBy(SessionUtil.getUserFromRequestSession(request));
				schedule.setUpdatedOn(new Date());
				schedule = scheduleService.mergeLocal(schedule);
				ProgramacionMedico zeusSchedule = programmacionService.findByIdZeus(schedule.getZeusScheduleId());
				zeusSchedule.setActivo(false);
				programmacionService.deleteZeus(zeusSchedule);
				programmacionMedicoDetalleService.deleteDetalle(schedule.getZeusScheduleId());
				scheduleSlotService.deleteAllSlotsFromDB(scheduleId);
				response = setMessage(CommonConstants.SUCCESS, DoctorConstants.SCHEDULE_CANCEL_SUCCESS);
			}
		} else {
			response = setMessage(CommonConstants.SUCCESS, DoctorConstants.SCHEDULE_CANCEL_CONFLICT);
		}
		redirectAttributes.addFlashAttribute(response.getStatus(), response.getMessage());
		return "redirect:" + DoctorConstants.DASHBOARD_CONTROLLER + "/schedules";
	}

	@RequestMapping("/modifySchedule")
	public String modifySchedule(HttpServletRequest request, RedirectAttributes redirectAttributes) {
		Response response = null;
		long scheduleId = Long.parseLong(request.getParameter("docModifySchId"));
		String docStimeModal = request.getParameter("docStimeModal");
		String docEtimeModal = request.getParameter("docEtimeModal");
		long docLocationModalId = Long.parseLong(request.getParameter("docLocationModal"));
		Schedule schedule = scheduleService.findByIdLocal(scheduleId);
		Status currentStatus = schedule.getStatus();

		if (currentStatus.equals(Status.CANCELLED) || currentStatus.equals(Status.AWAITING_MODIFICATION_APPROVAL)) {
			response = setMessage(CommonConstants.ERROR, "Schedule cannot be modified");
		} else if (currentStatus.equals(Status.AWAITING_APPROVAL)) {
			schedule.setStartTime(docStimeModal);
			schedule.setEndTime(docEtimeModal);
			schedule.setLocation(locationService.findByIdLocal(docLocationModalId));
			schedule.setUpdatedBy(SessionUtil.getUserFromRequestSession(request));
			schedule.setUpdatedOn(new Date());
			schedule = scheduleService.mergeLocal(schedule);
			response = setMessage(CommonConstants.SUCCESS, DoctorConstants.SCHEDULE_REQ_MODIFY_SUCCESS);
			scheduleService.sendNotification(schedule, Action.MODIFICATION_REQUESTED);
		} else if (currentStatus.equals(Status.AWAITING_CANCELLATION_APPROVAL)) {
			scheduleService.removeChildSchedule(scheduleId);
			schedule.setStatus(Status.AWAITING_MODIFICATION_APPROVAL);
			schedule.setUpdatedBy(SessionUtil.getUserFromRequestSession(request));
			schedule.setUpdatedOn(new Date());
			schedule = scheduleService.mergeLocal(schedule);
			schedule.setStartTime(docStimeModal);
			schedule.setEndTime(docEtimeModal);
			schedule.setLocation(locationService.findByIdLocal(docLocationModalId));
			createModifyScheduleChildEntry(schedule, request);
			response = setMessage(CommonConstants.SUCCESS, DoctorConstants.SCHEDULE_REQ_MODIFY_SUCCESS);
			scheduleService.sendNotification(schedule, Action.MODIFICATION_REQUESTED);
		} else if (currentStatus.equals(Status.ACTIVE)) {
			long appointmentCount = appointmentService.findScheduleAppointmentCount(Status.APPROVED, scheduleId);
			if (appointmentCount > 0) {
				schedule.setStatus(Status.AWAITING_MODIFICATION_APPROVAL);
				schedule.setUpdatedBy(SessionUtil.getUserFromRequestSession(request));
				schedule.setUpdatedOn(new Date());
				schedule = scheduleService.mergeLocal(schedule);
				schedule.setStartTime(docStimeModal);
				schedule.setEndTime(docEtimeModal);
				schedule.setLocation(locationService.findByIdLocal(docLocationModalId));
				createModifyScheduleChildEntry(schedule, request);
				response = setMessage(CommonConstants.SUCCESS, DoctorConstants.SCHEUDULE_MODIFY_ADMIN_REQ);
				scheduleService.sendNotification(schedule, Action.MODIFICATION_REQUESTED);
			} else {
				schedule.setStartTime(docStimeModal);
				schedule.setEndTime(docEtimeModal);
				schedule.setLocation(locationService.findByIdLocal(docLocationModalId));
				Response responseValidate = scheduleValidator(schedule);
				if (responseValidate.getStatus().equals(CommonConstants.ERROR)) {
					response = responseValidate;
				} else {
					try {
						scheduleSlotService.deleteAllSlotsFromDB(schedule.getScheduleId());
						response = scheduleSlotService.addScheduleSlots(schedule, schedule.getZeusScheduleId());
						if (response.getStatus().equals(CommonConstants.SUCCESS)) {
							programmacionMedicoDetalleService.deleteDetalle(schedule.getZeusScheduleId());
							updateZeus(schedule);
							schedule.setUpdatedBy(SessionUtil.getUserFromRequestSession(request));
							schedule.setUpdatedOn(new Date());
							scheduleService.mergeLocal(schedule);
							response = setMessage(CommonConstants.SUCCESS, DoctorConstants.SCHEDULE_MODIFY_SUCCESS);
						}
					} catch (Exception e) {
						e.printStackTrace();
						response = setMessage(CommonConstants.ERROR, DoctorConstants.SCHEUDULE_MODIFY_ERROR);
					}
				}
			}
		}

		redirectAttributes.addFlashAttribute(response.getStatus(), response.getMessage());
		return "redirect:" + DoctorConstants.DASHBOARD_CONTROLLER + "/schedules";
	}

	@RequestMapping("/getCancelreasons")
	@ResponseBody
	public ResponseEntity<Object> getCancellationReasons(HttpServletRequest request) {
		_log.info("cancellation reasons length: " + cancellationService.findAllLocalActive());
		List<Cancellation> list = cancellationService.findByUserType(UserType.Doctor);
		return new ResponseEntity<>(cancellationService.getArray(list).toString(), HttpStatus.OK);
	}

	@RequestMapping("/getChildSchedule")
	@ResponseBody
	public ResponseEntity<Object> getChildSchedule(HttpServletRequest request) {
		long parentScheduleId = Long.parseLong(request.getParameter("parentSchId"));
		Schedule childSchedule = scheduleService.getChildSchedule(parentScheduleId);
		return new ResponseEntity<>(scheduleService.getObjectFromSchedule(childSchedule, false, false).toString(),
				HttpStatus.OK);
	}

	@RequestMapping("/getLocations")
	@ResponseBody
	public ResponseEntity<Object> getLocations(HttpServletRequest request) {
		return new ResponseEntity<>(locationService.getArrayFromList(locationService.findAllLocal()).toString(),
				HttpStatus.OK);
	}

	private void createCancelScheduleChildEntry(Schedule sc, HttpServletRequest request) {
		Schedule childSchedule = new Schedule(sc);
		childSchedule.setCreatedBy(SessionUtil.getUserFromRequestSession(request));
		childSchedule.setCreatedOn(new Date());
		childSchedule.setUpdatedBy(SessionUtil.getUserFromRequestSession(request));
		childSchedule.setUpdatedOn(new Date());
		childSchedule.setParentScheduleId(sc);
		childSchedule.setStatus(Status.AWAITING_CANCELLATION_APPROVAL);
		scheduleService.persistLocal(childSchedule);
	}

	private void createModifyScheduleChildEntry(Schedule sc, HttpServletRequest request) {
		Schedule childSchedule = new Schedule(sc);
		childSchedule.setCreatedBy(SessionUtil.getUserFromRequestSession(request));
		childSchedule.setCreatedOn(new Date());
		childSchedule.setUpdatedBy(SessionUtil.getUserFromRequestSession(request));
		childSchedule.setUpdatedOn(new Date());
		childSchedule.setParentScheduleId(sc);
		childSchedule.setStatus(Status.AWAITING_MODIFICATION_APPROVAL);
		scheduleService.persistLocal(childSchedule);
	}

	private void updateZeus(Schedule schedule) {
		String startTime = schedule.getStartTime();
		String endTime = schedule.getEndTime();
		ProgramacionMedico programacion = programmacionService.findByIdZeus(schedule.getZeusScheduleId());
		programacion.setHorainicio(startTime.split(" ")[0]);
		programacion.setMeridianoi(startTime.split(" ")[1]);
		programacion.setHorafinal(endTime.split(" ")[0]);
		programacion.setMeridianof(endTime.split(" ")[1]);
		long locationId = schedule.getLocation().getZuesLocationId();
		PuntoAtencion puntoAtencion = zeusPuntoAtencionService.findByIdZeus(locationId);
		programacion.setId_sede(puntoAtencion.getId());
		programacion.setActivo(true);
		programmacionService.mergeZeus(programacion);
	}
}
