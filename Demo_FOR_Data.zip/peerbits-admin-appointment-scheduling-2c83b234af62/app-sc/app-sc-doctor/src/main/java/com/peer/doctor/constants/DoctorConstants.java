package com.peer.doctor.constants;

public class DoctorConstants {

	private DoctorConstants() {
	}

	// Login & Logout
	public static final String LOGIN_USER = "/validate";
	public static final String LOGOUT_USER = "/logout";
	public static final String FORGOT_PASSWORD = "/login/forgotpassword";
	public static final String RESET_PASSWORD = "/login/resetpassword";
	public static final String NEW_PASSWORD = "/login/update-password";
	public static final String NEWUPDATEPASSWORD = "/login/updatepassword";
	

	public static final String TAB_DASHBOARD = "tab1";
	public static final String TAB_MANAGE_SCHEDULE = "tab2";
	public static final String TAB_MANAGE_APPOINTMENTS = "tab3";

	public static final String DASHBOARD_CONTROLLER = "/dashboard";

	public static final String DASHBOARD_INDEX = "/index";
	public static final String DASHBOARD_ADD_SCHDEULE = "/add-schedule";

	public static final String SCHEDULE_ADD_SUCCESS = "schedule.add.success";
	public static final String SCHEDULE_ADD_ERROR = "schedule.add.error";
	public static final String SCHEDULE_DATE_ERROR = "schedule.date.error";
	public static final String SCHEDULE_SLOT_ADD_SUCCESS = "scheduleslot.add.success";
	public static final String SCHEDULE_SLOT_ADD_ERROR = "scheduleslot.add.error";
	public static final String SCHEDULE_DATE_RANGE_ERROR = "scheduleslot.error.daterange";
	public static final String SCHEDULE_SLOT_TIME_COFLICT = "scheduleslot.conflict.time";
	public static final String SCHEDULE_CANCEL_SUCCESS="schedule.cancel.success";
	public static final String SCHEDULE_CANCEL_CONFLICT="schedule.cancel.already.cancelled";
	public static final String SCHEDULE_MODIFICATION_REQ_CANEL_SUCCESS="schedule.modification.request.cancel.success";
	public static final String SCHEDULE_APPROVE_PREVDATES_ERROR = "schedule.approve.previousdates.error";
	public static final String SCHEUDULE_CANCEL_ADMIN_REQ="schedule.cancel.admin.request.success";
	public static final String SCHEUDULE_CANCEL_ERROR="schedule.cancel.issue";
	public static final String SCHEDULE_MODIFY_SUCCESS="schedule.modify.success";
	public static final String SCHEDULE_REQ_MODIFY_SUCCESS="schedule.request.modify.success";
	public static final String SCHEUDULE_MODIFY_ADMIN_REQ="schedule.modify.admin.request.success";
	public static final String SCHEUDULE_MODIFY_ERROR="schedule.modify.issue";

	// CONTACT US
	public static final String CONTACTUS_CONTROLLER = "/contact";
	public static final String VIEW_DOCTOR_CONTACTUS_MAPPING = "/contactForm";
	public static final String SEND_DOCTOR_CONTACTUS = "/sendmail";
	public static final String CHANGE_SUBJECT = "/changeSubject";

	public static final String DOCTORCONTACT_SUCCESS = "doctorcontact.success";
	public static final String DOCTORCONTACT_EXIT = "doctorcontact.exit";
	public static final String DOCTORCONTACT_ERROR = "doctorcontact.error";
	public static final String DOCTORCONTACT_EXCEPTION = "doctorcontact.exception";

	// Profile
	public static final String PROFILE_CONTROLLER = "/profile";
	public static final String VIEW_DOCTOR_PROFILE_MAPPING = "/viewProfile";
	public static final String EDIT_PROFILE_MAPPING = "/editProfilePage";
	public static final String EDIT_DOCTOR_PROFILE_MAPPING = "/editProfile";
	public static final String VERIFYEMAILMAPPING = "/verifyemail";

	public static final String PROFILE_UPDATE = "doctorprofile.update";
	public static final String PROFILE_ERROR = "doctorprofile.error";
	public static final String PROFILE_EXCEPTION = "doctorprofile.exception";
	public static final String PROFILE_EMAIL_ERROR = "userprofile.email";
	
	//Change Password
	public static final String CHANGEPASSWORD = "/changepassword";
	public static final String UPDATE_PASSWORD = "/updatepassword";
	public static final String RESET_PASSWORD_DOCTOR = "/resetpassworddoctor";
	
	// Password
	public static final String LOGIN_RESET = "login.reset";
	public static final String LOGIN_SUCCESS = "login.success";
	public static final String LOGIN_LINK = "login.link";
	public static final String PASSWORD_VALIDATION = "password.validation";
	public static final String PASSWORD_CURRENT = "password.current";
	public static final String PASSWORD_PASSWORD = "password.password";
	public static final String PASSWORD_MATCH = "password.match";
	public static final String PASSWORD_SIZE = "password.size";
}
