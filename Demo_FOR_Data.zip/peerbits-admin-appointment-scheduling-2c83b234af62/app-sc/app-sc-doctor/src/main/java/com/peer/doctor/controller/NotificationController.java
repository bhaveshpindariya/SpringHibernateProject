package com.peer.doctor.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.peer.constant.CommonConstants;
import com.peer.scenity.entity.local.User;
import com.peer.scenity.entity.pojo.NotificationDTO;
import com.peer.scenity.service.intf.INotificationsService;
import com.peer.scenity.util.SessionUtil;
import com.peer.util.CommonUtil;

@Controller
@RequestMapping("/notifications")
public class NotificationController {

	private static Logger _log = Logger.getLogger(NotificationController.class);

	private static final String VIEW_NOTIFICATION_LIST = "notification/list";
	private static final String NOTIFICATIONS_PAGE = "notification/notifications";

	@Autowired
	private INotificationsService notificationsService;

	@RequestMapping("/view/all")
	public String viewNotifications(HttpServletRequest request, Model model) {
		User user = SessionUtil.getUserFromRequestSession(request);
		List<NotificationDTO> receivedNotificationList = notificationsService
				.fetchReceivedNotifications(user.getUserId());
		Long unreadCount = notificationsService.countNotifications(user, false);
		model.addAttribute("receivedNotificationList", receivedNotificationList);
		model.addAttribute("unreadCount", unreadCount);
		return VIEW_NOTIFICATION_LIST;
	}

	@RequestMapping("/hasNotifications")
	@ResponseBody
	public ResponseEntity<Object> hasNotifications(HttpServletRequest request) {
		User user = SessionUtil.getUserFromRequestSession(request);
		boolean hasNotifications = notificationsService.hasNotifications(user, false);
		JSONObject jsonObject = new JSONObject();
		if (hasNotifications) {
			jsonObject.put("hasNotifications", true);
		} else {
			jsonObject.put("hasNotifications", false);
		}
		return new ResponseEntity<Object>(jsonObject.toString(), HttpStatus.OK);
	}

	@RequestMapping("/fetchNotifications")
	public String fetchNotifications(HttpServletRequest request, Model model) {
		User receiver = SessionUtil.getUserFromRequestSession(request);
		List<NotificationDTO> notificationList = notificationsService.fetchRecentNotifications(receiver.getUserId(),
				CommonConstants.MAX_NOTIFICATIONS);
		Long unreadCount = notificationsService.countNotifications(receiver, false);
		model.addAttribute("notificationList", notificationList);
		model.addAttribute("unreadCount", unreadCount);
		return NOTIFICATIONS_PAGE;
	}

	@RequestMapping("/markReadNotifications")
	@ResponseBody
	public ResponseEntity<Object> markReadNotifications(HttpServletRequest request) {
		User receiver = SessionUtil.getUserFromRequestSession(request);
		boolean markedRead = notificationsService.markAllReadNotifications(receiver);
		JSONObject jsonObject = new JSONObject();
		if (markedRead) {
			jsonObject.put("markedRead", true);
		} else {
			jsonObject.put("markedRead", false);
		}
		return new ResponseEntity<Object>(jsonObject.toString(), HttpStatus.OK);
	}

	@RequestMapping("/clearNotifications")
	public String clearNotifications(HttpServletRequest request, RedirectAttributes redirectAttributes) {
		String clearType = CommonConstants.RECEIVED;
		User user = SessionUtil.getUserFromRequestSession(request);
		boolean success = false;
		if (StringUtils.isNotBlank(clearType)) {
			success = notificationsService.deleteNotifications(user, clearType);
		}
		if (success) {
			redirectAttributes.addFlashAttribute("success", CommonConstants.SUCCESS);
		} else {
			redirectAttributes.addFlashAttribute("error", CommonConstants.ERROR);
		}
		return "redirect:/notifications/view/all";
	}

	@RequestMapping("/remote")
	@ResponseBody
	public ResponseEntity<Object> remoteNotifications(@RequestBody NotificationDTO notificationDTO,
			HttpServletRequest request) {
		String message = "error";
		if (null != notificationDTO) {
			notificationsService.notifyUser(notificationDTO);
		} else {
			Long notificationId = CommonUtil.getLongValue(request, "notificationId");
			_log.info("notificationId: " + notificationId);
			notificationsService.notifyUser(notificationId);
		}
		message = "success";
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("success", message);
		return new ResponseEntity<Object>(jsonObject.toString(), HttpStatus.OK);
	}

	@RequestMapping("/redirectToNotification")
	@ResponseBody
	public ResponseEntity<Object> redirectToNotification(HttpServletRequest request) {
		Long notificationId = CommonUtil.getLongValue(request, "notificationId");
		boolean markedRead = notificationsService.markReadNotifications(notificationId);
		JSONObject jsonObject = new JSONObject();
		if (markedRead) {
			jsonObject.put("markedRead", true);
		} else {
			jsonObject.put("markedRead", false);
		}
		return new ResponseEntity<Object>(jsonObject.toString(), HttpStatus.OK);
	}

}