package com.peer.doctor.validate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.peer.scenity.entity.local.DoctorContact;
import com.peer.scenity.service.constant.ServiceConstant;
import com.peer.scenity.service.intf.MessageByLocaleService;

@Component
public class DoctorContactValidator implements Validator {

	@Autowired
	private MessageByLocaleService messageByLocaleService;
	
	@Override
	public boolean supports(Class<?> clazz) {
		return DoctorContact.class.isAssignableFrom(clazz);
	}

	@Override
	public void validate(Object target, Errors errors) {
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "subject", "error.field.empty",messageByLocaleService.getMessage(ServiceConstant.DOCTORSUBJECT));
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "messagecontent", "error.field.empty",messageByLocaleService.getMessage(ServiceConstant.MESSAGE));
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "userType", "error.field.empty",messageByLocaleService.getMessage(ServiceConstant.USERTYPE));
	}
	
}