package com.peer.doctor.validate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.peer.scenity.entity.local.User;
import com.peer.scenity.service.constant.ServiceConstant;
import com.peer.scenity.service.intf.MessageByLocaleService;

@Component
public class DoctorProfileValidator implements Validator{

	@Autowired
	private MessageByLocaleService messageByLocaleService;
	
	@Override
	public boolean supports(Class<?> clazz) {
		return User.class.isAssignableFrom(clazz);
	}
	
	@Override
	public void validate(Object target, Errors errors) {
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "fullName", "error.field.empty",messageByLocaleService.getMessage(ServiceConstant.DOCTOR_FULLNAME));
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "emailAddress", "error.field.empty",messageByLocaleService.getMessage(ServiceConstant.DOCTOR_EMAILADDRESS));
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "contactNo", "error.field.empty",messageByLocaleService.getMessage(ServiceConstant.DOCTOR_CONTACTNO));
	}

}
