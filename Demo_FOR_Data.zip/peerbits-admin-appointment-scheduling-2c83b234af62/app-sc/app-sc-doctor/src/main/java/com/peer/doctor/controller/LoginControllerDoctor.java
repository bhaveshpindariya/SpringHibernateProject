package com.peer.doctor.controller;

import java.util.Date;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.peer.constant.CommonConstants;
import com.peer.doctor.constants.DoctorConstants;
import com.peer.enm.UserType;
import com.peer.scenity.entity.local.User;
import com.peer.scenity.entity.pojo.Response;
import com.peer.scenity.service.constant.ServiceConstant;
import com.peer.scenity.service.intf.IAuthTokenService;
import com.peer.scenity.service.intf.IFilesService;
import com.peer.scenity.service.intf.IUserService;
import com.peer.scenity.service.intf.MessageByLocaleService;
import com.peer.scenity.util.EmailTemplateLoader;
import com.peer.scenity.util.EncryptionUtil;
import com.peer.scenity.util.MailUtil;
import com.peer.scenity.util.SessionUtil;

@Controller
@RequestMapping("/")
public class LoginControllerDoctor {

	private static Logger _log = Logger.getLogger(LoginControllerDoctor.class);

	@Autowired
	private IUserService userService;

	@Autowired
	private IAuthTokenService authTokenService;

	@Autowired
	private IFilesService fileService;

	@Autowired
	private MessageByLocaleService messageByLocaleService;

	private static final String LOGIN_PAGE = "login/login";
	private static final String PAGE_NOT_FOUND = "page/notfound";
	private static final String DASHBOARD_HOME = "redirect:/dashboard/index";
	private static final String FORGOTPASSWORD_PAGE = "login/forgotpassword";
	private static final String RESETPASSWORD_PAGE = "login/reset";
	private static final String LINK_EXPIRED = "login/expired";

	@RequestMapping("/login")
	public String loginPage(Model model, HttpServletRequest request) {
		String redirect = LOGIN_PAGE;
		if (SessionUtil.isUserLoggedIn(request)) {
			redirect = DASHBOARD_HOME;
		} else {
			model.addAttribute("user", new User());
		}
		return redirect;
	}

	@RequestMapping(value = DoctorConstants.FORGOT_PASSWORD)
	public String forgotpasswordPage(Model model, HttpServletRequest request) {
		return FORGOTPASSWORD_PAGE;
	}

	@RequestMapping(value = DoctorConstants.NEW_PASSWORD)
	public String newpasswordPage(Model model, HttpServletRequest request) {
		String emailAddress = request.getParameter("emailAddress");
		String token = request.getParameter("token");
		Boolean flag = authTokenService.verifyToken(emailAddress, token);
		if (flag == true) {
			model.addAttribute("emailAddress", emailAddress);
			return RESETPASSWORD_PAGE;
		}
		return LINK_EXPIRED;
	}

	@RequestMapping(DoctorConstants.NEWUPDATEPASSWORD)
	public String updatePassword(Model model, HttpServletRequest request) {
		Response response = new Response();
		String newPassword = request.getParameter("newPassword");
		String confirmPassword = request.getParameter("confirmPassword");
		String email = request.getParameter("email");
		String message = validatePasswords(newPassword, confirmPassword);
		if (StringUtils.isBlank(message)) {
			User currentUser = userService.findUserByEmail(email);
			currentUser.setPassword(EncryptionUtil.encrypt(newPassword));
			userService.mergeLocal(currentUser);
		}
		if (StringUtils.isBlank(message)) {
			response = setMessage(CommonConstants.SUCCESS, DoctorConstants.LOGIN_SUCCESS);
			model.addAttribute("success", response.getMessage());
		} else {
			model.addAttribute("error", messageByLocaleService.getMessage(message));
		}
		return RESETPASSWORD_PAGE;
	}

	public String validatePasswords(String password1, String password2) {
		if (StringUtils.isBlank(password1) || StringUtils.isBlank(password2)) {
			return DoctorConstants.PASSWORD_PASSWORD;
		}
		if (!StringUtils.equals(password1, password2)) {
			return DoctorConstants.PASSWORD_MATCH;
		}
		if (password1.length() < 6) {
			return DoctorConstants.PASSWORD_SIZE;
		}
		return "";
	}

	@RequestMapping(value = DoctorConstants.RESET_PASSWORD, method = RequestMethod.POST)
	@ResponseBody
	public ResponseEntity<Object> resetPasswordPage(Locale locale, Model model, HttpServletRequest request,
			RedirectAttributes redirectAttributes) {
		Response response = new Response();
		JSONObject jsonObject = new JSONObject();
		String emailAddress = request.getParameter("emailAddress");
		if(!emailAddress.isEmpty())
		{
			User user = userService.findUserByEmail(emailAddress);
			if (user != null) {
				if (user.getUserType() == UserType.Doctor) {
					if (MailUtil.emailValidator(emailAddress)) {
						String token = authTokenService.createToken(emailAddress, new Date());
						String messageBody = EmailTemplateLoader.passwordResetTemplate(request, token, user);
						MailUtil.sendMail(user.getEmailAddress(), ServiceConstant.getPropertiesValue(ServiceConstant.MAIL_SUB),
								messageBody);
						response = setMessage(CommonConstants.SUCCESS, DoctorConstants.LOGIN_LINK);
						jsonObject.put("success", response.getMessage());
					} else {
						response = setMessage(CommonConstants.ERROR, DoctorConstants.LOGIN_RESET);
						jsonObject.put("error", response.getMessage());
					}
				} else {
					response = setMessage(CommonConstants.ERROR, DoctorConstants.LOGIN_RESET);
					jsonObject.put("error", response.getMessage());
				}
			}else {
				response = setMessage(CommonConstants.ERROR, DoctorConstants.LOGIN_RESET);
				jsonObject.put("error", response.getMessage());
			}
		}else {
			response = setMessage(CommonConstants.ERROR, DoctorConstants.LOGIN_RESET);
			jsonObject.put("error", response.getMessage());
		}
		return new ResponseEntity<>(jsonObject.toString(), HttpStatus.OK);
	}

	@RequestMapping(value = DoctorConstants.LOGIN_USER, method = RequestMethod.POST)
	public String addLoginPage(@ModelAttribute("user") User user, HttpServletRequest request,
			HttpServletResponse response, Model model) {
		String redirect = LOGIN_PAGE;
		try {
			User user2 = userService.finduserByEmail(user);
			String message = "";
			boolean fail = true;
			if (null != user2 && user2.getUserType().equals(UserType.Doctor)) {
				String password = user2.getPassword();
				String enteredPassword = EncryptionUtil.encrypt(user.getPassword());
				if (password.equals(enteredPassword)) {
					fail = false;
				} else {
					message = "user.wrongpassword";
				}
			} else {
				message = "user.notdoctor";
			}
			if (fail) {
				model.addAttribute("error", message);
			} else {
				redirect = DASHBOARD_HOME;
				createSession(request, user2);
				SessionUtil.updateLanguage(user2, request, response);
			}
		} catch (Exception e) {
			_log.error("", e);
		}
		return redirect;
	}

	@RequestMapping(value = DoctorConstants.LOGOUT_USER, method = RequestMethod.GET)
	public String logoutPage(HttpSession session) {
		_log.info("inside logout user page ");
		session.invalidate();
		return LOGIN_PAGE;
	}

	@RequestMapping("/success")
	public String loginSuccess() {
		_log.info("inside loginSuccess()");
		return LOGIN_PAGE;
	}

	@RequestMapping("/error")
	public String loginError() {
		_log.info("inside loginError");
		return LOGIN_PAGE;
	}

	@RequestMapping("/404")
	public String pageNotFound() {
		_log.info("inside pageNotFound");
		return PAGE_NOT_FOUND;
	}

	private Response setMessage(String type, String message) {
		Response response = new Response();
		response.setStatus(type);
		response.setMessage(messageByLocaleService.getMessage(message));
		return response;
	}

	public void createSession(HttpServletRequest request, User loginUser) {
		HttpSession httpSession = request.getSession(true);
		httpSession.setAttribute(ServiceConstant.USER, loginUser);
		httpSession.setAttribute(ServiceConstant.USER_ID, loginUser.getUserId());
		httpSession.setAttribute(ServiceConstant.USER_FULL_NAME, loginUser.getFullName());
		String profileImagePath = fileService.getFilePath(loginUser.getProfileImg());
		httpSession.setAttribute(ServiceConstant.USER_PROFILE_IMAGE, profileImagePath);
		httpSession.setAttribute(ServiceConstant.ZUES_ID, loginUser.getProgramacionId());
	}
}
