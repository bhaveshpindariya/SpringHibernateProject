package com.peer.doctor.controller;

import java.util.Date;
import java.util.List;
import java.util.Locale;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.apache.commons.lang3.StringUtils;
import com.peer.constant.CommonConstants;
import com.peer.doctor.constants.DoctorConstants;
import com.peer.doctor.validate.DoctorContactValidator;
import com.peer.enm.Action;
import com.peer.enm.ActionItem;
import com.peer.enm.Status;
import com.peer.enm.UserType;
import com.peer.scenity.entity.local.DoctorContact;
import com.peer.scenity.entity.local.Subject;
import com.peer.scenity.entity.local.User;
import com.peer.scenity.entity.pojo.Response;
import com.peer.scenity.service.constant.ServiceConstant;
import com.peer.scenity.service.intf.IAuthTokenService;
import com.peer.scenity.service.intf.IDoctorContactService;
import com.peer.scenity.service.intf.ISubjectService;
import com.peer.scenity.service.intf.IUserService;
import com.peer.scenity.service.intf.MessageByLocaleService;
import com.peer.scenity.util.EmailTemplateLoader;
import com.peer.scenity.util.EncryptionUtil;
import com.peer.scenity.util.MailUtil;
import com.peer.scenity.util.NotificationUtil;
import com.peer.scenity.util.SessionUtil;
import com.peer.util.CommonUtil;

@Controller
@RequestMapping(DoctorConstants.CONTACTUS_CONTROLLER)
public class DoctorContactController {
	private static Logger _log = Logger.getLogger(DoctorContactController.class);

	@Autowired
	private MessageByLocaleService messageByLocaleService;

	@Autowired
	IDoctorContactService doctorContactService;

	@Autowired
	private ISubjectService subjectService;

	@Autowired
	private IUserService userService;

	@Autowired
	private DoctorContactValidator contactvalidator;

	private static final String DOCTOR_CONTACTUS_PAGE = "contact/contact";
	private static final String CHANGEPASSWORD_PAGE = "contact/changepassword";

	@Autowired
	private IAuthTokenService authTokenService;

	@RequestMapping(DoctorConstants.VIEW_DOCTOR_CONTACTUS_MAPPING)
	public String viewDoctorContactPage(Locale locale, Model model, HttpServletRequest request,
			@ModelAttribute("subject") Subject subject) {
		List<Subject> sub = subjectService.findByUserType(UserType.Admin);
		List<User> analyst = userService.fetchUserListByType(UserType.Analyst);
		if (!analyst.isEmpty()) {
			model.addAttribute("analyst", analyst.get(0));
		}
		model.addAttribute("data", sub);
		return DOCTOR_CONTACTUS_PAGE;
	}

	@RequestMapping(DoctorConstants.CHANGE_SUBJECT)
	@ResponseBody
	public ResponseEntity<Object> changeDoctorSubjectPage(Locale locale, Model model, HttpServletRequest request,
			@ModelAttribute("subject") Subject subject) {

		String type = request.getParameter("sendTo");
		if (type.equals("Analyst")) {
			List<Subject> sub = subjectService.findByUserType(UserType.Analyst);
			JSONArray data = subjectService.getArrayFromList(sub);
			JSONArray jsonArray = new JSONArray();
			jsonArray.put(data);
			return new ResponseEntity<>(jsonArray.toString(), HttpStatus.OK);
		} else {
			List<Subject> sub = subjectService.findByUserType(UserType.Admin);
			JSONArray data = subjectService.getArrayFromList(sub);
			JSONArray jsonArray = new JSONArray();
			jsonArray.put(data);
			return new ResponseEntity<>(jsonArray.toString(), HttpStatus.OK);
		}
	}

	@RequestMapping(value = DoctorConstants.RESET_PASSWORD_DOCTOR, method = RequestMethod.POST)
	@ResponseBody
	public ResponseEntity<Object> resetPasswordPage(Locale locale, Model model, HttpServletRequest request,
			RedirectAttributes redirectAttributes) {
		Response response = new Response();
		String emailAddress = request.getParameter("emailAddress");
		User user = userService.findUserResetPasswordlAdmin(emailAddress);
		JSONObject jsonObject = new JSONObject();
		if (user != null) {
			if (MailUtil.emailValidator(emailAddress)) {
				String token = authTokenService.createToken(emailAddress, new Date());
				String messageBody = EmailTemplateLoader.passwordResetTemplate(request, token, user);
				MailUtil.sendMail(user.getEmailAddress(), ServiceConstant.getPropertiesValue(ServiceConstant.MAIL_SUB),
						messageBody);
				response = setMessage(CommonConstants.SUCCESS, DoctorConstants.LOGIN_LINK);
				jsonObject.put("success", response.getMessage());
			} else {
				response = setMessage(CommonConstants.ERROR, DoctorConstants.LOGIN_RESET);
				jsonObject.put("error", response.getMessage());
			}
		} else {
			response = setMessage(CommonConstants.ERROR, DoctorConstants.LOGIN_RESET);
			jsonObject.put("error", response.getMessage());
		}
		return new ResponseEntity<>(jsonObject.toString(), HttpStatus.OK);
	}

	@RequestMapping(value = DoctorConstants.CHANGEPASSWORD)
	public String changepasswordPage(Model model, HttpServletRequest request) {
		return CHANGEPASSWORD_PAGE;
	}

	@RequestMapping(value = DoctorConstants.UPDATE_PASSWORD, method = RequestMethod.POST)
	public String updatePassword(HttpServletRequest request, Model model, RedirectAttributes redirectAttrs) {
		User user = SessionUtil.getUserFromRequestSession(request);
		String currentPassword = request.getParameter("currentPassword");
		String newPassword = request.getParameter("newPassword");
		String confirmPassword = request.getParameter("confirmPassword");
		String message = validatePasswords(currentPassword, newPassword, confirmPassword);
		if (StringUtils.isBlank(message)) {
			User currentUser = userService.findByIdLocal(user.getUserId());
			String userPassword = currentUser.getPassword();
			String userPasswordEnc = EncryptionUtil.encrypt(currentPassword);
			if (userPassword.equals(userPasswordEnc)) {
				currentUser.setPassword(EncryptionUtil.encrypt(newPassword));
				userService.mergeLocal(currentUser);
			} else {
				message = DoctorConstants.PASSWORD_VALIDATION;
			}
		}
		if (StringUtils.isBlank(message)) {
			redirectAttrs.addFlashAttribute("success", CommonConstants.SUCCESS);
		} else {
			redirectAttrs.addFlashAttribute("error", CommonConstants.ERROR);
			redirectAttrs.addFlashAttribute("message", message);
		}
		return "redirect:" + DoctorConstants.CONTACTUS_CONTROLLER + DoctorConstants.CHANGEPASSWORD;
	}

	public String validatePasswords(String currentPassword, String password1, String password2) {
		if (StringUtils.isBlank(currentPassword)) {
			return DoctorConstants.PASSWORD_CURRENT;
		}
		if (StringUtils.isBlank(password1) || StringUtils.isBlank(password2)) {
			return DoctorConstants.PASSWORD_PASSWORD;
		}
		if (!StringUtils.equals(password1, password2)) {
			return DoctorConstants.PASSWORD_MATCH;
		}
		if (password1.length() < 6) {
			return DoctorConstants.PASSWORD_SIZE;
		}
		return "";
	}

	@RequestMapping(DoctorConstants.SEND_DOCTOR_CONTACTUS)
	public String addCmsPage(Locale locale, Model model, RedirectAttributes redirectAttrs, HttpServletRequest request,
			@ModelAttribute("doctorContact") DoctorContact doctorContact, HttpSession session,
			BindingResult bindingResult) {
		Response response = new Response();
		Boolean isEmpty = CommonUtil.checkNull(doctorContact);
		if (!isEmpty) {
			try {
				boolean check = validateContactForm(redirectAttrs, doctorContact, session, request, bindingResult,
						response);
				if (check) {
					if (doctorContact.getDoctorcontactId() == null || doctorContact.getDoctorcontactId().equals(0L)) {
						List<User> list = userService.fetchUserListByType(doctorContact.getUserType());
						if (list.size() > 0) {
							doctorContactService.persistLocal(doctorContact);
							String msg = doctorContact.getMessagecontent();
							String setsubject = doctorContact.getSubject();
							for (int i = 0; i < list.size(); i++) {
								User user = list.get(i);
								String to = user.getEmailAddress();
								MailUtil.sendMail(to, setsubject, msg);
								response = setMessage(CommonConstants.SUCCESS, DoctorConstants.DOCTORCONTACT_SUCCESS);
								List<Subject> sub = subjectService.findByUserType(UserType.Admin);
								model.addAttribute("data", sub);
								User sender = SessionUtil.getUserFromRequestSession(request);
								String notificationMessage = request.getParameter("messagecontent");
								_log.info("msg=" + notificationMessage);
								if (StringUtils.isNotBlank(notificationMessage)
										&& StringUtils.isNotBlank(notificationMessage.trim())) {
									NotificationUtil.createNotification(user.getUserId(), sender.getUserId(),
											notificationMessage, Action.NOTIFICATION, ActionItem.GENERAL, 0L, true);
								}
							}
						}
					}
				}
			} catch (Exception e) {
				_log.error("Error:--", e);
				response = setMessage(CommonConstants.ERROR, DoctorConstants.DOCTORCONTACT_ERROR);
			}
		}
		if (response.getStatus().equals(CommonConstants.SUCCESS)) {
			redirectAttrs.addFlashAttribute("success", response.getMessage());
			redirectAttrs.addFlashAttribute("Notification send successfully", "Notification send successfully");
		} else {
			redirectAttrs.addFlashAttribute("error", response.getMessage());
		}
		return "redirect:" + DoctorConstants.CONTACTUS_CONTROLLER + DoctorConstants.VIEW_DOCTOR_CONTACTUS_MAPPING;
	}

	private boolean validateContactForm(RedirectAttributes redirectAttrs, DoctorContact doctorContact,
			HttpSession session, HttpServletRequest request, BindingResult bindingResult, Response response) {
		boolean validated = true;
		if (doctorContact.getDoctorcontactId() == null || doctorContact.getDoctorcontactId().equals(0L)) {
			contactvalidator.validate(doctorContact, bindingResult);
			if (bindingResult.hasErrors()) {
				List<FieldError> errors = bindingResult.getFieldErrors();
				StringBuffer message = new StringBuffer();
				for (FieldError error : errors) {
					message.append(error.getDefaultMessage() + CommonConstants.MESSAGE);
				}
				response = setErrorValidate(CommonConstants.ERROR, message);
				redirectAttrs.addFlashAttribute("error", response.getMessage());
				validated = false;
			}
			doctorContact.setCreatedOn(new Date());
			doctorContact.setUpdatedOn(new Date());
			doctorContact.setCreatedBy(SessionUtil.getUserFromRequestSession(request));
			doctorContact.setUpdatedBy(SessionUtil.getUserFromRequestSession(request));
			doctorContact.setStatus(Status.ACTIVE);
		} else {
			contactvalidator.validate(doctorContact, bindingResult);
			if (bindingResult.hasErrors()) {
				List<FieldError> errors = bindingResult.getFieldErrors();
				StringBuffer message = new StringBuffer();
				for (FieldError error : errors) {
					message.append(error.getDefaultMessage() + CommonConstants.MESSAGE);
				}
				response = setErrorValidate(CommonConstants.ERROR, message);
				redirectAttrs.addFlashAttribute("error", response.getMessage());
				validated = false;
			}
			doctorContact.setStatus(Status.ACTIVE);
			doctorContact.setUpdatedOn(new Date());
			doctorContact.setUpdatedBy(SessionUtil.getUserFromRequestSession(request));
		}
		return validated;
	}

	private Response setErrorValidate(String type, StringBuffer message) {
		Response response = new Response();
		response.setStatus(type);
		response.setMessage(message.toString().substring(0, message.length() - 5));
		return response;
	}

	private Response setMessage(String type, String message) {
		Response response = new Response();
		response.setStatus(type);
		response.setMessage(messageByLocaleService.getMessage(message));
		return response;
	}

}