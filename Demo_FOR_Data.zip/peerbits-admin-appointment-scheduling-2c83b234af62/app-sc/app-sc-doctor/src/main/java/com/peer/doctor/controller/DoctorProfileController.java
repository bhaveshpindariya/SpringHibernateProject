package com.peer.doctor.controller;

import java.util.Date;
import java.util.List;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.peer.constant.CommonConstants;
import com.peer.doctor.constants.DoctorConstants;
import com.peer.doctor.validate.DoctorProfileValidator;
import com.peer.enm.Status;
import com.peer.scenity.entity.local.Files;
import com.peer.scenity.entity.local.User;
import com.peer.scenity.entity.pojo.Response;
import com.peer.scenity.service.constant.ServiceConstant;
import com.peer.scenity.service.intf.IFilesService;
import com.peer.scenity.service.intf.IUserService;
import com.peer.scenity.service.intf.MessageByLocaleService;
import com.peer.scenity.util.SessionUtil;
import com.peer.util.CommonUtil;

@Controller
@RequestMapping(DoctorConstants.PROFILE_CONTROLLER)
public class DoctorProfileController {
	private static Logger _log = Logger.getLogger(LoginControllerDoctor.class);

	@Autowired
	private IUserService userService;

	@Autowired
	private DoctorProfileValidator profileValidator;

	@Autowired
	private MessageByLocaleService messageByLocaleService;

	@Autowired
	private IFilesService fileService;

	private static final String DOCTOR_PROFILE_PAGE = "profile/viewprofile";
	private static final String EDIT_DOCTOR_PROFILE_PAGE = "profile/editprofile";

	@RequestMapping(DoctorConstants.VIEW_DOCTOR_PROFILE_MAPPING)
	public String viewDoctorProfilePage(Locale locale, Model model, HttpServletRequest request,
			@ModelAttribute("doctor") User doctor) {
		_log.info("inside landing doctor profile page");
		User data = SessionUtil.getUserFromRequestSession(request);
		User user = userService.findByIdLocal(data.getUserId());
		model.addAttribute("data", user);
		model.addAttribute("userEps", user.getEpsSet());
		model.addAttribute("userCategories", user.getCategorySet());
		String profileImagePath = fileService.getFilePath(user.getProfileImg());
		model.addAttribute("profileImagePath", profileImagePath);
		return DOCTOR_PROFILE_PAGE;
	}

	@RequestMapping(DoctorConstants.EDIT_PROFILE_MAPPING)
	public String editDoctorProfilePage(Locale locale, Model model, HttpServletRequest request,
			@ModelAttribute("doctor") User doctor) {
		_log.info("inside landing doctor edit profile page");
		User data = SessionUtil.getUserFromRequestSession(request);
		model.addAttribute("data", data);
		String profileImagePath = fileService.getFilePath(data.getProfileImg());
		model.addAttribute("profileImagePath", profileImagePath);
		return EDIT_DOCTOR_PROFILE_PAGE;
	}

	@RequestMapping(DoctorConstants.VERIFYEMAILMAPPING)
	@ResponseBody
	public ResponseEntity<Object> verifyallemail(Locale locale, Model model, HttpServletRequest request) {
		_log.info("inside landing verify all email page ");
		String emailAddress = request.getParameter("email");
		Response response = new Response();
		JSONObject jsonObject = new JSONObject();
		User user = SessionUtil.getUserFromRequestSession(request);
		boolean flag = userService.checkUserExist(emailAddress, user.getUserId());
		if (flag == true) {
			response = setMessage(CommonConstants.ERROR, DoctorConstants.PROFILE_EMAIL_ERROR);
			jsonObject.put("error", response.getMessage());
		}
		return new ResponseEntity<>(jsonObject.toString(), HttpStatus.OK);
	}

	@RequestMapping(value = DoctorConstants.EDIT_DOCTOR_PROFILE_MAPPING, method = RequestMethod.POST)
	public String addUser(@RequestParam("file") MultipartFile multipartFile, RedirectAttributes redirectAttrs,
			@ModelAttribute("user") User user, HttpServletRequest request, BindingResult bindingResult, Model model,
			Locale locale, HttpSession httpSession) {
		_log.info("inside edit doctor profile ");
		Response response = new Response();
		Boolean isEmpty = CommonUtil.checkNull(user);
		if (!isEmpty) {
			try {
				boolean check = validateDoctorProfile(redirectAttrs, user, httpSession, request, bindingResult,
						response);
				if (check) {
					boolean flag = userService.checkUserExist(user.getEmailAddress(), user.getUserId());
					if (flag == true) {
						response = setMessage(CommonConstants.ERROR, DoctorConstants.PROFILE_EMAIL_ERROR);
						redirectAttrs.addFlashAttribute("error", response.getMessage());
						return "redirect:" + DoctorConstants.PROFILE_CONTROLLER + DoctorConstants.EDIT_PROFILE_MAPPING;
					}
					User foundUser = userService.findByIdLocal(user.getUserId());
					Files image = fileService.addFile(multipartFile.getBytes(), user.getUserId().toString(),
							multipartFile.getOriginalFilename());
					if (multipartFile.isEmpty()) {
						foundUser.setFullName(user.getFullName());
						foundUser.setEmailAddress(user.getEmailAddress());
						foundUser.setContactNo(user.getContactNo());
						foundUser.setUpdatedOn(new Date());
						foundUser.setUpdatedBy(SessionUtil.getUserFromRequestSession(request));
					} else {
						_log.info("Image Path= " + image.getFilePath());
						foundUser.setProfileImgId(image.getFilesId());
						foundUser.setProfileImg(image.getFilePath());
						foundUser.setFullName(user.getFullName());
						foundUser.setEmailAddress(user.getEmailAddress());
						foundUser.setContactNo(user.getContactNo());
						foundUser.setUpdatedOn(new Date());
						foundUser.setUpdatedBy(SessionUtil.getUserFromRequestSession(request));
					}
					try {
						foundUser = userService.mergeLocal(foundUser);
						httpSession.setAttribute(ServiceConstant.USER, foundUser);
						httpSession.setAttribute(ServiceConstant.USER_FULL_NAME, foundUser.getFullName());
						httpSession.setAttribute(ServiceConstant.USEREMAIL, foundUser.getEmailAddress());
						httpSession.setAttribute(ServiceConstant.USERNUMBER, foundUser.getContactNo());
						response = setMessage(CommonConstants.SUCCESS, DoctorConstants.PROFILE_UPDATE);
					} catch (Exception e) {
						_log.error("Error:--", e);
						response = setMessage(CommonConstants.ERROR, DoctorConstants.PROFILE_ERROR);
						redirectAttrs.addFlashAttribute("error", response.getMessage());
						return "redirect:" + DoctorConstants.PROFILE_CONTROLLER + DoctorConstants.EDIT_PROFILE_MAPPING;
					}
				} else {
					return "redirect:" + DoctorConstants.PROFILE_CONTROLLER + DoctorConstants.EDIT_PROFILE_MAPPING;
				}
			} catch (Exception e) {
				response = setMessage(CommonConstants.ERROR, DoctorConstants.PROFILE_ERROR);
				redirectAttrs.addFlashAttribute("error", response.getMessage());
				return "redirect:" + DoctorConstants.PROFILE_CONTROLLER + DoctorConstants.EDIT_PROFILE_MAPPING;
			}
		} else {
			response = setMessage(CommonConstants.ERROR, DoctorConstants.PROFILE_ERROR);
			redirectAttrs.addFlashAttribute("error", response.getMessage());
			return "redirect:" + DoctorConstants.PROFILE_CONTROLLER + DoctorConstants.EDIT_PROFILE_MAPPING;
		}
		if (response.getStatus().equals(CommonConstants.SUCCESS)) {
			redirectAttrs.addFlashAttribute("success", response.getMessage());
		} else {
			redirectAttrs.addFlashAttribute("error", response.getMessage());
			return "redirect:" + DoctorConstants.PROFILE_CONTROLLER + DoctorConstants.EDIT_PROFILE_MAPPING;
		}
		return "redirect:" + DoctorConstants.PROFILE_CONTROLLER + DoctorConstants.VIEW_DOCTOR_PROFILE_MAPPING;

	}

	private boolean validateDoctorProfile(RedirectAttributes redirectAttrs, User user, HttpSession httpsession,
			HttpServletRequest request, BindingResult bindingResult, Response response) {
		boolean validated = true;
		profileValidator.validate(user, bindingResult);
		if (bindingResult.hasErrors()) {
			List<FieldError> errors = bindingResult.getFieldErrors();
			StringBuffer message = new StringBuffer();
			for (FieldError error : errors) {
				message.append(error.getDefaultMessage() + CommonConstants.MESSAGE);
			}
			response = setErrorValidate(CommonConstants.ERROR, message);
			redirectAttrs.addFlashAttribute("error", response.getMessage());
			validated = false;
		}
		user.setStatus(Status.ACTIVE);
		user.setUpdatedOn(new Date());
		user.setUpdatedBy(SessionUtil.getUserFromRequestSession(request));
		return validated;
	}

	private Response setErrorValidate(String type, StringBuffer message) {
		Response response = new Response();
		response.setStatus(type);
		response.setMessage(message.toString().substring(0, message.length() - 5));
		return response;
	}

	private Response setMessage(String type, String message) {
		Response response = new Response();
		response.setStatus(type);
		response.setMessage(messageByLocaleService.getMessage(message));
		return response;
	}
}
