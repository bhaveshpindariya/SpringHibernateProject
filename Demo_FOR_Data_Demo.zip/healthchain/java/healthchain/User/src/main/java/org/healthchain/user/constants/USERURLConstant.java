package org.healthchain.user.constants;

public class USERURLConstant {
	
	public static final String AUTHENTICATION_USER_ROOT_URL="/auth";
	public static final String AUTHORIZATION_USER="/authorizations";
	
	public static final String FORGOTPASSWORD="/forgotPassword";
	public static final String CHANGEPASSWORD="/changePassword";
	
	public static final String ADMIN_ROOT_URL="/admin";
	
	public static final String FACILITY_ADD_URL="/addfacility";
	
	public static final String FACILITY_GET_URL="/getAllfacility";
		
	public static final String SPECIALITY_ADD_OR_EDIT_URL="/addOrEditSpeciality";
	
	public static final String CLIENT_ADD_OR_EDIT_URL="/addOrEditClient";
	public static final String CLIENT_GET_URL="/getAllClient";
	
	public static final String SPECIALITY_GET_URL="/getAllSpeciality";
	
	public static final String TIMEZONE_ADD_OR_EDIT_URL="/addOrEditTimeZone";
	
	public static final String ADD_ADMINUSER_URL="/addAllUserByAdmin";
	
	public static final String FILE_DOWNLOAD="/download";
	
	public static final String FILE_EXITS="/exits";
	
	public static final String ROLE_ROOT_URL="/role";
	public static final String ADD_OR_EDIT_ROLE_URL="/addOrEditRole";
	public static final String ALL_ROLE="/getAllRole";
	
	public static final String USER_REGISTRATION="/userRegistration";
	public static final String USER_LOGIN="/login";
	public static final String USER_LOGOUT="/logout";
	public static final String ADD_PATIENT_URL="/addPatient";
		
	public static final String ADD_TYPE="Add";
	public static final String EDIT_TYPE="Update";
	
	public static final String TRANSACTION_RECEIPT="/receipt";
	
	public static final String LABREPORT_ADD_OR_EDIT_URL="/addOrEditLabreport";
	public static final String DIGNSOSIS_ADD_OR_EDIT_URL="/addOrEditDignsosis";
	
	public static final String DRUGMANUFACTURERS_ADD_OR_EDIT_URL="/addOrEditDrugManufacturers";
	public static final String DRUGSACTIVESUBSTANCEMASTER_ADD_OR_EDIT_URL="/addOrEditdrugsActiveSubstanceMaster";
	
	public static final String DRUGCOMPOUND_ADD_OR_EDIT_URL="/addOrEditdrugCompound";
	public static final String GET_IMAGES_URL="/getImages";
	
	public static final String DRUGCOMPOUND_SUCCESS="drugcompound.success";
	
	public static final String DRUGCOMPOUND_UPDATE="drugcompound.update";
	public static final String DRUGCOMPOUND_EXIT="drugcompound.exit";
	public static final String DRUGCOMPOUND_ERROR="drugcompound.error";
	public static final String DRUGCOMPOUND_EXCEPTION="drugcompound.exception";
	
	public static final String USER_FORGOT_SUCCESS="user.forgot.success";
	public static final String USER_FORGOT_ERROR="user.forgot.error";
	public static final String USER_FORGOT_EXCEPTION="user.forgot.exception";
	public static final String USER_FORGOT_SYSTEM_ERROR="user.forgot.system.error";
	
	public static final String USER_CHANGE_SUCCESS="user.change.success";
	public static final String USER_CHANGE_ERROR="user.change.error";
	public static final String USER_CHANGE_EXCEPTION="user.change.exception";
	public static final String USER_CHANGE_SYSTEM_ERROR="user.change.system.error";
	
	public static final String USER_SUCCESS="user.success";
	public static final String USER_EXIT="user.exit";
	public static final String USER_ERROR="user.error";
	public static final String USER_EXCEPTION="user.exception";
	
	public static final String USER_LOGIN_SUCCESS="user.login.success";
	public static final String USER_LOGIN_ERROR="user.login.error";
	
	public static final String DEVICE_ERROR="device.error";
	public static final String DEVICE_SYSTEM_ERROR="device.system.error";
	
	public static final String ROLE_SUCCESS="role.success";
	public static final String ROLE_UPDATE="role.update";
	public static final String ROLE_EXIT="role.exit";
	public static final String ROLE_ERROR="role.error";
	public static final String ROLE_EXCEPTION="role.exception";
	
	public static final String ALLUSER_SUCCESS="alluse.success";
	public static final String ALLUSER_EXIT="alluse.exit";
	public static final String ALLUSER_ERROR="alluse.error";
	public static final String ALLUSER_EXCEPTION="alluse.exception";
	
	public static final String TIMEZONE_SUCCESS="timezone.success";
	public static final String TIMEZONE_UPDATE="timezone.update";
	public static final String TIMEZONE_EXIT="timezone.exit";
	public static final String TIMEZONE_ERROR="timezone.error";
	public static final String TIMEZONE_EXCEPTION="timezone.exception";
	
	public static final String FACILITY_SUCCESS="facility.success";
	public static final String FACILITY_UPDATE="facility.update";
	public static final String FACILITY_EXIT="facility.exit";
	public static final String FACILITY_ERROR="facility.error";
	public static final String FACILITY_EXCEPTION="facility.exception";
	
	public static final String SPECIALITY_SUCCESS="speciality.success";
	public static final String SPECIALITY_UPDATE="speciality.update";
	public static final String SPECIALITY_EXIT="speciality.exit";
	public static final String SPECIALITY_ERROR="speciality.error";
	public static final String SPECIALITY_EXCEPTION="speciality.exception";
	
	public static final String CLIENT_SUCCESS="client.success";
	public static final String CLIENT_UPDATE="client.update";
	public static final String CLIENT_EXIT="client.exit";
	public static final String CLIENT_ERROR="client.error";
	public static final String CLIENT_EXCEPTION="client.exception";
	
	public static final String LAB1_SUCCESS="lab1.success";
	public static final String LAB1_UPDATE="lab1.update";
	public static final String LAB1_EXIT="lab1.exit";
	public static final String LAB1_ERROR="lab1.error";
	public static final String LAB1_EXCEPTION="lab1.exception";
	
	public static final String DIGNSOSIS_SUCCESS="dignsosis.success";
	public static final String DIGNSOSIS_UPDATE="dignsosis.update";
	public static final String DIGNSOSIS_EXIT="dignsosis.exit";
	public static final String DIGNSOSIS_ERROR="dignsosis.error";
	public static final String DIGNSOSIS_EXCEPTION="dignsosis.exception";
	
	public static final String DRUGSACTIVESUBSTANCE_SUCCESS="drugsActiveSubstance.success";
	public static final String DRUGSACTIVESUBSTANCE_UPDATE="drugsActiveSubstance.update";
	public static final String DRUGSACTIVESUBSTANCE_EXIT="drugsActiveSubstance.exit";
	public static final String DRUGSACTIVESUBSTANCE_ERROR="drugsActiveSubstance.error";
	public static final String DRUGSACTIVESUBSTANCE_EXCEPTION="drugsActiveSubstance.exception";

	
	public static final String DRUGMANUFACTURERS_SUCCESS="drugManufacture.success";
	public static final String DRUGMANUFACTURERS_UPDATE="drugManufacture.update";
	public static final String DRUGMANUFACTURERS_EXIT="drugManufacture.exit";
	public static final String DRUGMANUFACTURERS_ERROR="drugManufacture.error";
	public static final String DRUGMANUFACTURERS_EXCEPTION="drugManufacture.exception";
	
	public static final String FILE_SUCCESS="file.success";
	public static final String FILE_ERROR="file.error";
	
}
