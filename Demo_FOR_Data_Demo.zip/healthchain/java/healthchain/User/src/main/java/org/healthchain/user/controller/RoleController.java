package org.healthchain.user.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.healthchain.common.constants.CommonConstants;
import org.healthchain.common.constants.ResponseConstant;
import org.healthchain.common.utils.OperationsUtil;
import org.healthchain.entity.RoleMaster;
import org.healthchain.entity.UserMaster;
import org.healthchain.pojo.Response;
import org.healthchain.pojo.ResponseAllData;
import org.healthchain.pojo.RoleEntityPojo;
import org.healthchain.services.MessageByLocaleService;
import org.healthchain.services.RoleService;
import org.healthchain.services.UserService;
import org.healthchain.services.constants.ServiceConstant;
import org.healthchain.user.constants.USERURLConstant;
import org.healthchain.validate.RoleEditValidator;
import org.healthchain.validate.RoleValidator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@CrossOrigin
@RestController
@RequestMapping(USERURLConstant.ROLE_ROOT_URL)
public class RoleController {
	
	private static final Log logger = LogFactory.getLog(RoleController.class);

	@Autowired
	private RoleService roleService;
	
	@Autowired
	private UserService userService;
	
	@Autowired
	private RoleValidator roleValidator;
	
	@Autowired
	private RoleEditValidator roleEditValidator;
	
	@Autowired
	private MessageByLocaleService messageByLocaleService;

	@RequestMapping(value = USERURLConstant.ADD_OR_EDIT_ROLE_URL, method = RequestMethod.POST, headers = CommonConstants.CONTENT_TYPE_APPLICATION_JSON)
	public ResponseEntity<Response> addRole(Locale locale,@RequestBody RoleMaster roleEntity,BindingResult bindingResult) {
		UserDetails userDetails = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		UserMaster userEntity = userService.findByUserName(userDetails.getUsername());
		Boolean isEmpty = OperationsUtil.checkNull(roleEntity);
		Response response = new Response();
		String type=null;
		if (!isEmpty) {
			try {
				if(roleEntity.getRoleID() == null || roleEntity.getRoleID().equals(0L)) {
					roleValidator.validate( roleEntity, bindingResult );
					if(bindingResult.hasErrors()) {
						List<FieldError> errors = bindingResult.getFieldErrors();
						StringBuffer message=new StringBuffer();  
						for (FieldError error : errors ) {
					    	message.append(error.getDefaultMessage()+CommonConstants.MESSAGE);
					    }
						response.setStatus(ResponseConstant.ERROR);
						response.setMessage(message.toString().substring(0,message.length()-5));
						response.setData(message.toString().substring(0,message.length()-5));
						return new ResponseEntity<Response>(response, HttpStatus.BAD_REQUEST);
					}
					type=USERURLConstant.ADD_TYPE;
					roleEntity.setActive(true);
					roleEntity.setCreatedOn(new Date());
					roleEntity.setModifiedOn(new Date());
					roleEntity.setCreatedBy(userEntity);
					roleEntity.setModifiedBy(userEntity);
					roleEntity.setDeleted(false);
				}else {
					roleEditValidator.validate( roleEntity, bindingResult );
					if(bindingResult.hasErrors()) {
						List<FieldError> errors = bindingResult.getFieldErrors();
						StringBuffer message=new StringBuffer();  
						for (FieldError error : errors ) {
					    	message.append(error.getDefaultMessage()+CommonConstants.MESSAGE);
					    }
						response.setStatus(ResponseConstant.ERROR);
						response.setMessage(message.toString().substring(0,message.length()-5));
						response.setData(message.toString().substring(0,message.length()-5));
						return new ResponseEntity<Response>(response, HttpStatus.BAD_REQUEST);
					}
					roleEntity.setActive(true);
					roleEntity.setDeleted(false);
					roleEntity.setModifiedBy(userEntity);
					roleEntity.setModifiedOn(new Date());
					type=USERURLConstant.EDIT_TYPE;
				}
				RoleMaster roleEntitys = roleService.findByroleName(roleEntity.getRoleName());
				if (roleEntitys == null) {
					try {
						roleService.saveOrUpdate(roleEntity);
					}catch (Exception e) {
						logger.error("Error:--", e);
						response.setStatus(ResponseConstant.ERROR);
						response.setMessage(messageByLocaleService.getMessage(USERURLConstant.ROLE_ERROR));
						response.setData(messageByLocaleService.getMessage(USERURLConstant.ROLE_ERROR));
						return new ResponseEntity<Response>(response, HttpStatus.NOT_ACCEPTABLE);
					}
					response.setStatus(ResponseConstant.SUCCESS);
					response.setMessage(messageByLocaleService.getMessage(USERURLConstant.ROLE_SUCCESS));
					response.setData(messageByLocaleService.getMessage(USERURLConstant.ROLE_SUCCESS));
				}else {
					if(roleEntitys.getRoleID().equals(roleEntity.getRoleID())) {
						roleEntity.setCreatedBy(roleEntitys.getCreatedBy());
						roleEntity.setCreatedOn(roleEntitys.getCreatedOn());
						try {
							roleService.saveOrUpdate(roleEntity);
						}catch (Exception e) {
							logger.error("Error:--", e);
							response.setStatus(ResponseConstant.ERROR);
							response.setMessage(messageByLocaleService.getMessage(USERURLConstant.ROLE_ERROR));
							response.setData(messageByLocaleService.getMessage(USERURLConstant.ROLE_ERROR));
							return new ResponseEntity<Response>(response, HttpStatus.NOT_ACCEPTABLE);
						}
						response.setStatus(ResponseConstant.SUCCESS);
						response.setMessage(messageByLocaleService.getMessage(USERURLConstant.ROLE_UPDATE));
						response.setData(messageByLocaleService.getMessage(USERURLConstant.ROLE_UPDATE));
					}else {
						response.setStatus(ResponseConstant.WARNING);
						response.setMessage(messageByLocaleService.getMessage(USERURLConstant.ROLE_EXIT));
						response.setData(messageByLocaleService.getMessage(USERURLConstant.ROLE_EXIT));
						return new ResponseEntity<Response>(response, HttpStatus.BAD_REQUEST);
					}
					
				}
				
			} catch (Exception e) {
				logger.error("Error:--", e);
				response.setStatus(ResponseConstant.ERROR);
				response.setMessage(messageByLocaleService.getMessage(USERURLConstant.ROLE_ERROR));
				response.setData(messageByLocaleService.getMessage(USERURLConstant.ROLE_ERROR));
				return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
			}
		}else {
			response.setStatus(ResponseConstant.ERROR);
			response.setMessage(messageByLocaleService.getMessage(USERURLConstant.ROLE_EXCEPTION));
			response.setData(messageByLocaleService.getMessage(USERURLConstant.ROLE_EXCEPTION));
			return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}

		if(type.equalsIgnoreCase(USERURLConstant.ADD_TYPE)) {
			return new ResponseEntity<Response>(response, HttpStatus.CREATED);
		}else {
			return new ResponseEntity<Response>(response, HttpStatus.OK);
		}
	}
	
	@RequestMapping(value = USERURLConstant.ALL_ROLE, method = RequestMethod.POST, headers = CommonConstants.CONTENT_TYPE_APPLICATION_JSON)
	public ResponseEntity<ResponseAllData> getAllRole(Locale locale) {
		ResponseAllData response = new ResponseAllData();
		try {
			List<RoleMaster> roleData=roleService.getAllActiveRecord();
			List<RoleEntityPojo> rolPojo=new ArrayList<RoleEntityPojo>();
			for(RoleMaster re:roleData) {
				if(!re.getRoleName().equalsIgnoreCase(ServiceConstant.AUTHORITY_ADMIN)) {
				RoleEntityPojo rep=new RoleEntityPojo(); 
				rep.setId(re.getRoleID());
				rep.setName(re.getRoleName());
				rolPojo.add(rep);
				}
			}
			response.setStatus(ResponseConstant.SUCCESS);
			response.setData(rolPojo);
		}catch (Exception e) {
			logger.error("Error:--", e);
			response.setStatus(ResponseConstant.ERROR);
			response.setData(messageByLocaleService.getMessage(USERURLConstant.ROLE_ERROR));
			return new ResponseEntity<ResponseAllData>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<ResponseAllData>(response,HttpStatus.OK);
	}
	
	
}
