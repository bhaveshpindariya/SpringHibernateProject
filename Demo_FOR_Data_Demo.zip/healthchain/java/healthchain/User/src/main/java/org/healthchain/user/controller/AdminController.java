package org.healthchain.user.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.healthchain.common.constants.CommonConstants;
import org.healthchain.common.constants.ResponseConstant;
import org.healthchain.common.utils.OperationsUtil;
import org.healthchain.entity.ClientMaster;
import org.healthchain.entity.DiagnosisMaster;
import org.healthchain.entity.DrugCompoundMaster;
import org.healthchain.entity.DrugManufacturersMaster;
import org.healthchain.entity.DrugsActiveSubstanceMaster;
import org.healthchain.entity.FCLocationMap;
import org.healthchain.entity.FacilityCenterMaster;
import org.healthchain.entity.LabReportsLevel1;
import org.healthchain.entity.LocationMaster;
import org.healthchain.entity.SpecialityMaster;
import org.healthchain.entity.TimeZoneMaster;
import org.healthchain.entity.UserMaster;
import org.healthchain.pojo.ClientPojo;
import org.healthchain.pojo.FecilityPojo;
import org.healthchain.pojo.LocationPojo;
import org.healthchain.pojo.Response;
import org.healthchain.pojo.SpecialityPojo;
import org.healthchain.pojo.TimeZonePojo;
import org.healthchain.services.ClientService;
import org.healthchain.services.DiagnosisService;
import org.healthchain.services.DrugCompoundService;
import org.healthchain.services.DrugManufacturersService;
import org.healthchain.services.DrugsActiveSubstanceService;
import org.healthchain.services.FCLocationMapService;
import org.healthchain.services.FacilityCenterService;
import org.healthchain.services.LabReportsLevel1Service;
import org.healthchain.services.LocationService;
import org.healthchain.services.MessageByLocaleService;
import org.healthchain.services.SpecialityService;
import org.healthchain.services.TimeZoneService;
import org.healthchain.services.UserService;
import org.healthchain.services.constants.ServiceConstant;
import org.healthchain.user.constants.USERURLConstant;
import org.healthchain.validate.ClientEditValidator;
import org.healthchain.validate.ClientValidator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@CrossOrigin
@RestController
@RequestMapping(USERURLConstant.ADMIN_ROOT_URL)
public class AdminController {
	
	private static final Log logger = LogFactory.getLog(AdminController.class);

	@Autowired
	private UserService userService;

	@Autowired
	private TimeZoneService timeZoneService;
	
	@Autowired
	private DiagnosisService diagnosisService;

	@Autowired
	private ClientService clientService;

	@Autowired
	private FacilityCenterService facilityCenterService;

	@Autowired
	private LocationService locationService;

	@Autowired
	private FCLocationMapService fcLocationMapService;

	@Autowired
	private SpecialityService specialityService;
	
	@Autowired
	private LabReportsLevel1Service labReportsLevel1Service;

	@Autowired
	private DrugsActiveSubstanceService drugsActiveSubstanceService;
	
	@Autowired
	private DrugManufacturersService drugManufacturersService;
	
	@Autowired
	private DrugCompoundService drugCompoundService;
	
	@Autowired
	private MessageByLocaleService messageByLocaleService;
	
	@Autowired
	private ClientValidator clientValidator;
	
	@Autowired
	private ClientEditValidator clientEditValidator;

	@RequestMapping(value = USERURLConstant.TIMEZONE_ADD_OR_EDIT_URL, method = RequestMethod.POST, headers = CommonConstants.CONTENT_TYPE_APPLICATION_JSON)
	public ResponseEntity<Response> addTimeZone(Locale locale, @RequestBody TimeZoneMaster timeZoneMaster) {
		Response response = new Response();
		UserDetails userDetails = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		UserMaster userEntity = userService.findByUserName(userDetails.getUsername());
		Boolean isEmpty = OperationsUtil.checkNull(timeZoneMaster);
		String type = null;
		if (!isEmpty) {
			try {
				if (timeZoneMaster.getUtcTimeZoneId() == null || timeZoneMaster.getUtcTimeZoneId().equals(0L)) {
					type = USERURLConstant.ADD_TYPE;
					timeZoneMaster.setActive(true);
					timeZoneMaster.setCreatedOn(new Date());
					timeZoneMaster.setModifiedOn(new Date());
					timeZoneMaster.setCreatedBy(userEntity);
					timeZoneMaster.setModifiedBy(userEntity);
					timeZoneMaster.setDeleted(false);
				} else {
					timeZoneMaster.setActive(true);
					timeZoneMaster.setDeleted(false);
					timeZoneMaster.setModifiedBy(userEntity);
					timeZoneMaster.setModifiedOn(new Date());
					type = USERURLConstant.EDIT_TYPE;
				}

				TimeZoneMaster timeZoneList = timeZoneService.findByAbbreviation(timeZoneMaster.getTimezoneAbbreviation());
				if (timeZoneList == null) {
					try {
						timeZoneMaster = timeZoneService.saveOrUpdate(timeZoneMaster);
					}catch (Exception e) {
						logger.error("Error:--", e);
						response.setStatus(ResponseConstant.ERROR);
						response.setMessage(messageByLocaleService.getMessage(USERURLConstant.TIMEZONE_ERROR));
						response.setData(messageByLocaleService.getMessage(USERURLConstant.TIMEZONE_ERROR));
						return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
					}
					List<TimeZoneMaster> timeZoneData = timeZoneService.getAllActiveRecord();
					List<TimeZonePojo> timeZonePojo = new ArrayList<TimeZonePojo>();
					for (TimeZoneMaster timezone : timeZoneData) {
						TimeZonePojo tzp = new TimeZonePojo();
						tzp.setUtcTimeZoneId(timezone.getUtcTimeZoneId());
						tzp.setCountryCode(timezone.getCountryCode());
						tzp.setCountryName(timezone.getCountryName());
						tzp.setTimezoneAbbreviation(timezone.getTimezoneAbbreviation());
						tzp.setTimezoneName(timezone.getTimezoneName());
						tzp.setUtcOffset(timezone.getUtcOffset());
						timeZonePojo.add(tzp);
					}
					response.setStatus(ResponseConstant.SUCCESS);
					response.setMessage(messageByLocaleService.getMessage(USERURLConstant.TIMEZONE_SUCCESS));
					response.setData(timeZonePojo);
				} else {
					if (timeZoneMaster.getUtcTimeZoneId().equals(timeZoneList.getUtcTimeZoneId())) {
						timeZoneMaster.setCreatedOn(timeZoneList.getCreatedOn());
						timeZoneMaster.setCreatedBy(timeZoneList.getCreatedBy());
						try {
							timeZoneMaster = timeZoneService.saveOrUpdate(timeZoneMaster);
						}catch (Exception e) {
							logger.error("Error:--", e);
							response.setStatus(ResponseConstant.ERROR);
							response.setMessage(messageByLocaleService.getMessage(USERURLConstant.TIMEZONE_ERROR));
							response.setData(messageByLocaleService.getMessage(USERURLConstant.TIMEZONE_ERROR));
							return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
						}
						List<TimeZoneMaster> timeZoneData = timeZoneService.getAllActiveRecord();
						List<TimeZonePojo> timeZonePojo = new ArrayList<TimeZonePojo>();
						for (TimeZoneMaster timezone : timeZoneData) {
							TimeZonePojo tzp = new TimeZonePojo();
							tzp.setUtcTimeZoneId(timezone.getUtcTimeZoneId());
							tzp.setCountryCode(timezone.getCountryCode());
							tzp.setCountryName(timezone.getCountryName());
							tzp.setTimezoneAbbreviation(timezone.getTimezoneAbbreviation());
							tzp.setTimezoneName(timezone.getTimezoneName());
							tzp.setUtcOffset(timezone.getUtcOffset());
							timeZonePojo.add(tzp);
						}
						response.setStatus(ResponseConstant.SUCCESS);
						response.setMessage(messageByLocaleService.getMessage(USERURLConstant.TIMEZONE_UPDATE));
						response.setData(timeZonePojo);
					} else {
						response.setStatus(ResponseConstant.WARNING);
						response.setMessage(messageByLocaleService.getMessage(USERURLConstant.TIMEZONE_EXIT));
						response.setData(messageByLocaleService.getMessage(USERURLConstant.TIMEZONE_EXIT));
						return new ResponseEntity<Response>(response, HttpStatus.BAD_REQUEST);
					}
				}
			} catch (Exception e) {
				logger.error("Error:--", e);
				response.setStatus(ResponseConstant.ERROR);
				response.setMessage(messageByLocaleService.getMessage(USERURLConstant.TIMEZONE_ERROR));
				response.setData(messageByLocaleService.getMessage(USERURLConstant.TIMEZONE_ERROR));
				return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
			}
		} else {
			response.setStatus(ResponseConstant.ERROR);
			response.setMessage(messageByLocaleService.getMessage(USERURLConstant.TIMEZONE_EXCEPTION));
			response.setData(messageByLocaleService.getMessage(USERURLConstant.TIMEZONE_EXCEPTION));
			return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);

		}
		if (type.equalsIgnoreCase(USERURLConstant.ADD_TYPE)) {
			return new ResponseEntity<Response>(response, HttpStatus.CREATED);
		} else {
			return new ResponseEntity<Response>(response, HttpStatus.OK);
		}
	}

	@RequestMapping(value = USERURLConstant.CLIENT_ADD_OR_EDIT_URL, method = RequestMethod.POST, headers = CommonConstants.CONTENT_TYPE_APPLICATION_JSON)
	public ResponseEntity<Response> addOrEditClient(Locale locale, @RequestBody ClientMaster clientMaster,BindingResult bindingResult) {
		Response response = new Response();
		UserDetails userDetails = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		UserMaster userEntity = userService.findByUserName(userDetails.getUsername());
		Boolean isEmpty = OperationsUtil.checkNull(clientMaster);
		String type = null;
		if (!isEmpty) {
			try {
				if (clientMaster.getClientID() == null || clientMaster.getClientID().equals(0L)) {
					clientValidator.validate( clientMaster, bindingResult );
					if(bindingResult.hasErrors()) {
						List<FieldError> errors = bindingResult.getFieldErrors();
						StringBuffer message=new StringBuffer();  
						for (FieldError error : errors ) {
					    	message.append(error.getDefaultMessage()+CommonConstants.MESSAGE);
					    }
						response.setStatus(ResponseConstant.ERROR);
						response.setMessage(message.toString().substring(0,message.length()-5));
						response.setData(message.toString().substring(0,message.length()-5));
						return new ResponseEntity<Response>(response, HttpStatus.BAD_REQUEST);
					}
					type = USERURLConstant.ADD_TYPE;
					clientMaster.setActive(true);
					clientMaster.setCreatedOn(new Date());
					clientMaster.setModifiedOn(new Date());
					clientMaster.setCreatedBy(userEntity);
					clientMaster.setModifiedBy(userEntity);
					clientMaster.setDeleted(false);
				} else {
					clientEditValidator.validate( clientMaster, bindingResult );
					if(bindingResult.hasErrors()) {
						List<FieldError> errors = bindingResult.getFieldErrors();
						StringBuffer message=new StringBuffer();  
						for (FieldError error : errors ) {
					    	message.append(error.getDefaultMessage()+CommonConstants.MESSAGE);
					    }
						response.setStatus(ResponseConstant.ERROR);
						response.setMessage(message.toString().substring(0,message.length()-5));
						response.setData(message.toString().substring(0,message.length()-5));
						return new ResponseEntity<Response>(response, HttpStatus.BAD_REQUEST);
					}
					clientMaster.setActive(true);
					clientMaster.setDeleted(false);
					clientMaster.setModifiedBy(userEntity);
					clientMaster.setModifiedOn(new Date());
					type = USERURLConstant.EDIT_TYPE;
				}

				ClientMaster clientMasterList = clientService.findByCenterName(clientMaster.getClientComapnyName());
				if (clientMasterList == null) {
					try {
						clientMaster = clientService.saveOrUpdate(clientMaster);
					}catch (Exception e) {
						logger.error("Error:--", e);
						response.setStatus(ResponseConstant.ERROR);
						response.setMessage(messageByLocaleService.getMessage(USERURLConstant.CLIENT_ERROR));
						response.setData(messageByLocaleService.getMessage(USERURLConstant.CLIENT_ERROR));
						return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
					}
					response.setStatus(ResponseConstant.SUCCESS);
					response.setMessage(messageByLocaleService.getMessage(USERURLConstant.CLIENT_SUCCESS));
					response.setData(messageByLocaleService.getMessage(USERURLConstant.CLIENT_SUCCESS));
				} else {
					if (clientMaster.getClientID().equals(clientMasterList.getClientID())) {
						clientMaster.setCreatedOn(clientMasterList.getCreatedOn());
						clientMaster.setCreatedBy(clientMasterList.getCreatedBy());
						try {
							clientMaster = clientService.saveOrUpdate(clientMaster);
						}catch (Exception e) {
							logger.error("Error:--", e);
							response.setStatus(ResponseConstant.ERROR);
							response.setMessage(messageByLocaleService.getMessage(USERURLConstant.CLIENT_ERROR));
							response.setData(messageByLocaleService.getMessage(USERURLConstant.CLIENT_ERROR));
							return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
						}
						response.setStatus(ResponseConstant.SUCCESS);
						response.setMessage(messageByLocaleService.getMessage(USERURLConstant.CLIENT_UPDATE));
						response.setData(messageByLocaleService.getMessage(USERURLConstant.CLIENT_UPDATE));
					} else {
						response.setStatus(ResponseConstant.WARNING);
						response.setMessage(messageByLocaleService.getMessage(USERURLConstant.CLIENT_EXIT));
						response.setData(messageByLocaleService.getMessage(USERURLConstant.CLIENT_EXIT));
						return new ResponseEntity<Response>(response, HttpStatus.BAD_REQUEST);
					}
				}
			} catch (Exception e) {
				logger.error("Error:--", e);
				response.setStatus(ResponseConstant.ERROR);
				response.setMessage(messageByLocaleService.getMessage(USERURLConstant.CLIENT_ERROR));
				response.setData(messageByLocaleService.getMessage(USERURLConstant.CLIENT_ERROR));
				return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
			}
		} else {
			response.setStatus(ResponseConstant.ERROR);
			response.setMessage(messageByLocaleService.getMessage(USERURLConstant.CLIENT_EXCEPTION));
			response.setData(messageByLocaleService.getMessage(USERURLConstant.CLIENT_EXCEPTION));
			return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);

		}
		if (type.equalsIgnoreCase(USERURLConstant.ADD_TYPE)) {
			return new ResponseEntity<Response>(response, HttpStatus.CREATED);
		} else {
			return new ResponseEntity<Response>(response, HttpStatus.OK);
		}
	}

	@RequestMapping(value = USERURLConstant.CLIENT_GET_URL, method = RequestMethod.POST, headers = CommonConstants.CONTENT_TYPE_APPLICATION_JSON)
	public ResponseEntity<Response> getAllClient(Locale locale) {
		Response response = new Response();
		try {
			List<ClientMaster> clientData = clientService.getAllActiveRecord();
			List<ClientPojo> ClientPojo = new ArrayList<ClientPojo>();
			for (ClientMaster cm : clientData) {
				ClientPojo cp = new ClientPojo();
				cp.setClientID(cm.getClientID());
				cp.setClientComapnyName(cm.getClientComapnyName());
				cp.setWebsiteURL(cm.getWebsiteURL());
				if (cm.getTimeZoneMaster() != null) {
					TimeZonePojo tzp = new TimeZonePojo();
					tzp.setUtcTimeZoneId(cm.getTimeZoneMaster().getUtcTimeZoneId());
					tzp.setCountryCode(cm.getTimeZoneMaster().getCountryCode());
					tzp.setCountryName(cm.getTimeZoneMaster().getCountryName());
					tzp.setTimezoneAbbreviation(cm.getTimeZoneMaster().getTimezoneAbbreviation());
					tzp.setTimezoneName(cm.getTimeZoneMaster().getTimezoneName());
					tzp.setUtcOffset(cm.getTimeZoneMaster().getUtcOffset());
					cp.setTimeZoneMaster(tzp);
				}
				ClientPojo.add(cp);
			}
			response.setStatus(ResponseConstant.SUCCESS);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_SUCCESS));
			response.setData(ClientPojo);
		} catch (Exception e) {
			logger.error("Error:--", e);
			response.setStatus(ResponseConstant.ERROR);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			response.setData(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Response>(response, HttpStatus.OK);
	}
	
	@RequestMapping(value = USERURLConstant.FACILITY_ADD_URL, method = RequestMethod.POST, headers = CommonConstants.CONTENT_TYPE_APPLICATION_JSON)
	public ResponseEntity<Response> addOrEditfacility(Locale locale,@RequestBody FacilityCenterMaster facilityCenterMaster) {
		Response response = new Response();
		UserDetails userDetails = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		UserMaster userEntity = userService.findByUserName(userDetails.getUsername());
		Boolean isEmpty = OperationsUtil.checkNull(facilityCenterMaster);
		if (!isEmpty) {
			try {
				FacilityCenterMaster facilityCenterList = facilityCenterService.findByCenterName(facilityCenterMaster.getFacilityCenterName(),facilityCenterMaster.getFacilityCenterType());
				if (facilityCenterList == null) {
					Set<LocationMaster> locationData = new HashSet<LocationMaster>();
					Set<LocationMaster> locationMaster = facilityCenterMaster.getLocationMaster();
					for (LocationMaster lm : locationMaster) {
						if(lm.getLocationID() == null || lm.getLocationID().equals(0L)) {
							lm.setActive(true);
							lm.setCreatedOn(new Date());
							lm.setModifiedOn(new Date());
							lm.setCreatedBy(userEntity);
							lm.setModifiedBy(userEntity);
							lm.setDeleted(false);
							try {
								lm = locationService.saveOrUpdate(lm);
							}catch (Exception e) {
								logger.error("Error:--", e);
								response.setStatus(ResponseConstant.ERROR);
								response.setMessage(messageByLocaleService.getMessage(USERURLConstant.FACILITY_ERROR));
								response.setData(messageByLocaleService.getMessage(USERURLConstant.FACILITY_ERROR));
								return new ResponseEntity<Response>(response, HttpStatus.NOT_ACCEPTABLE);
							}
							locationData.add(lm);
						}else {
							LocationMaster lms=locationService.get(lm.getLocationID());
							lm.setLocationID(lms.getLocationID());
							lm.setActive(true);
							lm.setModifiedOn(new Date());
							lm.setModifiedBy(userEntity);
							lm.setDeleted(false);
							try {
								lm = locationService.saveOrUpdate(lm);
							}catch (Exception e) {
								logger.error("Error:--", e);
								response.setStatus(ResponseConstant.ERROR);
								response.setMessage(messageByLocaleService.getMessage(USERURLConstant.FACILITY_ERROR));
								response.setData(messageByLocaleService.getMessage(USERURLConstant.FACILITY_ERROR));
								return new ResponseEntity<Response>(response, HttpStatus.NOT_ACCEPTABLE);
							}
							locationData.add(lm);
						}
					}
					facilityCenterMaster.setActive(true);
					facilityCenterMaster.setCreatedOn(new Date());
					facilityCenterMaster.setModifiedOn(new Date());
					facilityCenterMaster.setCreatedBy(userEntity);
					facilityCenterMaster.setModifiedBy(userEntity);
					facilityCenterMaster.setDeleted(false);
					facilityCenterMaster = facilityCenterService.saveOrUpdate(facilityCenterMaster);
					for (LocationMaster lmd : locationData) {
						FCLocationMap fcLocationMap = new FCLocationMap();
						fcLocationMap.setActive(true);
						fcLocationMap.setCreatedOn(new Date());
						fcLocationMap.setModifiedOn(new Date());
						fcLocationMap.setCreatedBy(userEntity);
						fcLocationMap.setModifiedBy(userEntity);
						fcLocationMap.setDeleted(false);
						fcLocationMap.setFacilityCenterMaster(facilityCenterMaster);
						fcLocationMap.setLocationMaster(lmd);
						fcLocationMap.setFcLocationName(facilityCenterMaster.getFcLocationName());
						fcLocationMap.setDoesOfferHomeservice(false);
						fcLocationMap.setHavechildDepartmentMapCount(0);
						try {
							fcLocationMapService.saveOrUpdate(fcLocationMap);
						}catch (Exception e) {
							logger.error("Error:--", e);
							response.setStatus(ResponseConstant.ERROR);
							response.setMessage(messageByLocaleService.getMessage(USERURLConstant.FACILITY_ERROR));
							response.setData(messageByLocaleService.getMessage(USERURLConstant.FACILITY_ERROR));
							return new ResponseEntity<Response>(response, HttpStatus.NOT_ACCEPTABLE);
						}
					}
					response.setStatus(ResponseConstant.SUCCESS);
					response.setMessage(messageByLocaleService.getMessage(USERURLConstant.FACILITY_SUCCESS));
					response.setData(messageByLocaleService.getMessage(USERURLConstant.FACILITY_SUCCESS));
				} else {
					response.setStatus(ResponseConstant.WARNING);
					response.setMessage(messageByLocaleService.getMessage(USERURLConstant.FACILITY_EXIT));
					response.setData(messageByLocaleService.getMessage(USERURLConstant.FACILITY_EXIT));
					return new ResponseEntity<Response>(response, HttpStatus.BAD_REQUEST);
				}
			} catch (Exception e) {
				logger.error("Error:--", e);
				response.setStatus(ResponseConstant.ERROR);
				response.setMessage(messageByLocaleService.getMessage(USERURLConstant.FACILITY_ERROR));
				response.setData(messageByLocaleService.getMessage(USERURLConstant.FACILITY_ERROR));
				return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
			}
		} else {
			response.setStatus(ResponseConstant.ERROR);
			response.setMessage(messageByLocaleService.getMessage(USERURLConstant.FACILITY_EXCEPTION));
			response.setData(messageByLocaleService.getMessage(USERURLConstant.FACILITY_EXCEPTION));
			return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);

		}
		return new ResponseEntity<Response>(response, HttpStatus.CREATED);

	}

	@RequestMapping(value = USERURLConstant.SPECIALITY_ADD_OR_EDIT_URL, method = RequestMethod.POST, headers = CommonConstants.CONTENT_TYPE_APPLICATION_JSON)
	public ResponseEntity<Response> addOrEditSpeciality(Locale locale, @RequestBody SpecialityMaster specialityMaster) {
		Response response = new Response();
		UserDetails userDetails = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		UserMaster userEntity = userService.findByUserName(userDetails.getUsername());
		Boolean isEmpty = OperationsUtil.checkNull(specialityMaster);
		String type = null;
		if (!isEmpty) {
			try {
				if (specialityMaster.getSpecialityID() == null || specialityMaster.getSpecialityID().equals(0L)) {
					type = USERURLConstant.ADD_TYPE;
					specialityMaster.setActive(true);
					specialityMaster.setCreatedOn(new Date());
					specialityMaster.setModifiedOn(new Date());
					specialityMaster.setCreatedBy(userEntity);
					specialityMaster.setModifiedBy(userEntity);
					specialityMaster.setDeleted(false);
				} else {
					specialityMaster.setActive(true);
					specialityMaster.setDeleted(false);
					specialityMaster.setModifiedBy(userEntity);
					specialityMaster.setModifiedOn(new Date());
					type = USERURLConstant.EDIT_TYPE;
				}
				SpecialityMaster speciality = specialityService.findByName(specialityMaster.getSpecialityName());
				if (speciality == null) {
					try {
						specialityService.saveOrUpdate(specialityMaster);
					}catch (Exception e) {
						logger.error("Error:--", e);
						response.setStatus(ResponseConstant.ERROR);
						response.setMessage(messageByLocaleService.getMessage(USERURLConstant.SPECIALITY_ERROR));
						response.setData(messageByLocaleService.getMessage(USERURLConstant.SPECIALITY_ERROR));
						return new ResponseEntity<Response>(response, HttpStatus.NOT_ACCEPTABLE);
					}
					response.setStatus(ResponseConstant.SUCCESS);
					response.setMessage(messageByLocaleService.getMessage(USERURLConstant.SPECIALITY_SUCCESS));
					response.setData(messageByLocaleService.getMessage(USERURLConstant.SPECIALITY_SUCCESS));
				} else {
					if (specialityMaster.getSpecialityID().equals(speciality.getSpecialityID())) {
						specialityMaster.setCreatedOn(speciality.getCreatedOn());
						specialityMaster.setCreatedBy(speciality.getCreatedBy());
						try {
							specialityService.saveOrUpdate(specialityMaster);
						}catch (Exception e) {
							logger.error("Error:--", e);
							response.setStatus(ResponseConstant.ERROR);
							response.setMessage(messageByLocaleService.getMessage(USERURLConstant.SPECIALITY_ERROR));
							response.setData(messageByLocaleService.getMessage(USERURLConstant.SPECIALITY_ERROR));
							return new ResponseEntity<Response>(response, HttpStatus.NOT_ACCEPTABLE);
						}
						response.setStatus(ResponseConstant.SUCCESS);
						response.setMessage(messageByLocaleService.getMessage(USERURLConstant.SPECIALITY_UPDATE));
						response.setData(messageByLocaleService.getMessage(USERURLConstant.SPECIALITY_UPDATE));
					} else {
						response.setStatus(ResponseConstant.WARNING);
						response.setMessage(messageByLocaleService.getMessage(USERURLConstant.SPECIALITY_EXIT));
						response.setData(messageByLocaleService.getMessage(USERURLConstant.SPECIALITY_EXIT));
						return new ResponseEntity<Response>(response, HttpStatus.BAD_REQUEST);
					}
				}
			} catch (Exception e) {
				logger.error("Error:--", e);
				response.setStatus(ResponseConstant.ERROR);
				response.setMessage(messageByLocaleService.getMessage(USERURLConstant.SPECIALITY_ERROR));
				response.setData(messageByLocaleService.getMessage(USERURLConstant.SPECIALITY_ERROR));
				return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
			}
		} else {
			response.setStatus(ResponseConstant.ERROR);
			response.setMessage(messageByLocaleService.getMessage(USERURLConstant.SPECIALITY_EXCEPTION));
			response.setData(messageByLocaleService.getMessage(USERURLConstant.SPECIALITY_EXCEPTION));
			return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);

		}
		if (type.equalsIgnoreCase(USERURLConstant.ADD_TYPE)) {
			return new ResponseEntity<Response>(response, HttpStatus.CREATED);
		} else {
			return new ResponseEntity<Response>(response, HttpStatus.OK);
		}
	}
	
	@RequestMapping(value = USERURLConstant.SPECIALITY_GET_URL, method = RequestMethod.POST, headers = CommonConstants.CONTENT_TYPE_APPLICATION_JSON)
	public ResponseEntity<Response> getAllSpeciality(Locale locale) {
		Response response = new Response();
		try {
			List<SpecialityMaster> SpecialityData = specialityService.getAllActiveRecord();
			List<SpecialityPojo> specialityPojo = new ArrayList<SpecialityPojo>();
			for (SpecialityMaster sm : SpecialityData) {
				SpecialityPojo sp = new SpecialityPojo();
				sp.setSpecialityID(sm.getSpecialityID());
				sp.setSpecialityName(sm.getSpecialityName());
				sp.setSpecialityCode(sm.getSpecialityCode() + "");
				specialityPojo.add(sp);
			}
			response.setStatus(ResponseConstant.SUCCESS);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_SUCCESS));
			response.setData(specialityPojo);
		} catch (Exception e) {
			logger.error("Error:--", e);
			response.setStatus(ResponseConstant.ERROR);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			response.setData(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Response>(response, HttpStatus.OK);
	}

	@RequestMapping(value = USERURLConstant.FACILITY_GET_URL, method = RequestMethod.POST, headers = CommonConstants.CONTENT_TYPE_APPLICATION_JSON)
	public ResponseEntity<Response> getAllfacility(Locale locale) {
		Response response = new Response();
		try {
			List<FacilityCenterMaster> facilityCenterMaster = facilityCenterService.getAllActiveRecord();
			List<FecilityPojo> fecilityPojo = new ArrayList<FecilityPojo>();
			for (FacilityCenterMaster fcm : facilityCenterMaster) {
				FecilityPojo fp = new FecilityPojo();
				fp.setFacilityCenterID(fcm.getFacilityCenterID());
				fp.setFacilityCenterName(fcm.getFacilityCenterName());
				List<FCLocationMap> fcLocationMap = fcLocationMapService.getLocation(fcm);
				List<LocationPojo> locationPojo = new ArrayList<LocationPojo>();
				for(FCLocationMap flm:fcLocationMap) {
					LocationMaster lm=flm.getLocationMaster();
					LocationPojo lp=new LocationPojo();
					lp.setLocationID(lm.getLocationID());
					lp.setAddressLine1(lm.getAddressLine1());
					lp.setAddressLine2(lm.getAddressLine2());
					lp.setAddressLine3(lm.getAddressLine3());
					lp.setArea(lm.getArea());
					lp.setCity(lm.getCity());
					lp.setState(lm.getState());
					lp.setZip(lm.getZip());
					lp.setCountry(lm.getCountry());
					lp.setFcLocationName(flm.getFcLocationName());
					lp.setFcLocationMapID(flm.getFcLocationMapID());
					lp.setMilestone1(lm.getMilestone1());
					lp.setMilestone2(lm.getMilestone2());
					TimeZoneMaster tzm = timeZoneService.get(lm.getTimeZoneMaster().getUtcTimeZoneId());
					TimeZonePojo tzp = new TimeZonePojo();
					tzp.setUtcTimeZoneId(tzm.getUtcTimeZoneId());
					tzp.setCountryCode(tzm.getCountryCode());
					tzp.setCountryName(tzm.getCountryName());
					tzp.setTimezoneAbbreviation(tzm.getTimezoneAbbreviation());
					tzp.setTimezoneName(tzm.getTimezoneName());
					tzp.setUtcOffset(tzm.getUtcOffset());
					lp.setTimeZoneMaster(tzp);
					locationPojo.add(lp);
				}
				fp.setData(locationPojo);
				fecilityPojo.add(fp);
			}
			response.setStatus(ResponseConstant.SUCCESS);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_SUCCESS));
			response.setData(fecilityPojo);
		} catch (Exception e) {
			logger.error("Error:--", e);
			response.setStatus(ResponseConstant.ERROR);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			response.setData(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Response>(response, HttpStatus.OK);

	}
	
	@RequestMapping(value = USERURLConstant.LABREPORT_ADD_OR_EDIT_URL, method = RequestMethod.POST, headers = CommonConstants.CONTENT_TYPE_APPLICATION_JSON)
	public ResponseEntity<Response> addOrEditLabreport(Locale locale, @RequestBody LabReportsLevel1 labReportsLevel1) {
		Response response = new Response();
		UserDetails userDetails = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		UserMaster userEntity = userService.findByUserName(userDetails.getUsername());
		Boolean isEmpty = OperationsUtil.checkNull(labReportsLevel1);
		String type = null;
		if (!isEmpty) {
			try {
				if (labReportsLevel1.getLabReportLevel1ID() == null || labReportsLevel1.getLabReportLevel1ID().equals(0L)) {
					type = USERURLConstant.ADD_TYPE;
					labReportsLevel1.setActive(true);
					labReportsLevel1.setCreatedOn(new Date());
					labReportsLevel1.setModifiedOn(new Date());
					labReportsLevel1.setCreatedBy(userEntity);
					labReportsLevel1.setModifiedBy(userEntity);
					labReportsLevel1.setDeleted(false);
				} else {
					labReportsLevel1.setActive(true);
					labReportsLevel1.setDeleted(false);
					labReportsLevel1.setModifiedBy(userEntity);
					labReportsLevel1.setModifiedOn(new Date());
					type = USERURLConstant.EDIT_TYPE;
				}
				if (labReportsLevel1.getLabReportLevel1ID() == null || labReportsLevel1.getLabReportLevel1ID().equals(0L)) {
					try {
						labReportsLevel1Service.saveOrUpdate(labReportsLevel1);
					}catch (Exception e) {
						logger.error("Error:--", e);
						response.setStatus(ResponseConstant.ERROR);
						response.setMessage(messageByLocaleService.getMessage(USERURLConstant.LAB1_ERROR));
						response.setData(messageByLocaleService.getMessage(USERURLConstant.LAB1_ERROR));
						return new ResponseEntity<Response>(response, HttpStatus.NOT_ACCEPTABLE);
					}
					response.setStatus(ResponseConstant.SUCCESS);
					response.setMessage(messageByLocaleService.getMessage(USERURLConstant.LAB1_SUCCESS));
					response.setData(messageByLocaleService.getMessage(USERURLConstant.LAB1_SUCCESS));
				} else {
					LabReportsLevel1 labReportsLevel12=labReportsLevel1Service.findNames(labReportsLevel1.getLrl1Name());
					if (labReportsLevel1.getLabReportLevel1ID().equals(labReportsLevel12.getLabReportLevel1ID())) {
						labReportsLevel1.setCreatedOn(labReportsLevel12.getCreatedOn());
						labReportsLevel1.setCreatedBy(labReportsLevel12.getCreatedBy());
						try {
							labReportsLevel1Service.saveOrUpdate(labReportsLevel1);
						}catch (Exception e) {
							logger.error("Error:--", e);
							response.setStatus(ResponseConstant.ERROR);
							response.setMessage(messageByLocaleService.getMessage(USERURLConstant.LAB1_ERROR));
							response.setData(messageByLocaleService.getMessage(USERURLConstant.LAB1_ERROR));
							return new ResponseEntity<Response>(response, HttpStatus.NOT_ACCEPTABLE);
						}
						response.setStatus(ResponseConstant.SUCCESS);
						response.setMessage(messageByLocaleService.getMessage(USERURLConstant.LAB1_UPDATE));
						response.setData(messageByLocaleService.getMessage(USERURLConstant.LAB1_UPDATE));
					} else {
						response.setStatus(ResponseConstant.WARNING);
						response.setMessage(messageByLocaleService.getMessage(USERURLConstant.LAB1_EXIT));
						response.setData(messageByLocaleService.getMessage(USERURLConstant.LAB1_EXIT));
						return new ResponseEntity<Response>(response, HttpStatus.BAD_REQUEST);
					}
					
				}
			} catch (Exception e) {
				logger.error("Error:--", e);
				response.setStatus(ResponseConstant.ERROR);
				response.setMessage(messageByLocaleService.getMessage(USERURLConstant.LAB1_ERROR));
				response.setData(messageByLocaleService.getMessage(USERURLConstant.LAB1_ERROR));
				return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
			}
		} else {
			response.setStatus(ResponseConstant.ERROR);
			response.setMessage(messageByLocaleService.getMessage(USERURLConstant.LAB1_EXCEPTION));
			response.setData(messageByLocaleService.getMessage(USERURLConstant.LAB1_EXCEPTION));
			return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);

		}
		if (type.equalsIgnoreCase(USERURLConstant.ADD_TYPE)) {
			return new ResponseEntity<Response>(response, HttpStatus.CREATED);
		} else {
			return new ResponseEntity<Response>(response, HttpStatus.OK);
		}
	}
	
	@RequestMapping(value = USERURLConstant.DIGNSOSIS_ADD_OR_EDIT_URL, method = RequestMethod.POST, headers = CommonConstants.CONTENT_TYPE_APPLICATION_JSON)
	public ResponseEntity<Response> addOrEditDignsosis(Locale locale, @RequestBody DiagnosisMaster diagnosisMaster) {
		Response response = new Response();
		UserDetails userDetails = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		UserMaster userEntity = userService.findByUserName(userDetails.getUsername());
		Boolean isEmpty = OperationsUtil.checkNull(diagnosisMaster);
		String type = null;
		if (!isEmpty) {
			try {
				if (diagnosisMaster.getDiagnosisID() == null || diagnosisMaster.getDiagnosisID().equals(0L)) {
					type = USERURLConstant.ADD_TYPE;
					diagnosisMaster.setActive(true);
					diagnosisMaster.setCreatedOn(new Date());
					diagnosisMaster.setModifiedOn(new Date());
					diagnosisMaster.setCreatedBy(userEntity);
					diagnosisMaster.setModifiedBy(userEntity);
					diagnosisMaster.setDeleted(false);
				} else {
					diagnosisMaster.setActive(true);
					diagnosisMaster.setDeleted(false);
					diagnosisMaster.setModifiedBy(userEntity);
					diagnosisMaster.setModifiedOn(new Date());
					type = USERURLConstant.EDIT_TYPE;
				}
				DiagnosisMaster diagnosisMaster1=diagnosisService.findName(diagnosisMaster.getDiagnosiseName());
				if (diagnosisMaster1 == null) {
					try {
						diagnosisService.saveOrUpdate(diagnosisMaster);
					}catch (Exception e) {
						logger.error("Error:--", e);
						response.setStatus(ResponseConstant.ERROR);
						response.setMessage(messageByLocaleService.getMessage(USERURLConstant.DIGNSOSIS_ERROR));
						response.setData(messageByLocaleService.getMessage(USERURLConstant.DIGNSOSIS_ERROR));
						return new ResponseEntity<Response>(response, HttpStatus.NOT_ACCEPTABLE);
					}
					response.setStatus(ResponseConstant.SUCCESS);
					response.setMessage(messageByLocaleService.getMessage(USERURLConstant.DIGNSOSIS_SUCCESS));
					response.setData(messageByLocaleService.getMessage(USERURLConstant.DIGNSOSIS_SUCCESS));
				} else {
					if (diagnosisMaster1.getDiagnosisID().equals(diagnosisMaster.getDiagnosisID())) {
						diagnosisMaster.setCreatedOn(diagnosisMaster1.getCreatedOn());
						diagnosisMaster.setCreatedBy(diagnosisMaster1.getCreatedBy());
						try {
							diagnosisService.saveOrUpdate(diagnosisMaster);
						}catch (Exception e) {
							logger.error("Error:--", e);
							response.setStatus(ResponseConstant.ERROR);
							response.setMessage(messageByLocaleService.getMessage(USERURLConstant.DIGNSOSIS_ERROR));
							response.setData(messageByLocaleService.getMessage(USERURLConstant.DIGNSOSIS_ERROR));
							return new ResponseEntity<Response>(response, HttpStatus.NOT_ACCEPTABLE);
						}
						response.setStatus(ResponseConstant.SUCCESS);
						response.setMessage(messageByLocaleService.getMessage(USERURLConstant.DIGNSOSIS_UPDATE));
						response.setData(messageByLocaleService.getMessage(USERURLConstant.DIGNSOSIS_UPDATE));
					} else {
						response.setStatus(ResponseConstant.WARNING);
						response.setMessage(messageByLocaleService.getMessage(USERURLConstant.DIGNSOSIS_EXIT));
						response.setData(messageByLocaleService.getMessage(USERURLConstant.DIGNSOSIS_EXIT));
						return new ResponseEntity<Response>(response, HttpStatus.BAD_REQUEST);
					}
				}
			} catch (Exception e) {
				logger.error("Error:--", e);
				response.setStatus(ResponseConstant.ERROR);
				response.setMessage(messageByLocaleService.getMessage(USERURLConstant.DIGNSOSIS_ERROR));
				response.setData(messageByLocaleService.getMessage(USERURLConstant.DIGNSOSIS_ERROR));
				return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
			}
		} else {
			response.setStatus(ResponseConstant.ERROR);
			response.setMessage(messageByLocaleService.getMessage(USERURLConstant.DIGNSOSIS_EXCEPTION));
			response.setData(messageByLocaleService.getMessage(USERURLConstant.DIGNSOSIS_EXCEPTION));
			return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);

		}
		if (type.equalsIgnoreCase(USERURLConstant.ADD_TYPE)) {
			return new ResponseEntity<Response>(response, HttpStatus.CREATED);
		} else {
			return new ResponseEntity<Response>(response, HttpStatus.OK);
		}
	}
	
	@RequestMapping(value = USERURLConstant.DRUGMANUFACTURERS_ADD_OR_EDIT_URL, method = RequestMethod.POST, headers = CommonConstants.CONTENT_TYPE_APPLICATION_JSON)
	public ResponseEntity<Response> addOrEditDrugManufacturers(Locale locale, @RequestBody DrugManufacturersMaster drugManufacturersMaster) {
		Response response = new Response();
		UserDetails userDetails = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		UserMaster userEntity = userService.findByUserName(userDetails.getUsername());
		Boolean isEmpty = OperationsUtil.checkNull(drugManufacturersMaster);
		String type = null;
		if (!isEmpty) {
			try {
				if (drugManufacturersMaster.getDrugMfgrID() == null || drugManufacturersMaster.getDrugMfgrID().equals(0L)) {
					type = USERURLConstant.ADD_TYPE;
					drugManufacturersMaster.setActive(true);
					drugManufacturersMaster.setCreatedOn(new Date());
					drugManufacturersMaster.setModifiedOn(new Date());
					drugManufacturersMaster.setCreatedBy(userEntity);
					drugManufacturersMaster.setModifiedBy(userEntity);
					drugManufacturersMaster.setDeleted(false);
				} else {
					drugManufacturersMaster.setActive(true);
					drugManufacturersMaster.setDeleted(false);
					drugManufacturersMaster.setModifiedBy(userEntity);
					drugManufacturersMaster.setModifiedOn(new Date());
					type = USERURLConstant.EDIT_TYPE;
				}
				DrugManufacturersMaster drugManufact = drugManufacturersService.findData(drugManufacturersMaster.getDrugMfgrName());
				if (drugManufact == null) {
					try {
						drugManufacturersService.saveOrUpdate(drugManufacturersMaster);
					}catch (Exception e) {
						logger.error("Error:--", e);
						response.setStatus(ResponseConstant.ERROR);
						response.setMessage(messageByLocaleService.getMessage(USERURLConstant.DRUGMANUFACTURERS_ERROR));
						response.setData(messageByLocaleService.getMessage(USERURLConstant.DRUGMANUFACTURERS_ERROR));
						return new ResponseEntity<Response>(response, HttpStatus.NOT_ACCEPTABLE);
					}
					response.setStatus(ResponseConstant.SUCCESS);
					response.setMessage(messageByLocaleService.getMessage(USERURLConstant.DRUGMANUFACTURERS_SUCCESS));
					response.setData(messageByLocaleService.getMessage(USERURLConstant.DRUGMANUFACTURERS_SUCCESS));
				} else {
					if (drugManufact.getDrugMfgrID().equals(drugManufacturersMaster.getDrugMfgrID())) {
						drugManufacturersMaster.setCreatedOn(drugManufact.getCreatedOn());
						drugManufacturersMaster.setCreatedBy(drugManufact.getCreatedBy());
						try {
							drugManufacturersService.saveOrUpdate(drugManufacturersMaster);
						}catch (Exception e) {
							logger.error("Error:--", e);
							response.setStatus(ResponseConstant.ERROR);
							response.setMessage(messageByLocaleService.getMessage(USERURLConstant.DRUGMANUFACTURERS_ERROR));
							response.setData(messageByLocaleService.getMessage(USERURLConstant.DRUGMANUFACTURERS_ERROR));
							return new ResponseEntity<Response>(response, HttpStatus.NOT_ACCEPTABLE);
						}
						response.setStatus(ResponseConstant.SUCCESS);
						response.setMessage(messageByLocaleService.getMessage(USERURLConstant.DRUGMANUFACTURERS_UPDATE));
						response.setData(messageByLocaleService.getMessage(USERURLConstant.DRUGMANUFACTURERS_UPDATE));
					} else {
						response.setStatus(ResponseConstant.WARNING);
						response.setMessage(messageByLocaleService.getMessage(USERURLConstant.DRUGMANUFACTURERS_EXIT));
						response.setData(messageByLocaleService.getMessage(USERURLConstant.DRUGMANUFACTURERS_EXIT));
						return new ResponseEntity<Response>(response, HttpStatus.BAD_REQUEST);
					}
				}
			} catch (Exception e) {
				logger.error("Error:--", e);
				response.setStatus(ResponseConstant.ERROR);
				response.setMessage(messageByLocaleService.getMessage(USERURLConstant.DRUGMANUFACTURERS_ERROR));
				response.setData(messageByLocaleService.getMessage(USERURLConstant.DRUGMANUFACTURERS_ERROR));
				return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
			}
		} else {
			response.setStatus(ResponseConstant.ERROR);
			response.setMessage(messageByLocaleService.getMessage(USERURLConstant.DRUGMANUFACTURERS_EXCEPTION));
			response.setData(messageByLocaleService.getMessage(USERURLConstant.DRUGMANUFACTURERS_EXCEPTION));
			return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);

		}
		if (type.equalsIgnoreCase(USERURLConstant.ADD_TYPE)) {
			return new ResponseEntity<Response>(response, HttpStatus.CREATED);
		} else {
			return new ResponseEntity<Response>(response, HttpStatus.OK);
		}
	}
	
	@RequestMapping(value = USERURLConstant.DRUGSACTIVESUBSTANCEMASTER_ADD_OR_EDIT_URL, method = RequestMethod.POST, headers = CommonConstants.CONTENT_TYPE_APPLICATION_JSON)
	public ResponseEntity<Response> addOrEditdrugsActiveSubstanceMaster(Locale locale, @RequestBody DrugsActiveSubstanceMaster drugsActiveSubstanceMaster) {
		Response response = new Response();
		UserDetails userDetails = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		UserMaster userEntity = userService.findByUserName(userDetails.getUsername());
		Boolean isEmpty = OperationsUtil.checkNull(drugsActiveSubstanceMaster);
		String type = null;
		if (!isEmpty) {
			try {
				if (drugsActiveSubstanceMaster.getDrugsActiveSubstanceID() == null || drugsActiveSubstanceMaster.getDrugsActiveSubstanceID().equals(0L)) {
					type = USERURLConstant.ADD_TYPE;
					drugsActiveSubstanceMaster.setActive(true);
					drugsActiveSubstanceMaster.setCreatedOn(new Date());
					drugsActiveSubstanceMaster.setModifiedOn(new Date());
					drugsActiveSubstanceMaster.setCreatedBy(userEntity);
					drugsActiveSubstanceMaster.setModifiedBy(userEntity);
					drugsActiveSubstanceMaster.setDeleted(false);
				} else {
					drugsActiveSubstanceMaster.setActive(true);
					drugsActiveSubstanceMaster.setDeleted(false);
					drugsActiveSubstanceMaster.setModifiedBy(userEntity);
					drugsActiveSubstanceMaster.setModifiedOn(new Date());
					type = USERURLConstant.EDIT_TYPE;
				}
				DrugsActiveSubstanceMaster drugsActives = drugsActiveSubstanceService.findData(drugsActiveSubstanceMaster.getDasName());
				if (drugsActives == null) {
					try {
						drugsActiveSubstanceService.saveOrUpdate(drugsActiveSubstanceMaster);
					}catch (Exception e) {
						logger.error("Error:--", e);
						response.setStatus(ResponseConstant.ERROR);
						response.setMessage(messageByLocaleService.getMessage(USERURLConstant.DRUGSACTIVESUBSTANCE_ERROR));
						response.setData(messageByLocaleService.getMessage(USERURLConstant.DRUGSACTIVESUBSTANCE_ERROR));
						return new ResponseEntity<Response>(response, HttpStatus.NOT_ACCEPTABLE);
					}
					response.setStatus(ResponseConstant.SUCCESS);
					response.setMessage(messageByLocaleService.getMessage(USERURLConstant.DRUGSACTIVESUBSTANCE_SUCCESS));
					response.setData(messageByLocaleService.getMessage(USERURLConstant.DRUGSACTIVESUBSTANCE_SUCCESS));
				} else {
					if (drugsActives.getDrugsActiveSubstanceID().equals(drugsActiveSubstanceMaster.getDrugsActiveSubstanceID())) {
						drugsActiveSubstanceMaster.setCreatedOn(drugsActives.getCreatedOn());
						drugsActiveSubstanceMaster.setCreatedBy(drugsActives.getCreatedBy());
						try {
							drugsActiveSubstanceService.saveOrUpdate(drugsActiveSubstanceMaster);
						}catch (Exception e) {
							logger.error("Error:--", e);
							response.setStatus(ResponseConstant.ERROR);
							response.setMessage(messageByLocaleService.getMessage(USERURLConstant.DRUGSACTIVESUBSTANCE_ERROR));
							response.setData(messageByLocaleService.getMessage(USERURLConstant.DRUGSACTIVESUBSTANCE_ERROR));
							return new ResponseEntity<Response>(response, HttpStatus.NOT_ACCEPTABLE);
						}
						response.setStatus(ResponseConstant.SUCCESS);
						response.setMessage(messageByLocaleService.getMessage(USERURLConstant.DRUGSACTIVESUBSTANCE_UPDATE));
						response.setData(messageByLocaleService.getMessage(USERURLConstant.DRUGSACTIVESUBSTANCE_UPDATE));
					} else {
						response.setStatus(ResponseConstant.WARNING);
						response.setMessage(messageByLocaleService.getMessage(USERURLConstant.DRUGSACTIVESUBSTANCE_EXIT));
						response.setData(messageByLocaleService.getMessage(USERURLConstant.DRUGSACTIVESUBSTANCE_EXIT));
						return new ResponseEntity<Response>(response, HttpStatus.BAD_REQUEST);
					}
				}
			} catch (Exception e) {
				logger.error("Error:--", e);
				response.setStatus(ResponseConstant.ERROR);
				response.setMessage(messageByLocaleService.getMessage(USERURLConstant.DRUGSACTIVESUBSTANCE_ERROR));
				response.setData(messageByLocaleService.getMessage(USERURLConstant.DRUGSACTIVESUBSTANCE_ERROR));
				return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
			}
		} else {
			response.setStatus(ResponseConstant.ERROR);
			response.setMessage(messageByLocaleService.getMessage(USERURLConstant.DRUGSACTIVESUBSTANCE_EXCEPTION));
			response.setData(messageByLocaleService.getMessage(USERURLConstant.DRUGSACTIVESUBSTANCE_EXCEPTION));
			return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);

		}
		if (type.equalsIgnoreCase(USERURLConstant.ADD_TYPE)) {
			return new ResponseEntity<Response>(response, HttpStatus.CREATED);
		} else {
			return new ResponseEntity<Response>(response, HttpStatus.OK);
		}
	}
	
	@RequestMapping(value = USERURLConstant.DRUGCOMPOUND_ADD_OR_EDIT_URL, method = RequestMethod.POST, headers = CommonConstants.CONTENT_TYPE_APPLICATION_JSON)
	public ResponseEntity<Response> addOrEditdrugCompound(Locale locale, @RequestBody DrugCompoundMaster drugCompoundMaster) {
		Response response = new Response();
		UserDetails userDetails = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		UserMaster userEntity = userService.findByUserName(userDetails.getUsername());
		Boolean isEmpty = OperationsUtil.checkNull(drugCompoundMaster);
		String type = null;
		if (!isEmpty) {
			try {
				if (drugCompoundMaster.getDrugCompoundID() == null || drugCompoundMaster.getDrugCompoundID().equals(0L)) {
					type = USERURLConstant.ADD_TYPE;
					drugCompoundMaster.setActive(true);
					drugCompoundMaster.setCreatedOn(new Date());
					drugCompoundMaster.setModifiedOn(new Date());
					drugCompoundMaster.setCreatedBy(userEntity);
					drugCompoundMaster.setModifiedBy(userEntity);
					drugCompoundMaster.setDeleted(false);
				} else {
					drugCompoundMaster.setActive(true);
					drugCompoundMaster.setDeleted(false);
					drugCompoundMaster.setModifiedBy(userEntity);
					drugCompoundMaster.setModifiedOn(new Date());
					type = USERURLConstant.EDIT_TYPE;
				}
				DrugCompoundMaster drugcompound = drugCompoundService.findData(drugCompoundMaster.getDrugCompoundName());
				if (drugcompound == null) {
					try {
						drugCompoundService.saveOrUpdate(drugCompoundMaster);
					}catch (Exception e) {
						logger.error("Error:--", e);
						response.setStatus(ResponseConstant.ERROR);
						response.setMessage(messageByLocaleService.getMessage(USERURLConstant.DRUGCOMPOUND_ERROR));
						response.setData(messageByLocaleService.getMessage(USERURLConstant.DRUGCOMPOUND_ERROR));
						return new ResponseEntity<Response>(response, HttpStatus.NOT_ACCEPTABLE);
					}
					response.setStatus(ResponseConstant.SUCCESS);
					response.setMessage(messageByLocaleService.getMessage(USERURLConstant.DRUGCOMPOUND_SUCCESS));
					response.setData(messageByLocaleService.getMessage(USERURLConstant.DRUGCOMPOUND_SUCCESS));
				} else {
					if (drugcompound.getDrugCompoundID().equals(drugCompoundMaster.getDrugCompoundID())) {
						drugCompoundMaster.setCreatedOn(drugcompound.getCreatedOn());
						drugCompoundMaster.setCreatedBy(drugcompound.getCreatedBy());
						try {
							drugCompoundService.saveOrUpdate(drugCompoundMaster);
						}catch (Exception e) {
							logger.error("Error:--", e);
							response.setStatus(ResponseConstant.ERROR);
							response.setMessage(messageByLocaleService.getMessage(USERURLConstant.DRUGCOMPOUND_ERROR));
							response.setData(messageByLocaleService.getMessage(USERURLConstant.DRUGCOMPOUND_ERROR));
							return new ResponseEntity<Response>(response, HttpStatus.NOT_ACCEPTABLE);
						}
						response.setStatus(ResponseConstant.SUCCESS);
						response.setMessage(messageByLocaleService.getMessage(USERURLConstant.DRUGCOMPOUND_UPDATE));
						response.setData(messageByLocaleService.getMessage(USERURLConstant.DRUGCOMPOUND_UPDATE));
					} else {
						response.setStatus(ResponseConstant.WARNING);
						response.setMessage(messageByLocaleService.getMessage(USERURLConstant.DRUGCOMPOUND_EXIT));
						response.setData(messageByLocaleService.getMessage(USERURLConstant.DRUGCOMPOUND_EXIT));
						return new ResponseEntity<Response>(response, HttpStatus.BAD_REQUEST);
					}
				}
			} catch (Exception e) {
				logger.error("Error:--", e);
				response.setStatus(ResponseConstant.ERROR);
				response.setMessage(messageByLocaleService.getMessage(USERURLConstant.DRUGCOMPOUND_ERROR));
				response.setData(messageByLocaleService.getMessage(USERURLConstant.DRUGCOMPOUND_ERROR));
				return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
			}
		} else {
			response.setStatus(ResponseConstant.ERROR);
			response.setMessage(messageByLocaleService.getMessage(USERURLConstant.DRUGCOMPOUND_EXCEPTION));
			response.setData(messageByLocaleService.getMessage(USERURLConstant.DRUGCOMPOUND_EXCEPTION));
			return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);

		}
		if (type.equalsIgnoreCase(USERURLConstant.ADD_TYPE)) {
			return new ResponseEntity<Response>(response, HttpStatus.CREATED);
		} else {
			return new ResponseEntity<Response>(response, HttpStatus.OK);
		}
	}
}
