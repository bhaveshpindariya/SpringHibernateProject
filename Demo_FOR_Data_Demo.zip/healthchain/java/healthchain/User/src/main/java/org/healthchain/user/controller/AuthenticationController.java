package org.healthchain.user.controller;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.security.SecureRandom;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.healthchain.common.constants.CommonConstants;
import org.healthchain.common.constants.ResponseConstant;
import org.healthchain.common.utils.ApiUtil;
import org.healthchain.common.utils.HyperledgerApiUtil;
import org.healthchain.common.utils.OperationsUtil;
import org.healthchain.entity.DeviceDetail;
import org.healthchain.entity.FCLProviderMap;
import org.healthchain.entity.FCLocationMap;
import org.healthchain.entity.PatientMaster;
import org.healthchain.entity.PersonMaster;
import org.healthchain.entity.ProviderMaster;
import org.healthchain.entity.RoleMaster;
import org.healthchain.entity.SpecialityMaster;
import org.healthchain.entity.SpecialityProviderMaster;
import org.healthchain.entity.UserMaster;
import org.healthchain.entity.UserRoleEntity;
import org.healthchain.pojo.Response;
import org.healthchain.pojo.UserEntityPojo;
import org.healthchain.services.DeviceDetailService;
import org.healthchain.services.EmailService;
import org.healthchain.services.FCLProviderService;
import org.healthchain.services.MessageByLocaleService;
import org.healthchain.services.PatientService;
import org.healthchain.services.PersonService;
import org.healthchain.services.ProviderService;
import org.healthchain.services.RoleService;
import org.healthchain.services.SpecialityProviderService;
import org.healthchain.services.UserRoleService;
import org.healthchain.services.UserService;
import org.healthchain.services.constants.ServiceConstant;
import org.healthchain.user.constants.USERURLConstant;
import org.healthchain.validate.ChangePasswordValidator;
import org.healthchain.validate.DoctorRegistrationValidator;
import org.healthchain.validate.ForgotPasswordValidator;
import org.healthchain.validate.LoginValidator;
import org.healthchain.validate.UserRegistrationValidator;
import org.healthchain.validate.UserValidator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import net.sf.json.JSONObject;

@CrossOrigin
@RestController
@RequestMapping(USERURLConstant.AUTHENTICATION_USER_ROOT_URL)
public class AuthenticationController {
	
	private static final Log logger = LogFactory.getLog(AuthenticationController.class);
	
	@Autowired
	private UserService userService;
	
	@Autowired
    private UserValidator userValidator;
	
	@Autowired
    private ForgotPasswordValidator forgotPasswordValidator;
	
	@Autowired
    private ChangePasswordValidator changePasswordValidator;
	
	@Autowired
    private LoginValidator loginValidator;
	
	@Autowired
    private DoctorRegistrationValidator doctorRegistrationValidator;
	
	@Autowired
    private UserRegistrationValidator userRegistrationValidator;
	
	@Autowired
    private ServletContext servletContext;
	
	@Autowired
	private PersonService personService;

	@Autowired
	private RoleService roleService;
	
	@Autowired
	private UserRoleService userRoleService;
	
	@Autowired
	private DeviceDetailService deviceDetailService;
	
	@Autowired
    private EmailService emailService;
	
	@Autowired
    private ProviderService providerService;
	
	@Autowired
    private FCLProviderService fclProviderService;
	
	@Autowired
    private PatientService patientService;
	
	@Autowired
    private SpecialityProviderService specialityProviderService;
	
	@Autowired
	private MessageByLocaleService messageByLocaleService;

	@RequestMapping(value = USERURLConstant.USER_REGISTRATION, method = RequestMethod.POST, headers = CommonConstants.CONTENT_TYPE_APPLICATION_JSON)
	public ResponseEntity<Response> userRegistration(Locale locale,@RequestBody UserMaster userEntity,BindingResult bindingResult,HttpServletRequest req) {

		Boolean isEmpty = OperationsUtil.checkNull(userEntity);
		Response response = new Response();
		if (!isEmpty) {
			try {
				RoleMaster roleEntity=roleService.findByroleName(ServiceConstant.PATIENT_AUTHORITY);
				userEntity.setRoleName(roleEntity.getRoleName());
				userValidator.validate( userEntity, bindingResult );
				if(bindingResult.hasErrors()) {
					List<FieldError> errors = bindingResult.getFieldErrors();
					StringBuffer message=new StringBuffer();  
					for (FieldError error : errors ) {
				    	message.append(error.getDefaultMessage()+CommonConstants.MESSAGE);
				    }
					response.setStatus(ResponseConstant.ERROR);
					response.setMessage(message.toString().substring(0,message.length()-5));
					response.setData(message.toString().substring(0,message.length()-5));
					return new ResponseEntity<Response>(response, HttpStatus.BAD_REQUEST);
				}
				UserMaster userEntityName = userService.findByUserName(userEntity.getUserName());
				UserMaster userEntityEmail = userService.findByUserEmail(userEntity.getUserEmail());
				if (userEntityName == null && userEntityEmail == null) {
					try {
						String activeLink=OperationsUtil.getURL(req, userEntity.getUserEmail());
						emailService.sendEmail(userEntity.getUserEmail(),OperationsUtil.convertLink(activeLink),ServiceConstant.USER_ACTIVATION_SUBJECT);
					}catch (Exception e) {
						logger.error("Error:--", e);
						response.setStatus(ResponseConstant.ERROR);
						response.setMessage(messageByLocaleService.getMessage(ServiceConstant.EMAIL_EXCEPTION));
						response.setData(messageByLocaleService.getMessage(ServiceConstant.EMAIL_EXCEPTION));
						return new ResponseEntity<Response>(response, HttpStatus.NOT_ACCEPTABLE);
					}
					
					userEntity.setActive(false);
					userEntity.setCreatedBy(userEntity);
					userEntity.setModifiedBy(userEntity);
					userEntity.setCreatedOn(new Date());
					userEntity.setModifiedOn(new Date());
					userEntity.setDeleted(false);
					if(userEntity.getDeviceType().equalsIgnoreCase(CommonConstants.DEVICE_ANDROID_TYPE) || userEntity.getDeviceType().equalsIgnoreCase(CommonConstants.DEVICE_IOS_TYPE)) {
						Set<DeviceDetail> deviceDetailList=new HashSet<DeviceDetail>();
						DeviceDetail deviceDetail=new DeviceDetail();
						deviceDetail.setUserMaster(userEntity);
						deviceDetail.setActive(true);
						deviceDetail.setDeleted(false);
						deviceDetail.setCreatedOn(new Date());
						deviceDetail.setCreatedBy(userEntity);
						deviceDetail.setModifiedOn(new Date());
						deviceDetail.setModifiedBy(userEntity);
						deviceDetail.setDeviceToken(userEntity.getDeviceToken());
						deviceDetail.setDeviceType(userEntity.getDeviceType());
						deviceDetail.setDeviceID(userEntity.getDeviceID());
						deviceDetailList.add(deviceDetail);
						userEntity.setDeviceDetail(deviceDetailList);	
					}
					PersonMaster personMaster=new PersonMaster();
					personMaster.setPerFname(userEntity.getPerFname());
					personMaster.setPerLName(userEntity.getPerLname());
					personMaster.setPerEmailPrimary(userEntity.getUserEmail());
					personMaster.setPerMobilePrimary(userEntity.getPerContactNumber());
					personMaster.setActive(true);
					personMaster.setDeleted(false);
					personMaster.setCreatedOn(new Date());
					personMaster.setModifiedOn(new Date());
					personMaster.setCreatedBy(userEntity);
					personMaster.setModifiedBy(userEntity);
					personMaster.setUserMaster(userEntity);
					userEntity.setPersonMaster(personMaster);	
					try {
						userEntity = userService.saveOrUpdate(userEntity);
					}catch (Exception e) {
						logger.error("Error:--", e);
						response.setStatus(ResponseConstant.ERROR);
						response.setMessage(messageByLocaleService.getMessage(USERURLConstant.USER_ERROR));
						response.setData(messageByLocaleService.getMessage(USERURLConstant.USER_ERROR));
						return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
					}
					UserRoleEntity userRoleEntity = new UserRoleEntity();
					userRoleEntity.setRoleMaster(roleEntity);
					userRoleEntity.setUserMaster(userEntity);
					userRoleEntity.setActive(true);
					userRoleEntity.setDeleted(false);
					userRoleEntity.setCreatedOn(new Date());
					userRoleEntity.setModifiedOn(new Date());
					userRoleEntity.setCreatedBy(userEntity);
					userRoleEntity.setModifiedBy(userEntity);
					try {
						userRoleService.saveOrUpdate(userRoleEntity);
					}catch (Exception e) {
						logger.error("Error:--", e);
						response.setStatus(ResponseConstant.ERROR);
						response.setMessage(messageByLocaleService.getMessage(USERURLConstant.USER_ERROR));
						response.setData(messageByLocaleService.getMessage(USERURLConstant.USER_ERROR));
						return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
					}
					PatientMaster patientMaster=new PatientMaster();
					patientMaster.setPersonID(userEntity.getPersonMaster());
					patientMaster.setActive(true);
					patientMaster.setDeleted(false);
					patientMaster.setCreatedOn(new Date());
					patientMaster.setModifiedOn(new Date());
					patientMaster.setCreatedBy(userEntity);
					patientMaster.setModifiedBy(userEntity);
					try {
						patientService.saveOrUpdate(patientMaster);
					}catch (Exception e) {
						logger.error("Error:--", e);
						response.setStatus(ResponseConstant.ERROR);
						response.setMessage(messageByLocaleService.getMessage(USERURLConstant.USER_ERROR));
						response.setData(messageByLocaleService.getMessage(USERURLConstant.USER_ERROR));
						return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
					}
					response.setStatus(ResponseConstant.SUCCESS);
					response.setMessage(messageByLocaleService.getMessage(USERURLConstant.USER_SUCCESS));
					response.setData(messageByLocaleService.getMessage(USERURLConstant.USER_SUCCESS));
					
				} else {
					response.setStatus(ResponseConstant.WARNING);
					response.setMessage(messageByLocaleService.getMessage(USERURLConstant.USER_EXCEPTION));
					response.setData(messageByLocaleService.getMessage(USERURLConstant.USER_EXCEPTION));
					return new ResponseEntity<Response>(response, HttpStatus.BAD_REQUEST);
				}

			} catch (Exception e) {
				logger.error("Error:--", e);
				response.setStatus(ResponseConstant.ERROR);
				response.setMessage(messageByLocaleService.getMessage(USERURLConstant.USER_ERROR));
				response.setData(messageByLocaleService.getMessage(USERURLConstant.USER_ERROR));
				return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
			}
		} else {
			response.setStatus(ResponseConstant.ERROR);
			response.setMessage(messageByLocaleService.getMessage(USERURLConstant.USER_EXCEPTION));
			response.setData(messageByLocaleService.getMessage(USERURLConstant.USER_EXCEPTION));
			return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Response>(response, HttpStatus.OK);
	}

	@RequestMapping(value = USERURLConstant.AUTHORIZATION_USER, method = RequestMethod.GET)
	public void userActivation(HttpServletRequest request){
		String emailid = request.getParameter("emailid_");
		if (StringUtils.isNotBlank(emailid)) {
			UserMaster userEntity = userService.findByUserEmail(emailid);
			if (userEntity != null ) {
				PersonMaster person = personService.findByPerEmailPrimary(userEntity.getUserEmail());
				if(CommonConstants.getPropertiesValue("TYPE").equalsIgnoreCase(CommonConstants.HYPERLEDGER)) {
					JSONObject userEntityData = new JSONObject();
					userEntityData.put("perLname", person.getPerLName());
					userEntityData.put("perFname", person.getPerFname());
					userEntityData.put("userEmail", userEntity.getUserEmail());
					userEntityData.put("userName", userEntity.getUserName());
					userEntityData.put("patientID", userEntity.getUserEmail());
					userEntityData.put("perContactNumber",person.getPerMobilePrimary());
					try {
						String userEntityUpdated = (String) HyperledgerApiUtil.post(
								CommonConstants.getPropertiesValue("HYPERLEDGER_BASE_REGISTER"),
								CommonConstants.getPropertiesValue("HYPERLEDGER_BASE_HOST"),
								userEntityData);
						if(userEntityUpdated.equalsIgnoreCase(CommonConstants.CODE)) {
							userEntity.setUserHyperledgerID(userEntity.getUserEmail());
						}else {
							JSONObject userEntityDatas = new JSONObject();
							userEntityDatas.put("perLname", person.getPerLName());
							userEntityDatas.put("perFname", person.getPerFname());
							userEntityDatas.put("userEmail", userEntity.getUserEmail());
							userEntityDatas.put("userName", userEntity.getUserName());
							userEntityDatas.put("perContactNumber",person.getPerMobilePrimary());
							String userEntityUpdateds = (String) HyperledgerApiUtil.put(
									CommonConstants.getPropertiesValue("HYPERLEDGER_BASE_REGISTER")+"/"+userEntity.getUserEmail(),
									CommonConstants.getPropertiesValue("HYPERLEDGER_BASE_HOST"),
									userEntityDatas);
							if(userEntityUpdateds.equalsIgnoreCase(CommonConstants.CODE)) {
								userEntity.setUserHyperledgerID(userEntity.getUserEmail());
							}else {
								userEntity.setUserHyperledgerID(null);
							}
						}
					}catch (Exception e) {
						logger.error("Error:--", e);
					}
				}else {
					JSONObject userEntityData = new JSONObject();
					userEntityData.put("lastName", person.getPerLName());
					userEntityData.put("firstName", person.getPerFname());
					userEntityData.put("emailId", userEntity.getUserEmail());
					userEntityData.put("password", userEntity.getUserPassword());
					userEntityData.put("patientId", "");
					try {
						JSONObject userEntityUpdated = (JSONObject) ApiUtil.post(
								CommonConstants.getPropertiesValue("BLOCKCHAIN_BASE_REGISTER"),
								CommonConstants.getPropertiesValue("BLOCKCHAIN_POST_METHOD"),
								userEntityData);
						String ethreumId = userEntityUpdated.get("id").toString();
						String transectionId = userEntityUpdated.getString("transactionId").toString();
						userEntity.setUserTransectionID(transectionId);
						userEntity.setUserBlockChainID(ethreumId);
					}catch (Exception e) {
						logger.error("Error:--", e);
					}
				}
				userEntity.setActive(true);
				userEntity.setModifiedOn(new Date());
				userEntity.setModifiedBy(userEntity);
				userEntity.setDeleted(false);
				userService.saveOrUpdate(userEntity);
			}
		}
		
	}
	
	@RequestMapping(value = USERURLConstant.FORGOTPASSWORD, method = RequestMethod.POST, headers = CommonConstants.CONTENT_TYPE_APPLICATION_JSON)
	public ResponseEntity<Response> forgotPassword(Locale locale,@RequestBody UserMaster userEntity,BindingResult bindingResult,HttpServletRequest req){
		Boolean isEmpty = OperationsUtil.checkNull(userEntity);
		Response response = new Response();
		if (!isEmpty) {
			try {
				forgotPasswordValidator.validate(userEntity, bindingResult);
				if(bindingResult.hasErrors()) {
					List<FieldError> errors = bindingResult.getFieldErrors();
					StringBuffer message=new StringBuffer();  
					for (FieldError error : errors ) {
				    	message.append(error.getDefaultMessage()+CommonConstants.MESSAGE);
				    }
					response.setStatus(ResponseConstant.ERROR);
					response.setMessage(message.toString().substring(0,message.length()-5));
					response.setData(message.toString().substring(0,message.length()-5));
					return new ResponseEntity<Response>(response, HttpStatus.BAD_REQUEST);
				}
				UserMaster userEntityList = userService.findByUserEmail(userEntity.getUserEmail());
				if (userEntityList == null) {
					response.setStatus(ResponseConstant.ERROR);
					response.setMessage(messageByLocaleService.getMessage(USERURLConstant.USER_FORGOT_ERROR));
					response.setData(messageByLocaleService.getMessage(USERURLConstant.USER_FORGOT_ERROR));
					return new ResponseEntity<Response>(response, HttpStatus.NOT_ACCEPTABLE);
				} else {
					SecureRandom random = new SecureRandom();
					String result = "";
					String passString=ServiceConstant.ALPHA_CAPS + ServiceConstant.ALPHA + ServiceConstant.SPECIAL_CHARS;
				    for (int i = 0; i < 10; i++) {
				        int index = random.nextInt(passString.length());
				        result += passString.charAt(index);
				    }
				    userEntityList.setUserPassword(result);
					userEntityList.setActive(true);
					userEntityList.setModifiedOn(new Date());
					userEntityList.setDeleted(false);
					userEntityList.setModifiedBy(userEntityList);
					try {
						userEntityList = userService.saveOrUpdate(userEntityList);
					}catch (Exception e) {
						logger.error("Error:--", e);
						response.setStatus(ResponseConstant.ERROR);
						response.setMessage(messageByLocaleService.getMessage(USERURLConstant.USER_FORGOT_SYSTEM_ERROR));
						response.setData(messageByLocaleService.getMessage(USERURLConstant.USER_FORGOT_SYSTEM_ERROR));
						return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
					}
					try {
						emailService.sendEmail(userEntityList.getUserEmail(),OperationsUtil.forgotPassword(result),ServiceConstant.USER_PASSWORD_SUBJECT);
					}catch (Exception e) {
						logger.error("Error:--", e);
						response.setStatus(ResponseConstant.ERROR);
						response.setMessage(messageByLocaleService.getMessage(USERURLConstant.USER_FORGOT_SYSTEM_ERROR));
						response.setData(messageByLocaleService.getMessage(USERURLConstant.USER_FORGOT_SYSTEM_ERROR));
						return new ResponseEntity<Response>(response, HttpStatus.NOT_ACCEPTABLE);
					}
					response.setStatus(ResponseConstant.SUCCESS);
					response.setMessage(messageByLocaleService.getMessage(USERURLConstant.USER_FORGOT_SUCCESS));
					response.setData(messageByLocaleService.getMessage(USERURLConstant.USER_FORGOT_SUCCESS));
				}

			} catch (Exception e) {
				logger.error("Error:--", e);
				response.setStatus(ResponseConstant.ERROR);
				response.setMessage(messageByLocaleService.getMessage(USERURLConstant.USER_FORGOT_SYSTEM_ERROR));
				response.setData(messageByLocaleService.getMessage(USERURLConstant.USER_FORGOT_SYSTEM_ERROR));
				return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
			}
		} else {
			response.setStatus(ResponseConstant.ERROR);
			response.setMessage(messageByLocaleService.getMessage(USERURLConstant.USER_FORGOT_EXCEPTION));
			response.setData(messageByLocaleService.getMessage(USERURLConstant.USER_FORGOT_EXCEPTION));
			return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);

		}
		return new ResponseEntity<Response>(response, HttpStatus.OK);
		
	}
	
	@RequestMapping(value = USERURLConstant.CHANGEPASSWORD, method = RequestMethod.POST, headers = CommonConstants.CONTENT_TYPE_APPLICATION_JSON)
	public ResponseEntity<Response> changePassword(Locale locale,@RequestBody UserMaster master,BindingResult bindingResult,HttpServletRequest req){
		Response response = new Response();
		UserDetails userDetails = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		UserMaster userEntity = userService.findByUserName(userDetails.getUsername());
		Boolean isEmpty = OperationsUtil.checkNull(userEntity);
		if (!isEmpty) {
			try {
				changePasswordValidator.validate( master, bindingResult );
				if(bindingResult.hasErrors()) {
					List<FieldError> errors = bindingResult.getFieldErrors();
					StringBuffer message=new StringBuffer();  
					for (FieldError error : errors ) {
				    	message.append(error.getDefaultMessage()+CommonConstants.MESSAGE);
				    }
					response.setStatus(ResponseConstant.ERROR);
					response.setMessage(message.toString().substring(0,message.length()-5));
					response.setData(message.toString().substring(0,message.length()-5));
					return new ResponseEntity<Response>(response, HttpStatus.BAD_REQUEST);
				}
				UserMaster userEntityList = userService.findByUserEmail(userEntity.getUserEmail());
				if(userEntityList.getUserPassword().equalsIgnoreCase(master.getOldPassword())) {
					userEntityList.setUserPassword(master.getUserPassword());
					userEntityList.setActive(true);
					userEntityList.setModifiedOn(new Date());
					userEntityList.setDeleted(false);
					userEntityList.setModifiedBy(userEntityList);
					try {
						userEntity = userService.saveOrUpdate(userEntityList);
					}catch (Exception e) {
						logger.error("Error:--", e);
						response.setStatus(ResponseConstant.ERROR);
						response.setMessage(messageByLocaleService.getMessage(USERURLConstant.USER_CHANGE_SYSTEM_ERROR));
						response.setData(messageByLocaleService.getMessage(USERURLConstant.USER_CHANGE_SYSTEM_ERROR));
						return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
					}
					response.setStatus(ResponseConstant.SUCCESS);
					response.setMessage(messageByLocaleService.getMessage(USERURLConstant.USER_CHANGE_SUCCESS));
					response.setData(messageByLocaleService.getMessage(USERURLConstant.USER_CHANGE_SUCCESS));
				}else {
					response.setStatus(ResponseConstant.ERROR);
					response.setMessage(messageByLocaleService.getMessage(USERURLConstant.USER_CHANGE_EXCEPTION));
					response.setData(messageByLocaleService.getMessage(USERURLConstant.USER_CHANGE_EXCEPTION));
					return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
				}
			} catch (Exception e) {
				logger.error("Error:--", e);
				response.setStatus(ResponseConstant.ERROR);
				response.setMessage(messageByLocaleService.getMessage(USERURLConstant.USER_CHANGE_SYSTEM_ERROR));
				response.setData(messageByLocaleService.getMessage(USERURLConstant.USER_CHANGE_SYSTEM_ERROR));
				return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
			}
		}else {
			response.setStatus(ResponseConstant.ERROR);
			response.setMessage(messageByLocaleService.getMessage(USERURLConstant.USER_CHANGE_EXCEPTION));
			response.setData(messageByLocaleService.getMessage(USERURLConstant.USER_CHANGE_EXCEPTION));
			return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);

		}
		return new ResponseEntity<Response>(response, HttpStatus.OK);
		
	}
	
	@RequestMapping(value = USERURLConstant.USER_LOGIN, method = RequestMethod.POST ,headers = CommonConstants.CONTENT_TYPE_APPLICATION_JSON)
	public ResponseEntity<Response> login(@RequestBody UserMaster userMaster,BindingResult bindingResult,HttpServletRequest request) {
		Response response = new Response();
		UserDetails userDetails = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		loginValidator.validate( userMaster, bindingResult );
		if(bindingResult.hasErrors()) {
			List<FieldError> errors = bindingResult.getFieldErrors();
			StringBuffer message=new StringBuffer();  
			for (FieldError error : errors ) {
		    	message.append(error.getDefaultMessage()+CommonConstants.MESSAGE);
		    }
			response.setStatus(ResponseConstant.ERROR);
			response.setMessage(message.toString().substring(0,message.length()-5));
			response.setData(message.toString().substring(0,message.length()-5));
			return new ResponseEntity<Response>(response, HttpStatus.BAD_REQUEST);
		}
		UserMaster userEntity = userService.findByUserName(userDetails.getUsername());
		UserEntityPojo userEntityPojo=new UserEntityPojo();
		userEntityPojo.setId(userEntity.getUserID());
		userEntityPojo.setName(userEntity.getPerFname()+" "+userEntity.getPerLname());
		Set<UserRoleEntity> userRoleList = userEntity.getUserRoleEntity();
		Set<String> role = new HashSet<String>();
		for (UserRoleEntity userRoleEntity : userRoleList) {
			role.add(userRoleEntity.getRoleMaster().getRoleName());
		}
		userEntityPojo.setData(role);
		PersonMaster person=new PersonMaster(); 
		try {
			person = personService.findByPerEmailPrimary(userEntity.getUserEmail());
		}catch (Exception e) {
			logger.error("Error:--", e);
			response.setStatus(ResponseConstant.ERROR);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.EMAIL_EXCEPTION));
			response.setData(messageByLocaleService.getMessage(ServiceConstant.EMAIL_EXCEPTION));
			return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		userEntityPojo.setPerProfile(request.getScheme() + "://" + request.getServerName() + ":"
				+ request.getServerPort() + request.getContextPath() + USERURLConstant.AUTHENTICATION_USER_ROOT_URL + USERURLConstant.GET_IMAGES_URL
				+ "?filepath=" + person.getPerProfile());
		if(userEntityPojo.getPerProfile().equalsIgnoreCase("/getImages?filepath=null")) {
			userEntityPojo.setPerProfile(null);
		}
		if(userMaster.getDeviceType().equalsIgnoreCase(CommonConstants.DEVICE_ANDROID_TYPE) || userMaster.getDeviceType().equalsIgnoreCase(CommonConstants.DEVICE_IOS_TYPE)) {
			DeviceDetail deviceDetail=new DeviceDetail();
			deviceDetail.setDeviceToken(userMaster.getDeviceToken());
			deviceDetail.setDeviceType(userMaster.getDeviceType());
			deviceDetail.setDeviceID(userMaster.getDeviceID());
			deviceDetail.setUserMaster(userEntity);
			DeviceDetail detail=new DeviceDetail();
			try {
				detail=deviceDetailService.findByUserForDevice(deviceDetail);
			}catch (Exception e) {
				logger.error("Error:--", e);
				response.setStatus(ResponseConstant.ERROR);
				response.setMessage(messageByLocaleService.getMessage(USERURLConstant.DEVICE_ERROR));
				response.setData(messageByLocaleService.getMessage(USERURLConstant.DEVICE_ERROR));
				return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
			}
			if (detail == null) { 
				DeviceDetail detais=new DeviceDetail();
				detais.setDeviceID(deviceDetail.getDeviceID());
				detais.setDeviceToken(deviceDetail.getDeviceToken());
				detais.setDeviceType(deviceDetail.getDeviceType());
				detais.setActive(true);
				detais.setDeleted(false);
				detais.setModifiedBy(userEntity);
				detais.setModifiedOn(new Date());
				detais.setUserMaster(userEntity);
				detais.setCreatedBy(userEntity);
				detais.setCreatedOn(new Date());
				try {
					detais=deviceDetailService.saveOrUpdate(detais);
				}catch (Exception e) {
					logger.error("Error:--", e);
					response.setStatus(ResponseConstant.ERROR);
					response.setMessage(messageByLocaleService.getMessage(USERURLConstant.DEVICE_SYSTEM_ERROR));
					response.setData(messageByLocaleService.getMessage(USERURLConstant.DEVICE_SYSTEM_ERROR));
					return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
				}
				userEntityPojo.setDeviceToken(detais.getDeviceToken());
				userEntityPojo.setDeviceID(detais.getDeviceID());
				userEntityPojo.setDeviceType(detais.getDeviceType());
				userEntityPojo.setName(person.getPerFname()+" "+person.getPerLName());
			}else {
				if(detail.isActive() == false && detail.isDeleted() == true) {
					detail.setActive(true);
					detail.setDeleted(false);
					detail.setModifiedBy(userEntity);
					detail.setModifiedOn(new Date());
					detail.setUserMaster(userEntity);
					try {
						detail=deviceDetailService.saveOrUpdate(detail);
					}catch (Exception e) {
						logger.error("Error:--", e);
						response.setStatus(ResponseConstant.ERROR);
						response.setMessage(messageByLocaleService.getMessage(USERURLConstant.DEVICE_SYSTEM_ERROR));
						response.setData(messageByLocaleService.getMessage(USERURLConstant.DEVICE_SYSTEM_ERROR));
						return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
					}
					userEntityPojo.setDeviceToken(detail.getDeviceToken());
					userEntityPojo.setDeviceID(detail.getDeviceID());
					userEntityPojo.setDeviceType(detail.getDeviceType());
					userEntityPojo.setName(person.getPerFname()+" "+person.getPerLName());
				}else {
					userEntityPojo.setDeviceToken(userMaster.getDeviceToken());
					userEntityPojo.setDeviceType(userMaster.getDeviceType());
					userEntityPojo.setDeviceID(userMaster.getDeviceID());
					userEntityPojo.setName(person.getPerFname()+" "+person.getPerLName());
				}
			}
		}else{
			userEntityPojo.setDeviceType(CommonConstants.DEVICE_WEB);
			userEntityPojo.setName(person.getPerFname()+" "+person.getPerLName());
		}
		response.setStatus(ResponseConstant.SUCCESS);
		response.setMessage(messageByLocaleService.getMessage(USERURLConstant.USER_LOGIN_SUCCESS));
		response.setData(userEntityPojo);
		return new ResponseEntity<Response>(response, HttpStatus.OK);
	}

	@RequestMapping(value = USERURLConstant.USER_LOGOUT, method = RequestMethod.POST ,headers = CommonConstants.CONTENT_TYPE_APPLICATION_JSON)
	public void logout(@RequestBody UserMaster userMaster) {
		UserDetails userDetails = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		UserMaster userEntity = userService.findByUserName(userDetails.getUsername());
		UserEntityPojo userEntityPojo=new UserEntityPojo();
		userEntityPojo.setId(userEntity.getUserID());
		userEntityPojo.setName(userEntity.getPerFname()+" "+userEntity.getPerLname());
		Set<UserRoleEntity> userRoleList = userEntity.getUserRoleEntity();
		Set<String> role = new HashSet<String>();
		for (UserRoleEntity userRoleEntity : userRoleList) {
			role.add(userRoleEntity.getRoleMaster().getRoleName());
		}
		userEntityPojo.setData(role);
		if(userMaster.getDeviceType().equalsIgnoreCase(CommonConstants.DEVICE_ANDROID_TYPE) || userMaster.getDeviceType().equalsIgnoreCase(CommonConstants.DEVICE_IOS_TYPE)) {
			DeviceDetail deviceDetail=new DeviceDetail();
			deviceDetail.setDeviceToken(userMaster.getDeviceToken());
			deviceDetail.setDeviceType(userMaster.getDeviceType());
			deviceDetail.setDeviceID(userMaster.getDeviceID());
			deviceDetail.setUserMaster(userEntity);
			DeviceDetail detail=deviceDetailService.findByUserForDevice(deviceDetail);
			if(detail.isActive() == true && detail.isDeleted() == false) {
				detail.setActive(false);
				detail.setDeleted(true);
				detail.setModifiedBy(userEntity);
				detail.setModifiedOn(new Date());
				detail.setUserMaster(userEntity);
				deviceDetailService.saveOrUpdate(detail);
			}
		}
	}

	@RequestMapping(value = USERURLConstant.ADD_ADMINUSER_URL, method = RequestMethod.POST, headers = CommonConstants.CONTENT_TYPE_APPLICATION_JSON)
	public ResponseEntity<Response> addDoctor(Locale locale,@RequestBody UserMaster userEntity,BindingResult bindingResult,HttpServletRequest req) {
		UserDetails userDetails = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		UserMaster createdBy = userService.findByUserName(userDetails.getUsername());
		Response response = new Response();
		if(userEntity.getRoleName().equalsIgnoreCase(ServiceConstant.DOCTOR_AUTHORITY)) {
			doctorRegistrationValidator.validate( userEntity, bindingResult );
			if(bindingResult.hasErrors()) {
				List<FieldError> errors = bindingResult.getFieldErrors();
				StringBuffer message=new StringBuffer();  
				for (FieldError error : errors ) {
			    	message.append(error.getDefaultMessage()+CommonConstants.MESSAGE);
			    }
				response.setStatus(ResponseConstant.ERROR);
				response.setMessage(message.toString().substring(0,message.length()-5));
				response.setData(message.toString().substring(0,message.length()-5));
				return new ResponseEntity<Response>(response, HttpStatus.BAD_REQUEST);
			}
		}else {
			userRegistrationValidator.validate( userEntity, bindingResult );
			if(bindingResult.hasErrors()) {
				List<FieldError> errors = bindingResult.getFieldErrors();
				StringBuffer message=new StringBuffer();  
				for (FieldError error : errors ) {
			    	message.append(error.getDefaultMessage()+CommonConstants.MESSAGE);
			    }
				response.setStatus(ResponseConstant.ERROR);
				response.setMessage(message.toString().substring(0,message.length()-5));
				response.setData(message.toString().substring(0,message.length()-5));
				return new ResponseEntity<Response>(response, HttpStatus.BAD_REQUEST);
			}
		}
		Boolean isEmpty = OperationsUtil.checkNull(userEntity);
		if (!isEmpty) {
			try {
				UserMaster userEntityName = userService.findByUserName(userEntity.getUserName());
				UserMaster userEntityEmail = userService.findByUserEmail(userEntity.getUserEmail());
				if (userEntityName == null && userEntityEmail == null) {
					SecureRandom random = new SecureRandom();
					String result = "";
					String passString=ServiceConstant.ALPHA_CAPS + ServiceConstant.ALPHA + ServiceConstant.SPECIAL_CHARS;
				    for (int i = 0; i < 10; i++) {
				        int index = random.nextInt(passString.length());
				        result += passString.charAt(index);
				    }
				    try {
						emailService.sendEmail(userEntity.getUserEmail(),OperationsUtil.forgotPassword(result),ServiceConstant.USER_PASSWORD_SUBJECT);
					}catch (Exception e) {
						logger.error("Error:--", e);
						response.setStatus(ResponseConstant.ERROR);
						response.setMessage(messageByLocaleService.getMessage(ServiceConstant.EMAIL_EXCEPTION));
						response.setData(messageByLocaleService.getMessage(ServiceConstant.EMAIL_EXCEPTION));
						return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
					}
				    userEntity.setActive(true);
					userEntity.setUserPassword(result);
					userEntity.setCreatedBy(createdBy);
					userEntity.setModifiedBy(createdBy);
					userEntity.setCreatedOn(new Date());
					userEntity.setModifiedOn(new Date());
					userEntity.setDeleted(false);
					if(userEntity.getDeviceType().equalsIgnoreCase(CommonConstants.DEVICE_ANDROID_TYPE) || userEntity.getDeviceType().equalsIgnoreCase(CommonConstants.DEVICE_IOS_TYPE)) {
						Set<DeviceDetail> deviceDetailList=new HashSet<DeviceDetail>(0);
						DeviceDetail deviceDetail=new DeviceDetail();
						deviceDetail.setUserMaster(userEntity);
						deviceDetail.setActive(true);
						deviceDetail.setDeleted(false);
						deviceDetail.setCreatedOn(new Date());
						deviceDetail.setCreatedBy(createdBy);
						deviceDetail.setModifiedOn(new Date());
						deviceDetail.setModifiedBy(createdBy);
						deviceDetail.setDeviceToken(userEntity.getDeviceToken());
						deviceDetail.setDeviceType(userEntity.getDeviceType());
						deviceDetail.setDeviceID(userEntity.getDeviceID());
						deviceDetailList.add(deviceDetail);
						userEntity.setDeviceDetail(deviceDetailList);	
					}
					
					PersonMaster personMaster=new PersonMaster();
					personMaster.setPerFname(userEntity.getPerFname());
					personMaster.setPerLName(userEntity.getPerLname());
					personMaster.setPerEmailPrimary(userEntity.getUserEmail());
					personMaster.setPerMobilePrimary(userEntity.getPerContactNumber());
					personMaster.setActive(true);
					personMaster.setDeleted(false);
					personMaster.setCreatedOn(new Date());
					personMaster.setModifiedOn(new Date());
					personMaster.setCreatedBy(createdBy);
					personMaster.setModifiedBy(createdBy);
					personMaster.setUserMaster(userEntity);
					userEntity.setPersonMaster(personMaster);
					try {
						userEntity = userService.saveOrUpdate(userEntity);
					}catch (Exception e) {
						logger.error("Error:--", e);
						response.setStatus(ResponseConstant.ERROR);
						response.setMessage(messageByLocaleService.getMessage(USERURLConstant.ALLUSER_ERROR));
						response.setData(messageByLocaleService.getMessage(USERURLConstant.ALLUSER_ERROR));
						return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
					}
					ProviderMaster providerMaster=new ProviderMaster();
					providerMaster.setPersonMaster(userEntity.getPersonMaster());
					providerMaster.setProviderTypeStatus(userEntity.getProviderTypeStatus());
					providerMaster.setActive(true);
					providerMaster.setDeleted(false);
					providerMaster.setCreatedOn(new Date());
					providerMaster.setModifiedOn(new Date());
					providerMaster.setCreatedBy(createdBy);
					providerMaster.setModifiedBy(createdBy);
					try {
						providerMaster=providerService.saveOrUpdate(providerMaster);
					}catch (Exception e) {
						logger.error("Error:--", e);
						response.setStatus(ResponseConstant.ERROR);
						response.setMessage(messageByLocaleService.getMessage(USERURLConstant.ALLUSER_ERROR));
						response.setData(messageByLocaleService.getMessage(USERURLConstant.ALLUSER_ERROR));
						return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
					}
					for(SpecialityMaster sm:userEntity.getSpecialityMaster()) {
						SpecialityProviderMaster specialityProviderMaster=new SpecialityProviderMaster();
						specialityProviderMaster.setProviderMaster(providerMaster);
						specialityProviderMaster.setSpecialityMaster(sm);
						specialityProviderMaster.setActive(true);
						specialityProviderMaster.setDeleted(false);
						specialityProviderMaster.setCreatedOn(new Date());
						specialityProviderMaster.setModifiedOn(new Date());
						specialityProviderMaster.setCreatedBy(createdBy);
						specialityProviderMaster.setModifiedBy(createdBy);
						try {
							specialityProviderService.saveOrUpdate(specialityProviderMaster);
						}catch (Exception e) {
							logger.error("Error:--", e);
							response.setStatus(ResponseConstant.ERROR);
							response.setMessage(messageByLocaleService.getMessage(USERURLConstant.ALLUSER_ERROR));
							response.setData(messageByLocaleService.getMessage(USERURLConstant.ALLUSER_ERROR));
							return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
						}	
					}
					for(FCLocationMap flm:userEntity.getFcLocationMap()) {
						FCLProviderMap fclProviderMap=new FCLProviderMap();
						fclProviderMap.setProviderID(providerMaster);
						fclProviderMap.setLocationMapID(flm);
						fclProviderMap.setActive(true);
						fclProviderMap.setDeleted(false);
						fclProviderMap.setCreatedOn(new Date());
						fclProviderMap.setCreatedBy(createdBy);
						fclProviderMap.setModifiedOn(new Date());
						fclProviderMap.setModifiedBy(createdBy);
						try {
							fclProviderService.saveOrUpdate(fclProviderMap);
						}catch (Exception e) {
							logger.error("Error:--", e);
							response.setStatus(ResponseConstant.ERROR);
							response.setMessage(messageByLocaleService.getMessage(USERURLConstant.ALLUSER_ERROR));
							response.setData(messageByLocaleService.getMessage(USERURLConstant.ALLUSER_ERROR));
							return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
						}
					}
										
					RoleMaster roleEntity = roleService.findByroleName(userEntity.getRoleName());

					UserRoleEntity userRoleEntity = new UserRoleEntity();
					userRoleEntity.setRoleMaster(roleEntity);
					userRoleEntity.setUserMaster(userEntity);
					userRoleEntity.setActive(true);
					userRoleEntity.setDeleted(false);
					userRoleEntity.setCreatedOn(new Date());
					userRoleEntity.setModifiedOn(new Date());
					userRoleEntity.setCreatedBy(createdBy);
					userRoleEntity.setModifiedBy(createdBy);
					try {
						userRoleService.saveOrUpdate(userRoleEntity);
					}catch (Exception e) {
						logger.error("Error:--", e);
						response.setStatus(ResponseConstant.ERROR);
						response.setMessage(messageByLocaleService.getMessage(USERURLConstant.ALLUSER_ERROR));
						response.setData(messageByLocaleService.getMessage(USERURLConstant.ALLUSER_ERROR));
						return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
					}
					response.setStatus(ResponseConstant.SUCCESS);
					response.setMessage(messageByLocaleService.getMessage(USERURLConstant.ALLUSER_SUCCESS));
					response.setData(messageByLocaleService.getMessage(USERURLConstant.ALLUSER_SUCCESS));
					
				} else {
					response.setStatus(ResponseConstant.WARNING);
					response.setMessage(messageByLocaleService.getMessage(USERURLConstant.ALLUSER_EXIT));
					response.setData(messageByLocaleService.getMessage(USERURLConstant.ALLUSER_EXIT));
					return new ResponseEntity<Response>(response, HttpStatus.CONFLICT);
				}
			} catch (Exception e) {
				logger.error("Error:--", e);
				response.setStatus(ResponseConstant.ERROR);
				response.setMessage(messageByLocaleService.getMessage(USERURLConstant.ALLUSER_ERROR));
				response.setData(messageByLocaleService.getMessage(USERURLConstant.ALLUSER_ERROR));
				return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
			}
		} else {

			response.setStatus(ResponseConstant.ERROR);
			response.setMessage(messageByLocaleService.getMessage(USERURLConstant.ALLUSER_EXCEPTION));
			response.setData(messageByLocaleService.getMessage(USERURLConstant.ALLUSER_EXCEPTION));
			return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);

		}
		return new ResponseEntity<Response>(response, HttpStatus.OK);
	}

	@RequestMapping(USERURLConstant.GET_IMAGES_URL)
	public ResponseEntity<byte[]> decryptImages(HttpServletRequest request,@RequestParam(required=true)String filepath) throws IOException {
		final HttpHeaders headers = new HttpHeaders();
	    headers.setContentType(MediaType.IMAGE_JPEG);
		if(new File(filepath).exists()) {
			try {
				FileInputStream fis=new FileInputStream(filepath);
				byte[] media = new byte[fis.available()];
				fis.read(media);
				ByteArrayOutputStream resultdata=new ByteArrayOutputStream();
				resultdata.write(media);
				resultdata.flush();
				fis.close();
				return new ResponseEntity<byte[]>(resultdata.toByteArray(),headers,HttpStatus.OK);
			} catch (IOException io) {
				logger.debug(io.getMessage());
				io.printStackTrace();
			}
		}
		return null;
	}
	
	@RequestMapping(USERURLConstant.FILE_DOWNLOAD)
    public ResponseEntity<InputStreamResource> download(
            @RequestParam(required=true) String fileName,HttpServletRequest request) throws IOException {
        MediaType mediaType = OperationsUtil.getMediaTypeForFileName(this.servletContext, fileName);
        File file = new File(File.separator + fileName);
        InputStreamResource resource = new InputStreamResource(new FileInputStream(file));
         return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION,"attachment;filename=" + file.getName())
                .contentType(mediaType)
               .contentLength(file.length()) 
                .body(resource);
    }
	
	@RequestMapping(USERURLConstant.FILE_EXITS)
    public ResponseEntity<Response> exits(Locale locale,@RequestParam(required=true) String fileName,HttpServletRequest request) throws IOException {
		Response response = new Response();
		File templateFolder = new File(fileName);
		if (templateFolder.exists()) {
			response.setStatus(ResponseConstant.SUCCESS);
			response.setMessage(messageByLocaleService.getMessage(USERURLConstant.FILE_SUCCESS));
			response.setData(messageByLocaleService.getMessage(USERURLConstant.FILE_SUCCESS));
			return new ResponseEntity<Response>(response, HttpStatus.OK);
		}else {
			response.setStatus(ResponseConstant.ERROR);
			response.setMessage(messageByLocaleService.getMessage(USERURLConstant.FILE_ERROR));
			response.setData(messageByLocaleService.getMessage(USERURLConstant.FILE_ERROR));
			return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
       
    }
}
