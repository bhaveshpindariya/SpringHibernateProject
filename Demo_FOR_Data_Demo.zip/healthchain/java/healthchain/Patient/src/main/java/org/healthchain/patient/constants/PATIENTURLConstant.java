package org.healthchain.patient.constants;

public class PATIENTURLConstant {
	
	public static final String PROFILE_ROOT_URL="/profile";
	
	public static final String PROFILE_IMAGE_ROOT_URL="/image";
	
	public static final String COMMON_ROOT_URL="/common";
	
	public static final String PATIENT_ROOT_URL="/patient";
	
	public static final String GET_IMAGES_URL="/getImages";
	
	public static final String GET_ALL_FACILITY_BY_PROFESSIONAL_URL="/getAllFacilityByMedicalProfessional";
	
	public static final String GET_ALL_DRUGMANUFACTURER_URL="/getAlldrugsManufacturer";
	public static final String GET_ALL_DRUGMANUFACTURER_BY_PERAMETER_URL="/getAlldrugsManufacturerByperameter";
	public static final String LAB_STATUS_CHANGE_URL="/labStatusChange";
	
	public static final String APPOINTMENT_STATUS_CHANGE_URL="/appointmentStatusChange";
	public static final String APPOINTMENT_ADD_OR_EDIT_URL="/addOrEditAppointment";
	public static final String GET_APPOINTMENT_PATIENT_URL="/getAppointmentPatient";
	public static final String VIEW_AND_EDIT_APPOINTMENT_PATIENT_URL="/viewAndEditAppointmentPatient";
	public static final String GET_DOCTOR_VISIT_PATIENT_URL="/getAllDoctorVisitPatient";
	public static final String VIEW_AND_EDIT_DOCTOR_VISIT_PATIENT_URL="/viewAndEditDoctorVisitPatient";
	public static final String PROVIDER_URL="/providerType";
	public static final String FACILITY_URL="/facilityType";
	public static final String APPOINTMENT_TYPE_URL="/appointmentType";
	public static final String APPOINTMENT_STATUS_URL="/appointmentStatus";
	public static final String APPOINTMENT_RESON_URL="/appointmentReason";
	public static final String LAB_APPOINTMENT_RESON_URL="/labappointmentReson";
	
	public static final String GET_ALL_FACILITY_DOCTOR_URL="/getAllFacilityDoctor";
	public static final String GET_ALL_LOCATIONBASED_ON_FACILITY_DOCTOR_URL="/getAllLocationByFacilityAndDoctor";
	
	public static final String GET_ALL_FACILITY_URL="/getAllFacility";
	public static final String GET_ALL_FACILITY_BY_PERAMETER_URL="/getAllFacilityByPerameter";
	public static final String GET_ALL_LAB1_REPORT_URL="/getAllLab1Report";
	public static final String GET_ALL_PATIENT_URL="/getAllPatient";
	public static final String GET_ALL_DIGNSOSIS_URL="/getAllDiagnosis";
	public static final String GET_ALL_MEDICINE_URL="/getAllMedicine";
	
	public static final String GET_ALL_LAB1_REPORT_BY_LAB_URL="/getAllLab1ReportByLab";
	
	public static final String GET_ALL_LOCATION_URL="/getAllLocation";
	public static final String GET_ALL_DOCTOR_URL="/getAllDoctor";
	public static final String GET_ALL_DOCTOR_BY_PERAMETER_URL="/getAllDoctorByperameter";
	public static final String GET_ALL_PATIENT_BY_PERAMETER_URL="/getAllPatientByperameter";
	public static final String GET_ALL_DIGNSOSIS_BY_PERAMETER_URL="/getAllDiagnosisByperameter";
	public static final String GET_ALL_LAB1_BY_PERAMETER_URL="/getAllLab1ReportByperameter";
	public static final String GET_ALL_MEDICINE_BY_PERAMETER_URL="/getAllMedicineByperameter";
	
	public static final String GET_ALL_LOCATIONBASED_ON_FACILITY_URL="/getAllLocationByFacility";
	public static final String GET_SPECIALITY_BY_LOCATION_AND_FACILITY="/getAllSpecialityByLocationAndFacility";
	public static final String GET_DOCTOR_BY_SPECIALITY_AND_LOCATION="/getAllDoctorByLocationAndspeciality";
	public static final String GET_DOCTOR_BY_LOCATIONBASED_ON_FACILITY_URL="/getAllDoctorByLocationAndFacility";
	public static final String GET_REPORT_BY_FACILITY_URL="/getAllReportByFacilityProvider";
	public static final String GET_ALL_FACILITY_BY_REPORT_URL="/getAllFacilityByReport";
	
	public static final String SPECIALITY_URL="/specialityCode";
	public static final String SPECIALITY_GET_URL="/getAllSpeciality";
	public static final String TIMEZONE_GET_URL="/getAllTimeZone";
	
	public static final String ADD_PERSON_URL="/addPerson";
	public static final String PROFILE_PERSONAL_MARITAL="/maritalStatus";
	public static final String PROFILE_PERSONAL_GENDERL="/gender";
	public static final String PROFILE_PERSONAL_PMLLOCATION="/pmlLocation";
	public static final String PROFILE_PERSONAL_URL="/personal";
	public static final String PROFILE_PERSONAL_GETDATA_URL="/getPersonalData";
	public static final String PROFILE_DEMOGRAPHIC_URL="/demographic";
	public static final String PROFILE_DEMOGRAPHIC_GETDATA_URL="/getDemographicData";
	public static final String PROFILE_PERSONAL_WORK="/workStatus";
	public static final String PROFILE_PERSONAL_EMPLOYMENT="/employmentStatus";
	public static final String PROFILE_EXTENDED_URL="/extended";
	public static final String PROFILE_EXTENDED_GETDATA_URL="/getExtendedData";
	public static final String PROFILE_DOCUMENTS_URL="/documents";
	public static final String PROFILE_DOCUMENTS_GETDATA_URL="/getDocuments";
	
	public static final String LABREPORT_TYPE_URL="/labreportTypeStatus";	
	
	public static final String LAB_ADD_OR_EDIT_URL="/addOrEditLab";
	public static final String GET_LAB_PATIENT_URL="/getAllLabPatient";
	public static final String VIEW_AND_EDIT_LAB_PATIENT_URL="/viewAndEditLabPatient";
	
	public static final String GET_LAB_REPORT_LIST_URL="/getAllLabReport";
	public static final String GET_LAB_REPORT_URL="/ViewLabReport";
	
	public static final String PERSONAL_UPDATE="personal.update";
	public static final String PERSONAL_ERROR="personal.error";
	
	public static final String APPOINTMENT_SUCCESS="appointment.success";
	public static final String APPOINTMENT_UPDATE="appointment.update";
	public static final String APPOINTMENT_ERROR="appointment.error";
	public static final String APPOINTMENT_UPDATE_ERROR="appointment.update.error";
	public static final String APPOINTMENT_EXCEPTION="appointment.exception";
	public static final String APPOINTMENT="appointment";
	public static final String APPOINTMENT_VALIDATION="appointment.validation";
	
	public static final String LAB_SUCCESS="lab.success";
	public static final String LAB_UPDATE="lab.update";
	public static final String LAB_ERROR="lab.error";
	public static final String LAB_UPDATE_ERROR="lab.update.error";
	public static final String LAB_EXCEPTION="lab.exception";
	public static final String LABAPPOINTMENT="labappointment";
	public static final String LABAPPOINTMENT_VALIDATION="labappointment.validation";
		
	public static final String ADD_TYPE="Add";
	public static final String EDIT_TYPE="Update";
	
	public static final String GET_REGISTERDATA_FOR_HYPERLEDGER="/getRegisterDataForHyperledger";
	
	
}
