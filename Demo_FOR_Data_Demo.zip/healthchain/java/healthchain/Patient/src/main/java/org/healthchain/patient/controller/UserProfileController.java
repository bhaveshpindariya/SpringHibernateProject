package org.healthchain.patient.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.healthchain.common.constants.CommonConstants;
import org.healthchain.common.constants.ResponseConstant;
import org.healthchain.common.utils.ApiUtil;
import org.healthchain.common.utils.HyperledgerApiUtil;
import org.healthchain.common.utils.OperationsUtil;
import org.healthchain.entity.LocationMaster;
import org.healthchain.entity.PersonLocationMap;
import org.healthchain.entity.PersonMaster;
import org.healthchain.entity.TimeZoneMaster;
import org.healthchain.entity.UserMaster;
import org.healthchain.entity.enums.PLMLocationStatus;
import org.healthchain.patient.constants.PATIENTURLConstant;
import org.healthchain.pojo.DemographicPojo;
import org.healthchain.pojo.DocumentPojo;
import org.healthchain.pojo.ExtendedPojo;
import org.healthchain.pojo.LocationPojo;
import org.healthchain.pojo.PersonalPojo;
import org.healthchain.pojo.Response;
import org.healthchain.pojo.TimeZonePojo;
import org.healthchain.services.LocationService;
import org.healthchain.services.MessageByLocaleService;
import org.healthchain.services.PersonLocationService;
import org.healthchain.services.PersonService;
import org.healthchain.services.TimeZoneService;
import org.healthchain.services.UserService;
import org.healthchain.services.constants.ServiceConstant;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

@CrossOrigin
@RestController
@RequestMapping(PATIENTURLConstant.PROFILE_ROOT_URL)
public class UserProfileController {

	private static final Log logger = LogFactory.getLog(UserProfileController.class);
	
	@Autowired
	private PersonService personService;
	
	@Autowired
	private UserService userService;
	
	@Autowired
	private TimeZoneService timeZoneService;

	@Autowired
	private LocationService locationService;

	@Autowired
	private PersonLocationService personLocationService;
	
	@Autowired
	private MessageByLocaleService messageByLocaleService;
	
	@RequestMapping(value = PATIENTURLConstant.PROFILE_PERSONAL_GETDATA_URL, method = RequestMethod.POST, headers = CommonConstants.CONTENT_TYPE_APPLICATION_JSON)
	public ResponseEntity<Response> getPersonalData(Locale locale,HttpServletRequest request) {
		Response response = new Response();
		UserDetails userDetails = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		UserMaster userEntity = userService.findByUserName(userDetails.getUsername());
		PersonalPojo personalPojo = new PersonalPojo();
		try {
			PersonMaster person = personService.findByPerEmailPrimary(userEntity.getUserEmail());
			personalPojo.setPersonID(person.getPersonID());
			personalPojo.setPerFname(person.getPerFname());
			personalPojo.setPerLName(person.getPerLName());
			personalPojo.setPerEmailPrimary(person.getPerEmailPrimary());
			List<String> mlist = person.getPerEmailList();
			List<Map<String, String>> providerMapList = new ArrayList<Map<String, String>>(0);
			for (int i=0;i<mlist.size();i++) {
				Map<String, String> providerMap = new HashMap<String, String>(0);
				providerMap.put("value", mlist.get(i));
				providerMapList.add(providerMap);
			}
			personalPojo.setPerProfile(request.getScheme() + "://" + request.getServerName() + ":"
					+ request.getServerPort() + request.getContextPath() + PATIENTURLConstant.PROFILE_IMAGE_ROOT_URL + PATIENTURLConstant.GET_IMAGES_URL
					+ "?filepath=" + person.getPerProfile());
			if(personalPojo.getPerProfile().equalsIgnoreCase("/getImages?filepath=null")) {
				personalPojo.setPerProfile(null);
			}
			personalPojo.setPerEmailList(providerMapList);
			personalPojo.setUserName(userEntity.getUserName());
			response.setStatus(ResponseConstant.SUCCESS);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_SUCCESS));
			response.setData(personalPojo);
		}catch (Exception e) {
			logger.error("Error:--", e);
			response.setStatus(ResponseConstant.ERROR);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			response.setData(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Response>(response, HttpStatus.OK);
	}

	@RequestMapping(value = PATIENTURLConstant.PROFILE_PERSONAL_URL, method = RequestMethod.POST)
	public ResponseEntity<Response> personal(Locale locale, @RequestParam(value = "perProfile", required = false) MultipartFile files,HttpServletRequest request) {
		Response response = new Response();
		UserDetails userDetails = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		UserMaster userEntity = userService.findByUserName(userDetails.getUsername());
		try {
			PersonMaster person = personService.get(Long.parseLong(request.getParameter("personID")));
			personService.deletePersonEmailList(person.getPersonID());
			person.setPerFname(request.getParameter("perFname"));
			person.setPerLName(request.getParameter("perLName"));
			person.setPerEmailPrimary(request.getParameter("perEmailPrimary"));
			if(request.getParameter("perEmailList").length()>0) {
				String[] perEmailList = request.getParameter("perEmailList").split(",");
				if(perEmailList != null && perEmailList.length > 0) {
					List<String> list = new ArrayList<String>(0); 
					for(String s:perEmailList) {
						list.add(s);
					}
					person.getPerEmailList().addAll(list);
				}else {
					String perEmailLists = request.getParameter("perEmailList");
					List<String> list = new ArrayList<String>(0); 
					list.add(perEmailLists);
					person.getPerEmailList().addAll(list);
				}
			}
			person.setActive(true);
			person.setModifiedBy(userEntity);
			person.setModifiedOn(new Date());
			person.setDeleted(false);
			if (files != null) {
				String fileName=OperationsUtil.uploadFile(files,person,CommonConstants.PROFILE);
				if(fileName == null) {
					response.setStatus(ResponseConstant.ERROR);
					response.setMessage(messageByLocaleService.getMessage(PATIENTURLConstant.PERSONAL_ERROR));
					response.setData(messageByLocaleService.getMessage(PATIENTURLConstant.PERSONAL_ERROR));
					return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
				}else {
					person.setPerProfile(fileName);
				}
			}else {
				person.setPerProfile(person.getPerProfile());
			}
			
			try {
				person=personService.saveOrUpdate(person);
			}catch (Exception e) {
				logger.error("Error:--", e);
				response.setStatus(ResponseConstant.ERROR);
				response.setMessage(messageByLocaleService.getMessage(PATIENTURLConstant.PERSONAL_ERROR));
				response.setData(messageByLocaleService.getMessage(PATIENTURLConstant.PERSONAL_ERROR));
				return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
			}
			boolean role=false;
			for (GrantedAuthority grantedAuthority : userDetails.getAuthorities()) {
				if(grantedAuthority.getAuthority().toString().equalsIgnoreCase(ServiceConstant.PATIENT_AUTHORITY)) {
					role=true;
				}
			}
			if(role) {
				if(CommonConstants.getPropertiesValue("TYPE").equalsIgnoreCase(CommonConstants.HYPERLEDGER)) {
					JSONObject userEntityData = new JSONObject();
					userEntityData.put("perLname", person.getPerLName());
					userEntityData.put("perFname", person.getPerFname());
					userEntityData.put("userEmail", userEntity.getUserEmail());
					userEntityData.put("userName", userEntity.getUserName());
					userEntityData.put("patientID", userEntity.getUserEmail());
					userEntityData.put("perContactNumber",person.getPerMobilePrimary());
					try {
						String userEntityUpdated = (String) HyperledgerApiUtil.post(
								CommonConstants.getPropertiesValue("HYPERLEDGER_BASE_REGISTER"),
								CommonConstants.getPropertiesValue("HYPERLEDGER_BASE_HOST"),
								userEntityData);
						if(userEntityUpdated.equalsIgnoreCase(CommonConstants.CODE)) {
							userEntity.setUserHyperledgerID(userEntity.getUserEmail());
						}else {
							JSONObject userEntityDatas = new JSONObject();
							userEntityDatas.put("perLname", person.getPerLName());
							userEntityDatas.put("perFname", person.getPerFname());
							userEntityDatas.put("userEmail", userEntity.getUserEmail());
							userEntityDatas.put("userName", userEntity.getUserName());
							userEntityDatas.put("perContactNumber",person.getPerMobilePrimary());
							String userEntityUpdateds = (String) HyperledgerApiUtil.put(
									CommonConstants.getPropertiesValue("HYPERLEDGER_BASE_REGISTER")+"/"+userEntity.getUserEmail(),
									CommonConstants.getPropertiesValue("HYPERLEDGER_BASE_HOST"),
									userEntityDatas);
							if(userEntityUpdateds.equalsIgnoreCase(CommonConstants.CODE)) {
								userEntity.setUserHyperledgerID(userEntity.getUserEmail());
							}else {
								userEntity.setUserHyperledgerID(null);
							}
						}
					}catch (Exception e) {
						logger.error("Error:--", e);
					}
				}else {
					JSONObject userEntityData = new JSONObject();
					userEntityData.put("lastName", person.getPerLName());
					userEntityData.put("firstName", person.getPerFname());
					userEntityData.put("emailId", userEntity.getUserEmail());
					userEntityData.put("password", userEntity.getUserPassword());
					userEntityData.put("patientId",userEntity.getUserBlockChainID());
					try {
						JSONObject userEntityUpdated = (JSONObject) ApiUtil.post(
								CommonConstants.getPropertiesValue("BLOCKCHAIN_BASE_REGISTER"),
								CommonConstants.getPropertiesValue("BLOCKCHAIN_POST_METHOD"),
								userEntityData);
						String ethreumId = userEntityUpdated.get("id").toString();
						String transectionId = userEntityUpdated.getString("transactionId").toString();
						userEntity.setUserTransectionID(transectionId);
						userEntity.setUserBlockChainID(ethreumId);
					}catch (Exception e) {
						logger.error("Error:--", e);
					}
				}
				userEntity.setActive(true);
				userEntity.setModifiedBy(userEntity);
				userEntity.setModifiedOn(new Date());
				userEntity.setDeleted(false);
				try {
					userService.saveOrUpdate(userEntity);
				}catch (Exception e) {
					logger.error("Error:--", e);
					response.setStatus(ResponseConstant.ERROR);
					response.setMessage(messageByLocaleService.getMessage(PATIENTURLConstant.PERSONAL_ERROR));
					response.setData(messageByLocaleService.getMessage(PATIENTURLConstant.PERSONAL_ERROR));
					return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
				}
			}
			response.setStatus(ResponseConstant.SUCCESS);
			response.setMessage(messageByLocaleService.getMessage(PATIENTURLConstant.PERSONAL_UPDATE));
			response.setData(messageByLocaleService.getMessage(PATIENTURLConstant.PERSONAL_UPDATE));
		} catch (Exception e) {
			logger.error("Error:--", e);
			response.setStatus(ResponseConstant.ERROR);
			response.setMessage(messageByLocaleService.getMessage(PATIENTURLConstant.PERSONAL_ERROR));
			response.setData(messageByLocaleService.getMessage(PATIENTURLConstant.PERSONAL_ERROR));
			return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Response>(response, HttpStatus.OK);
	}

	@RequestMapping(value = PATIENTURLConstant.PROFILE_DEMOGRAPHIC_GETDATA_URL, method = RequestMethod.POST, headers = CommonConstants.CONTENT_TYPE_APPLICATION_JSON)
	public ResponseEntity<Response> getDemographicData(Locale locale) {
		Response response = new Response();
		UserDetails userDetails = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		UserMaster userEntity = userService.findByUserName(userDetails.getUsername());
		try {
			PersonMaster person = personService.findByPerEmailPrimary(userEntity.getUserEmail());
			DemographicPojo demographicPojo = new DemographicPojo();
			List<String> mlist = person.getPerMobileList(); 
			List<Map<String, String>> providerMapList = new ArrayList<Map<String, String>>(0);
			for (int i=0;i<mlist.size();i++) {
				Map<String, String> providerMap = new HashMap<String, String>(0);
				providerMap.put("value", mlist.get(i));
				providerMapList.add(providerMap);
			}
			demographicPojo.setPerMobileList(providerMapList);
			demographicPojo.setPersonID(person.getPersonID());
			demographicPojo.setPerMobilePrimary(person.getPerMobilePrimary());
			demographicPojo.setPlmLocationStatus(PLMLocationStatus.Resi);
			List<LocationPojo> locationPojo=new ArrayList<LocationPojo>();
			List<PersonLocationMap> personLocationMap=personLocationService.getPersonDatas(person.getPersonID());
			for(PersonLocationMap plm:personLocationMap) {
				LocationMaster lm=locationService.get(plm.getLocationMaster().getLocationID());
				LocationPojo lp=new LocationPojo();
				lp.setLocationID(lm.getLocationID());
				lp.setAddressLine1(lm.getAddressLine1());
				lp.setAddressLine2(lm.getAddressLine2());
				lp.setAddressLine3(lm.getAddressLine3());
				lp.setArea(lm.getArea());
				lp.setCity(lm.getCity());
				lp.setState(lm.getState());
				lp.setZip(lm.getZip());
				lp.setCountry(lm.getCountry());
				lp.setMilestone1(lm.getMilestone1());
				lp.setMilestone2(lm.getMilestone2());
				TimeZoneMaster tzm = timeZoneService.get(lm.getTimeZoneMaster().getUtcTimeZoneId());
				TimeZonePojo tzp = new TimeZonePojo();
				tzp.setUtcTimeZoneId(tzm.getUtcTimeZoneId());
				tzp.setCountryCode(tzm.getCountryCode());
				tzp.setCountryName(tzm.getCountryName());
				tzp.setTimezoneAbbreviation(tzm.getTimezoneAbbreviation());
				tzp.setTimezoneName(tzm.getTimezoneName());
				tzp.setUtcOffset(tzm.getUtcOffset());
				lp.setTimeZoneMaster(tzp);
				locationPojo.add(lp);
			}
			demographicPojo.setLocationMaster(locationPojo);
			response.setStatus(ResponseConstant.SUCCESS);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_SUCCESS));
			response.setData(demographicPojo);
		}catch (Exception e) {
			logger.error("Error:--", e);
			response.setStatus(ResponseConstant.ERROR);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			response.setData(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Response>(response, HttpStatus.OK);
	}
	
	@RequestMapping(value = PATIENTURLConstant.PROFILE_DEMOGRAPHIC_URL, method = RequestMethod.POST, headers = CommonConstants.CONTENT_TYPE_APPLICATION_JSON)
	public ResponseEntity<Response> demographic(Locale locale, @RequestBody PersonMaster personMaster) {
		Response response = new Response();
		UserDetails userDetails = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		UserMaster userEntity = userService.findByUserName(userDetails.getUsername());
		try {
			    PersonMaster person = personService.get(personMaster.getPersonID());
			    personService.deletePersonMobileList(personMaster.getPersonID());
			    person.setPerMobilePrimary(personMaster.getPerMobilePrimary());
				person.setPerMobileList(personMaster.getPerMobileList());
				person=personService.saveOrUpdate(person);
				Set<LocationMaster> locationMaster = personMaster.getLocationMasterdata();
				for (LocationMaster lm : locationMaster) {
					if (lm.getLocationID() == null || lm.getLocationID().equals(0L)) {
						lm.setActive(true);
						lm.setCreatedOn(new Date());
						lm.setModifiedOn(new Date());
						lm.setCreatedBy(userEntity);
						lm.setModifiedBy(userEntity);
						lm.setDeleted(false);
						try {
							lm = locationService.saveOrUpdate(lm);
						}catch (Exception e) {
							logger.error("Error:--", e);
							response.setStatus(ResponseConstant.ERROR);
							response.setMessage(messageByLocaleService.getMessage(PATIENTURLConstant.PERSONAL_ERROR));
							response.setData(messageByLocaleService.getMessage(PATIENTURLConstant.PERSONAL_ERROR));
							return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
						}
						PersonLocationMap personLocationMap=new PersonLocationMap();
						personLocationMap.setLocationMaster(lm);
						personLocationMap.setCreatedOn(new Date());
						personLocationMap.setModifiedOn(new Date());
						personLocationMap.setCreatedBy(userEntity);
						personLocationMap.setModifiedBy(userEntity);
						personLocationMap.setDeleted(false);
						personLocationMap.setActive(true);
						personLocationMap.setPersonMaster(person);
						personLocationMap.setPlmLocationStatus(person.getPlmLocationStatus());
						try {
							personLocationService.saveOrUpdate(personLocationMap);
						}catch (Exception e) {
							logger.error("Error:--", e);
							response.setStatus(ResponseConstant.ERROR);
							response.setMessage(messageByLocaleService.getMessage(PATIENTURLConstant.PERSONAL_ERROR));
							response.setData(messageByLocaleService.getMessage(PATIENTURLConstant.PERSONAL_ERROR));
							return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
						}
					} else {
						lm.setActive(true);
						lm.setModifiedOn(new Date());
						lm.setModifiedBy(userEntity);
						lm.setDeleted(false);
						try {
							lm = locationService.saveOrUpdate(lm);
						}catch (Exception e) {
							logger.error("Error:--", e);
							response.setStatus(ResponseConstant.ERROR);
							response.setMessage(messageByLocaleService.getMessage(PATIENTURLConstant.PERSONAL_ERROR));
							response.setData(messageByLocaleService.getMessage(PATIENTURLConstant.PERSONAL_ERROR));
							return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
						}
						List<PersonLocationMap> personLocationMap=personLocationService.getPersonData(person.getPersonID(),lm.getLocationID());
						for(PersonLocationMap plm:personLocationMap) {
							plm.setActive(true);
							plm.setModifiedOn(new Date());
							plm.setModifiedBy(userEntity);
							plm.setDeleted(false);
							plm.setPersonMaster(person);
							plm.setLocationMaster(lm);
							plm.setPlmLocationStatus(person.getPlmLocationStatus());
							try {
								personLocationService.saveOrUpdate(plm);
							}catch (Exception e) {
								logger.error("Error:--", e);
								response.setStatus(ResponseConstant.ERROR);
								response.setMessage(messageByLocaleService.getMessage(PATIENTURLConstant.PERSONAL_ERROR));
								response.setData(messageByLocaleService.getMessage(PATIENTURLConstant.PERSONAL_ERROR));
								return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
							}
						}
						
					}
				}
				response.setStatus(ResponseConstant.SUCCESS);
				response.setMessage(messageByLocaleService.getMessage(PATIENTURLConstant.PERSONAL_UPDATE));
				response.setData(messageByLocaleService.getMessage(PATIENTURLConstant.PERSONAL_UPDATE));
			
		} catch (Exception e) {
			logger.error("Error:--", e);
			response.setStatus(ResponseConstant.ERROR);
			response.setMessage(messageByLocaleService.getMessage(PATIENTURLConstant.PERSONAL_ERROR));
			response.setData(messageByLocaleService.getMessage(PATIENTURLConstant.PERSONAL_ERROR));
			return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Response>(response, HttpStatus.OK);
	}
	
	@RequestMapping(value = PATIENTURLConstant.PROFILE_EXTENDED_GETDATA_URL, method = RequestMethod.POST, headers = CommonConstants.CONTENT_TYPE_APPLICATION_JSON)
	public ResponseEntity<Response> getExtendedData(Locale locale) {
		Response response = new Response();
		UserDetails userDetails = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		UserMaster userEntity = userService.findByUserName(userDetails.getUsername());
		try {
			ExtendedPojo extendedPojo = new ExtendedPojo();
			PersonMaster person = personService.findByPerEmailPrimary(userEntity.getUserEmail());
			extendedPojo.setPersonID(person.getPersonID());
			extendedPojo.setPerDOB(person.getPerDOB());
			if(person.getGender() != null) {
				extendedPojo.setGender(person.getGender());
			}
			extendedPojo.setPerDegree(person.getPerDegree());
			extendedPojo.setPerDesignation(person.getPerDesignation());
			if(person.getMarital() != null) {
				extendedPojo.setMarital(person.getMarital());
			}
			extendedPojo.setBodyHeight(person.getBodyHeight());
			extendedPojo.setBodyWeightInKG(person.getBodyWeightInKG());
			extendedPojo.setPerBloodGroup(person.getPerBloodGroup());
			extendedPojo.setChestInches(person.getChestInches());
			extendedPojo.setWaistInches(person.getWaistInches());
			if(person.getWork() != null) {
				extendedPojo.setWork(person.getWork());
			}
			if(person.getEmployment() != null) {
				extendedPojo.setEmployment(person.getEmployment());
			}
			response.setStatus(ResponseConstant.SUCCESS);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_SUCCESS));
			response.setData(extendedPojo);
		} catch (Exception e) {
			logger.error("Error:--", e);
			response.setStatus(ResponseConstant.ERROR);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			response.setData(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Response>(response, HttpStatus.OK);
	}

	@RequestMapping(value = PATIENTURLConstant.PROFILE_EXTENDED_URL, method = RequestMethod.POST, headers = CommonConstants.CONTENT_TYPE_APPLICATION_JSON)
	public ResponseEntity<Response> extended(Locale locale, @RequestBody PersonMaster personMaster) {
		Response response = new Response();
		UserDetails userDetails = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		UserMaster userEntity = userService.findByUserName(userDetails.getUsername());
		try {
			PersonMaster person = personService.get(personMaster.getPersonID());
			person.setPerDOB(personMaster.getPerDOB());
			person.setGender(personMaster.getGender());
			person.setPerDegree(personMaster.getPerDegree());
			person.setPerDesignation(personMaster.getPerDesignation());
			person.setMarital(personMaster.getMarital());
			person.setBodyHeight(personMaster.getBodyHeight());
			person.setBodyWeightInKG(personMaster.getBodyWeightInKG());
			person.setPerBloodGroup(personMaster.getPerBloodGroup());
			person.setChestInches(personMaster.getChestInches());
			person.setWaistInches(personMaster.getWaistInches());
			person.setWork(personMaster.getWork());
			person.setEmployment(personMaster.getEmployment());
			person.setActive(true);
			person.setModifiedBy(userEntity);
			person.setModifiedOn(new Date());
			person.setDeleted(false);
			try {
				personService.saveOrUpdate(person);
			}catch (Exception e) {
				logger.error("Error:--", e);
				response.setStatus(ResponseConstant.ERROR);
				response.setMessage(messageByLocaleService.getMessage(PATIENTURLConstant.PERSONAL_ERROR));
				response.setData(messageByLocaleService.getMessage(PATIENTURLConstant.PERSONAL_ERROR));
				return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
			}
			response.setStatus(ResponseConstant.SUCCESS);
			response.setMessage(messageByLocaleService.getMessage(PATIENTURLConstant.PERSONAL_UPDATE));
			response.setData(messageByLocaleService.getMessage(PATIENTURLConstant.PERSONAL_UPDATE));
		} catch (Exception e) {
			logger.error("Error:--", e);
			response.setStatus(ResponseConstant.ERROR);
			response.setMessage(messageByLocaleService.getMessage(PATIENTURLConstant.PERSONAL_ERROR));
			response.setData(messageByLocaleService.getMessage(PATIENTURLConstant.PERSONAL_ERROR));
			return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Response>(response, HttpStatus.OK);
	}

	@RequestMapping(value = PATIENTURLConstant.PROFILE_DOCUMENTS_GETDATA_URL, method = RequestMethod.POST, headers = CommonConstants.CONTENT_TYPE_APPLICATION_JSON)
	public ResponseEntity<Response> getDocuments(Locale locale,HttpServletRequest request) {
		Response response = new Response();
		UserDetails userDetails = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		UserMaster userEntity = userService.findByUserName(userDetails.getUsername());
		try {
			DocumentPojo documentPojo=new DocumentPojo();
			PersonMaster person = personService.findByPerEmailPrimary(userEntity.getUserEmail());
			documentPojo.setPersonID(person.getPersonID());
			documentPojo.setIsAadhaarverified(person.getIsAadhaarverified());
			documentPojo.setIsPerDrivingLicense(person.getIsPerDrivingLicense());
			documentPojo.setIsPerPANCardverified(person.getIsPerPANCardverified());
			documentPojo.setPerPANcardID(request.getScheme() + "://" + request.getServerName() + ":"
					+ request.getServerPort() + request.getContextPath() + PATIENTURLConstant.PROFILE_IMAGE_ROOT_URL + PATIENTURLConstant.GET_IMAGES_URL
					+ "?filepath=" + person.getPerPANcardID());
			if(documentPojo.getPerPANcardID().equalsIgnoreCase("/getImages?filepath=null")) {
				documentPojo.setPerPANcardID(null);
			}
			documentPojo.setPerAadhaarCardID(request.getScheme() + "://" + request.getServerName() + ":"
					+ request.getServerPort() + request.getContextPath() + PATIENTURLConstant.PROFILE_IMAGE_ROOT_URL + PATIENTURLConstant.GET_IMAGES_URL
					+ "?filepath=" + person.getPerAadhaarCardID());
			if(documentPojo.getPerAadhaarCardID().equalsIgnoreCase("/getImages?filepath=null")) {
				documentPojo.setPerAadhaarCardID(null);
			}
			documentPojo.setPerDrivingLicenseID(request.getScheme() + "://" + request.getServerName() + ":"
					+ request.getServerPort() + request.getContextPath() + PATIENTURLConstant.PROFILE_IMAGE_ROOT_URL + PATIENTURLConstant.GET_IMAGES_URL
					+ "?filepath=" + person.getPerDrivingLicenseID());
			if(documentPojo.getPerDrivingLicenseID().equalsIgnoreCase("/getImages?filepath=null")) {
				documentPojo.setPerDrivingLicenseID(null);
			}
			documentPojo.setPerAadhaarCardNo(person.getPerAadhaarCardNo());
			documentPojo.setPerDrivingLicenseNo(person.getPerDrivingLicenseNo());
			documentPojo.setPerPANcardNo(person.getPerPANcardNo());
			documentPojo.setPerSIN(person.getPerSIN());
			documentPojo.setPerSSN(person.getPerSSN());
			response.setStatus(ResponseConstant.SUCCESS);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_SUCCESS));
			response.setData(documentPojo);
		} catch (Exception e) {
			logger.error("Error:--", e);
			response.setStatus(ResponseConstant.ERROR);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			response.setData(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Response>(response, HttpStatus.OK);
	}

	@RequestMapping(value = PATIENTURLConstant.PROFILE_DOCUMENTS_URL, method = RequestMethod.POST)
	public ResponseEntity<Response> documents(Locale locale, @RequestParam(value = "perAadhaar", required = false) MultipartFile perAadhaar,
			@RequestParam(value = "perDriving", required = false) MultipartFile perDriving,@RequestParam(value = "perPANCard", required = false) MultipartFile perPANCard,
			HttpServletRequest request) {
		Response response = new Response();
		UserDetails userDetails = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		UserMaster userEntity = userService.findByUserName(userDetails.getUsername());
		try {
			PersonMaster person = personService.get(Long.parseLong(request.getParameter("personID")));
			if(request.getParameter("isAadhaarverified") !=null && request.getParameter("isAadhaarverified").equalsIgnoreCase(CommonConstants.TRUE)) {	
				if (perAadhaar != null) {
					String fileName=OperationsUtil.uploadFile(perAadhaar,person,CommonConstants.ATHAR);
					if(fileName == null) {
						response.setStatus(ResponseConstant.ERROR);
						response.setMessage(messageByLocaleService.getMessage(PATIENTURLConstant.PERSONAL_ERROR));
						response.setData(messageByLocaleService.getMessage(PATIENTURLConstant.PERSONAL_ERROR));
						return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
					}else {
						person.setPerAadhaarCardNo(request.getParameter("perAadhaarNo"));
						person.setIsAadhaarverified(true);
						person.setPerAadhaarCardID(fileName);
					}
				}else {
					person.setPerAadhaarCardNo(request.getParameter("perAadhaarNo"));
					person.setIsAadhaarverified(true);
					person.setPerAadhaarCardID(person.getPerAadhaarCardID());
				}
			}else {
				person.setPerAadhaarCardNo(null);
				person.setIsAadhaarverified(false);
				person.setPerAadhaarCardID(null);
			}
			if(request.getParameter("isPerDrivingLicense") !=null && request.getParameter("isPerDrivingLicense").equalsIgnoreCase(CommonConstants.TRUE)) {	
				if (perDriving != null) {
					String fileName=OperationsUtil.uploadFile(perDriving,person,CommonConstants.DRIVING);
					if(fileName == null) {
						response.setStatus(ResponseConstant.ERROR);
						response.setMessage(messageByLocaleService.getMessage(PATIENTURLConstant.PERSONAL_ERROR));
						response.setData(messageByLocaleService.getMessage(PATIENTURLConstant.PERSONAL_ERROR));
						return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
					}else {
						person.setPerDrivingLicenseNo(request.getParameter("perDrivingNo"));
						person.setIsPerDrivingLicense(true);
						person.setPerDrivingLicenseID(fileName);
					}
				}else {
					person.setPerDrivingLicenseNo(request.getParameter("perDrivingNo"));
					person.setIsPerDrivingLicense(true);
					person.setPerDrivingLicenseID(person.getPerAadhaarCardID());
				}
			}else {
				person.setPerDrivingLicenseNo(null);
				person.setIsPerDrivingLicense(false);
				person.setPerDrivingLicenseID(null);
			}
			if(request.getParameter("isPerPANCardverified") !=null && request.getParameter("isPerPANCardverified").equalsIgnoreCase(CommonConstants.TRUE)) {	
				if (perPANCard != null) {
					String fileName=OperationsUtil.uploadFile(perPANCard,person,CommonConstants.PANCARD);
					if(fileName == null) {
						response.setStatus(ResponseConstant.ERROR);
						response.setMessage(messageByLocaleService.getMessage(PATIENTURLConstant.PERSONAL_ERROR));
						response.setData(messageByLocaleService.getMessage(PATIENTURLConstant.PERSONAL_ERROR));
						return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
					}else {
						person.setPerPANcardNo(request.getParameter("perPANCardNo"));
						person.setIsPerPANCardverified(true);
						person.setPerPANcardID(fileName);
					}
				}else {
					person.setPerPANcardNo(request.getParameter("perPANCardNo"));
					person.setIsPerPANCardverified(true);
					person.setPerPANcardID(person.getPerAadhaarCardID());
				}
			}else {
				person.setPerPANcardNo(null);
				person.setIsPerPANCardverified(false);
				person.setPerPANcardID(null);
			}
			person.setPerSIN(request.getParameter("perSIN"));
			person.setPerSSN(request.getParameter("perSSN"));
			person.setActive(true);
			person.setModifiedBy(userEntity);
			person.setModifiedOn(new Date());
			person.setDeleted(false);
			try {
				personService.saveOrUpdate(person);
			}catch (Exception e) {
				logger.error("Error:--", e);
				response.setStatus(ResponseConstant.ERROR);
				response.setMessage(messageByLocaleService.getMessage(PATIENTURLConstant.PERSONAL_ERROR));
				response.setData(messageByLocaleService.getMessage(PATIENTURLConstant.PERSONAL_ERROR));
				return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
			}
			response.setStatus(ResponseConstant.SUCCESS);
			response.setMessage(messageByLocaleService.getMessage(PATIENTURLConstant.PERSONAL_UPDATE));
			response.setData(messageByLocaleService.getMessage(PATIENTURLConstant.PERSONAL_UPDATE));
		} catch (Exception e) {
			logger.error("Error:--", e);
			response.setStatus(ResponseConstant.ERROR);
			response.setMessage(messageByLocaleService.getMessage(PATIENTURLConstant.PERSONAL_ERROR));
			response.setData(messageByLocaleService.getMessage(PATIENTURLConstant.PERSONAL_ERROR));
			return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Response>(response, HttpStatus.OK);
	}
	
	@RequestMapping(value = PATIENTURLConstant.GET_REGISTERDATA_FOR_HYPERLEDGER, method = RequestMethod.POST, headers = CommonConstants.CONTENT_TYPE_APPLICATION_JSON)
	public ResponseEntity<Response> getRegisterDataForHyperledger(Locale locale,@RequestBody UserMaster userMaster) {
		Response response = new Response();
		try {
			JSONObject userEntityUpdateds = (JSONObject) HyperledgerApiUtil.getForPatient(
					CommonConstants.getPropertiesValue("HYPERLEDGER_BASE_GET_REGISTER")+"/"+userMaster.getUserEmail(),
					CommonConstants.getPropertiesValue("HYPERLEDGER_BASE_HOST"));
			if(userEntityUpdateds !=null) {
				JSONArray lab = (JSONArray) HyperledgerApiUtil.get(
						CommonConstants.getPropertiesValue("HYPERLEDGER_BASE_GET_REPORT")+"?patientID="+userMaster.getUserEmail(),
						CommonConstants.getPropertiesValue("HYPERLEDGER_BASE_HOST"));
				userEntityUpdateds.put("Reports", lab);
				JSONArray vistit = (JSONArray) HyperledgerApiUtil.get(
						CommonConstants.getPropertiesValue("HYPERLEDGER_BASE_GET_VISITNOTE")+"?patientID="+userMaster.getUserEmail(),
						CommonConstants.getPropertiesValue("HYPERLEDGER_BASE_HOST"));
				userEntityUpdateds.put("Visits", vistit);
				response.setStatus(ResponseConstant.SUCCESS);
				response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_SUCCESS));
				response.setData(userEntityUpdateds);
			}else {
				response.setStatus(ResponseConstant.ERROR);
				response.setMessage(messageByLocaleService.getMessage(ServiceConstant.NOT_DATA));
				response.setData(messageByLocaleService.getMessage(ServiceConstant.NOT_DATA));
				return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
			}
		}catch (Exception e) {
			logger.error("Error:--", e);
			response.setStatus(ResponseConstant.ERROR);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			response.setData(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Response>(response, HttpStatus.OK);
	}
}
