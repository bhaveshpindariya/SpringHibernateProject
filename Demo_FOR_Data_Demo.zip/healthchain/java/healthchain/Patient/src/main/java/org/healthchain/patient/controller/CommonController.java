package org.healthchain.patient.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.healthchain.common.constants.CommonConstants;
import org.healthchain.common.constants.ResponseConstant;
import org.healthchain.common.utils.DateUtil;
import org.healthchain.common.utils.OperationsUtil;
import org.healthchain.entity.CFLPatRegistrationMap;
import org.healthchain.entity.DiagnosisMaster;
import org.healthchain.entity.DrugCompoundMaster;
import org.healthchain.entity.DrugManufacturersMaster;
import org.healthchain.entity.FCLProviderMap;
import org.healthchain.entity.FCLProviderReportMap;
import org.healthchain.entity.FCLocationMap;
import org.healthchain.entity.FacilityCenterMaster;
import org.healthchain.entity.LabReportsLevel1;
import org.healthchain.entity.LocationMaster;
import org.healthchain.entity.PatAppointments;
import org.healthchain.entity.PatLabAppointments;
import org.healthchain.entity.PatientMaster;
import org.healthchain.entity.PersonMaster;
import org.healthchain.entity.ProviderMaster;
import org.healthchain.entity.SpecialityMaster;
import org.healthchain.entity.SpecialityProviderMaster;
import org.healthchain.entity.SuggestReport;
import org.healthchain.entity.TimeZoneMaster;
import org.healthchain.entity.UserMaster;
import org.healthchain.entity.enums.EmploymentStatus;
import org.healthchain.entity.enums.FacilityCenterType;
import org.healthchain.entity.enums.GenderStatus;
import org.healthchain.entity.enums.LabReportType;
import org.healthchain.entity.enums.MaritalStatus;
import org.healthchain.entity.enums.PLMLocationStatus;
import org.healthchain.entity.enums.PatientAppointmentReason;
import org.healthchain.entity.enums.PatientAppointmentStatus;
import org.healthchain.entity.enums.PatientAppointmentType;
import org.healthchain.entity.enums.PatientLabAppointmentReason;
import org.healthchain.entity.enums.ProviderTypeStatus;
import org.healthchain.entity.enums.SpecialityCode;
import org.healthchain.entity.enums.WorkStatus;
import org.healthchain.patient.constants.PATIENTURLConstant;
import org.healthchain.pojo.DiseasePojo;
import org.healthchain.pojo.DrugCompoundPojo;
import org.healthchain.pojo.DrugManufacturersPojo;
import org.healthchain.pojo.FCLProviderReportMapPojo;
import org.healthchain.pojo.FCLocationMapPojo;
import org.healthchain.pojo.FacilityCenterPojo;
import org.healthchain.pojo.LabDataPojo;
import org.healthchain.pojo.LabReportsLevel1Pojo;
import org.healthchain.pojo.LocationPojo;
import org.healthchain.pojo.PatientPojo;
import org.healthchain.pojo.ProfessionalPojo;
import org.healthchain.pojo.ProviderPojo;
import org.healthchain.pojo.Response;
import org.healthchain.pojo.SpecialityPojo;
import org.healthchain.pojo.StatusChange;
import org.healthchain.pojo.TimeZonePojo;
import org.healthchain.services.CFLPatRegistrationMapService;
import org.healthchain.services.DiagnosisService;
import org.healthchain.services.DrugCompoundService;
import org.healthchain.services.DrugManufacturersService;
import org.healthchain.services.FCLProviderReportMapService;
import org.healthchain.services.FCLProviderService;
import org.healthchain.services.FCLocationMapService;
import org.healthchain.services.FacilityCenterService;
import org.healthchain.services.LabReportsLevel1Service;
import org.healthchain.services.LocationService;
import org.healthchain.services.MessageByLocaleService;
import org.healthchain.services.PatAppointmentService;
import org.healthchain.services.PatLabAppointmentService;
import org.healthchain.services.PatientService;
import org.healthchain.services.PersonService;
import org.healthchain.services.ProviderService;
import org.healthchain.services.SpecialityService;
import org.healthchain.services.SuggestReportService;
import org.healthchain.services.TimeZoneService;
import org.healthchain.services.UserService;
import org.healthchain.services.constants.ServiceConstant;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@CrossOrigin
@RestController
@RequestMapping(PATIENTURLConstant.COMMON_ROOT_URL)
public class CommonController {

	private static final Log logger = LogFactory.getLog(CommonController.class);

	@Autowired
	private PersonService personService;

	@Autowired
	private PatientService patientService;

	@Autowired
	private DiagnosisService diagnosisService;

	@Autowired
	private TimeZoneService timeZoneService;

	@Autowired
	private FacilityCenterService facilityCenterService;

	@Autowired
	private PatLabAppointmentService patLabAppointmentService;

	@Autowired
	private FCLProviderReportMapService fclProviderReportMapService;

	@Autowired
	private LocationService locationService;

	@Autowired
	private ProviderService providerService;

	@Autowired
	private SpecialityService specialityService;

	@Autowired
	private FCLProviderService fclProviderService;

	@Autowired
	private LabReportsLevel1Service labReportsLevel1Service;

	@Autowired
	private DrugCompoundService drugCompoundService;

	@Autowired
	private PatAppointmentService patAppointmentService;

	@Autowired
	private UserService userService;

	@Autowired
	private DrugManufacturersService drugManufacturersService;

	@Autowired
	private MessageByLocaleService messageByLocaleService;

	@Autowired
	private FCLocationMapService fcLocationMapService;

	@Autowired
	private SuggestReportService suggestReportService;

	@Autowired
	private CFLPatRegistrationMapService cflPatRegistrationMapService;

	@RequestMapping(value = PATIENTURLConstant.GET_ALL_FACILITY_BY_PROFESSIONAL_URL, method = RequestMethod.POST, headers = CommonConstants.CONTENT_TYPE_APPLICATION_JSON)
	public ResponseEntity<Response> getAllFacilityByMedicalProfessional(Locale locale,
			@RequestBody FacilityCenterMaster facilityCenterMaster) throws JSONException {
		Response response = new Response();
		try {
			List<FacilityCenterMaster> facilityCenterData = facilityCenterService.getAllActiveRecordByPerameterData(
					facilityCenterMaster.getFacilityCenterType(), facilityCenterMaster.getFacilityCenterName());
			List<ProviderPojo> facilityCenterPojo = new ArrayList<ProviderPojo>();
			for (FacilityCenterMaster fcm : facilityCenterData) {
				List<FCLocationMap> fcLocationMapData = fcLocationMapService.getLocation(fcm);
				for (FCLocationMap fl : fcLocationMapData) {
					List<FCLProviderMap> fclProviderMap = fclProviderService.getAllProvider(fl);
					for (FCLProviderMap fpm : fclProviderMap) {
						ProviderPojo fcp = new ProviderPojo();
						fcp.setProviderID(fcm.getFacilityCenterID());
						fcp.setProviderName(fcm.getFacilityCenterName());
						fcp.setFclProviderMapID(fpm.getFclProviderMapID());
						facilityCenterPojo.add(fcp);
					}
				}

			}
			response.setStatus(ResponseConstant.SUCCESS);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_SUCCESS));
			response.setData(facilityCenterPojo);
		} catch (Exception e) {
			logger.error("Error:--", e);
			response.setStatus(ResponseConstant.ERROR);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			response.setData(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Response>(response, HttpStatus.OK);
	}

	@RequestMapping(value = PATIENTURLConstant.GET_ALL_FACILITY_URL, method = RequestMethod.POST, headers = CommonConstants.CONTENT_TYPE_APPLICATION_JSON)
	public ResponseEntity<Response> getAllFacility(Locale locale) {
		Response response = new Response();
		try {
			List<FacilityCenterMaster> facilityCenterData = facilityCenterService.getAllActiveRecord();
			List<FacilityCenterPojo> facilityCenterPojo = new ArrayList<FacilityCenterPojo>();
			for (FacilityCenterMaster fcm : facilityCenterData) {
				FacilityCenterPojo fcp = new FacilityCenterPojo();
				fcp.setFacilityCenterID(fcm.getFacilityCenterID());
				fcp.setFacilityCenterName(fcm.getFacilityCenterName());
				fcp.setFacilityCenterType(fcm.getFacilityCenterType());
				fcp.setFcCertificateNumber(fcm.getFcCertificateNumber());
				facilityCenterPojo.add(fcp);
			}
			response.setStatus(ResponseConstant.SUCCESS);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_SUCCESS));
			response.setData(facilityCenterPojo);
		} catch (Exception e) {
			logger.error("Error:--", e);
			response.setStatus(ResponseConstant.ERROR);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			response.setData(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Response>(response, HttpStatus.OK);
	}

	@RequestMapping(value = PATIENTURLConstant.GET_ALL_FACILITY_BY_PERAMETER_URL, method = RequestMethod.POST, headers = CommonConstants.CONTENT_TYPE_APPLICATION_JSON)
	public ResponseEntity<Response> getAllFacilityByPerameter(Locale locale,
			@RequestBody FacilityCenterMaster facilityCenterMaster) {
		Response response = new Response();
		try {
			List<FacilityCenterMaster> facilityCenterData = facilityCenterService
					.getAllActiveRecordByPerameter(facilityCenterMaster.getFacilityCenterType());
			List<FacilityCenterPojo> facilityCenterPojo = new ArrayList<FacilityCenterPojo>();
			for (FacilityCenterMaster fcm : facilityCenterData) {
				FacilityCenterPojo fcp = new FacilityCenterPojo();
				fcp.setFacilityCenterID(fcm.getFacilityCenterID());
				fcp.setFacilityCenterName(fcm.getFacilityCenterName());
				fcp.setFacilityCenterType(fcm.getFacilityCenterType());
				fcp.setFcCertificateNumber(fcm.getFcCertificateNumber());
				facilityCenterPojo.add(fcp);
			}
			response.setStatus(ResponseConstant.SUCCESS);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_SUCCESS));
			response.setData(facilityCenterPojo);
		} catch (Exception e) {
			logger.error("Error:--", e);
			response.setStatus(ResponseConstant.ERROR);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			response.setData(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Response>(response, HttpStatus.OK);
	}

	@RequestMapping(value = PATIENTURLConstant.GET_ALL_LOCATIONBASED_ON_FACILITY_URL, method = RequestMethod.POST, headers = CommonConstants.CONTENT_TYPE_APPLICATION_JSON)
	public ResponseEntity<Response> getAllLocationByFacility(Locale locale,
			@RequestBody FacilityCenterMaster facilityCenterMaster) {
		Response response = new Response();
		try {
			List<FCLocationMap> fcLocationMapData = fcLocationMapService.getLocation(facilityCenterMaster);
			List<FCLocationMapPojo> fcLocationMapPojo = new ArrayList<FCLocationMapPojo>();
			for (FCLocationMap flm : fcLocationMapData) {
				FCLocationMapPojo flp = new FCLocationMapPojo();
				flp.setFcLocationMapID(flm.getFcLocationMapID());
				flp.setFcLocationName(flm.getFcLocationName());
				fcLocationMapPojo.add(flp);
			}
			response.setStatus(ResponseConstant.SUCCESS);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_SUCCESS));
			response.setData(fcLocationMapPojo);
		} catch (Exception e) {
			logger.error("Error:--", e);
			response.setStatus(ResponseConstant.ERROR);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			response.setData(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Response>(response, HttpStatus.OK);
	}

	@RequestMapping(value = PATIENTURLConstant.GET_SPECIALITY_BY_LOCATION_AND_FACILITY, method = RequestMethod.POST, headers = CommonConstants.CONTENT_TYPE_APPLICATION_JSON)
	public ResponseEntity<Response> getAllSpecialityByLocationAndFacility(Locale locale,
			@RequestBody FCLocationMap fcLocationMap) {
		Response response = new Response();
		try {
			List<FCLProviderMap> fclProviderMap = fclProviderService.getAllProvider(fcLocationMap);
			List<SpecialityPojo> specialityPojo = new ArrayList<SpecialityPojo>();
			Set<String> spName = new HashSet<String>();
			Set<SpecialityProviderMaster> specialityProviderMaster = new HashSet<SpecialityProviderMaster>(0);
			for (FCLProviderMap fpm : fclProviderMap) {
				specialityProviderMaster.addAll(fpm.getProviderID().getSpecialityProviderMaster());
			}
			for (SpecialityProviderMaster spm : specialityProviderMaster) {
				spName.add(spm.getSpecialityMaster().getSpecialityName());
			}
			if (spName.size() > 0) {
				for (String name : spName) {
					SpecialityPojo sp = new SpecialityPojo();
					SpecialityMaster specialityMaster = specialityService.findByName(name);
					sp.setSpecialityID(specialityMaster.getSpecialityID());
					sp.setSpecialityName(specialityMaster.getSpecialityName());
					sp.setSpecialityCode(specialityMaster.getSpecialityCode() + "");
					specialityPojo.add(sp);
				}
			}
			response.setStatus(ResponseConstant.SUCCESS);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_SUCCESS));
			response.setData(specialityPojo);
		} catch (Exception e) {
			logger.error("Error:--", e);
			response.setStatus(ResponseConstant.ERROR);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			response.setData(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Response>(response, HttpStatus.OK);
	}

	@RequestMapping(value = PATIENTURLConstant.GET_DOCTOR_BY_SPECIALITY_AND_LOCATION, method = RequestMethod.POST, headers = CommonConstants.CONTENT_TYPE_APPLICATION_JSON)
	public ResponseEntity<Response> getAllDoctorByLocationAndspeciality(Locale locale, @RequestBody String jsonData)
			throws JSONException {
		final JSONObject obj = new JSONObject(jsonData);
		Long specialityID = obj.getLong("SpecialityID");
		Long fcLocationMapID = obj.getLong("FcLocationMapID");
		Response response = new Response();
		try {
			List<ProviderPojo> providerPojo = new ArrayList<ProviderPojo>();
			FCLocationMap fcLocationMap = fcLocationMapService.get(fcLocationMapID);
			List<FCLProviderMap> fclProviderMap = fclProviderService.getAllProvider(fcLocationMap);
			Set<SpecialityProviderMaster> specialityProviderMaster = new HashSet<SpecialityProviderMaster>(0);
			for (FCLProviderMap fpm : fclProviderMap) {
				specialityProviderMaster.addAll(fpm.getProviderID().getSpecialityProviderMaster());
			}
			for (SpecialityProviderMaster spm : specialityProviderMaster) {
				if (spm.getSpecialityMaster().getSpecialityID().equals(specialityID)) {
					FCLProviderMap fpm = fclProviderService.getdata(spm.getProviderMaster().getProviderID(),
							fcLocationMap.getFcLocationMapID());
					if (fpm != null) {
						ProviderPojo pp = new ProviderPojo();
						pp.setProviderID(fpm.getProviderID().getProviderID());
						pp.setFclProviderMapID(fpm.getFclProviderMapID());
						PersonMaster person = personService.get(fpm.getProviderID().getPersonMaster().getPersonID());
						pp.setProviderName(person.getPerFname() + " " + person.getPerLName());
						pp.setProviderTypeStatus(spm.getProviderMaster().getProviderTypeStatus());
						providerPojo.add(pp);
					}
				}
			}
			response.setStatus(ResponseConstant.SUCCESS);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_SUCCESS));
			response.setData(providerPojo);
		} catch (Exception e) {
			logger.error("Error:--", e);
			response.setStatus(ResponseConstant.ERROR);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			response.setData(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Response>(response, HttpStatus.OK);
	}

	@RequestMapping(value = PATIENTURLConstant.GET_ALL_DOCTOR_URL, method = RequestMethod.POST, headers = CommonConstants.CONTENT_TYPE_APPLICATION_JSON)
	public ResponseEntity<Response> getAllDoctor(Locale locale) {
		Response response = new Response();
		try {
			ProviderTypeStatus providerType = ProviderTypeStatus.parse(ServiceConstant.DOCTOR_AUTHORITY);
			List<ProviderMaster> providerMaster = providerService.getAllActiveDoctor(providerType);
			List<ProviderPojo> providerPojo = new ArrayList<ProviderPojo>();
			for (ProviderMaster pm : providerMaster) {
				List<FCLProviderMap> fclProviderMap = fclProviderService.getFclDataforDoctor(pm.getProviderID(),pm.getProviderTypeStatus());
				if (fclProviderMap.size() > 0) {
					ProviderPojo pp = new ProviderPojo();
					pp.setProviderID(pm.getProviderID());
					PersonMaster person = personService.get(pm.getPersonMaster().getPersonID());
					pp.setProviderName(
							CommonConstants.DR_SHORT + " " + person.getPerFname() + " " + person.getPerLName());
					pp.setProviderTypeStatus(pm.getProviderTypeStatus());
					pp.setFclProviderMapID(fclProviderMap.get(0).getFclProviderMapID());
					providerPojo.add(pp);
				}

			}
			response.setStatus(ResponseConstant.SUCCESS);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_SUCCESS));
			response.setData(providerPojo);
		} catch (Exception e) {
			logger.error("Error:--", e);
			response.setStatus(ResponseConstant.ERROR);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			response.setData(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Response>(response, HttpStatus.OK);
	}

	@RequestMapping(value = PATIENTURLConstant.GET_ALL_DOCTOR_BY_PERAMETER_URL, method = RequestMethod.POST, headers = CommonConstants.CONTENT_TYPE_APPLICATION_JSON)
	public ResponseEntity<Response> getAllDoctorByperameter(Locale locale, @RequestBody String jsonData)
			throws JSONException {
		final JSONObject obj = new JSONObject(jsonData);
		String name = obj.getString("DoctorName");
		Response response = new Response();
		try {
			ProviderTypeStatus providerType = ProviderTypeStatus.parse(ServiceConstant.DOCTOR_AUTHORITY);
			List<ProviderMaster> providerMaster = providerService.getAllDoctorByperameter(providerType, name);
			List<ProviderPojo> providerPojo = new ArrayList<ProviderPojo>();
			for (ProviderMaster pm : providerMaster) {
				List<FCLProviderMap> fclProviderMap = fclProviderService.getFclDataforDoctor(pm.getProviderID(),
						pm.getProviderTypeStatus());
				if (fclProviderMap.size() > 0) {
					ProviderPojo pp = new ProviderPojo();
					pp.setProviderID(pm.getProviderID());
					PersonMaster person = personService.get(pm.getPersonMaster().getPersonID());
					pp.setProviderName(
							CommonConstants.DR_SHORT + " " + person.getPerFname() + " " + person.getPerLName());
					pp.setProviderTypeStatus(pm.getProviderTypeStatus());
					pp.setFclProviderMapID(fclProviderMap.get(0).getFclProviderMapID());
					providerPojo.add(pp);
				}

			}
			response.setStatus(ResponseConstant.SUCCESS);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_SUCCESS));
			response.setData(providerPojo);
		} catch (Exception e) {
			logger.error("Error:--", e);
			response.setStatus(ResponseConstant.ERROR);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			response.setData(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Response>(response, HttpStatus.OK);
	}

	@RequestMapping(value = PATIENTURLConstant.GET_ALL_LOCATION_URL, method = RequestMethod.POST, headers = CommonConstants.CONTENT_TYPE_APPLICATION_JSON)
	public ResponseEntity<Response> getAllLocation(Locale locale) {
		Response response = new Response();
		try {
			List<LocationMaster> locationMasterData = locationService.getAllActiveRecord();
			List<LocationPojo> locationPojo = new ArrayList<LocationPojo>();
			for (LocationMaster lm : locationMasterData) {
				LocationPojo lp = new LocationPojo();
				lp.setLocationID(lm.getLocationID());
				lp.setAddressLine1(lm.getAddressLine1());
				lp.setAddressLine2(lm.getAddressLine2());
				lp.setAddressLine3(lm.getAddressLine3());
				lp.setArea(lm.getArea());
				lp.setCity(lm.getCity());
				lp.setState(lm.getState());
				lp.setZip(lm.getZip());
				lp.setCountry(lm.getCountry());
				lp.setMilestone1(lm.getMilestone1());
				lp.setMilestone2(lm.getMilestone2());
				TimeZoneMaster tzm = timeZoneService.get(lm.getTimeZoneMaster().getUtcTimeZoneId());
				TimeZonePojo tzp = new TimeZonePojo();
				tzp.setUtcTimeZoneId(tzm.getUtcTimeZoneId());
				tzp.setCountryCode(tzm.getCountryCode());
				tzp.setCountryName(tzm.getCountryName());
				tzp.setTimezoneAbbreviation(tzm.getTimezoneAbbreviation());
				tzp.setTimezoneName(tzm.getTimezoneName());
				tzp.setUtcOffset(tzm.getUtcOffset());
				lp.setTimeZoneMaster(tzp);
				locationPojo.add(lp);
			}
			response.setStatus(ResponseConstant.SUCCESS);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_SUCCESS));
			response.setData(locationPojo);
		} catch (Exception e) {
			logger.error("Error:--", e);
			response.setStatus(ResponseConstant.ERROR);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			response.setData(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Response>(response, HttpStatus.OK);
	}

	@RequestMapping(value = PATIENTURLConstant.TIMEZONE_GET_URL, method = RequestMethod.POST, headers = CommonConstants.CONTENT_TYPE_APPLICATION_JSON)
	public ResponseEntity<Response> getAllTimeZone(Locale locale) {
		Response response = new Response();
		try {
			List<TimeZoneMaster> timeZoneData = timeZoneService.getAllActiveRecord();
			List<TimeZonePojo> timeZonePojo = new ArrayList<TimeZonePojo>();
			for (TimeZoneMaster timezone : timeZoneData) {
				TimeZonePojo tzp = new TimeZonePojo();
				tzp.setUtcTimeZoneId(timezone.getUtcTimeZoneId());
				tzp.setCountryCode(timezone.getCountryCode());
				tzp.setCountryName(timezone.getCountryName());
				tzp.setTimezoneAbbreviation(timezone.getTimezoneAbbreviation());
				tzp.setTimezoneName(timezone.getTimezoneName());
				tzp.setUtcOffset(timezone.getUtcOffset());
				timeZonePojo.add(tzp);
			}
			response.setStatus(ResponseConstant.SUCCESS);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_SUCCESS));
			response.setData(timeZonePojo);
		} catch (Exception e) {
			logger.error("Error:--", e);
			response.setStatus(ResponseConstant.ERROR);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			response.setData(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Response>(response, HttpStatus.OK);
	}

	@RequestMapping(value = PATIENTURLConstant.SPECIALITY_GET_URL, method = RequestMethod.POST, headers = CommonConstants.CONTENT_TYPE_APPLICATION_JSON)
	public ResponseEntity<Response> getAllSpeciality(Locale locale) {
		Response response = new Response();
		try {
			List<SpecialityMaster> SpecialityData = specialityService.getAllActiveRecord();
			List<SpecialityPojo> specialityPojo = new ArrayList<SpecialityPojo>();
			for (SpecialityMaster sm : SpecialityData) {
				SpecialityPojo sp = new SpecialityPojo();
				sp.setSpecialityID(sm.getSpecialityID());
				sp.setSpecialityName(sm.getSpecialityName());
				sp.setSpecialityCode(sm.getSpecialityCode() + "");
				specialityPojo.add(sp);
			}
			response.setStatus(ResponseConstant.SUCCESS);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_SUCCESS));
			response.setData(specialityPojo);
		} catch (Exception e) {
			logger.error("Error:--", e);
			response.setStatus(ResponseConstant.ERROR);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			response.setData(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Response>(response, HttpStatus.OK);
	}

	@RequestMapping(value = PATIENTURLConstant.FACILITY_URL, method = RequestMethod.POST, headers = CommonConstants.CONTENT_TYPE_APPLICATION_JSON)
	public ResponseEntity<Response> facilityType(Locale locale) {
		Response response = new Response();
		try {
			List<String> facilityType = FacilityCenterType.getFacilityCenterType();
			List<Map<String, String>> mapList = new ArrayList<Map<String, String>>(0);
			for (String string : facilityType) {
				Map<String, String> facilityMap = new HashMap<String, String>(0);
				String value = FacilityCenterType.getValue(string);
				facilityMap.put("key", string);
				facilityMap.put("value", value);
				mapList.add(facilityMap);
			}
			response.setStatus(ResponseConstant.SUCCESS);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_SUCCESS));
			response.setData(mapList);
		} catch (Exception e) {
			logger.error("Error:--", e);
			response.setStatus(ResponseConstant.ERROR);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			response.setData(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Response>(response, HttpStatus.OK);
	}

	@RequestMapping(value = PATIENTURLConstant.PROVIDER_URL, method = RequestMethod.POST, headers = CommonConstants.CONTENT_TYPE_APPLICATION_JSON)
	public ResponseEntity<Response> providerType(Locale locale) {
		Response response = new Response();
		try {
			List<String> providerType = ProviderTypeStatus.getAllProviderTypeStatus();
			List<Map<String, String>> providerlist = new ArrayList<Map<String, String>>(0);
			for (String string : providerType) {
				Map<String, String> providerMap = new HashMap<String, String>(0);
				String value = ProviderTypeStatus.getValue(string);
				providerMap.put("key", string);
				providerMap.put("value", value);
				providerlist.add(providerMap);
			}
			response.setStatus(ResponseConstant.SUCCESS);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_SUCCESS));
			response.setData(providerlist);
		} catch (Exception e) {
			logger.error("Error:--", e);
			response.setStatus(ResponseConstant.ERROR);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			response.setData(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Response>(response, HttpStatus.OK);
	}

	@RequestMapping(value = PATIENTURLConstant.SPECIALITY_URL, method = RequestMethod.POST, headers = CommonConstants.CONTENT_TYPE_APPLICATION_JSON)
	public ResponseEntity<Response> specialityCode(Locale locale) {
		Response response = new Response();
		try {
			List<String> specialityCode = SpecialityCode.getAllSpecialityCode();
			List<Map<String, String>> specialitylist = new ArrayList<Map<String, String>>(0);
			for (String string : specialityCode) {
				Map<String, String> specialityMap = new HashMap<String, String>(0);
				String value = SpecialityCode.getValue(string);
				specialityMap.put("key", string);
				specialityMap.put("value", value);
				specialitylist.add(specialityMap);
			}
			response.setStatus(ResponseConstant.SUCCESS);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_SUCCESS));
			response.setData(specialitylist);
		} catch (Exception e) {
			logger.error("Error:--", e);
			response.setStatus(ResponseConstant.ERROR);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			response.setData(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Response>(response, HttpStatus.OK);
	}

	@RequestMapping(value = PATIENTURLConstant.APPOINTMENT_TYPE_URL, method = RequestMethod.POST, headers = CommonConstants.CONTENT_TYPE_APPLICATION_JSON)
	public ResponseEntity<Response> appointmentType(Locale locale) {
		Response response = new Response();
		try {
			List<String> appointmentType = PatientAppointmentType.getAllPatientAppointmentType();
			List<Map<String, String>> appointmentlist = new ArrayList<Map<String, String>>(0);
			for (String string : appointmentType) {
				Map<String, String> appointmentTypeMap = new HashMap<String, String>(0);
				String value = PatientAppointmentType.getValue(string);
				appointmentTypeMap.put("key", string);
				appointmentTypeMap.put("value", value);
				appointmentlist.add(appointmentTypeMap);
			}
			response.setStatus(ResponseConstant.SUCCESS);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_SUCCESS));
			response.setData(appointmentlist);
		} catch (Exception e) {
			logger.error("Error:--", e);
			response.setStatus(ResponseConstant.ERROR);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			response.setData(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Response>(response, HttpStatus.OK);
	}

	@RequestMapping(value = PATIENTURLConstant.APPOINTMENT_STATUS_URL, method = RequestMethod.POST, headers = CommonConstants.CONTENT_TYPE_APPLICATION_JSON)
	public ResponseEntity<Response> appointmentStatus(Locale locale) {
		Response response = new Response();
		try {
			List<String> appointmentStatus = PatientAppointmentStatus.getAllPatientAppointmentStatus();
			List<Map<String, String>> appointmentlist = new ArrayList<Map<String, String>>(0);
			for (String string : appointmentStatus) {
				Map<String, String> appointmentTypeMap = new HashMap<String, String>(0);
				String value = PatientAppointmentStatus.getValue(string);
				appointmentTypeMap.put("key", string);
				appointmentTypeMap.put("value", value);
				appointmentlist.add(appointmentTypeMap);
			}
			response.setStatus(ResponseConstant.SUCCESS);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_SUCCESS));
			response.setData(appointmentlist);
		} catch (Exception e) {
			logger.error("Error:--", e);
			response.setStatus(ResponseConstant.ERROR);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			response.setData(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Response>(response, HttpStatus.OK);
	}

	@RequestMapping(value = PATIENTURLConstant.APPOINTMENT_RESON_URL, method = RequestMethod.POST, headers = CommonConstants.CONTENT_TYPE_APPLICATION_JSON)
	public ResponseEntity<Response> appointmentReson(Locale locale) {
		Response response = new Response();
		try {
			List<String> appointmentReson = PatientAppointmentReason.getAllPatientAppointmentReason();
			List<Map<String, String>> appointmentlist = new ArrayList<Map<String, String>>(0);
			for (String string : appointmentReson) {
				Map<String, String> appointmentTypeMap = new HashMap<String, String>(0);
				String value = PatientAppointmentReason.getValue(string);
				appointmentTypeMap.put("key", string);
				appointmentTypeMap.put("value", value);
				appointmentlist.add(appointmentTypeMap);
			}
			response.setStatus(ResponseConstant.SUCCESS);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_SUCCESS));
			response.setData(appointmentlist);
		} catch (Exception e) {
			logger.error("Error:--", e);
			response.setStatus(ResponseConstant.ERROR);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			response.setData(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Response>(response, HttpStatus.OK);

	}

	@RequestMapping(value = PATIENTURLConstant.PROFILE_PERSONAL_MARITAL, method = RequestMethod.POST, headers = CommonConstants.CONTENT_TYPE_APPLICATION_JSON)
	public ResponseEntity<Response> maritalStatus(Locale locale) {
		Response response = new Response();
		try {
			List<String> maritalStatus = MaritalStatus.getAllMaritalStatus();
			List<Map<String, String>> maritallist = new ArrayList<Map<String, String>>(0);
			for (String string : maritalStatus) {
				Map<String, String> maritalMap = new HashMap<String, String>(0);
				String value = MaritalStatus.getValue(string);
				maritalMap.put("key", string);
				maritalMap.put("value", value);
				maritallist.add(maritalMap);
			}
			response.setStatus(ResponseConstant.SUCCESS);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_SUCCESS));
			response.setData(maritallist);
		} catch (Exception e) {
			logger.error("Error:--", e);
			response.setStatus(ResponseConstant.ERROR);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			response.setData(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Response>(response, HttpStatus.OK);
	}

	@RequestMapping(value = PATIENTURLConstant.PROFILE_PERSONAL_GENDERL, method = RequestMethod.POST, headers = CommonConstants.CONTENT_TYPE_APPLICATION_JSON)
	public ResponseEntity<Response> gender(Locale locale) {
		Response response = new Response();
		try {
			List<String> genderStatus = GenderStatus.getAllGenderStatus();
			List<Map<String, String>> genderlist = new ArrayList<Map<String, String>>(0);
			for (String string : genderStatus) {
				Map<String, String> genderMap = new HashMap<String, String>(0);
				String value = GenderStatus.getValue(string);
				genderMap.put("key", string);
				genderMap.put("value", value);
				genderlist.add(genderMap);
			}
			response.setStatus(ResponseConstant.SUCCESS);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_SUCCESS));
			response.setData(genderlist);
		} catch (Exception e) {
			logger.error("Error:--", e);
			response.setStatus(ResponseConstant.ERROR);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			response.setData(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Response>(response, HttpStatus.OK);
	}

	@RequestMapping(value = PATIENTURLConstant.PROFILE_PERSONAL_PMLLOCATION, method = RequestMethod.POST, headers = CommonConstants.CONTENT_TYPE_APPLICATION_JSON)
	public ResponseEntity<Response> pmlLocation(Locale locale) {
		Response response = new Response();
		try {
			List<String> plmLocationStatus = PLMLocationStatus.getAllPLMLocationStatus();
			List<Map<String, String>> plmLocationlist = new ArrayList<Map<String, String>>(0);
			for (String string : plmLocationStatus) {
				Map<String, String> plmLocationMap = new HashMap<String, String>(0);
				String value = PLMLocationStatus.getValue(string);
				plmLocationMap.put("key", string);
				plmLocationMap.put("value", value);
				plmLocationlist.add(plmLocationMap);
			}
			response.setStatus(ResponseConstant.SUCCESS);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_SUCCESS));
			response.setData(plmLocationlist);
		} catch (Exception e) {
			logger.error("Error:--", e);
			response.setStatus(ResponseConstant.ERROR);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			response.setData(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Response>(response, HttpStatus.OK);
	}

	@RequestMapping(value = PATIENTURLConstant.PROFILE_PERSONAL_WORK, method = RequestMethod.POST, headers = CommonConstants.CONTENT_TYPE_APPLICATION_JSON)
	public ResponseEntity<Response> workStatus(Locale locale) {
		Response response = new Response();
		try {
			List<String> workStatus = WorkStatus.getAllWorkStatus();
			List<Map<String, String>> worklist = new ArrayList<Map<String, String>>(0);
			for (String string : workStatus) {
				Map<String, String> workMap = new HashMap<String, String>(0);
				String value = WorkStatus.getValue(string);
				workMap.put("key", string);
				workMap.put("value", value);
				worklist.add(workMap);
			}
			response.setStatus(ResponseConstant.SUCCESS);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_SUCCESS));
			response.setData(worklist);
		} catch (Exception e) {
			logger.error("Error:--", e);
			response.setStatus(ResponseConstant.ERROR);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			response.setData(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Response>(response, HttpStatus.OK);
	}

	@RequestMapping(value = PATIENTURLConstant.PROFILE_PERSONAL_EMPLOYMENT, method = RequestMethod.POST, headers = CommonConstants.CONTENT_TYPE_APPLICATION_JSON)
	public ResponseEntity<Response> employmentStatus(Locale locale) {
		Response response = new Response();
		try {
			List<String> employmentStatus = EmploymentStatus.getAllEmploymentStatus();
			List<Map<String, String>> employmentlist = new ArrayList<Map<String, String>>(0);
			for (String string : employmentStatus) {
				Map<String, String> employmentMap = new HashMap<String, String>(0);
				String value = EmploymentStatus.getValue(string);
				employmentMap.put("key", string);
				employmentMap.put("value", value);
				employmentlist.add(employmentMap);
			}
			response.setStatus(ResponseConstant.SUCCESS);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_SUCCESS));
			response.setData(employmentlist);
		} catch (Exception e) {
			logger.error("Error:--", e);
			response.setStatus(ResponseConstant.ERROR);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			response.setData(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Response>(response, HttpStatus.OK);
	}

	@RequestMapping(value = PATIENTURLConstant.LABREPORT_TYPE_URL, method = RequestMethod.POST, headers = CommonConstants.CONTENT_TYPE_APPLICATION_JSON)
	public ResponseEntity<Response> labreportTypeStatus(Locale locale) {
		Response response = new Response();
		try {
			List<String> labreportTypeStatus = LabReportType.getAllCurrencyType();
			List<Map<String, String>> labreportTypelist = new ArrayList<Map<String, String>>(0);
			for (String string : labreportTypeStatus) {
				Map<String, String> labreportTypeMap = new HashMap<String, String>(0);
				String value = LabReportType.getValue(string);
				labreportTypeMap.put("key", string);
				labreportTypeMap.put("value", value);
				labreportTypelist.add(labreportTypeMap);
			}
			response.setStatus(ResponseConstant.SUCCESS);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_SUCCESS));
			response.setData(labreportTypelist);
		} catch (Exception e) {
			logger.error("Error:--", e);
			response.setStatus(ResponseConstant.ERROR);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			response.setData(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Response>(response, HttpStatus.OK);
	}

	@RequestMapping(value = PATIENTURLConstant.LAB_APPOINTMENT_RESON_URL, method = RequestMethod.POST, headers = CommonConstants.CONTENT_TYPE_APPLICATION_JSON)
	public ResponseEntity<Response> labappointmentReson(Locale locale) {
		Response response = new Response();
		try {
			List<String> labappointmentReson = PatientLabAppointmentReason.getAllPatientLabAppointmentReason();
			List<Map<String, String>> labappointmentResonlist = new ArrayList<Map<String, String>>(0);
			for (String string : labappointmentReson) {
				Map<String, String> labappointmentMap = new HashMap<String, String>(0);
				String value = PatientLabAppointmentReason.getValue(string);
				labappointmentMap.put("key", string);
				labappointmentMap.put("value", value);
				labappointmentResonlist.add(labappointmentMap);
			}
			response.setStatus(ResponseConstant.SUCCESS);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_SUCCESS));
			response.setData(labappointmentResonlist);
		} catch (Exception e) {
			logger.error("Error:--", e);
			response.setStatus(ResponseConstant.ERROR);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			response.setData(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Response>(response, HttpStatus.OK);
	}

	@RequestMapping(value = PATIENTURLConstant.GET_ALL_LAB1_REPORT_URL, method = RequestMethod.POST, headers = CommonConstants.CONTENT_TYPE_APPLICATION_JSON)
	public ResponseEntity<Response> getAllLab1Report(Locale locale) {
		Response response = new Response();
		try {
			List<LabReportsLevel1> labReportsLevel1 = labReportsLevel1Service.getAllActiveRecord();
			List<LabReportsLevel1Pojo> labReportsLevel1Pojo = new ArrayList<LabReportsLevel1Pojo>();
			for (LabReportsLevel1 lr1 : labReportsLevel1) {
				LabReportsLevel1Pojo lrlp = new LabReportsLevel1Pojo();
				lrlp.setLabReportLevel1ID(lr1.getLabReportLevel1ID());
				lrlp.setLrl1Category(lr1.getLrl1Category());
				lrlp.setLabReportType(lr1.getLabReportType());
				lrlp.setLrl1Name(lr1.getLrl1Name());
				lrlp.setGenericTestcode(lr1.getGenericTestcode());
				lrlp.setGenericSourceName(lr1.getGenericSourceName());
				labReportsLevel1Pojo.add(lrlp);
			}
			response.setStatus(ResponseConstant.SUCCESS);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_SUCCESS));
			response.setData(labReportsLevel1Pojo);
		} catch (Exception e) {
			logger.error("Error:--", e);
			response.setStatus(ResponseConstant.ERROR);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			response.setData(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Response>(response, HttpStatus.OK);
	}

	@RequestMapping(value = PATIENTURLConstant.GET_ALL_PATIENT_URL, method = RequestMethod.POST, headers = CommonConstants.CONTENT_TYPE_APPLICATION_JSON)
	public ResponseEntity<Response> getAllPatient(Locale locale) {
		Response response = new Response();
		try {
			List<PatientMaster> patientMaster = patientService.getAllActiveRecord();
			List<PatientPojo> patientPojo = new ArrayList<PatientPojo>();
			for (PatientMaster pm : patientMaster) {
				PatientPojo pp = new PatientPojo();
				pp.setPatientID(pm.getPatientID());
				pp.setPatientName(pm.getPersonID().getPerFname() + " " + pm.getPersonID().getPerLName());
				patientPojo.add(pp);
			}
			response.setStatus(ResponseConstant.SUCCESS);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_SUCCESS));
			response.setData(patientPojo);
		} catch (Exception e) {
			logger.error("Error:--", e);
			response.setStatus(ResponseConstant.ERROR);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			response.setData(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Response>(response, HttpStatus.OK);
	}

	@RequestMapping(value = PATIENTURLConstant.GET_ALL_DIGNSOSIS_URL, method = RequestMethod.POST, headers = CommonConstants.CONTENT_TYPE_APPLICATION_JSON)
	public ResponseEntity<Response> getAllDiagnosis(Locale locale) {
		Response response = new Response();
		try {
			List<DiagnosisMaster> diagnosisMaster = diagnosisService.getAllActiveRecord();
			List<DiseasePojo> diseasePojo = new ArrayList<DiseasePojo>();
			for (DiagnosisMaster dm : diagnosisMaster) {
				DiseasePojo dp = new DiseasePojo();
				dp.setDiagnosisID(dm.getDiagnosisID());
				dp.setDiagnosiseName(dm.getDiagnosiseName());
				diseasePojo.add(dp);
			}
			response.setStatus(ResponseConstant.SUCCESS);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_SUCCESS));
			response.setData(diseasePojo);
		} catch (Exception e) {
			logger.error("Error:--", e);
			response.setStatus(ResponseConstant.ERROR);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			response.setData(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Response>(response, HttpStatus.OK);
	}

	@RequestMapping(value = PATIENTURLConstant.GET_ALL_MEDICINE_URL, method = RequestMethod.POST, headers = CommonConstants.CONTENT_TYPE_APPLICATION_JSON)
	public ResponseEntity<Response> getAllMedicine(Locale locale) {
		Response response = new Response();
		try {
			List<DrugCompoundMaster> drugCompoundMaster = drugCompoundService.getAllActiveRecord();
			List<DrugCompoundPojo> drugCompoundPojo = new ArrayList<DrugCompoundPojo>();
			for (DrugCompoundMaster dm : drugCompoundMaster) {
				DrugCompoundPojo dcp = new DrugCompoundPojo();
				dcp.setDrugCompoundID(dm.getDrugCompoundID());
				dcp.setDrugCompoundName(dm.getDrugCompoundName());
				drugCompoundPojo.add(dcp);
			}
			response.setStatus(ResponseConstant.SUCCESS);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_SUCCESS));
			response.setData(drugCompoundPojo);
		} catch (Exception e) {
			logger.error("Error:--", e);
			response.setStatus(ResponseConstant.ERROR);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			response.setData(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Response>(response, HttpStatus.OK);
	}

	@RequestMapping(value = PATIENTURLConstant.GET_ALL_PATIENT_BY_PERAMETER_URL, method = RequestMethod.POST, headers = CommonConstants.CONTENT_TYPE_APPLICATION_JSON)
	public ResponseEntity<Response> getAllPatientByperameter(Locale locale, @RequestBody String jsonData)
			throws JSONException {
		final JSONObject obj = new JSONObject(jsonData);
		String name = obj.getString("PatientName");
		Response response = new Response();
		try {
			List<PatientMaster> patientMaster = patientService.findbynames(name);
			List<PatientPojo> patientPojo = new ArrayList<PatientPojo>();
			for (PatientMaster pm : patientMaster) {
				PatientPojo pp = new PatientPojo();
				pp.setPatientID(pm.getPatientID());
				pp.setPatientName(pm.getPersonID().getPerFname() + " " + pm.getPersonID().getPerLName());
				patientPojo.add(pp);
			}
			response.setStatus(ResponseConstant.SUCCESS);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_SUCCESS));
			response.setData(patientPojo);
		} catch (Exception e) {
			logger.error("Error:--", e);
			response.setStatus(ResponseConstant.ERROR);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			response.setData(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Response>(response, HttpStatus.OK);
	}

	@RequestMapping(value = PATIENTURLConstant.GET_ALL_DIGNSOSIS_BY_PERAMETER_URL, method = RequestMethod.POST, headers = CommonConstants.CONTENT_TYPE_APPLICATION_JSON)
	public ResponseEntity<Response> getAllDiagnosisByperameter(Locale locale, @RequestBody DiagnosisMaster diagnosis) {
		Response response = new Response();
		try {
			List<DiagnosisMaster> diagnosisMaster = diagnosisService.findbynames(diagnosis.getDiagnosiseName());
			List<DiseasePojo> diseasePojo = new ArrayList<DiseasePojo>();
			for (DiagnosisMaster dm : diagnosisMaster) {
				DiseasePojo dp = new DiseasePojo();
				dp.setDiagnosisID(dm.getDiagnosisID());
				dp.setDiagnosiseName(dm.getDiagnosiseName());
				diseasePojo.add(dp);
			}
			response.setStatus(ResponseConstant.SUCCESS);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_SUCCESS));
			response.setData(diseasePojo);
		} catch (Exception e) {
			logger.error("Error:--", e);
			response.setStatus(ResponseConstant.ERROR);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			response.setData(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Response>(response, HttpStatus.OK);
	}

	@RequestMapping(value = PATIENTURLConstant.GET_ALL_LAB1_BY_PERAMETER_URL, method = RequestMethod.POST, headers = CommonConstants.CONTENT_TYPE_APPLICATION_JSON)
	public ResponseEntity<Response> getAllLab1ReportByperameter(Locale locale,
			@RequestBody LabReportsLevel1 labReports) {
		Response response = new Response();
		try {
			List<LabReportsLevel1> labReportsLevel1 = labReportsLevel1Service.findbynames(labReports.getLrl1Name());
			List<LabReportsLevel1Pojo> labReportsLevel1Pojo = new ArrayList<LabReportsLevel1Pojo>();
			for (LabReportsLevel1 lr1 : labReportsLevel1) {
				LabReportsLevel1Pojo lrlp = new LabReportsLevel1Pojo();
				lrlp.setLabReportLevel1ID(lr1.getLabReportLevel1ID());
				lrlp.setLrl1Category(lr1.getLrl1Category());
				lrlp.setLabReportType(lr1.getLabReportType());
				lrlp.setLrl1Name(lr1.getLrl1Name());
				lrlp.setGenericTestcode(lr1.getGenericTestcode());
				lrlp.setGenericSourceName(lr1.getGenericSourceName());
				labReportsLevel1Pojo.add(lrlp);
			}
			response.setStatus(ResponseConstant.SUCCESS);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_SUCCESS));
			response.setData(labReportsLevel1Pojo);
		} catch (Exception e) {
			logger.error("Error:--", e);
			response.setStatus(ResponseConstant.ERROR);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			response.setData(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Response>(response, HttpStatus.OK);
	}

	@RequestMapping(value = PATIENTURLConstant.GET_ALL_MEDICINE_BY_PERAMETER_URL, method = RequestMethod.POST, headers = CommonConstants.CONTENT_TYPE_APPLICATION_JSON)
	public ResponseEntity<Response> getAllMedicineByperameter(Locale locale,
			@RequestBody DrugCompoundMaster drugCompoundMaster) {
		Response response = new Response();
		try {
			List<DrugCompoundMaster> drugCompound = drugCompoundService
					.findbynames(drugCompoundMaster.getDrugCompoundName());
			List<DrugCompoundPojo> drugCompoundPojo = new ArrayList<DrugCompoundPojo>();
			for (DrugCompoundMaster dm : drugCompound) {
				DrugCompoundPojo dcp = new DrugCompoundPojo();
				dcp.setDrugCompoundID(dm.getDrugCompoundID());
				dcp.setDrugCompoundName(dm.getDrugCompoundName());
				drugCompoundPojo.add(dcp);
			}
			response.setStatus(ResponseConstant.SUCCESS);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_SUCCESS));
			response.setData(drugCompoundPojo);
		} catch (Exception e) {
			logger.error("Error:--", e);
			response.setStatus(ResponseConstant.ERROR);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			response.setData(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Response>(response, HttpStatus.OK);
	}

	@RequestMapping(value = PATIENTURLConstant.GET_ALL_FACILITY_DOCTOR_URL, method = RequestMethod.POST, headers = CommonConstants.CONTENT_TYPE_APPLICATION_JSON)
	public ResponseEntity<Response> getAllFacilityDoctor(Locale locale) {
		UserDetails userDetails = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		UserMaster userEntity = userService.findByUserName(userDetails.getUsername());
		Response response = new Response();
		try {
			ProviderMaster providerMaster = providerService.getProvider(userEntity.getUserEmail(),
					ProviderTypeStatus.Doctor);
			List<FacilityCenterMaster> facilityCenterData = fclProviderService
					.getAllFacilityByDoctor(providerMaster.getProviderID());
			List<FacilityCenterPojo> facilityCenterPojo = new ArrayList<FacilityCenterPojo>();
			for (FacilityCenterMaster fcm : facilityCenterData) {
				FacilityCenterPojo fcp = new FacilityCenterPojo();
				fcp.setFacilityCenterID(fcm.getFacilityCenterID());
				fcp.setFacilityCenterName(fcm.getFacilityCenterName());
				fcp.setFacilityCenterType(fcm.getFacilityCenterType());
				fcp.setFcCertificateNumber(fcm.getFcCertificateNumber());
				facilityCenterPojo.add(fcp);
			}
			response.setStatus(ResponseConstant.SUCCESS);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_SUCCESS));
			response.setData(facilityCenterPojo);
		} catch (Exception e) {
			logger.error("Error:--", e);
			response.setStatus(ResponseConstant.ERROR);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			response.setData(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Response>(response, HttpStatus.OK);
	}

	@RequestMapping(value = PATIENTURLConstant.GET_ALL_LOCATIONBASED_ON_FACILITY_DOCTOR_URL, method = RequestMethod.POST, headers = CommonConstants.CONTENT_TYPE_APPLICATION_JSON)
	public ResponseEntity<Response> getAllLocationByFacilityAndDoctor(Locale locale,
			@RequestBody FacilityCenterMaster facilityCenterMaster) {
		UserDetails userDetails = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		UserMaster userEntity = userService.findByUserName(userDetails.getUsername());
		Response response = new Response();
		try {
			ProviderMaster providerMaster = providerService.getProvider(userEntity.getUserEmail(),
					ProviderTypeStatus.Doctor);
			List<FCLocationMap> fcLocationMapData = fclProviderService.getAllLocationByDoctorAndFacility(
					providerMaster.getProviderID(), facilityCenterMaster.getFacilityCenterID());
			List<FCLocationMapPojo> fcLocationMapPojo = new ArrayList<FCLocationMapPojo>();
			for (FCLocationMap flm : fcLocationMapData) {
				FCLocationMapPojo flp = new FCLocationMapPojo();
				flp.setFcLocationMapID(flm.getFcLocationMapID());
				flp.setFcLocationName(flm.getFcLocationName());
				fcLocationMapPojo.add(flp);
			}
			response.setStatus(ResponseConstant.SUCCESS);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_SUCCESS));
			response.setData(fcLocationMapPojo);
		} catch (Exception e) {
			logger.error("Error:--", e);
			response.setStatus(ResponseConstant.ERROR);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			response.setData(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Response>(response, HttpStatus.OK);
	}

	@RequestMapping(value = PATIENTURLConstant.GET_ALL_DRUGMANUFACTURER_URL, method = RequestMethod.POST, headers = CommonConstants.CONTENT_TYPE_APPLICATION_JSON)
	public ResponseEntity<Response> getAlldrugsManufacturer(Locale locale) {
		Response response = new Response();
		try {
			List<DrugManufacturersMaster> drugManufacturersMaster = drugManufacturersService.getAllActiveRecord();
			List<DrugManufacturersPojo> drugManufacturersPojo = new ArrayList<DrugManufacturersPojo>();
			for (DrugManufacturersMaster dm : drugManufacturersMaster) {
				DrugManufacturersPojo dmp = new DrugManufacturersPojo();
				dmp.setDrugMfgrID(dm.getDrugMfgrID());
				dmp.setDrugMfgrName(dm.getDrugMfgrName());
				drugManufacturersPojo.add(dmp);
			}
			response.setStatus(ResponseConstant.SUCCESS);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_SUCCESS));
			response.setData(drugManufacturersPojo);
		} catch (Exception e) {
			logger.error("Error:--", e);
			response.setStatus(ResponseConstant.ERROR);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			response.setData(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Response>(response, HttpStatus.OK);
	}

	@RequestMapping(value = PATIENTURLConstant.GET_ALL_DRUGMANUFACTURER_BY_PERAMETER_URL, method = RequestMethod.POST, headers = CommonConstants.CONTENT_TYPE_APPLICATION_JSON)
	public ResponseEntity<Response> getAlldrugsManufacturerByperameter(Locale locale, @RequestBody String jsonData)
			throws JSONException {
		final JSONObject obj = new JSONObject(jsonData);
		String name = obj.getString("drugMfgrName");
		Response response = new Response();
		try {
			List<DrugManufacturersMaster> drugManufacturersMaster = drugManufacturersService.findbynames(name);
			List<DrugManufacturersPojo> dmp = new ArrayList<DrugManufacturersPojo>();
			for (DrugManufacturersMaster pm : drugManufacturersMaster) {
				DrugManufacturersPojo pp = new DrugManufacturersPojo();
				pp.setDrugMfgrID(pm.getDrugMfgrID());
				pp.setDrugMfgrName(pm.getDrugMfgrName());
				dmp.add(pp);
			}
			response.setStatus(ResponseConstant.SUCCESS);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_SUCCESS));
			response.setData(dmp);
		} catch (Exception e) {
			logger.error("Error:--", e);
			response.setStatus(ResponseConstant.ERROR);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			response.setData(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Response>(response, HttpStatus.OK);
	}

	@RequestMapping(value = PATIENTURLConstant.APPOINTMENT_STATUS_CHANGE_URL, method = RequestMethod.POST, headers = CommonConstants.CONTENT_TYPE_APPLICATION_JSON)
	public ResponseEntity<Response> appointmentStatusChange(Locale locale, @RequestBody StatusChange statusChange) {
		Response response = new Response();
		UserDetails userDetails = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		UserMaster userEntity = userService.findByUserName(userDetails.getUsername());
		try {
			PatAppointments patAppointment = patAppointmentService.get(statusChange.getId());
			if (PatientAppointmentStatus.Approved == patAppointment.getPatAppStatus()
					|| PatientAppointmentStatus.Pending == patAppointment.getPatAppStatus()) {
				patAppointment.setPatAppStatus(statusChange.getPatientAppointmentStatus());
				patAppointment.setPatAppDescription(statusChange.getDescription());
				patAppointment.setModifiedBy(userEntity);
				patAppointment.setModifiedOn(new Date());
				try {
					patAppointmentService.saveOrUpdate(patAppointment);
				} catch (Exception e) {
					logger.error("Error:--", e);
					response.setStatus(ResponseConstant.ERROR);
					response.setMessage(messageByLocaleService.getMessage(PATIENTURLConstant.APPOINTMENT_ERROR));
					response.setData(messageByLocaleService.getMessage(PATIENTURLConstant.APPOINTMENT_ERROR));
					return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
				}
				response.setStatus(ResponseConstant.SUCCESS);
				response.setMessage(messageByLocaleService.getMessage(PATIENTURLConstant.APPOINTMENT_UPDATE));
				response.setData(messageByLocaleService.getMessage(PATIENTURLConstant.APPOINTMENT_UPDATE));

			} else {
				response.setStatus(ResponseConstant.WARNING);
				response.setMessage(messageByLocaleService.getMessage(PATIENTURLConstant.APPOINTMENT_UPDATE_ERROR));
				response.setData(messageByLocaleService.getMessage(PATIENTURLConstant.APPOINTMENT_UPDATE_ERROR));
				return new ResponseEntity<Response>(response, HttpStatus.CONFLICT);
			}
		} catch (Exception e) {
			logger.error("Error:--", e);
			response.setStatus(ResponseConstant.ERROR);
			response.setMessage(messageByLocaleService.getMessage(PATIENTURLConstant.APPOINTMENT_ERROR));
			response.setData(messageByLocaleService.getMessage(PATIENTURLConstant.APPOINTMENT_ERROR));
			return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Response>(response, HttpStatus.OK);
	}

	@RequestMapping(value = PATIENTURLConstant.GET_DOCTOR_BY_LOCATIONBASED_ON_FACILITY_URL, method = RequestMethod.POST, headers = CommonConstants.CONTENT_TYPE_APPLICATION_JSON)
	public ResponseEntity<Response> getAllDoctorByLocationAndFacility(Locale locale,
			@RequestBody FCLocationMap fcLocationMap) {
		Response response = new Response();
		try {
			List<ProviderPojo> providerPojo = new ArrayList<ProviderPojo>();
			List<FCLProviderMap> fclProviderMap = fclProviderService.getAllProvider(fcLocationMap);
			for (FCLProviderMap fpm : fclProviderMap) {
				ProviderPojo pp = new ProviderPojo();
				pp.setProviderID(fpm.getProviderID().getProviderID());
				pp.setFclProviderMapID(fpm.getFclProviderMapID());
				PersonMaster person = personService.get(fpm.getProviderID().getPersonMaster().getPersonID());
				pp.setProviderName(person.getPerFname() + " " + person.getPerLName());
				pp.setProviderTypeStatus(fpm.getProviderID().getProviderTypeStatus());
				providerPojo.add(pp);
			}
			response.setStatus(ResponseConstant.SUCCESS);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_SUCCESS));
			response.setData(providerPojo);
		} catch (Exception e) {
			logger.error("Error:--", e);
			response.setStatus(ResponseConstant.ERROR);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			response.setData(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Response>(response, HttpStatus.OK);
	}

	@RequestMapping(value = PATIENTURLConstant.GET_ALL_FACILITY_BY_REPORT_URL, method = RequestMethod.POST, headers = CommonConstants.CONTENT_TYPE_APPLICATION_JSON)
	public ResponseEntity<Response> getAllFacilityByReport(Locale locale, @RequestBody LabDataPojo labDataPojo) {
		Response response = new Response();
		try {
			List<LabReportsLevel1> labReportsLevel = labDataPojo.getLabReportsLevelData();
			List<Long> labReportLevel1ID = new ArrayList<Long>(0);
			for (LabReportsLevel1 ll : labReportsLevel) {
				labReportLevel1ID.add(ll.getLabReportLevel1ID());
			}
			if (labReportLevel1ID.size() == 0) {
				response.setStatus(ResponseConstant.ERROR);
				response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
				response.setData(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
				return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
			}
			List<FacilityCenterMaster> facilityCenterData = fclProviderReportMapService
					.getAllFacilitybyLocation(labReportLevel1ID);
			List<FacilityCenterPojo> facilityCenterPojo = new ArrayList<FacilityCenterPojo>();
			for (FacilityCenterMaster fcm : facilityCenterData) {
				FacilityCenterPojo fcp = new FacilityCenterPojo();
				fcp.setFacilityCenterID(fcm.getFacilityCenterID());
				fcp.setFacilityCenterName(fcm.getFacilityCenterName());
				fcp.setFacilityCenterType(fcm.getFacilityCenterType());
				fcp.setFcCertificateNumber(fcm.getFcCertificateNumber());
				facilityCenterPojo.add(fcp);
			}
			response.setStatus(ResponseConstant.SUCCESS);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_SUCCESS));
			response.setData(facilityCenterPojo);
		} catch (Exception e) {
			logger.error("Error:--", e);
			response.setStatus(ResponseConstant.ERROR);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			response.setData(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Response>(response, HttpStatus.OK);
	}

	@RequestMapping(value = PATIENTURLConstant.GET_REPORT_BY_FACILITY_URL, method = RequestMethod.POST, headers = CommonConstants.CONTENT_TYPE_APPLICATION_JSON)
	public ResponseEntity<Response> getAllReportByFacilityProvider(Locale locale,
			@RequestBody FCLProviderMap fclProviderMap) {
		Response response = new Response();
		try {
			List<FCLProviderReportMap> fclProviderReportMap = fclProviderReportMapService
					.getAllFacility(fclProviderMap.getFclProviderMapID());
			List<FCLProviderReportMapPojo> fclProviderReportMapPojo = new ArrayList<FCLProviderReportMapPojo>(0);
			for (FCLProviderReportMap fprm : fclProviderReportMap) {
				FCLProviderReportMapPojo pojo = new FCLProviderReportMapPojo();
				pojo.setFclProviderReportMapID(fprm.getFclProviderReportMapID());
				pojo.setLabReportLevel1ID(fprm.getLabReportLevel1ID().getLabReportLevel1ID());
				pojo.setLrl1Name(fprm.getLabReportLevel1ID().getLrl1Name());
				fclProviderReportMapPojo.add(pojo);
			}
			response.setStatus(ResponseConstant.SUCCESS);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_SUCCESS));
			response.setData(fclProviderReportMapPojo);
		} catch (Exception e) {
			logger.error("Error:--", e);
			response.setStatus(ResponseConstant.ERROR);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			response.setData(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Response>(response, HttpStatus.OK);
	}

	@RequestMapping(value = PATIENTURLConstant.APPOINTMENT_ADD_OR_EDIT_URL, method = RequestMethod.POST, headers = CommonConstants.CONTENT_TYPE_APPLICATION_JSON)
	public ResponseEntity<Response> addOrEditAppointment(Locale locale,@RequestBody PatAppointments patAppointmentsMaster) {
		Response response = new Response();
		UserDetails userDetails = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		UserMaster userEntity = userService.findByUserName(userDetails.getUsername());
		String type = null;
		Boolean isEmpty = OperationsUtil.checkNull(patAppointmentsMaster);
		if (!isEmpty) {
			try {
				PatientMaster patientMaster=patientService.findByPatient(userEntity.getUserEmail());
				Date date =DateUtil.getZeroTimeDate(new Date());
				Long mills = date.getTime();
				Long millData = new Date().getTime();
				boolean result=false;
				if (patAppointmentsMaster.getPatAppointmentID() == null
						|| patAppointmentsMaster.getPatAppointmentID().equals(0L)) {
					type = PATIENTURLConstant.ADD_TYPE;
					patAppointmentsMaster.setActive(true);
					patAppointmentsMaster.setCreatedOn(new Date());
					patAppointmentsMaster.setModifiedOn(new Date());
					patAppointmentsMaster.setCreatedBy(userEntity);
					patAppointmentsMaster.setModifiedBy(userEntity);
					patAppointmentsMaster.setDeleted(false);
				} else {
					patAppointmentsMaster.setActive(true);
					patAppointmentsMaster.setDeleted(false);
					patAppointmentsMaster.setModifiedBy(userEntity);
					patAppointmentsMaster.setModifiedOn(new Date());
					type = PATIENTURLConstant.EDIT_TYPE;
				}
				if (patAppointmentsMaster.getPatAppointmentID() == null	|| patAppointmentsMaster.getPatAppointmentID().equals(0L)) {
					if(patAppointmentsMaster.getPatAppTimeFrom()>=millData && patAppointmentsMaster.getPatAppTimeTo()>patAppointmentsMaster.getPatAppTimeFrom()) {
						List<PatAppointments> patAppointment=patAppointmentService.findPatient(patientMaster,mills);
						if(patAppointment.size()>0) {
							for(PatAppointments pa:patAppointment) {
								if((patAppointmentsMaster.getPatAppTimeFrom() < pa.getPatAppTimeFrom() || patAppointmentsMaster.getPatAppTimeFrom() > pa.getPatAppTimeTo())
									&& ((patAppointmentsMaster.getPatAppTimeTo() < pa.getPatAppTimeFrom() || patAppointmentsMaster.getPatAppTimeTo() > pa.getPatAppTimeTo()) 
									&& (patAppointmentsMaster.getPatAppTimeTo()>patAppointmentsMaster.getPatAppTimeFrom()))) {
									result=true;
								}else {
									result=false;
									break;
								}
							}
						}else {
							result=true;
						}
					}else {
						response.setStatus(ResponseConstant.ERROR);
						response.setMessage(messageByLocaleService.getMessage(PATIENTURLConstant.APPOINTMENT_VALIDATION));
						response.setData(messageByLocaleService.getMessage(PATIENTURLConstant.APPOINTMENT_VALIDATION));
						return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
					}
					if(result == false) {
						response.setStatus(ResponseConstant.ERROR);
						response.setMessage(messageByLocaleService.getMessage(PATIENTURLConstant.APPOINTMENT));
						response.setData(messageByLocaleService.getMessage(PATIENTURLConstant.APPOINTMENT));
						return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
					}
					FCLProviderMap fclProviderMap = fclProviderService
							.get(patAppointmentsMaster.getFclProviderMapID().getFclProviderMapID());
					CFLPatRegistrationMap getcflPatRegistrationMap = cflPatRegistrationMapService.findCflData(
							patientMaster.getPatientID(), fclProviderMap.getLocationMapID().getFcLocationMapID());
					if (getcflPatRegistrationMap != null) {
						getcflPatRegistrationMap.setModifiedBy(userEntity);
						getcflPatRegistrationMap.setModifiedOn(new Date());
						patAppointmentsMaster.setFclpID(getcflPatRegistrationMap);
					} else {
						CFLPatRegistrationMap cflPatRegistrationMap = SetCFLPatRegistrationMap(userEntity,
								fclProviderMap, patientMaster);
						patAppointmentsMaster.setFclpID(cflPatRegistrationMap);
					}
					try {
						patAppointmentService.saveOrUpdate(patAppointmentsMaster);
					} catch (Exception e) {
						logger.error("Error:--", e);
						response.setStatus(ResponseConstant.ERROR);
						response.setMessage(messageByLocaleService.getMessage(PATIENTURLConstant.APPOINTMENT_ERROR));
						response.setData(messageByLocaleService.getMessage(PATIENTURLConstant.APPOINTMENT_ERROR));
						return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
					}
					response.setStatus(ResponseConstant.SUCCESS);
					response.setMessage(messageByLocaleService.getMessage(PATIENTURLConstant.APPOINTMENT_SUCCESS));
					response.setData(messageByLocaleService.getMessage(PATIENTURLConstant.APPOINTMENT_SUCCESS));
				} else {
					PatAppointments patAppointment = patAppointmentService.get(patAppointmentsMaster.getPatAppointmentID());
					if(patAppointmentsMaster.getPatAppTimeFrom()>=millData && patAppointmentsMaster.getPatAppTimeTo()>patAppointmentsMaster.getPatAppTimeFrom()) {
						List<PatAppointments> patAppointments=patAppointmentService.findPatient(patientMaster,mills);
						if(patAppointments.size()>0) {
							for(PatAppointments pa:patAppointments) {
								if((patAppointmentsMaster.getPatAppTimeFrom() < pa.getPatAppTimeFrom() || patAppointmentsMaster.getPatAppTimeFrom() > pa.getPatAppTimeTo())
									&& ((patAppointmentsMaster.getPatAppTimeTo() < pa.getPatAppTimeFrom() || patAppointmentsMaster.getPatAppTimeTo() > pa.getPatAppTimeTo()) 
									&& (patAppointmentsMaster.getPatAppTimeTo()>patAppointmentsMaster.getPatAppTimeFrom()))) {
										result=true;
								}else {
									if(patAppointment.getPatAppointmentID().equals(pa.getPatAppointmentID())) {
										result=true;
									}else {
										result=false;
										break;
									}
								}
							}
						}else {
							result=true;
						}
					}else {
						response.setStatus(ResponseConstant.ERROR);
						response.setMessage(messageByLocaleService.getMessage(PATIENTURLConstant.APPOINTMENT_VALIDATION));
						response.setData(messageByLocaleService.getMessage(PATIENTURLConstant.APPOINTMENT_VALIDATION));
						return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
					}
					if(result == false) {
						response.setStatus(ResponseConstant.ERROR);
						response.setMessage(messageByLocaleService.getMessage(PATIENTURLConstant.APPOINTMENT));
						response.setData(messageByLocaleService.getMessage(PATIENTURLConstant.APPOINTMENT));
						return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
					}
					if (PatientAppointmentStatus.Approved == patAppointment.getPatAppStatus()
							|| PatientAppointmentStatus.Pending == patAppointment.getPatAppStatus()) {
						FCLProviderMap fclProviderMap = fclProviderService
								.get(patAppointmentsMaster.getFclProviderMapID().getFclProviderMapID());
						CFLPatRegistrationMap getcflPatRegistrationMap = cflPatRegistrationMapService.findCflData(
								patientMaster.getPatientID(), fclProviderMap.getLocationMapID().getFcLocationMapID());
						if (getcflPatRegistrationMap != null) {
							getcflPatRegistrationMap.setModifiedBy(userEntity);
							getcflPatRegistrationMap.setModifiedOn(new Date());
							patAppointmentsMaster.setFclpID(getcflPatRegistrationMap);
						} else {
							CFLPatRegistrationMap cflPatRegistrationMap = SetCFLPatRegistrationMap(userEntity,
									fclProviderMap, patientMaster);
							patAppointmentsMaster.setFclpID(cflPatRegistrationMap);
						}
						patAppointmentsMaster.setCreatedOn(patAppointment.getCreatedOn());
						patAppointmentsMaster.setCreatedBy(patAppointment.getCreatedBy());
						try {
							patAppointmentService.saveOrUpdate(patAppointmentsMaster);
						} catch (Exception e) {
							logger.error("Error:--", e);
							response.setStatus(ResponseConstant.ERROR);
							response.setMessage(
									messageByLocaleService.getMessage(PATIENTURLConstant.APPOINTMENT_ERROR));
							response.setData(messageByLocaleService.getMessage(PATIENTURLConstant.APPOINTMENT_ERROR));
							return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
						}
						response.setStatus(ResponseConstant.SUCCESS);
						response.setMessage(messageByLocaleService.getMessage(PATIENTURLConstant.APPOINTMENT_UPDATE));
						response.setData(messageByLocaleService.getMessage(PATIENTURLConstant.APPOINTMENT_UPDATE));
					} else {
						response.setStatus(ResponseConstant.WARNING);
						response.setMessage(
								messageByLocaleService.getMessage(PATIENTURLConstant.APPOINTMENT_UPDATE_ERROR));
						response.setData(
								messageByLocaleService.getMessage(PATIENTURLConstant.APPOINTMENT_UPDATE_ERROR));
						return new ResponseEntity<Response>(response, HttpStatus.BAD_REQUEST);
					}
				}
			} catch (Exception e) {
				logger.error("Error:--", e);
				response.setStatus(ResponseConstant.ERROR);
				response.setMessage(messageByLocaleService.getMessage(PATIENTURLConstant.APPOINTMENT_ERROR));
				response.setData(messageByLocaleService.getMessage(PATIENTURLConstant.APPOINTMENT_ERROR));
				return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
			}
		} else {
			response.setStatus(ResponseConstant.ERROR);
			response.setMessage(messageByLocaleService.getMessage(PATIENTURLConstant.APPOINTMENT_EXCEPTION));
			response.setData(messageByLocaleService.getMessage(PATIENTURLConstant.APPOINTMENT_EXCEPTION));
			return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}

		if (type.equalsIgnoreCase(PATIENTURLConstant.ADD_TYPE)) {
			return new ResponseEntity<Response>(response, HttpStatus.CREATED);
		} else {
			return new ResponseEntity<Response>(response, HttpStatus.OK);
		}
	}

	private CFLPatRegistrationMap SetCFLPatRegistrationMap(UserMaster userEntity, FCLProviderMap fclProviderMap,
			PatientMaster patientMaster) {
		CFLPatRegistrationMap cflPatRegistrationMap = new CFLPatRegistrationMap();
		cflPatRegistrationMap.setActive(true);
		cflPatRegistrationMap.setDateRegistered(new Date());
		cflPatRegistrationMap.setCreatedOn(new Date());
		cflPatRegistrationMap.setModifiedOn(new Date());
		cflPatRegistrationMap.setCreatedBy(userEntity);
		cflPatRegistrationMap.setModifiedBy(userEntity);
		cflPatRegistrationMap.setDeleted(false);
		cflPatRegistrationMap.setFcLocationMap(fclProviderMap.getLocationMapID());
		cflPatRegistrationMap.setPatientID(patientMaster);
		return cflPatRegistrationMapService.saveOrUpdate(cflPatRegistrationMap);
	}

	@RequestMapping(value = PATIENTURLConstant.LAB_ADD_OR_EDIT_URL, method = RequestMethod.POST, headers = CommonConstants.CONTENT_TYPE_APPLICATION_JSON)
	public ResponseEntity<Response> addOrEditLab(Locale locale, @RequestBody PatLabAppointments patLabAppointments) {
		Response response = new Response();
		UserDetails userDetails = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		UserMaster userEntity = userService.findByUserName(userDetails.getUsername());
		String type = null;
		Boolean isEmpty = OperationsUtil.checkNull(patLabAppointments);
		if (!isEmpty) {
			try {
				Date date =DateUtil.getZeroTimeDate(new Date());
				Long mills = date.getTime();
				Long millData = new Date().getTime();
				boolean result=false;
				PatientMaster patientMaster = patientService.findByPatient(userEntity.getUserEmail());
				if (patLabAppointments.getPatLabAppointmentID() == null
						|| patLabAppointments.getPatLabAppointmentID().equals(0L)) {
					type = PATIENTURLConstant.ADD_TYPE;
					patLabAppointments.setActive(true);
					patLabAppointments.setCreatedOn(new Date());
					patLabAppointments.setModifiedOn(new Date());
					patLabAppointments.setCreatedBy(userEntity);
					patLabAppointments.setModifiedBy(userEntity);
					patLabAppointments.setDeleted(false);
				} else {
					patLabAppointments.setActive(true);
					patLabAppointments.setDeleted(false);
					patLabAppointments.setModifiedBy(userEntity);
					patLabAppointments.setModifiedOn(new Date());
					type = PATIENTURLConstant.EDIT_TYPE;
				}
				Set<LabReportsLevel1> labReportsLevel1s = patLabAppointments.getLabReportsLevel1();
				if (patLabAppointments.getPatLabAppointmentID() == null	|| patLabAppointments.getPatLabAppointmentID().equals(0L)) {
					if(patLabAppointments.getPatLabAppTimeFrom()>=millData && patLabAppointments.getPatLabAppTimeTo()>patLabAppointments.getPatLabAppTimeFrom()) {
						List<PatLabAppointments> patLabAppointment=patLabAppointmentService.findPatient(patientMaster,mills);
						if(patLabAppointment.size()>0) {
							for(PatLabAppointments pa:patLabAppointment) {
								if((patLabAppointments.getPatLabAppTimeFrom() < pa.getPatLabAppTimeFrom() || patLabAppointments.getPatLabAppTimeFrom() > pa.getPatLabAppTimeTo())
									&& ((patLabAppointments.getPatLabAppTimeTo() < pa.getPatLabAppTimeFrom() || patLabAppointments.getPatLabAppTimeTo() > pa.getPatLabAppTimeTo()) 
									&& (patLabAppointments.getPatLabAppTimeTo()>patLabAppointments.getPatLabAppTimeFrom()))) {
									result=true;
								}else {
									result=false;
									break;
								}
							}
						}else {
							result=true;
						}
					}else {
						response.setStatus(ResponseConstant.ERROR);
						response.setMessage(messageByLocaleService.getMessage(PATIENTURLConstant.LABAPPOINTMENT_VALIDATION));
						response.setData(messageByLocaleService.getMessage(PATIENTURLConstant.LABAPPOINTMENT_VALIDATION));
						return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
					}
					if(result == false) {
						response.setStatus(ResponseConstant.ERROR);
						response.setMessage(messageByLocaleService.getMessage(PATIENTURLConstant.LABAPPOINTMENT));
						response.setData(messageByLocaleService.getMessage(PATIENTURLConstant.LABAPPOINTMENT));
						return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
					}
					FCLProviderMap fclProviderMap = fclProviderService
							.get(patLabAppointments.getFclProviderMapID().getFclProviderMapID());
					CFLPatRegistrationMap getcflPatRegistrationMap = cflPatRegistrationMapService.findCflData(
							patientMaster.getPatientID(), fclProviderMap.getLocationMapID().getFcLocationMapID());
					if (getcflPatRegistrationMap != null) {
						getcflPatRegistrationMap.setModifiedBy(userEntity);
						getcflPatRegistrationMap.setModifiedOn(new Date());
						patLabAppointments.setFclpID(getcflPatRegistrationMap);
					} else {
						CFLPatRegistrationMap cflPatRegistrationMap = SetCFLPatRegistrationMap(userEntity,
								fclProviderMap, patientMaster);
						patLabAppointments.setFclpID(cflPatRegistrationMap);
					}
					try {
						patLabAppointments = patLabAppointmentService.saveOrUpdate(patLabAppointments);
						for (LabReportsLevel1 ll : labReportsLevel1s) {
							SetSuggestReport(userEntity, ll, patLabAppointments);
						}
					} catch (Exception e) {
						logger.error("Error:--", e);
						response.setStatus(ResponseConstant.ERROR);
						response.setMessage(messageByLocaleService.getMessage(PATIENTURLConstant.LAB_ERROR));
						response.setData(messageByLocaleService.getMessage(PATIENTURLConstant.LAB_ERROR));
						return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
					}
					response.setStatus(ResponseConstant.SUCCESS);
					response.setMessage(messageByLocaleService.getMessage(PATIENTURLConstant.LAB_SUCCESS));
					response.setData(messageByLocaleService.getMessage(PATIENTURLConstant.LAB_SUCCESS));
				} else {
					PatLabAppointments patLabAppointment = patLabAppointmentService.get(patLabAppointments.getPatLabAppointmentID());
					if(patLabAppointments.getPatLabAppTimeFrom()>=millData && patLabAppointments.getPatLabAppTimeTo()>patLabAppointments.getPatLabAppTimeFrom()) {
						List<PatLabAppointments> patLabAppointmentdata=patLabAppointmentService.findPatient(patientMaster,mills);
						if(patLabAppointmentdata.size()>0) {
							for(PatLabAppointments pa:patLabAppointmentdata) {
								if((patLabAppointments.getPatLabAppTimeFrom() < pa.getPatLabAppTimeFrom() || patLabAppointments.getPatLabAppTimeFrom() > pa.getPatLabAppTimeTo())
									&& ((patLabAppointments.getPatLabAppTimeTo() < pa.getPatLabAppTimeFrom() || patLabAppointments.getPatLabAppTimeTo() > pa.getPatLabAppTimeTo()) 
									&& (patLabAppointments.getPatLabAppTimeTo()>patLabAppointments.getPatLabAppTimeFrom()))) {
									result=true;
								}else {
									if(patLabAppointments.getPatLabAppointmentID().equals(pa.getPatLabAppointmentID())) {
										result=true;
									}else {
										result=false;
										break;
									}
								}
							}
						}else {
							result=true;
						}
					}else {
						response.setStatus(ResponseConstant.ERROR);
						response.setMessage(messageByLocaleService.getMessage(PATIENTURLConstant.LABAPPOINTMENT_VALIDATION));
						response.setData(messageByLocaleService.getMessage(PATIENTURLConstant.LABAPPOINTMENT_VALIDATION));
						return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
					}
					if(result == false) {
						response.setStatus(ResponseConstant.ERROR);
						response.setMessage(messageByLocaleService.getMessage(PATIENTURLConstant.LABAPPOINTMENT));
						response.setData(messageByLocaleService.getMessage(PATIENTURLConstant.LABAPPOINTMENT));
						return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
					}
					if (PatientAppointmentStatus.Approved == patLabAppointment.getPatAppStatus()
							|| PatientAppointmentStatus.Pending == patLabAppointment.getPatAppStatus()) {
						List<SuggestReport> all = suggestReportService
								.findAllData(patLabAppointments.getPatLabAppointmentID());
						for (SuggestReport pd : all) {
							SetSuggestReportDiseble(userEntity, pd);
						}
						FCLProviderMap fclProviderMap = fclProviderService
								.get(patLabAppointments.getFclProviderMapID().getFclProviderMapID());
						CFLPatRegistrationMap getcflPatRegistrationMap = cflPatRegistrationMapService.findCflData(
								patientMaster.getPatientID(), fclProviderMap.getLocationMapID().getFcLocationMapID());
						if (getcflPatRegistrationMap != null) {
							getcflPatRegistrationMap.setModifiedBy(userEntity);
							getcflPatRegistrationMap.setModifiedOn(new Date());
							patLabAppointments.setFclpID(getcflPatRegistrationMap);
						} else {
							CFLPatRegistrationMap cflPatRegistrationMap = SetCFLPatRegistrationMap(userEntity,
									fclProviderMap, patientMaster);
							patLabAppointments.setFclpID(cflPatRegistrationMap);
						}
						patLabAppointments.setCreatedOn(patLabAppointment.getCreatedOn());
						patLabAppointments.setCreatedBy(patLabAppointment.getCreatedBy());
						try {
							patLabAppointments = patLabAppointmentService.saveOrUpdate(patLabAppointments);
							for (LabReportsLevel1 ll : labReportsLevel1s) {
								SuggestReport pgs = suggestReportService.findData(ll.getLabReportLevel1ID(),
										patLabAppointments.getPatLabAppointmentID());
								if (pgs == null) {
									SetSuggestReport(userEntity, ll, patLabAppointments);
								} else {
									pgs.setModifiedOn(new Date());
									pgs.setModifiedBy(userEntity);
									pgs.setActive(true);
									pgs.setDeleted(false);
									try {
										suggestReportService.saveOrUpdate(pgs);
									} catch (Exception e) {
										logger.error("Error:--", e);
										response.setStatus(ResponseConstant.ERROR);
										response.setMessage(
												messageByLocaleService.getMessage(PATIENTURLConstant.LAB_ERROR));
										response.setData(
												messageByLocaleService.getMessage(PATIENTURLConstant.LAB_ERROR));
										return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
									}
								}
							}
						} catch (Exception e) {
							logger.error("Error:--", e);
							response.setStatus(ResponseConstant.ERROR);
							response.setMessage(messageByLocaleService.getMessage(PATIENTURLConstant.LAB_ERROR));
							response.setData(messageByLocaleService.getMessage(PATIENTURLConstant.LAB_ERROR));
							return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
						}
						response.setStatus(ResponseConstant.SUCCESS);
						response.setMessage(messageByLocaleService.getMessage(PATIENTURLConstant.LAB_UPDATE));
						response.setData(messageByLocaleService.getMessage(PATIENTURLConstant.LAB_UPDATE));
					} else {
						response.setStatus(ResponseConstant.WARNING);
						response.setMessage(messageByLocaleService.getMessage(PATIENTURLConstant.LAB_UPDATE_ERROR));
						response.setData(messageByLocaleService.getMessage(PATIENTURLConstant.LAB_UPDATE_ERROR));
						return new ResponseEntity<Response>(response, HttpStatus.BAD_REQUEST);
					}
				}
			} catch (Exception e) {
				logger.error("Error:--", e);
				response.setStatus(ResponseConstant.ERROR);
				response.setMessage(messageByLocaleService.getMessage(PATIENTURLConstant.LAB_ERROR));
				response.setData(messageByLocaleService.getMessage(PATIENTURLConstant.LAB_ERROR));
				return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
			}
		} else {
			response.setStatus(ResponseConstant.ERROR);
			response.setMessage(messageByLocaleService.getMessage(PATIENTURLConstant.LAB_EXCEPTION));
			response.setData(messageByLocaleService.getMessage(PATIENTURLConstant.LAB_EXCEPTION));
			return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}

		if (type.equalsIgnoreCase(PATIENTURLConstant.ADD_TYPE)) {
			return new ResponseEntity<Response>(response, HttpStatus.CREATED);
		} else {
			return new ResponseEntity<Response>(response, HttpStatus.OK);
		}
	}

	private void SetSuggestReport(UserMaster userEntity, LabReportsLevel1 ll, PatLabAppointments patLabAppointments) {
		SuggestReport suggestReport = new SuggestReport();
		suggestReport.setPatLabAppointments(patLabAppointments);
		suggestReport.setLabReportsLevel1(ll);
		suggestReport.setActive(true);
		suggestReport.setCreatedOn(new Date());
		suggestReport.setModifiedOn(new Date());
		suggestReport.setCreatedBy(userEntity);
		suggestReport.setModifiedBy(userEntity);
		suggestReport.setDeleted(false);
		try {
			suggestReportService.saveOrUpdate(suggestReport);
		} catch (Exception e) {
			logger.error("Error:--", e);
		}

	}

	private void SetSuggestReportDiseble(UserMaster userEntity, SuggestReport pg) {
		pg.setActive(false);
		pg.setModifiedOn(new Date());
		pg.setModifiedBy(userEntity);
		pg.setDeleted(true);
		try {
			suggestReportService.saveOrUpdate(pg);
		} catch (Exception e) {
			logger.error("Error:--", e);
		}

	}

	@RequestMapping(value = PATIENTURLConstant.LAB_STATUS_CHANGE_URL, method = RequestMethod.POST, headers = CommonConstants.CONTENT_TYPE_APPLICATION_JSON)
	public ResponseEntity<Response> labStatusChange(Locale locale, @RequestBody StatusChange statusChange) {
		Response response = new Response();
		UserDetails userDetails = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		UserMaster userEntity = userService.findByUserName(userDetails.getUsername());
		try {
			PatLabAppointments patLabAppointments = patLabAppointmentService.get(statusChange.getId());
			if (PatientAppointmentStatus.Approved == patLabAppointments.getPatAppStatus()
					|| PatientAppointmentStatus.Pending == patLabAppointments.getPatAppStatus()) {
				patLabAppointments.setPatAppStatus(statusChange.getPatientAppointmentStatus());
				patLabAppointments.setPatLabAppDescription(statusChange.getDescription());
				patLabAppointments.setModifiedBy(userEntity);
				patLabAppointments.setModifiedOn(new Date());
				try {
					patLabAppointmentService.saveOrUpdate(patLabAppointments);
				} catch (Exception e) {
					logger.error("Error:--", e);
					response.setStatus(ResponseConstant.ERROR);
					response.setMessage(messageByLocaleService.getMessage(PATIENTURLConstant.LAB_ERROR));
					response.setData(messageByLocaleService.getMessage(PATIENTURLConstant.LAB_ERROR));
					return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
				}
				response.setStatus(ResponseConstant.SUCCESS);
				response.setMessage(messageByLocaleService.getMessage(PATIENTURLConstant.LAB_UPDATE));
				response.setData(messageByLocaleService.getMessage(PATIENTURLConstant.LAB_UPDATE));
			} else {
				response.setStatus(ResponseConstant.WARNING);
				response.setMessage(messageByLocaleService.getMessage(PATIENTURLConstant.LAB_UPDATE_ERROR));
				response.setData(messageByLocaleService.getMessage(PATIENTURLConstant.LAB_UPDATE_ERROR));
				return new ResponseEntity<Response>(response, HttpStatus.CONFLICT);
			}
		} catch (Exception e) {
			logger.error("Error:--", e);
			response.setStatus(ResponseConstant.ERROR);
			response.setMessage(messageByLocaleService.getMessage(PATIENTURLConstant.LAB_ERROR));
			response.setData(messageByLocaleService.getMessage(PATIENTURLConstant.LAB_ERROR));
			return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Response>(response, HttpStatus.OK);
	}

	@RequestMapping(value = PATIENTURLConstant.GET_ALL_LAB1_REPORT_BY_LAB_URL, method = RequestMethod.POST, headers = CommonConstants.CONTENT_TYPE_APPLICATION_JSON)
	public ResponseEntity<Response> getAllLab1ReportByLab(Locale locale) {
		Response response = new Response();
		UserDetails userDetails = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		UserMaster userEntity = userService.findByUserName(userDetails.getUsername());
		try {
			ProviderMaster providerMaster = providerService.getProvider(userEntity.getUserEmail(),ProviderTypeStatus.LabUser);
			List<FCLProviderMap> fclProviderMap = fclProviderService.getFclDataforDoctor(providerMaster.getProviderID(),providerMaster.getProviderTypeStatus());
			ProfessionalPojo professionalPojo = new ProfessionalPojo();
			professionalPojo.setFclProviderMap(fclProviderMap.get(0).getFclProviderMapID());
			List<LabReportsLevel1Pojo> labReportsLevel1Pojo = new ArrayList<LabReportsLevel1Pojo>(0);
			List<FCLProviderReportMap> fclProviderReportMap = fclProviderReportMapService.getAllData(fclProviderMap.get(0).getFclProviderMapID());
			for (FCLProviderReportMap fpr : fclProviderReportMap) {
				LabReportsLevel1Pojo lrlp = new LabReportsLevel1Pojo();
				lrlp.setLabReportLevel1ID(fpr.getLabReportLevel1ID().getLabReportLevel1ID());
				lrlp.setLabReportType(fpr.getLabReportLevel1ID().getLabReportType());
				lrlp.setLrl1Category(fpr.getLabReportLevel1ID().getLrl1Category());
				lrlp.setLrl1Name(fpr.getLabReportLevel1ID().getLrl1Name());
				lrlp.setGenericTestcode(fpr.getLabReportLevel1ID().getGenericTestcode());
				lrlp.setGenericSourceName(fpr.getLabReportLevel1ID().getGenericSourceName());
				labReportsLevel1Pojo.add(lrlp);
			}
			response.setStatus(ResponseConstant.SUCCESS);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_SUCCESS));
			response.setData(labReportsLevel1Pojo);
		} catch (Exception e) {
			logger.error("Error:--", e);
			response.setStatus(ResponseConstant.ERROR);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			response.setData(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Response>(response, HttpStatus.OK);
	}
}
