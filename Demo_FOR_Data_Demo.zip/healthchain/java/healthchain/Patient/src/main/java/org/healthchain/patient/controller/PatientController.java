package org.healthchain.patient.controller;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.healthchain.common.constants.CommonConstants;
import org.healthchain.common.constants.ResponseConstant;
import org.healthchain.common.utils.DateUtil;
import org.healthchain.entity.DiagnosisMaster;
import org.healthchain.entity.DrugCompoundMaster;
import org.healthchain.entity.FCLProviderMap;
import org.healthchain.entity.LabPatvisitNote;
import org.healthchain.entity.LabReportsLevel1;
import org.healthchain.entity.PatAppointments;
import org.healthchain.entity.PatDiagnosis;
import org.healthchain.entity.PatLabAppointments;
import org.healthchain.entity.PatVisitNote;
import org.healthchain.entity.PatientMaster;
import org.healthchain.entity.ProviderMaster;
import org.healthchain.entity.ReportLapApp;
import org.healthchain.entity.ReportPatLapApp;
import org.healthchain.entity.SuggestReport;
import org.healthchain.entity.UserMaster;
import org.healthchain.entity.enums.ProviderTypeStatus;
import org.healthchain.patient.constants.PATIENTURLConstant;
import org.healthchain.pojo.DiseasePojo;
import org.healthchain.pojo.DrugCompoundPojo;
import org.healthchain.pojo.LabReportPojo;
import org.healthchain.pojo.LabReportPojoList;
import org.healthchain.pojo.LabReportsLevel1Pojo;
import org.healthchain.pojo.PatAppointmentPojo;
import org.healthchain.pojo.PatAppointmentPojoList;
import org.healthchain.pojo.PatLabAppointmentsPojo;
import org.healthchain.pojo.PatLabAppointmentsPojoList;
import org.healthchain.pojo.PatVisitNotePojo;
import org.healthchain.pojo.PatVisitNotePojoList;
import org.healthchain.pojo.ReportLapPojo;
import org.healthchain.pojo.Response;
import org.healthchain.services.FCLProviderService;
import org.healthchain.services.LabPatvisitNoteService;
import org.healthchain.services.MessageByLocaleService;
import org.healthchain.services.PatAppointmentService;
import org.healthchain.services.PatDiagnosisService;
import org.healthchain.services.PatLabAppointmentService;
import org.healthchain.services.PatVisitNoteService;
import org.healthchain.services.PatientService;
import org.healthchain.services.ProviderService;
import org.healthchain.services.ReportLapAppService;
import org.healthchain.services.ReportLapReportPatLapService;
import org.healthchain.services.ReportPatLapAppService;
import org.healthchain.services.RxDetailService;
import org.healthchain.services.SuggestReportService;
import org.healthchain.services.UserService;
import org.healthchain.services.constants.MethodConstants;
import org.healthchain.services.constants.ServiceConstant;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@CrossOrigin
@RestController
@RequestMapping(PATIENTURLConstant.PATIENT_ROOT_URL)
public class PatientController {
	
	private static final Log logger = LogFactory.getLog(PatientController.class);
	
	@Autowired
	private UserService userService;
	
	@Autowired
    private FCLProviderService fclProviderService;
	
	@Autowired
	private ProviderService providerService;
	
	@Autowired
	private PatVisitNoteService patVisitNoteService;
		
	@Autowired
    private PatAppointmentService patAppointmentService;
	
	@Autowired
    private PatLabAppointmentService patLabAppointmentService;
	
	@Autowired
    private PatDiagnosisService patDiagnosisService;
	
	@Autowired
	private MessageByLocaleService messageByLocaleService;
	
	@Autowired
    private PatientService patientService;
	
	@Autowired
    private RxDetailService rxDetailService;
	
	@Autowired
    private SuggestReportService suggestReportService;
	
	@Autowired
    private LabPatvisitNoteService labPatvisitNoteService;
	
	@Autowired
	private ReportPatLapAppService reportPatLapAppService;
	
	@Autowired
	private ReportLapReportPatLapService reportLapReportPatLapService;
	
	@Autowired
	private ReportLapAppService reportLapAppService;
		
	@RequestMapping(value = PATIENTURLConstant.GET_APPOINTMENT_PATIENT_URL, method = RequestMethod.GET, headers = CommonConstants.CONTENT_TYPE_APPLICATION_JSON)
	public ResponseEntity<Response> getAppointmentPatient(Locale locale,Pageable pageable) {
		Response response = new Response();
		PatAppointmentPojoList patAppointmentPojoList=new PatAppointmentPojoList();
		List<PatAppointmentPojo> patAppointmentPojo=new ArrayList<PatAppointmentPojo>();
		UserDetails userDetails = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		UserMaster userEntity = userService.findByUserName(userDetails.getUsername());
		try {
			PatientMaster patientMaster=patientService.findByPatient(userEntity.getUserEmail());
			List<PatAppointments> patAppointments=patAppointmentService.findPatientData(patientMaster,pageable);
			List<PatAppointments> patAppointment=patAppointmentService.findPatientDatas(patientMaster);
			if(patAppointments.size()>0) {
				for(PatAppointments pa:patAppointments) {
					PatAppointmentPojo pap=MethodConstants.SetPatAppointmentPojo(pa);
					patAppointmentPojo.add(pap);
				}
				patAppointmentPojoList.setTotalNumber(patAppointment.size());
				patAppointmentPojoList.setPatAppointmentPojo(patAppointmentPojo);
			}
			response.setStatus(ResponseConstant.SUCCESS);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_SUCCESS));
			response.setData(patAppointmentPojoList);
		}catch (Exception e) {
			logger.error("Error:--", e);
			response.setStatus(ResponseConstant.ERROR);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			response.setData(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Response>(response, HttpStatus.OK);
	}
	
	@RequestMapping(value = PATIENTURLConstant.VIEW_AND_EDIT_APPOINTMENT_PATIENT_URL, method = RequestMethod.POST, headers = CommonConstants.CONTENT_TYPE_APPLICATION_JSON)
	public ResponseEntity<Response> viewAndEditAppointmentPatient(Locale locale,@RequestBody PatAppointments patAppointmentsMaster) {
		Response response = new Response();
		try {
			PatAppointments pa=patAppointmentService.get(patAppointmentsMaster.getPatAppointmentID());
			PatAppointmentPojo pap=MethodConstants.SetPatAppointmentPojo(pa);
			response.setStatus(ResponseConstant.SUCCESS);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_SUCCESS));
			response.setData(pap);
		}catch (Exception e) {
			logger.error("Error:--", e);
			response.setStatus(ResponseConstant.ERROR);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			response.setData(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Response>(response, HttpStatus.OK);
	}
	
	@RequestMapping(value = PATIENTURLConstant.GET_DOCTOR_VISIT_PATIENT_URL, method = RequestMethod.GET, headers = CommonConstants.CONTENT_TYPE_APPLICATION_JSON)
	public ResponseEntity<Response> getAllDoctorVisitPatient(Locale locale,Pageable pageable) {
		Response response = new Response();
		PatVisitNotePojoList patVisitNotePojoList=new PatVisitNotePojoList();
		List<PatVisitNotePojo> patVisitNotePojo=new ArrayList<PatVisitNotePojo>();
		UserDetails userDetails = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		UserMaster userEntity = userService.findByUserName(userDetails.getUsername());
		try {
			PatientMaster patientMaster=patientService.findByPatient(userEntity.getUserEmail());
			List<PatVisitNote> patVisitNote=patVisitNoteService.findPatientData(patientMaster.getPatientID(),pageable);
			List<PatVisitNote> patVisitNotes=patVisitNoteService.findPatientDatas(patientMaster.getPatientID());
			if(patVisitNote.size()>0) {
				for(PatVisitNote pvn:patVisitNote) {
					PatVisitNotePojo pvnp=SetPatVisitNote(pvn);
					patVisitNotePojo.add(pvnp);
				}
				patVisitNotePojoList.setTotalNumber(patVisitNotes.size());
				patVisitNotePojoList.setPatVisitNotePojo(patVisitNotePojo);
			}
			response.setStatus(ResponseConstant.SUCCESS);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_SUCCESS));
			response.setData(patVisitNotePojoList);
		}catch (Exception e) {
			logger.error("Error:--", e);
			response.setStatus(ResponseConstant.ERROR);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			response.setData(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Response>(response, HttpStatus.OK);
	}
	
	@RequestMapping(value = PATIENTURLConstant.VIEW_AND_EDIT_DOCTOR_VISIT_PATIENT_URL, method = RequestMethod.POST, headers = CommonConstants.CONTENT_TYPE_APPLICATION_JSON)
	public ResponseEntity<Response> viewAndEditDoctorVisitPatient(Locale locale,@RequestBody PatVisitNote patVisitNote) {
		Response response = new Response();
		try {
			PatVisitNote pvn=patVisitNoteService.get(patVisitNote.getPatVisitNoteID());
			PatVisitNotePojo pap=SetPatVisitNote(pvn);
			response.setStatus(ResponseConstant.SUCCESS);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_SUCCESS));
			response.setData(pap);
		}catch (Exception e) {
			logger.error("Error:--", e);
			response.setStatus(ResponseConstant.ERROR);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			response.setData(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Response>(response, HttpStatus.OK);
	}
	
	private PatVisitNotePojo SetPatVisitNote(PatVisitNote pvn) {
		PatVisitNotePojo pvp=new PatVisitNotePojo();
		pvp.setPatVisitNoteID(pvn.getPatVisitNoteID());
		String dates=DateUtil.getLocalDateFormatted(pvn.getPatVisitDate(), DateUtil.dateTimeFormatterDDMMMYYYY);
		pvp.setPatVisitDate(dates);
		String tim=DateUtil.getLocalDateFormatted(pvn.getPatVisitDate(), DateUtil.timeFormatterHHMMA);
		pvp.setTimes(tim);
		pvp.setTreatmentProvided(pvn.getTreatmentProvided());
		pvp.setPatSymptoms(pvn.getPatSymptoms());
		pvp.setPatSideEffect(pvn.getPatSideEffect());
		pvp.setPatExtraDetails(pvn.getPatExtraDetails());
		pvp.setPatVisitType(pvn.getPatVisitType());
		List<PatDiagnosis> patDiagnosis=patDiagnosisService.findAll(pvn.getPatVisitNoteID());
		List<DiseasePojo> dm=new ArrayList<DiseasePojo>();
		for(PatDiagnosis pd : patDiagnosis){
			DiseasePojo dms=new DiseasePojo();
			dms.setDiagnosisID(pd.getDiagnosisMaster().getDiagnosisID());
			dms.setDiagnosiseName(pd.getDiagnosisMaster().getDiagnosiseName());
			dm.add(dms);
		}
		pvp.setDiagnosisMaster(dm);
		pvp.setPatientID(pvn.getClfPatRegistrationMap().getPatientID().getPatientID());
		pvp.setName(pvn.getClfPatRegistrationMap().getPatientID().getPersonID().getPerFname()+" "+pvn.getClfPatRegistrationMap().getPatientID().getPersonID().getPerLName());
		pvp.setProviderID(pvn.getFclProviderMapID().getProviderID().getProviderID());
		pvp.setProviderName(CommonConstants.DR_SHORT+" "+pvn.getFclProviderMapID().getProviderID().getPersonMaster().getPerFname()+" "+pvn.getFclProviderMapID().getProviderID().getPersonMaster().getPerLName());
		pvp.setFcLocationMapID(pvn.getFclProviderMapID().getLocationMapID().getFcLocationMapID());
		pvp.setFcLocationName(pvn.getFclProviderMapID().getLocationMapID().getFcLocationName());
		pvp.setFacilityCenterID(pvn.getFclProviderMapID().getLocationMapID().getFacilityCenterMaster().getFacilityCenterID());
		pvp.setFacilityCenterName(pvn.getFclProviderMapID().getLocationMapID().getFacilityCenterMaster().getFacilityCenterName());
		pvp.setFacilityCenterType(pvn.getFclProviderMapID().getLocationMapID().getFacilityCenterMaster().getFacilityCenterType());
		if(pvn.getAppointmentID() != null) {
			pvp.setAppointmentID(pvn.getAppointmentID().getPatAppointmentID());
		}
		List<LabPatvisitNote> labPatvisitNote=labPatvisitNoteService.findAll(pvn.getPatVisitNoteID());
		List<LabReportsLevel1Pojo> llp=new ArrayList<LabReportsLevel1Pojo>();
		for(LabPatvisitNote lpn : labPatvisitNote){
			LabReportsLevel1Pojo ll=new LabReportsLevel1Pojo();
			ll.setLabReportLevel1ID(lpn.getLabReportsLevel1().getLabReportLevel1ID());
			ll.setLabReportType(lpn.getLabReportsLevel1().getLabReportType());
			ll.setLrl1Category(lpn.getLabReportsLevel1().getLrl1Category());
			ll.setLrl1Name(lpn.getLabReportsLevel1().getLrl1Name());
			ll.setGenericTestcode(lpn.getLabReportsLevel1().getGenericTestcode());
			ll.setGenericSourceName(lpn.getLabReportsLevel1().getGenericSourceName());
			llp.add(ll);
		}
		pvp.setLabReportsLevel1(llp);
		List<DrugCompoundMaster> rxds=rxDetailService.findAll(pvn.getPatVisitNoteID());
		List<DrugCompoundPojo> drugCompoundPojo=new ArrayList<DrugCompoundPojo>();
		for(DrugCompoundMaster dcm:rxds) {
			DrugCompoundPojo dcp=new DrugCompoundPojo();
			dcp.setDrugCompoundID(dcm.getDrugCompoundID());
			dcp.setDrugCompoundName(dcm.getDrugCompoundName());
			drugCompoundPojo.add(dcp);
		}
		pvp.setDrugCompoundMaster(drugCompoundPojo);
		return pvp;
	}
		
	@RequestMapping(value = PATIENTURLConstant.GET_LAB_PATIENT_URL, method = RequestMethod.GET, headers = CommonConstants.CONTENT_TYPE_APPLICATION_JSON)
	public ResponseEntity<Response> getAllLabPatient(Locale locale,Pageable pageable) {
		Response response = new Response();
		PatLabAppointmentsPojoList patLabAppointmentsPojoList=new PatLabAppointmentsPojoList();
		List<PatLabAppointmentsPojo> patLabAppointmentsPojo=new ArrayList<PatLabAppointmentsPojo>();
		UserDetails userDetails = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		UserMaster userEntity = userService.findByUserName(userDetails.getUsername());
		try {
			PatientMaster patientMaster=patientService.findByPatient(userEntity.getUserEmail());
			List<PatLabAppointments> patLabAppointments=patLabAppointmentService.findPatientData(patientMaster,pageable);
			List<PatLabAppointments> patLabAppointment=patLabAppointmentService.findPatientDatas(patientMaster);
			if(patLabAppointments.size()>0) {
				for(PatLabAppointments pa:patLabAppointments) {
					PatLabAppointmentsPojo pap=SetPatLabAppointmentsPojo(pa);
					patLabAppointmentsPojo.add(pap);
				}
				patLabAppointmentsPojoList.setTotalNumber(patLabAppointment.size());
				patLabAppointmentsPojoList.setPatLabAppointmentsPojo(patLabAppointmentsPojo);
			}
			response.setStatus(ResponseConstant.SUCCESS);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_SUCCESS));
			response.setData(patLabAppointmentsPojoList);
		}catch (Exception e) {
			logger.error("Error:--", e);
			response.setStatus(ResponseConstant.ERROR);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			response.setData(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Response>(response, HttpStatus.OK);
	}
	
	@RequestMapping(value = PATIENTURLConstant.VIEW_AND_EDIT_LAB_PATIENT_URL, method = RequestMethod.POST, headers = CommonConstants.CONTENT_TYPE_APPLICATION_JSON)
	public ResponseEntity<Response> viewAndEditLabPatient(Locale locale,@RequestBody PatLabAppointments patLabAppointments) {
		Response response = new Response();
		try {
			PatLabAppointments pa=patLabAppointmentService.get(patLabAppointments.getPatLabAppointmentID());
			PatLabAppointmentsPojo pap=SetPatLabAppointmentsPojo(pa);
			response.setStatus(ResponseConstant.SUCCESS);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_SUCCESS));
			response.setData(pap);
		}catch (Exception e) {
			logger.error("Error:--", e);
			response.setStatus(ResponseConstant.ERROR);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			response.setData(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Response>(response, HttpStatus.OK);
	}
	
	@RequestMapping(value = PATIENTURLConstant.GET_LAB_REPORT_LIST_URL, method = RequestMethod.GET, headers = CommonConstants.CONTENT_TYPE_APPLICATION_JSON)
	public ResponseEntity<Response> getAllLabReport(Locale locale,Pageable pageable) {
		Response response = new Response();
		UserDetails userDetails = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		UserMaster userEntity = userService.findByUserName(userDetails.getUsername());
		try {
			PatientMaster patientMaster=patientService.findByPatient(userEntity.getUserEmail());
			LabReportPojoList labReportPojoList=new LabReportPojoList();
			List<LabReportPojo> labReportPojo=new ArrayList<LabReportPojo>(0);
			List<ReportPatLapApp> reportPatLap=reportPatLapAppService.findReportAllpatient(patientMaster.getPatientID(),pageable);
			List<ReportPatLapApp> reportPatLaps=reportPatLapAppService.findReportAllpatients(patientMaster.getPatientID());
			if(reportPatLap.size()>0) {
				for(ReportPatLapApp reportPatLapApp:reportPatLap) {
					LabReportPojo lrps=SetLabReportPojo(reportPatLapApp,patientMaster);
					labReportPojo.add(lrps);
				}
				labReportPojoList.setTotalNumber(reportPatLaps.size());
				labReportPojoList.setLabReportPojo(labReportPojo);
			}
			response.setStatus(ResponseConstant.SUCCESS);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_SUCCESS));
			response.setData(labReportPojoList);
		} catch (Exception e) {
			logger.error("Error:--", e);
			response.setStatus(ResponseConstant.ERROR);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			response.setData(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Response>(response, HttpStatus.OK);
	}
	
	@RequestMapping(value = PATIENTURLConstant.GET_LAB_REPORT_URL, method = RequestMethod.POST, headers = CommonConstants.CONTENT_TYPE_APPLICATION_JSON)
	public ResponseEntity<Response> ViewLabReport(Locale locale,@RequestBody ReportPatLapApp reportPatLapApps) {
		Response response = new Response();
		UserDetails userDetails = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		UserMaster userEntity = userService.findByUserName(userDetails.getUsername());
		try {
			LabReportPojo lrp=new LabReportPojo();
			PatientMaster patientMaster=patientService.findByPatient(userEntity.getUserEmail());
			ReportPatLapApp reportPatLap=reportPatLapAppService.get(reportPatLapApps.getReportPatLapAppId());
			if(reportPatLap != null) {
				lrp=SetLabReportPojo(reportPatLap,patientMaster);
			}
			response.setStatus(ResponseConstant.SUCCESS);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_SUCCESS));
			response.setData(lrp);
		} catch (Exception e) {
			logger.error("Error:--", e);
			response.setStatus(ResponseConstant.ERROR);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			response.setData(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Response>(response, HttpStatus.OK);
	}
	
	
	
	private PatLabAppointmentsPojo SetPatLabAppointmentsPojo(PatLabAppointments pa) {
		PatLabAppointmentsPojo pap=new PatLabAppointmentsPojo();
		pap.setAthome(pa.isAthome());
		pap.setPatLabAppointmentID(pa.getPatLabAppointmentID());
		pap.setPatientID(pa.getFclpID().getPatientID().getPatientID());
		pap.setName(pa.getFclpID().getPatientID().getPersonID().getPerFname()+" "+pa.getFclpID().getPatientID().getPersonID().getPerLName());
		pap.setFclProviderMapID(pa.getFclProviderMapID().getFclProviderMapID());
		pap.setProviderID(pa.getFclProviderMapID().getProviderID().getProviderID());
		pap.setProviderName(CommonConstants.DR_SHORT+" "+pa.getFclProviderMapID().getProviderID().getPersonMaster().getPerFname()+" "+pa.getFclProviderMapID().getProviderID().getPersonMaster().getPerLName());
		pap.setPatLabAppDate(pa.getPatLabAppDate());
		pap.setPatLabAppTimeFrom(pa.getPatLabAppTimeFrom());
		pap.setPatLabAppTimeTo(pa.getPatLabAppTimeTo());
		pap.setFcLocationMapID(pa.getFclProviderMapID().getLocationMapID().getFcLocationMapID());
		pap.setFcLocationName(pa.getFclProviderMapID().getLocationMapID().getFcLocationName());
		pap.setFacilityCenterID(pa.getFclProviderMapID().getLocationMapID().getFacilityCenterMaster().getFacilityCenterID());
		pap.setFacilityCenterName(pa.getFclProviderMapID().getLocationMapID().getFacilityCenterMaster().getFacilityCenterName());
		pap.setFacilityCenterType(pa.getFclProviderMapID().getLocationMapID().getFacilityCenterMaster().getFacilityCenterType());
		pap.setPatAppType(pa.getPatAppType());
		pap.setPatAppStatus(pa.getPatAppStatus());
		pap.setPatientLabAppointmentReason(pa.getPatientLabAppointmentReason());
		pap.setPatLabDetail(pa.getPatLabDetail());
		if(pa.getPatVisitNote() !=null) {
			pap.setPatVisitNoteID(pa.getPatVisitNote().getPatVisitNoteID());
		}else {
			pap.setPatVisitNoteID(null);
		}
		List<SuggestReport> sr=suggestReportService.findAll(pa.getPatLabAppointmentID());
		List<LabReportsLevel1Pojo> labReportsLevel1Pojo = new ArrayList<LabReportsLevel1Pojo>();
		for(SuggestReport srs:sr) {
			LabReportsLevel1Pojo lrlp = new LabReportsLevel1Pojo();
			lrlp.setLabReportLevel1ID(srs.getLabReportsLevel1().getLabReportLevel1ID());
			lrlp.setLrl1Category(srs.getLabReportsLevel1().getLrl1Category());
			lrlp.setLabReportType(srs.getLabReportsLevel1().getLabReportType());
			lrlp.setLrl1Name(srs.getLabReportsLevel1().getLrl1Name());
			lrlp.setGenericTestcode(srs.getLabReportsLevel1().getGenericTestcode());
			lrlp.setGenericSourceName(srs.getLabReportsLevel1().getGenericSourceName());
			labReportsLevel1Pojo.add(lrlp);
		}
		pap.setData(labReportsLevel1Pojo);
		return pap;
	}
	
	private LabReportPojo SetLabReportPojo(ReportPatLapApp reportPatLapApp,PatientMaster patientMaster) {
		LabReportPojo lrp=new LabReportPojo();
		if(reportPatLapApp.getPatLabAppointments() == null) {
			lrp.setPatLabAppointmentID(null);
			lrp.setPatVisitNoteID(null);
			ProviderMaster providerMaster=providerService.getProvider(reportPatLapApp.getCreatedBy().getUserEmail(),ProviderTypeStatus.LabUser);
			List<FCLProviderMap> fclProviderMap=fclProviderService.getFclDataforDoctor(providerMaster.getProviderID(),providerMaster.getProviderTypeStatus());
			lrp.setProviderName(fclProviderMap.get(0).getLocationMapID().getFacilityCenterMaster().getFacilityCenterName());
		}else {
			lrp.setPatLabAppointmentID(reportPatLapApp.getPatLabAppointments().getPatLabAppointmentID());
			if(reportPatLapApp.getPatLabAppointments().getPatVisitNote() == null) {
				lrp.setPatVisitNoteID(null);
			}else {
				lrp.setPatVisitNoteID(reportPatLapApp.getPatLabAppointments().getPatVisitNote().getPatVisitNoteID());
				lrp.setProviderName(reportPatLapApp.getPatLabAppointments().getFclProviderMapID().getLocationMapID().getFacilityCenterMaster().getFacilityCenterName());
			}
		}
		lrp.setPatientMaster(patientMaster.getPatientID());
		lrp.setPatientName(patientMaster.getPersonID().getPerFname()+" "+patientMaster.getPersonID().getPerLName());
		String dates=DateUtil.getLocalDateFormatted(reportPatLapApp.getCreatedOn(), DateUtil.dateTimeFormatterDDMMMYYYY);
		lrp.setDate(dates);
		String fromtime=DateUtil.getLocalDateFormatted(reportPatLapApp.getCreatedOn(), DateUtil.timeFormatterHHMMA);
		lrp.setTime(fromtime);
		lrp.setReportPatLapAppId(reportPatLapApp.getReportPatLapAppId());
		lrp.setAdditionalDetail(reportPatLapApp.getAdditionalDetail());
		lrp.setReportDetail(reportPatLapApp.getReportDetail());
		List<ReportLapApp> reportLapApp=reportLapReportPatLapService.findReport(reportPatLapApp.getReportPatLapAppId());
		Set<ReportLapPojo> reportLapdata = new HashSet<ReportLapPojo>(0);
		for(ReportLapApp rla:reportLapApp) {
			ReportLapPojo rlp=new ReportLapPojo();
			rlp.setReportLapAppId(rla.getReportLapAppId());
			rlp.setExtraDetail(rla.getExtraDetail());
			rlp.setReportPath(rla.getReportPath());
			Set<DiseasePojo> diagnosisMasterdata = new HashSet<DiseasePojo>(0);
			List<DiagnosisMaster> dms=reportLapReportPatLapService.findDisease(rla.getReportLapAppId());
			for(DiagnosisMaster dm:dms) {
				DiseasePojo diseasePojo=new DiseasePojo();
				diseasePojo.setDiagnosisID(dm.getDiagnosisID());
				diseasePojo.setDiagnosiseName(dm.getDiagnosiseName());
				diagnosisMasterdata.add(diseasePojo);
			}
			LabReportsLevel1 ll=reportLapAppService.findAlllabreport(rla.getReportLapAppId());
			LabReportsLevel1Pojo llp=new LabReportsLevel1Pojo();
			llp.setLabReportLevel1ID(ll.getLabReportLevel1ID());
			llp.setLrl1Name(ll.getLrl1Name());
			rlp.setLabReportsLevel1Pojo(llp);
			rlp.setDiagnosisMasterdata(diagnosisMasterdata);
			reportLapdata.add(rlp);
		}
		lrp.setReportLapdata(reportLapdata);
		
		return lrp;
	}
}
