package org.healthchain.base;

import org.healthchain.entity.LocationMaster;
import org.springframework.stereotype.Repository;

@Repository
public interface LocationRepository extends GenericRepository<LocationMaster, Long> {

	
}
