package org.healthchain.base;

import java.util.List;

import org.healthchain.entity.PatDiagnosis;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface PatDiagnosisRepository extends GenericRepository<PatDiagnosis, Long> {

	@Query("SELECT distinct(u) FROM PatDiagnosis u WHERE u.diagnosisMaster.diagnosisID = :diagnosisID And u.patVisitNoteOutdoor.patVisitNoteID = :patVisitNoteID")
	PatDiagnosis findData(@Param("diagnosisID") Long diagnosisID,@Param("patVisitNoteID") Long patVisitNoteID);
	
	@Query("SELECT distinct(u) FROM PatDiagnosis u WHERE u.patVisitNoteOutdoor.patVisitNoteID = :patVisitNoteID And u.active = true And u.deleted= false")
	List<PatDiagnosis> findAll(@Param("patVisitNoteID") Long patVisitNoteID);
	
	@Query("SELECT distinct(u) FROM PatDiagnosis u WHERE u.patVisitNoteOutdoor.patVisitNoteID = :patVisitNoteID")
	List<PatDiagnosis> findAllData(@Param("patVisitNoteID") Long patVisitNoteID);
}
