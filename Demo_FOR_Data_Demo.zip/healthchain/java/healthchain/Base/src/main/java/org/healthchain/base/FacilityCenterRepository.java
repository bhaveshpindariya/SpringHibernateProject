package org.healthchain.base;

import java.util.List;

import org.healthchain.entity.FacilityCenterMaster;
import org.healthchain.entity.enums.FacilityCenterType;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface FacilityCenterRepository extends GenericRepository<FacilityCenterMaster, Long> {

	@Query("SELECT distinct(u) FROM FacilityCenterMaster u WHERE LOWER(u.facilityCenterName) = LOWER(:facilityCenterName) And u.facilityCenterType = :facilityCenterType And u.active = true And u.deleted= false")
	FacilityCenterMaster findByCenterName(@Param("facilityCenterName") String facilityCenterName,@Param("facilityCenterType") FacilityCenterType facilityCenterType);
	
	@Query("SELECT distinct(u) FROM FacilityCenterMaster u WHERE u.facilityCenterType = :facilityCenterType And LOWER(u.facilityCenterName) like %:facilityCenterName% And u.active = true And u.deleted= false")
	List<FacilityCenterMaster> getAllActiveRecordByPerameterData(@Param("facilityCenterType") FacilityCenterType facilityCenterType,@Param("facilityCenterName") String facilityCenterName);

	@Query("SELECT distinct(u) FROM FacilityCenterMaster u WHERE u.facilityCenterType = :facilityCenterType And u.active = true And u.deleted= false")
	List<FacilityCenterMaster> getAllActiveRecordByPerameter(@Param("facilityCenterType") FacilityCenterType facilityCenterType);

}
