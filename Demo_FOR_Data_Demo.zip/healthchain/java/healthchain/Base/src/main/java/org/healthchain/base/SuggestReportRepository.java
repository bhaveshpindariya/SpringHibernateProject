package org.healthchain.base;

import java.util.List;

import org.healthchain.entity.SuggestReport;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface SuggestReportRepository extends GenericRepository<SuggestReport, Long> {

	@Query("SELECT distinct(u) FROM SuggestReport u WHERE u.labReportsLevel1.labReportLevel1ID = :labReportLevel1ID And u.patLabAppointments.patLabAppointmentID = :patLabAppointmentID")
	SuggestReport findData(@Param("labReportLevel1ID")Long labReportLevel1ID,@Param("patLabAppointmentID")Long patLabAppointmentID);

	@Query("SELECT distinct(u) FROM SuggestReport u WHERE u.patLabAppointments.patLabAppointmentID = :patLabAppointmentID And u.active = true And u.deleted= false")
	List<SuggestReport> findAll(@Param("patLabAppointmentID") Long patLabAppointmentID);
	
	@Query("SELECT distinct(u) FROM SuggestReport u WHERE u.patLabAppointments.patLabAppointmentID = :patLabAppointmentID")
	List<SuggestReport> findAllData(@Param("patLabAppointmentID") Long patLabAppointmentID);
}
