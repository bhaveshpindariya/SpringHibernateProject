package org.healthchain.base;

import java.util.List;

import org.healthchain.entity.PersonLocationMap;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface PersonLocationRepository extends GenericRepository<PersonLocationMap, Long> {

	@Query("SELECT distinct(u) FROM PersonLocationMap u WHERE u.personMaster.personID = :patientID And u.locationMaster.locationID = :locationID And u.active = true And u.deleted= false")
	List<PersonLocationMap> getPersonData(@Param("patientID")Long patientID,@Param("locationID")Long locationID);
	
	@Query("SELECT distinct(u) FROM PersonLocationMap u WHERE u.personMaster.personID = :patientID And u.active = true And u.deleted= false")
	List<PersonLocationMap> getPersonDatas(@Param("patientID")Long patientID);
	
}
