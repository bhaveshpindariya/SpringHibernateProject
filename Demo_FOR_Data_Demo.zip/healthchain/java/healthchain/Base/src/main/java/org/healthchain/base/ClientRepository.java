package org.healthchain.base;

import org.healthchain.entity.ClientMaster;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface ClientRepository extends GenericRepository<ClientMaster, Long> {

	@Query("SELECT distinct(u) FROM ClientMaster u WHERE LOWER(u.clientComapnyName) = LOWER(:clientComapnyName) And u.active = true And u.deleted= false")
	ClientMaster findByCenterName(@Param("clientComapnyName") String clientComapnyName);

}
