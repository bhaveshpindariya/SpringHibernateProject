package org.healthchain.common.utils;

import org.healthchain.common.constants.CommonConstants;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;

import net.sf.json.JSONObject;
import net.sf.json.JSONSerializer;

public class ApiUtil {
	
	public static Object get() {
		return null;
	}

	public static Object post(String endpoint, String type, Object Obj) {
		if (Obj.toString().equals("{}")) {
			return null;
		}else {
			Client client1 = Client.create();
			String finalURL = CommonConstants.getPropertiesValue(CommonConstants.BLOCKCHAIN_HOST) + CommonConstants.getPropertiesValue(CommonConstants.BLOCKCHAIN_PORT) + endpoint;
			WebResource webResource1 = client1.resource(finalURL);
			ClientResponse response1 = webResource1.type("application/json").post(ClientResponse.class,Obj.toString());
			if (response1.getStatus() != 200) {
				System.out.println("RESPONSE " + response1.toString());
			}
			JSONObject obj = (JSONObject) JSONSerializer.toJSON(response1.getEntity(String.class));
			JSONObject data = obj.getJSONObject("data");
			return data;
		}
	}

	public static Object put() {
		return null;
	}

	public static Object delete() {

		return null;
	}
	
	/*public static void main(String args[]) {

		JSONObject userEntity = new JSONObject();
		userEntity.put("transactionHash", "0xf6dc993eb47af92c81f559a0752ed083523d42eeb5edfa6d1726c5544df63154");

		Client client1 = Client.create();
		
		 * String finalURL = host+port+endpoint;
		 
		String finalURL = "http://192.168.15.228:8081/getTransactionReceipt";
		WebResource webResource1 = client1.resource(finalURL);
		ClientResponse response1 = webResource1.type("application/json").post(ClientResponse.class,
				userEntity.toString());
		if (response1.getStatus() != 200) {
			System.out.println("RESPONSE " + response1.toString());
		}

		JSONObject obj = (JSONObject) JSONSerializer.toJSON(response1.getEntity(String.class));
		System.out.println("Respone is " + obj.get("data"));

		JSONObject data = obj.getJSONObject("data");

	}
*/
}
