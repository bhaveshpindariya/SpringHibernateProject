package org.healthchain.base;

import java.util.List;

import org.healthchain.entity.ProviderMaster;
import org.healthchain.entity.enums.ProviderTypeStatus;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface ProviderRepository extends GenericRepository<ProviderMaster, Long> {

	@Query("SELECT distinct(u) FROM ProviderMaster u WHERE u.providerTypeStatus = :providerTypeStatus And u.active = true And u.deleted= false")
	List<ProviderMaster> getAllActiveDoctor(@Param("providerTypeStatus") ProviderTypeStatus providerTypeStatus);
	
	@Query("SELECT distinct(u) FROM ProviderMaster u WHERE u.providerTypeStatus = :providerTypeStatus And (LOWER(u.personMaster.perFname) like %:name% "  
			+"OR LOWER(u.personMaster.perLName) like %:name%) And u.active = true And u.deleted= false")
	List<ProviderMaster> getAllDoctorByperameter(@Param("providerTypeStatus") ProviderTypeStatus providerTypeStatus,@Param("name") String name);
	
	@Query("SELECT distinct(u) FROM ProviderMaster u WHERE u.personMaster.personID = :personID And u.active = true And u.deleted= false")
	List<ProviderMaster> getAllperson(@Param("personID") Long personID);
																				
	@Query("SELECT distinct(u) FROM ProviderMaster u WHERE LOWER(u.personMaster.perEmailPrimary) = LOWER(:perEmailPrimary) And u.providerTypeStatus = :providerTypeStatus And u.active = true And u.deleted= false")
	ProviderMaster getProvider(@Param("perEmailPrimary") String perEmailPrimary,@Param("providerTypeStatus") ProviderTypeStatus providerTypeStatus);

}
