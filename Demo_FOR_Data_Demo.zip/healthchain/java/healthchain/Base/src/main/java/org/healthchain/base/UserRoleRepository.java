package org.healthchain.base;

import java.util.List;

import org.healthchain.entity.RoleMaster;
import org.healthchain.entity.UserMaster;
import org.healthchain.entity.UserRoleEntity;
import org.springframework.stereotype.Repository;

@Repository
public interface UserRoleRepository extends GenericRepository<UserRoleEntity, Long> {

	List<UserRoleEntity> findByRoleMaster(RoleMaster roleEntity);

	List<UserRoleEntity> findByUserMaster(UserMaster userEntity);

}
