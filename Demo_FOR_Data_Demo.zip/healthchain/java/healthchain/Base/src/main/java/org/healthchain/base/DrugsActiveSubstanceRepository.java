package org.healthchain.base;

import org.healthchain.entity.DrugsActiveSubstanceMaster;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface DrugsActiveSubstanceRepository extends GenericRepository<DrugsActiveSubstanceMaster, Long> {

	@Query("SELECT distinct(u) FROM DrugsActiveSubstanceMaster u WHERE LOWER(u.dasName) = LOWER(:dasName) And u.active = true And u.deleted= false")
	DrugsActiveSubstanceMaster findData(@Param("dasName") String dasName);
}
