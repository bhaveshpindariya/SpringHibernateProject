package org.healthchain.base;

import java.util.List;

import org.healthchain.entity.DiagnosisMaster;
import org.healthchain.entity.ReportLapApp;
import org.healthchain.entity.ReportLapReportPatLap;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface ReportLapReportPatLapRepository extends GenericRepository<ReportLapReportPatLap, Long> {

	@Query("SELECT distinct(u) FROM ReportLapReportPatLap u WHERE u.reportPatLapApp.reportPatLapAppId = :reportPatLapAppId "
			+ "And u.active = true And u.deleted= false")
	List<ReportLapReportPatLap> findData(@Param("reportPatLapAppId") Long reportPatLapAppId);
	
	@Query("SELECT distinct(u) FROM ReportLapReportPatLap u WHERE u.reportLapApp.reportLapAppId = :reportLapAppId")
	List<ReportLapReportPatLap> findDatas(@Param("reportLapAppId") Long reportLapAppId);
	
	@Query("SELECT distinct(u.diagnosisMaster) FROM ReportLapReportPatLap u WHERE u.reportLapApp.reportLapAppId = :reportLapAppId "
			+ "And u.active = true And u.deleted= false")
	List<DiagnosisMaster> findDisease(@Param("reportLapAppId") Long reportLapAppId);

	@Query("SELECT distinct(u.reportLapApp) FROM ReportLapReportPatLap u WHERE u.reportPatLapApp.reportPatLapAppId = :reportPatLapAppId "
			+ "And u.active = true And u.deleted= false")
	List<ReportLapApp> findReport(@Param("reportPatLapAppId") Long reportPatLapAppId);
	
	@Query("SELECT distinct(u) FROM ReportLapReportPatLap u WHERE u.reportLapApp.reportLapAppId = :reportLapAppId "
			+ "And u.diagnosisMaster.diagnosisID = :diagnosisID And u.active = true And u.deleted= false")
	ReportLapReportPatLap findAllPerameterData(@Param("reportLapAppId") Long reportLapAppId,@Param("diagnosisID") Long diagnosisID);
	
}
