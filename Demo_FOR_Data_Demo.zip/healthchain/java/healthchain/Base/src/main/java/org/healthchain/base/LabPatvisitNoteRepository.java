package org.healthchain.base;

import java.util.List;

import org.healthchain.entity.LabPatvisitNote;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface LabPatvisitNoteRepository extends GenericRepository<LabPatvisitNote, Long> {

	@Query("SELECT distinct(u) FROM LabPatvisitNote u WHERE u.labReportsLevel1.labReportLevel1ID = :labReportLevel1ID And u.patVisitNote.patVisitNoteID = :patVisitNoteID")
	LabPatvisitNote findData(@Param("labReportLevel1ID")Long labReportLevel1ID,@Param("patVisitNoteID")Long patVisitNoteID);

	@Query("SELECT distinct(u) FROM LabPatvisitNote u WHERE u.patVisitNote.patVisitNoteID = :patVisitNoteID And u.active = true And u.deleted= false")
	List<LabPatvisitNote> findAll(@Param("patVisitNoteID") Long patVisitNoteID);
	
	@Query("SELECT distinct(u) FROM LabPatvisitNote u WHERE u.patVisitNote.patVisitNoteID = :patVisitNoteID")
	List<LabPatvisitNote> findAllData(@Param("patVisitNoteID") Long patVisitNoteID);
}
