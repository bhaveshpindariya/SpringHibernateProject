package org.healthchain.base;

import org.healthchain.entity.DeviceDetail;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface DeviceDetailRepository extends GenericRepository<DeviceDetail, Long> {

	
	@Query("SELECT distinct(u) FROM DeviceDetail u WHERE u.deviceToken = :deviceToken And u.deviceType = :deviceType"+
			" And u.deviceID = :deviceID And u.userMaster.userID = :userID And u.active = true And u.deleted= false")
	DeviceDetail findByUserForDevice(@Param("deviceToken") String deviceToken,@Param("deviceType") String deviceType,
			@Param("deviceID") String deviceID,@Param("userID") Long userID);
	

}
