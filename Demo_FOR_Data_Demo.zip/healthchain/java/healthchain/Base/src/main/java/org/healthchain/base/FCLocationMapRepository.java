package org.healthchain.base;

import java.util.List;

import org.healthchain.entity.FCLocationMap;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface FCLocationMapRepository extends GenericRepository<FCLocationMap, Long> {

	@Query("SELECT distinct(u) FROM FCLocationMap u WHERE u.facilityCenterMaster.facilityCenterID = :facilityCenterID And u.active = true And u.deleted= false")
	List<FCLocationMap> getLocation(@Param("facilityCenterID") Long facilityCenterID);
	
	@Query("SELECT distinct(u) FROM FCLocationMap u WHERE u.facilityCenterMaster.facilityCenterID = :facilityCenterID "+
			"And u.locationMaster.locationID = :locationID")
	FCLocationMap getdata(@Param("facilityCenterID") Long facilityCenterID,@Param("locationID") Long locationID);

}
