package org.healthchain.base;

import org.healthchain.entity.CFLPatRegistrationMap;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface CFLPatRegistrationMapRepository extends GenericRepository<CFLPatRegistrationMap, Long> {

	@Query("SELECT distinct(u) FROM CFLPatRegistrationMap u WHERE u.fcLocationMap.fcLocationMapID = :fcLocationMapID And u.patientID.patientID = :patientID "+
	"And u.active = true And u.deleted= false")
	CFLPatRegistrationMap findCflData(@Param("patientID")Long patientID,@Param("fcLocationMapID")Long fcLocationMapID);
	

}
