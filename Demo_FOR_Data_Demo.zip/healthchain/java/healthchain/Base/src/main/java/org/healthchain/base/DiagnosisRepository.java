package org.healthchain.base;

import java.util.List;

import org.healthchain.entity.DiagnosisMaster;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface DiagnosisRepository extends GenericRepository<DiagnosisMaster, Long> {

	@Query("SELECT distinct(u) FROM DiagnosisMaster u WHERE LOWER(u.diagnosiseName) = LOWER(:diagnosiseName) And u.active = true And u.deleted= false")
	DiagnosisMaster findName(@Param("diagnosiseName") String diagnosiseName);
	
	@Query("SELECT distinct(u) FROM DiagnosisMaster u WHERE LOWER(u.diagnosiseName) like %:diagnosiseName% And u.active = true And u.deleted= false")
	List<DiagnosisMaster> findbynames(@Param("diagnosiseName") String diagnosiseName);
}
