package org.healthchain.base;

import java.util.List;

import org.healthchain.entity.FCLProviderMap;
import org.healthchain.entity.FCLocationMap;
import org.healthchain.entity.FacilityCenterMaster;
import org.healthchain.entity.enums.ProviderTypeStatus;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface FCLProviderMapRepository extends GenericRepository<FCLProviderMap, Long> {

	@Query("SELECT distinct(u) FROM FCLProviderMap u WHERE u.locationMapID.fcLocationMapID = :fcLocationMapID And u.active = true And u.deleted= false")
	List<FCLProviderMap> getAllProvider(@Param("fcLocationMapID") Long fcLocationMapID);
	
	@Query("SELECT distinct(u) FROM FCLProviderMap u WHERE u.locationMapID.fcLocationMapID = :fcLocationMapID And u.providerID.providerID = :providerID And u.active = true And u.deleted= false")
	FCLProviderMap getdata(@Param("providerID") Long providerID,@Param("fcLocationMapID") Long fcLocationMapID);

	@Query("SELECT distinct(u.locationMapID.facilityCenterMaster) FROM FCLProviderMap u WHERE u.providerID.providerID = :providerID And u.active = true And u.deleted= false")
	List<FacilityCenterMaster> getAllFacilityByDoctor(@Param("providerID") Long providerID);
	
	@Query("SELECT distinct(u.locationMapID) FROM FCLProviderMap u WHERE u.providerID.providerID = :providerID And u.locationMapID.facilityCenterMaster.facilityCenterID = :facilityCenterID And u.active = true And u.deleted= false")
	List<FCLocationMap> getAllLocationByDoctorAndFacility(@Param("providerID") Long providerID,@Param("facilityCenterID") Long facilityCenterID);

	@Query("SELECT distinct(u) FROM FCLProviderMap u WHERE u.providerID.providerID = :providerID And u.providerID.providerTypeStatus = :providerTypeStatus And u.active = true And u.deleted= false")
	List<FCLProviderMap> getFclDataforDoctor(@Param("providerID") Long providerID,@Param("providerTypeStatus") ProviderTypeStatus providerTypeStatus);
}
