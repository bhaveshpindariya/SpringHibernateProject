package org.healthchain.base;

import org.healthchain.entity.PersonMaster;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface PersonRepository extends GenericRepository<PersonMaster, Long> {

	PersonMaster findByPerEmailPrimary(String email);
	
	@Modifying
	@Query(value = "DELETE FROM person_email_list p WHERE p.personID = ?1", nativeQuery = true)
	void deletePersonEmailList(Long personid);
	
	@Modifying
	@Query(value = "DELETE FROM person_mobile_list p WHERE p.personID = ?1", nativeQuery = true)
	void deletePersonMobileList(Long personid);
	

}
