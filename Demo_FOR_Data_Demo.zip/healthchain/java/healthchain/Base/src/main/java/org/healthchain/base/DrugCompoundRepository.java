package org.healthchain.base;

import java.util.List;

import org.healthchain.entity.DrugCompoundMaster;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface DrugCompoundRepository extends GenericRepository<DrugCompoundMaster, Long> {

	@Query("SELECT distinct(u) FROM DrugCompoundMaster u WHERE LOWER(u.drugCompoundName) = LOWER(:drugCompoundName) And u.active = true And u.deleted= false")
	DrugCompoundMaster findData(@Param("drugCompoundName") String drugCompoundName);
	
	@Query("SELECT distinct(u) FROM DrugCompoundMaster u WHERE LOWER(u.drugCompoundName) like %:drugCompoundName% And u.active = true And u.deleted= false")
	List<DrugCompoundMaster> findbynames(@Param("drugCompoundName") String drugCompoundName);
}
