package org.healthchain.base;

import org.healthchain.entity.UserMaster;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface UserRepository extends GenericRepository<UserMaster, Long> {

	
	@Query("SELECT distinct(u) FROM UserMaster u left join u.userRoleEntity ur WHERE LOWER(u.userName) = LOWER(:userName) And u.active= true And u.deleted = false")
	UserMaster searchByuserName(@Param("userName") String userName);
	
	@Query("SELECT distinct(u) FROM UserMaster u WHERE LOWER(u.userName) = LOWER(:userName) And LOWER(u.userEmail) = LOWER(:userEmail) And u.active = true And u.deleted= false")
	UserMaster serarchByUser(@Param("userName") String userName,@Param("userEmail") String userEmail);
	
	UserMaster findByUserEmail(String userEmail);
	
	UserMaster findByUserName(String userName);

}
