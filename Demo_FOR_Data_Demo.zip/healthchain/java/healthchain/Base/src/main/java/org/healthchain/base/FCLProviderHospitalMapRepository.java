package org.healthchain.base;

import java.util.List;

import org.healthchain.entity.FCLProviderHospitalMap;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface FCLProviderHospitalMapRepository extends GenericRepository<FCLProviderHospitalMap, Long> {

	@Query("SELECT distinct(u) FROM FCLProviderHospitalMap u WHERE u.fclProviderMapID.fclProviderMapID = :fclProviderMapID And u.active = true And u.deleted= false")
	List<FCLProviderHospitalMap> getAllData(@Param("fclProviderMapID") Long fclProviderMapID);
	
	@Query("SELECT distinct(u) FROM FCLProviderHospitalMap u WHERE u.fclProviderMapID.fclProviderMapID = :fclProviderMapID")
	List<FCLProviderHospitalMap> getAllDatas(@Param("fclProviderMapID") Long fclProviderMapID);
	
	@Query("SELECT distinct(u) FROM FCLProviderHospitalMap u WHERE u.fclProviderMapID.providerID.providerID = :providerID And "+
			"u.hospital.fclProviderMapID = :hospitalId")
	FCLProviderHospitalMap getData(@Param("providerID") Long providerID,@Param("hospitalId") Long hospitalId);
	
}
