package org.healthchain.base;

import java.util.List;

import org.healthchain.entity.FCLProviderDoctorMap;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface FCLProviderDoctorMapRepository extends GenericRepository<FCLProviderDoctorMap, Long> {

	@Query("SELECT distinct(u) FROM FCLProviderDoctorMap u WHERE u.fclProviderMapID.fclProviderMapID = :fclProviderMapID And u.active = true And u.deleted= false")
	List<FCLProviderDoctorMap> getAllData(@Param("fclProviderMapID") Long fclProviderMapID);
	
	@Query("SELECT distinct(u) FROM FCLProviderDoctorMap u WHERE u.fclProviderMapID.fclProviderMapID = :fclProviderMapID")
	List<FCLProviderDoctorMap> getAllDatas(@Param("fclProviderMapID") Long fclProviderMapID);
	
	@Query("SELECT distinct(u) FROM FCLProviderDoctorMap u WHERE u.fclProviderMapID.providerID.providerID = :providerID And "+
			"u.doctor.fclProviderMapID = :doctorId")
	FCLProviderDoctorMap getData(@Param("providerID") Long providerID,@Param("doctorId") Long doctorId);
	
}
