package org.healthchain.base;

import java.util.List;

import org.healthchain.entity.FCLProviderLabDrugCompoundMap;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface FCLProviderLabDrugCompoundMapRepository extends GenericRepository<FCLProviderLabDrugCompoundMap, Long> {

	@Query("SELECT distinct(u) FROM FCLProviderLabDrugCompoundMap u WHERE u.fclProviderMapID.providerID.providerID = :providerID And u.active = true And u.deleted= false")
	List<FCLProviderLabDrugCompoundMap> getAllData(@Param("providerID") Long providerID);
	
	@Query("SELECT distinct(u) FROM FCLProviderLabDrugCompoundMap u WHERE u.fclProviderMapID.fclProviderMapID = :fclProviderMapID")
	List<FCLProviderLabDrugCompoundMap> getAllDatas(@Param("fclProviderMapID") Long fclProviderMapID);
	
	@Query("SELECT distinct(u) FROM FCLProviderLabDrugCompoundMap u WHERE u.fclProviderMapID.fclProviderMapID = :fclProviderMapID And u.active = true And u.deleted= false")
	List<FCLProviderLabDrugCompoundMap> getAllFacility(@Param("fclProviderMapID") Long fclProviderMapID);
	
	@Query("SELECT distinct(u) FROM FCLProviderLabDrugCompoundMap u WHERE u.fclProviderMapID.providerID.providerID = :providerID And "+
			"u.drugCompoundID.drugCompoundID = :drugCompoundID")
	FCLProviderLabDrugCompoundMap getData(@Param("providerID") Long providerID,@Param("drugCompoundID") Long drugCompoundID);
	
}
