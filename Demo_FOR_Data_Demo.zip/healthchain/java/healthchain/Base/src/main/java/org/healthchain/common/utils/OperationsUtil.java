package org.healthchain.common.utils;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.healthchain.common.constants.CommonConstants;
import org.healthchain.entity.PersonMaster;
import org.springframework.http.MediaType;
import org.springframework.web.multipart.MultipartFile;



public class OperationsUtil {
	
	
	private static final Log logger = LogFactory.getLog(OperationsUtil.class);

	public static Boolean checkNull(Object obj) {
		if (obj != null) {
			return false;
		} else {
			return true;
		}
	}

	public static String getURL(HttpServletRequest request, String email) {
		return request.getScheme() + "://" + request.getServerName() + ":" + request.getServerPort()
				+ request.getContextPath() + CommonConstants.ACTIVATION_URL + email;
	}

	public static String convertLink(String link) {
		return "<B>Account Activation Link</B><br><br><br><a href=\"" + link
				+ "\" style=\"text-decoration:none; background-color: #93C47D;border:none;border-radius: 5px;color: #000;"
				+ "font: bold 12px/1 'Lucida Grande','Lucida Sans Unicode','Lucida Sans',Geneva,Verdana,sans-serif;"
				+ "padding: 7px 50px 8px;text-align: center;text-shadow: 0px -1px 0px #4C9021;"
				+ "width: 149px;\">Accept</a>";

	}
	
	public static String forgotPassword(String link) {
		return "<B>New Password :-------"+link+"</B>";

	}
	
   public static MediaType getMediaTypeForFileName(ServletContext servletContext, String fileName) {
        String mineType = servletContext.getMimeType(fileName);
        try {
            MediaType mediaType = MediaType.parseMediaType(mineType);
            return mediaType;
        } catch (Exception e) {
            return MediaType.APPLICATION_OCTET_STREAM;
        }
    }
	  
	public static String uploadFile(MultipartFile files,PersonMaster person,String location) {
		String storagePath = null;
		String fileName=null;
		try {
			storagePath = CommonConstants.getPropertiesValue("FilePath") + File.separator + location +File.separator+person.getPersonID();
			byte[] bytes = files.getBytes();
			
			File templateFolder = new File(storagePath);
			if (!templateFolder.exists()) {
				templateFolder.mkdirs();
			}
			fileName = Math.random()+files.getOriginalFilename();
			storagePath = storagePath + File.separator + fileName;
			Path path = Paths.get(storagePath);
            Files.write(path, bytes);
		} catch (Exception e) {
			logger.error("Error:-----",e);
			return storagePath;
		}
		return storagePath;
	}
}
