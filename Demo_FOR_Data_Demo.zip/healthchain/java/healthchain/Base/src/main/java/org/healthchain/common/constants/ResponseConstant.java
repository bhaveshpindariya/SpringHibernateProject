package org.healthchain.common.constants;

public class ResponseConstant {
	
	public static final String SUCCESS="Success";
	public static final String ERROR="Error";
	public static final String WARNING="warning";
	public static final String UNDEFINED="Undefined";
	
	

}
