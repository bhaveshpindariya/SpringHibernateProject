package org.healthchain.common.utils;

import org.healthchain.common.constants.CommonConstants;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import net.sf.json.JSONSerializer;

public class HyperledgerApiUtil {
	
	public static Object getForPatient(String endpoint, String type) {
		Client client1 = Client.create();
		String finalURL = CommonConstants.getPropertiesValue(CommonConstants.HYPERLEDGER_HOST) + CommonConstants.getPropertiesValue(CommonConstants.HYPERLEDGER_PORT) + endpoint;
		WebResource webResource1 = client1.resource(finalURL);
		ClientResponse response1 = webResource1.type("application/json").get(ClientResponse.class);
		if (response1.getStatus() == 200) {
			return (JSONObject) JSONSerializer.toJSON(response1.getEntity(String.class));
		}else {
			return null;
		}
	}
	
	public static Object get(String endpoint, String type) {
		Client client1 = Client.create();
		String finalURL = CommonConstants.getPropertiesValue(CommonConstants.HYPERLEDGER_HOST) + CommonConstants.getPropertiesValue(CommonConstants.HYPERLEDGER_PORT) + endpoint;
		WebResource webResource1 = client1.resource(finalURL);
		ClientResponse response1 = webResource1.type("application/json").get(ClientResponse.class);
		if (response1.getStatus() == 200) {
			return (JSONArray) JSONSerializer.toJSON(response1.getEntity(String.class));
		}else {
			return null;
		}
	}

	public static String post(String endpoint, String type, Object Obj) {
		if (Obj.toString().equals("{}")) {
			return null;
		}else {
			Client client1 = Client.create();
			String finalURL = CommonConstants.getPropertiesValue(CommonConstants.HYPERLEDGER_HOST) + CommonConstants.getPropertiesValue(CommonConstants.HYPERLEDGER_PORT) + endpoint;
			WebResource webResource1 = client1.resource(finalURL);
			ClientResponse response1 = webResource1.type("application/json").post(ClientResponse.class,Obj.toString());
			return response1.getStatus()+""; 
		}
	}

	public static String put(String endpoint, String type, Object Obj) {
		if (Obj.toString().equals("{}")) {
			return null;
		}else {
			Client client1 = Client.create();
			String finalURL = CommonConstants.getPropertiesValue(CommonConstants.HYPERLEDGER_HOST) + CommonConstants.getPropertiesValue(CommonConstants.HYPERLEDGER_PORT) + endpoint;
			WebResource webResource1 = client1.resource(finalURL);
			ClientResponse response1 = webResource1.type("application/json").put(ClientResponse.class,Obj.toString());
			return response1.getStatus()+""; 
		}
	}

	public static Object delete() {

		return null;
	}


}
