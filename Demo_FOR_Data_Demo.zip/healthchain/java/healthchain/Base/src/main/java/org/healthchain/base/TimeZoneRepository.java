package org.healthchain.base;

import org.healthchain.entity.TimeZoneMaster;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface TimeZoneRepository extends GenericRepository<TimeZoneMaster, Long> {

	@Query("SELECT distinct(u) FROM TimeZoneMaster u WHERE LOWER(u.timezoneAbbreviation) = LOWER(:timezoneAbbreviation) And u.active = true And u.deleted= false")
	TimeZoneMaster findByAbbreviation(@Param("timezoneAbbreviation") String timezoneAbbreviation);

}
