package org.healthchain.base;

import org.healthchain.entity.RxHeader;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface RxHeaderRepository extends GenericRepository<RxHeader, Long> {

	@Query("SELECT distinct(u) FROM RxHeader u WHERE u.patVisitNote.patVisitNoteID = :patVisitNoteID And u.active = true And u.deleted= false")
	RxHeader findData(@Param("patVisitNoteID") Long patVisitNoteID);
}
