package org.healthchain.base;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;

@EntityScan("org.healthchain.entity")
@SpringBootApplication
public class BaseApplication {

}
