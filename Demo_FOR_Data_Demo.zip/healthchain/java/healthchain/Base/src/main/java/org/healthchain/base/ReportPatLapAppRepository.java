package org.healthchain.base;

import java.util.List;

import org.healthchain.entity.ReportPatLapApp;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface ReportPatLapAppRepository extends GenericRepository<ReportPatLapApp, Long> {

	@Query("SELECT distinct(u) FROM ReportPatLapApp u WHERE u.patLabAppointments.patLabAppointmentID = :patLabAppointmentID "
			+ "And u.active = true And u.deleted= false ORDER BY createdOn DESC")
	ReportPatLapApp findReport(@Param("patLabAppointmentID") Long patLabAppointmentID);
	
	@Query("SELECT distinct(u) FROM ReportPatLapApp u WHERE u.createdBy.userID = :userID "
			+ "And u.active = true And u.deleted= false ORDER BY createdOn DESC")
	List<ReportPatLapApp> findReportAll(@Param("userID") Long userID,Pageable pageable);
	
	@Query("SELECT distinct(u) FROM ReportPatLapApp u WHERE u.patientMaster.patientID = :patientID "
			+ "And u.active = true And u.deleted= false ORDER BY createdOn DESC")
	List<ReportPatLapApp> findReportAllpatient(@Param("patientID") Long patientID,Pageable pageable);
	
	@Query("SELECT distinct(u) FROM ReportPatLapApp u WHERE u.createdBy.userID = :userID "
			+ "And u.active = true And u.deleted= false ORDER BY createdOn DESC")
	List<ReportPatLapApp> findReportAlls(@Param("userID") Long userID);
	
	@Query("SELECT distinct(u) FROM ReportPatLapApp u WHERE u.patientMaster.patientID = :patientID "
			+ "And u.active = true And u.deleted= false ORDER BY createdOn DESC")
	List<ReportPatLapApp> findReportAllpatients(@Param("patientID") Long patientID);
}
