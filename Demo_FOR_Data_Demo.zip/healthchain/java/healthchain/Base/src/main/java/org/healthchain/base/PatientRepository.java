package org.healthchain.base;

import java.util.List;

import org.healthchain.entity.PatientMaster;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface PatientRepository extends GenericRepository<PatientMaster, Long> {

	@Query("SELECT distinct(u) FROM PatientMaster u WHERE u.personID.perEmailPrimary = :perEmailPrimary "
			+"And u.active = true And u.deleted= false")
	PatientMaster findByPatient(@Param("perEmailPrimary") String perEmailPrimary);	
	
	@Query("SELECT distinct(u) FROM PatientMaster u WHERE LOWER(u.personID.perFname) like %:name% "
			+"OR LOWER(u.personID.perLName) like %:name% And u.active = true And u.deleted= false")
	List<PatientMaster> findbynames(@Param("name") String name);

}
