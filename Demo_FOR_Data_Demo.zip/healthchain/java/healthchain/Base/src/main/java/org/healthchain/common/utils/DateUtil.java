package org.healthchain.common.utils;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;
import org.joda.time.Days;
import org.joda.time.Hours;
import org.joda.time.LocalDateTime;
import org.joda.time.Minutes;
import org.joda.time.Months;
import org.joda.time.Seconds;
import org.joda.time.Years;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;


/**
 * 
 * @author Prakash Vidja
 *
 */
public class DateUtil {

	private static final Log _log = LogFactory.getLog(DateUtil.class);
	

	public static final String defaultFormat = "dd/MM/yyyy";
	public static final DateFormat defaultFormatddMMyyyy = new SimpleDateFormat("dd/MM/yyyy");
	public static final DateFormat dateTimeFormatterddMMYY = new SimpleDateFormat("dd/MM/yy");

	public static final DateTimeFormatter dateTimeFormatter = DateTimeFormat.forPattern("dd MMM,yyyy HH:mm:ss");
	public static final DateTimeFormatter dateTimeFormatterDDMMMYY = DateTimeFormat.forPattern("dd MMM yy");
	public static final DateTimeFormatter timeFormatterHHMMA = DateTimeFormat.forPattern("hh:mm a");
	public static final DateTimeFormatter dateTimeFormatterDDMMMYYYY = DateTimeFormat.forPattern("dd MMM yyyy");

	public static final DateFormat dateFormatter = new SimpleDateFormat("dd MMM,yyyy HH:mm:ss");
	public static final DateFormat dateFormatterDDMMMYY = new SimpleDateFormat("dd MMM yy");
	public static final DateFormat dateFormatterMMDDYYYY = new SimpleDateFormat("MM/dd/yyyy");
	public static final DateFormat dateTimeFormatterHHMMA = new SimpleDateFormat("hh:mm a");
	public static final DateFormat dateFormatterDDMMMYYYY = new SimpleDateFormat("dd MMM yyyy");
	public static final DateFormat dateFormatterMMMYYYY = new SimpleDateFormat("MMM yyyy");
	public static final DateFormat dateFormatterDDMMMYYwithQuotes = new SimpleDateFormat("dd MMM ''yy");
	public static final DateFormat dateFormatterDDMMMYYwithAMPM = new SimpleDateFormat("dd MMM ''yy  hh:mm a");

	private DateUtil() {
		super();
	}

	/**
	 * getCurrentDateUTC
	 * 
	 * @return utc date
	 */
	@SuppressWarnings("unused")
	public static Date getCurrentDateUTC() {
		Date d=new Date();
		Calendar calendar = Calendar.getInstance();
		calendar.add(Calendar.MILLISECOND, -calendar.getTimeZone().getOffset(calendar.getTimeInMillis()));
		return calendar.getTime();
	}
	
	public static Date getTimerCurrentDateUTC(Date date) {
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		calendar.add(Calendar.MILLISECOND, -calendar.getTimeZone().getOffset(calendar.getTimeInMillis()));
		return calendar.getTime();
	}
	
	public static Date getDateUTC(Date date) {
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		calendar.add(Calendar.MILLISECOND, -calendar.getTimeZone().getOffset(calendar.getTimeInMillis()));
		return calendar.getTime();
	}

	/*public static Date getDateInUserTimeZone(User user, Date date) {
		Date newDate = convertDateInUserTimeZone(date, user);
		Date dateObject = null;
		try {
			dateObject = dateFormatter.parse(dateFormatter.format(newDate));
		} catch (ParseException e) {
			_log.error(e);
		}
		return dateObject;
	}

	public static String getDateInUserTimeZoneFormatted(User user, Date date) {
		Date newDate = convertDateInUserTimeZone(date, user);
		return dateFormatter.format(newDate);
	}

	public static String getDateInUserTimeZoneFormatted(User user, Date date, DateFormat dateFormatter) {
		Date newDate = convertDateInUserTimeZone(date, user);
		return dateFormatter.format(newDate);
	}

	public static Date convertDateInUserTimeZone(Date date, User user) {
		String userTimeZone = WebConstants.TIMEZONE_DEFAULT;
		if (null != user && StringUtils.isNotBlank(user.getTimezone())) {
			userTimeZone = user.getTimezone();
		}
		TimeZone timeZone = TimeZone.getTimeZone(userTimeZone);
		int offSet = timeZone.getOffset(0);

		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		calendar.add(Calendar.MILLISECOND, offSet);
		return calendar.getTime();
	}*/

	/**
	 * getLocalDateFromUTC
	 * 
	 * @param date
	 * @return
	 */
	public static Date getLocalDateFromUTC(Date date) {
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		calendar.add(Calendar.MILLISECOND, calendar.getTimeZone().getOffset(calendar.getTimeInMillis()));
		return calendar.getTime();
	}

	/**
	 * 
	 * @param date
	 * @return
	 */
	public static DateTime getDateTimeUTC(Date date) {
		return new DateTime(date.getTime(), DateTimeZone.UTC);
	}

	/**
	 * 
	 * @param dateTime
	 * @param pattern
	 * @return
	 */
	public static String getDateTimeFormetted(DateTime dateTime, String pattern) {
		return getDateTimeFormatter(pattern).print(dateTime);
	}

	/**
	 * 
	 * @param date
	 * @param timeZoneId
	 * @return
	 */
	public static DateTime convertDateToLocalDate(Date date, String timeZoneId) {
		return new DateTime(date.getTime(), DateTimeZone.forID(timeZoneId));
	}

	/**
	 * 
	 * @param date
	 * @return
	 */
	public static DateTime getLocalDateTime(Date date) {
		return new DateTime(date.getTime(), DateTimeZone.UTC);
	}

	/**
	 * 
	 * @param date
	 * @return
	 */
	public static Date getLocalDate(Date date) {
		return new DateTime(date.getTime(), DateTimeZone.UTC).toDate();
	}

	/**
	 * 
	 * @param date
	 * @param formatter
	 * @return
	 */
	public static String getLocalDateFormatted(Date date, DateTimeFormatter formatter) {
		DateTime dateTime = new LocalDateTime(getDateTimeFromDate(date)).toDateTime(DateTimeZone.UTC);
		return formatter.print(dateTime);
	}

	public static String getLocalDateFormattedComment(Date date) {
		DateTime dateTime = new LocalDateTime(getDateTimeFromDate(date)).toDateTime(DateTimeZone.UTC);
		String dateFormatted = "";
		dateFormatted = dateTimeFormatterDDMMMYY.print(dateTime);
		dateFormatted += " | " + timeFormatterHHMMA.print(dateTime);
		return dateFormatted;
	}

	public static String getLocalDateFormattedFileinfo(Date date) {
		DateTime dateTime = new LocalDateTime(getDateTimeFromDate(date)).toDateTime(DateTimeZone.UTC);
		String dateFormatted = "";
		dateFormatted = dateTimeFormatterDDMMMYYYY.print(dateTime);

		return dateFormatted;
	}

	/**
	 * 
	 * @param date
	 * @return
	 */
	public static DateTime getDateTimeFromDate(Date date) {
		return new DateTime(date.getTime());
	}

	/**
	 * 
	 * @param format
	 * @return
	 */
	public static DateTimeFormatter getDateTimeFormatter(String format) {
		return DateTimeFormat.forPattern(format);
	}

	public static DateFormat getDateFormatter(String format) {
		return new SimpleDateFormat(format);
	}

	public static Date getDateFromString(String dateStr) {
		return getDateFromString(dateStr, dateFormatter);
	}

	public static Date getDateFromString(String dateStr, DateFormat formatter) {
		_log.info("datestr : "+dateStr);
		Date date = null;
		try {
			date = formatter.parse(dateStr);
			_log.info("Date : "+date);
		} catch (ParseException e) {
			_log.error(e);
		}
		return date;
	}

	@SuppressWarnings("deprecation")
	public static Date getDateFromStringStaticTimeForDueDate(String dateStr, DateFormat formatter) {
		Date date = null;
		try {
			date = formatter.parse(dateStr);
			date.setHours(00);
			date.setMinutes(00);
			date.setSeconds(00);
		} catch (ParseException e) {
			_log.error(e);
		}
		return date;
	}

	@SuppressWarnings("deprecation")
	public static Date getDateFromStringStaticTime(String dateStr, DateFormat formatter) {
		Date date = null;
		try {
			date = formatter.parse(dateStr);
			date.setHours(23);
			date.setMinutes(59);
			date.setSeconds(59);
		} catch (ParseException e) {
			_log.error(e);
		}
		return date;
	}

	@SuppressWarnings("deprecation")
	public static Date getDateFromStringStaticTimeZero(String dateStr, DateFormat formatter) {
		Date date = null;
		try {
			date = formatter.parse(dateStr);
			date.setHours(00);
			date.setMinutes(00);
			date.setSeconds(00);
		} catch (ParseException e) {
			_log.error(e);
		}
		return date;
	}

	
	/**
	 * 
	 * @param dt1
	 * @param dt2
	 * @return
	 */
	public static String getTimeDiff(DateTime dt1, DateTime dt2) {
		String timeDiff;
		long diff = Years.yearsBetween(dt1, dt2).getYears();
		if (diff >= 1) {
			timeDiff = diff + "y ago";
		} else {
			diff = Months.monthsBetween(dt1, dt2).getMonths();
			if (diff >= 1) {
				timeDiff = diff + "mo ago";
			} else {
				diff = Days.daysBetween(dt1, dt2).getDays();
				if (diff >= 1) {
					timeDiff = diff + "d ago";
				} else {
					diff = Hours.hoursBetween(dt1, dt2).getHours();
					if (diff >= 1) {
						timeDiff = diff + "h ago";
					} else {
						diff = Minutes.minutesBetween(dt1, dt2).getMinutes();
						if (diff >= 1) {
							timeDiff = diff + "m ago";
						} else {
							timeDiff = "Just Now";
						}
					}
				}
			}
		}
		return timeDiff;
	}

	public static Long getCommentEditableMinutes(long totalSeconds) {
		long minutes = totalSeconds / 60;
		return minutes;
	}

	public static Long getCommentEditableSeconds(long minutes, long totalSeconds) {
		long minuteSeconds = minutes * 60;
		long secondDiff = totalSeconds - minuteSeconds;
		return secondDiff;
	}

	public static Long getCommentEditableTimeInSecond(Date fromDate, Date toDate) {
		long difference = 0;
		if (checkCommentEditable(fromDate, toDate)) {
			long timeDifference = getSecondDifference(fromDate, toDate);
			long totalTime = 300;
			difference = totalTime - timeDifference;
		}
		return difference;
	}

	public static boolean checkCommentEditable(Date fromDate, Date toDate) {
		double timeDifference = getSecondDifference(fromDate, toDate);
		if (timeDifference >= 300) {
			return false;
		}
		return true;
	}

	public static Long getSecondDifference(Date fromDate, Date toDate) {
		return getSecondDifference(getDateTimeFromDate(fromDate), getDateTimeFromDate(toDate));
	}

	public static Long getSecondDifference(DateTime fromDateTime, DateTime toDateTime) {
		long seconds = Seconds.secondsBetween(fromDateTime, toDateTime).getSeconds();
		return seconds;
	}

	public static Date getUTCDefaultDateFromString(String date) {
		Date dateString = DateUtil.getDateFromString(date, DateUtil.getDateFormatter("MM/dd/yyyy"));
		return DateUtil.getDateUTC(dateString);
	}

	@SuppressWarnings("deprecation")
	public static Date getDateFromStringStaticTimeForActivityEndDate(String dateStr, DateFormat formatter) {
		Date date = null;
		try {
			date = formatter.parse(dateStr);
			LocalDateTime now = LocalDateTime.now();
			date.setHours(now.getHourOfDay());
			date.setMinutes(now.getMinuteOfHour());
			date.setSeconds(now.getSecondOfMinute());
		} catch (ParseException e) {
			_log.error(e);
		}
		return date;
	}
	
	public static Date getZeroTimeDate(Date fecha) {
	    Date res = fecha;
	    Calendar calendar = Calendar.getInstance();

	    calendar.setTime(fecha );
	    calendar.set(Calendar.HOUR_OF_DAY, 0);
	    calendar.set(Calendar.MINUTE, 0);
	    calendar.set(Calendar.SECOND, 0);
	    calendar.set(Calendar.MILLISECOND, 0);
	    res = calendar.getTime();
	    return res;
	}

	public static String getTimeDiffActivity(DateTime dt1, DateTime dt2) {
		String timeDiff = "";
		long diff = Years.yearsBetween(dt1, dt2).getYears();
		if (diff >= 1) {
			timeDiff = diff + ">1yr ago";
		} else {
			diff = Months.monthsBetween(dt1, dt2).getMonths();
			if (diff >= 1) {
				long daydiff = Days.daysBetween(dt1, dt2).getDays();
				long days = daydiff - (diff * 30);
				if (days > 0) {
					timeDiff = diff + "m" + days + "d";
				} else {
					timeDiff = diff + "m";
				}
			} else {
				diff = Days.daysBetween(dt1, dt2).getDays();
				if (diff >= 1) {
					timeDiff = diff + "d";
				} else {
					diff = Hours.hoursBetween(dt1, dt2).getHours();
					if (diff >= 1) {
						timeDiff = diff + "h";
					} else {
						diff = Minutes.minutesBetween(dt1, dt2).getMinutes();
						if (diff >= 1) {
							timeDiff = diff + "min";
						} else {
							timeDiff = "Just Now";
						}
					}
				}
			}
		}
		return timeDiff;
	}

}