package org.healthchain.base;

import java.util.List;

import org.healthchain.entity.PatVisitNote;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface PatVisitRepository extends GenericRepository<PatVisitNote, Long> {

	@Query("SELECT distinct(u) FROM PatVisitNote u WHERE u.appointmentID.patAppointmentID = :patAppointmentID "
			+"And u.active = true And u.deleted= false ORDER BY createdOn DESC")
	PatVisitNote findData(@Param("patAppointmentID") Long patAppointmentID);
	
	@Query("SELECT distinct(u) FROM PatVisitNote u WHERE u.clfPatRegistrationMap.patientID.patientID = :patientID "
			+"And u.active = true And u.deleted= false ORDER BY createdOn DESC")
	List<PatVisitNote> findPatientData(@Param("patientID") Long patientID,Pageable pageable);
	
	@Query("SELECT distinct(u) FROM PatVisitNote u WHERE u.fclProviderMapID.providerID.providerID = :providerID "
			+"And u.active = true And u.deleted= false ORDER BY createdOn DESC")
	List<PatVisitNote> findProviderData(@Param("providerID") Long providerID,Pageable pageable);
	
	@Query("SELECT distinct(u) FROM PatVisitNote u WHERE u.clfPatRegistrationMap.patientID.patientID = :patientID "
			+"And u.active = true And u.deleted= false ORDER BY createdOn DESC")
	List<PatVisitNote> findPatientDatas(@Param("patientID") Long patientID);
	
	@Query("SELECT distinct(u) FROM PatVisitNote u WHERE u.fclProviderMapID.providerID.providerID = :providerID "
			+"And u.active = true And u.deleted= false ORDER BY createdOn DESC")
	List<PatVisitNote> findProviderDatas(@Param("providerID") Long providerID);

}
