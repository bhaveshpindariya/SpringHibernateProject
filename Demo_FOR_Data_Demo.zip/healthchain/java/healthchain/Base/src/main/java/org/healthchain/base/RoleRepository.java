package org.healthchain.base;

import org.healthchain.entity.RoleMaster;
import org.springframework.stereotype.Repository;

@Repository
public interface RoleRepository extends GenericRepository<RoleMaster, Long> {

	RoleMaster findByroleName(String roleName);
	
}
