package org.healthchain.base;

import java.util.List;

import org.healthchain.entity.LabReportsLevel1;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface LabReportsLevel1Repository extends GenericRepository<LabReportsLevel1, Long> {

	@Query("SELECT distinct(u) FROM LabReportsLevel1 u WHERE LOWER(u.lrl1Category) = LOWER(:lrl1Category) And LOWER(u.lrl1Name) = LOWER(:lrl1Name) "
			+"And u.active = true And u.deleted= false")
	LabReportsLevel1 findData(@Param("lrl1Category") String lrl1Category,@Param("lrl1Name") String lrl1Name);
	
	@Query("SELECT distinct(u) FROM LabReportsLevel1 u WHERE LOWER(u.lrl1Name) like %:lrl1Name% And u.active = true And u.deleted= false")
	List<LabReportsLevel1> findbynames(@Param("lrl1Name") String lrl1Name);
	
	@Query("SELECT distinct(u) FROM LabReportsLevel1 u WHERE LOWER(u.lrl1Name) = LOWER(:lrl1Name) And u.active = true And u.deleted= false")
	LabReportsLevel1 findNames(@Param("lrl1Name") String lrl1Name);
}
