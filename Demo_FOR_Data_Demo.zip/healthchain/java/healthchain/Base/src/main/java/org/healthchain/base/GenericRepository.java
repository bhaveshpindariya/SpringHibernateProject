package org.healthchain.base;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.NoRepositoryBean;

@NoRepositoryBean
public interface GenericRepository<E, K> extends JpaRepository<E, K> {

	@Query("select e from #{#entityName} e where e.active = true And e.deleted= false")
	List<E> getAllActiveRecord();
	
	@Query("select e from #{#entityName} e where e.active = false And e.deleted= true")
	List<E> getAllDeletedRecord();
	
	@Query("select e from #{#entityName} e where e.active = false And e.deleted= false")
	List<E> getAllInActiveRecord();
	
	@Query("select e from #{#entityName} e where e.active = true And e.deleted= true")
	List<E> getAllDeletedAndActiveRecord();
	
	
}
