package org.healthchain.base;

import java.util.List;

import org.healthchain.entity.PatLabAppointments;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface PatLabAppointmentRepository extends GenericRepository<PatLabAppointments, Long> {

	@Query("SELECT distinct(u) FROM PatLabAppointments u WHERE u.fclpID.patientID.patientID = :patientID "+
			"And u.active = true And u.deleted= false ORDER BY patLabAppDate DESC")
	List<PatLabAppointments> findPatientData(@Param("patientID")Long patientID,Pageable pageable);
	
	@Query("SELECT distinct(u) FROM PatLabAppointments u WHERE u.fclProviderMapID.providerID.providerID = :providerID "+
			"And u.active = true And u.deleted= false ORDER BY patLabAppDate DESC")
	List<PatLabAppointments> findProviderData(@Param("providerID")Long providerID,Pageable pageable);
	
	@Query("SELECT distinct(u) FROM PatLabAppointments u WHERE u.fclpID.patientID.patientID = :patientID "+
			"And u.active = true And u.deleted= false ORDER BY patLabAppDate DESC")
	List<PatLabAppointments> findPatientDatas(@Param("patientID")Long patientID);
	
	@Query("SELECT distinct(u) FROM PatLabAppointments u WHERE u.fclpID.patientID.patientID = :patientID "+
			"And u.patLabAppDate >= :dates And u.active = true And u.deleted= false ORDER BY patLabAppDate DESC")
	List<PatLabAppointments> findPatient(@Param("patientID")Long patientID,@Param("dates") Long dates);
	
	@Query("SELECT distinct(u) FROM PatLabAppointments u WHERE u.fclProviderMapID.providerID.providerID = :providerID "+
			"And u.active = true And u.deleted= false ORDER BY patLabAppDate DESC")
	List<PatLabAppointments> findProviderDatas(@Param("providerID")Long providerID);
}
