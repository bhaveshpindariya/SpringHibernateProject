package org.healthchain.base;

import java.util.List;

import org.healthchain.entity.DrugCompoundMaster;
import org.healthchain.entity.RxDetail;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface RxDetailRepository extends GenericRepository<RxDetail, Long> {

	@Query("SELECT distinct(u) FROM RxDetail u WHERE u.drugCompoundMaster.drugCompoundID = :drugCompoundID And u.rxHeader.rxID = :rxID")
	RxDetail findData(@Param("drugCompoundID")Long drugCompoundID,@Param("rxID")Long rxID);
	
	@Query("SELECT distinct(u.drugCompoundMaster) FROM RxDetail u WHERE u.rxHeader.patVisitNote.patVisitNoteID = :patVisitNoteID And u.active = true And u.deleted= false")
	List<DrugCompoundMaster> findAll(@Param("patVisitNoteID") Long patVisitNoteID);
	
	@Query("SELECT distinct(u) FROM RxDetail u WHERE u.rxHeader.rxID = :rxID")
	List<RxDetail> findAllData(@Param("rxID")Long rxID);
}
