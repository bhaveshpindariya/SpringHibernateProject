package org.healthchain.base;

import java.util.List;

import org.healthchain.entity.PatAppointments;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface PatAppointmentRepository extends GenericRepository<PatAppointments, Long> {

	@Query("SELECT distinct(u) FROM PatAppointments u WHERE u.fclpID.patientID.patientID = :patientID "+
			"And u.active = true And u.deleted= false ORDER BY patAppDate DESC")
	List<PatAppointments> findPatientData(@Param("patientID")Long patientID,Pageable pageable);
	
	@Query("SELECT distinct(u) FROM PatAppointments u WHERE u.fclProviderMapID.providerID.providerID = :providerID "+
			"And u.active = true And u.deleted= false ORDER BY patAppDate DESC")
	List<PatAppointments> findProviderData(@Param("providerID")Long providerID,Pageable pageable);
	
	@Query("SELECT distinct(u) FROM PatAppointments u WHERE u.fclpID.patientID.patientID = :patientID "+
			"And u.active = true And u.deleted= false ORDER BY patAppDate DESC")
	List<PatAppointments> findPatientDatas(@Param("patientID")Long patientID);
	
	@Query("SELECT distinct(u) FROM PatAppointments u WHERE u.fclProviderMapID.providerID.providerID = :providerID "+
			"And u.active = true And u.deleted= false ORDER BY patAppDate DESC")
	List<PatAppointments> findProviderDatas(@Param("providerID")Long providerID);
	
	@Query("SELECT distinct(u) FROM PatAppointments u WHERE u.fclpID.patientID.patientID = :patientID "+
			"And u.patAppDate >= :dates And u.active = true And u.deleted= false ORDER BY patAppDate DESC")
	List<PatAppointments> findPatient(@Param("patientID") Long patientID,@Param("dates") Long dates);
}
