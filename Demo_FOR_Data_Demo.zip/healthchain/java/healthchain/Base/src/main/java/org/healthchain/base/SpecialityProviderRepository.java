package org.healthchain.base;

import org.healthchain.entity.SpecialityProviderMaster;
import org.springframework.stereotype.Repository;

@Repository
public interface SpecialityProviderRepository extends GenericRepository<SpecialityProviderMaster, Long> {

}
