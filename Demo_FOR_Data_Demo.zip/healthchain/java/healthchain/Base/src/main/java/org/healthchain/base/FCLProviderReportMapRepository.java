package org.healthchain.base;

import java.util.List;

import org.healthchain.entity.FCLProviderReportMap;
import org.healthchain.entity.FacilityCenterMaster;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface FCLProviderReportMapRepository extends GenericRepository<FCLProviderReportMap, Long> {

	@Query("SELECT distinct(u) FROM FCLProviderReportMap u WHERE u.fclProviderMapID.fclProviderMapID = :fclProviderMapID And u.active = true And u.deleted= false")
	List<FCLProviderReportMap> getAllData(@Param("fclProviderMapID") Long fclProviderMapID);
	
	@Query("SELECT distinct(u) FROM FCLProviderReportMap u WHERE u.fclProviderMapID.fclProviderMapID = :fclProviderMapID")
	List<FCLProviderReportMap> getAllDatas(@Param("fclProviderMapID") Long fclProviderMapID);
	
	@Query("SELECT distinct(u) FROM FCLProviderReportMap u WHERE u.fclProviderMapID.fclProviderMapID = :fclProviderMapID And u.active = true And u.deleted= false")
	List<FCLProviderReportMap> getAllFacility(@Param("fclProviderMapID") Long fclProviderMapID);
	
	@Query("SELECT distinct(u) FROM FCLProviderReportMap u WHERE u.fclProviderMapID.providerID.providerID = :providerID And "+
			"u.labReportLevel1ID.labReportLevel1ID = :labReportLevel1ID")
	FCLProviderReportMap getData(@Param("providerID") Long providerID,@Param("labReportLevel1ID") Long labReportLevel1ID);
	
	@Query("SELECT distinct(u.fclProviderMapID.locationMapID.facilityCenterMaster) FROM FCLProviderReportMap u WHERE u.labReportLevel1ID.labReportLevel1ID in :labReportLevel1ID And u.active = true And u.deleted= false")
	List<FacilityCenterMaster> getAllFacilitybyLocation(@Param("labReportLevel1ID") List<Long> labReportLevel1ID);
	
}
