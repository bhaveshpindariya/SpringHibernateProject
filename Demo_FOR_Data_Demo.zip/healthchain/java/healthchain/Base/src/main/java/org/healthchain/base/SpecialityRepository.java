package org.healthchain.base;

import org.healthchain.entity.SpecialityMaster;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface SpecialityRepository extends GenericRepository<SpecialityMaster, Long> {

	@Query("SELECT distinct(u) FROM SpecialityMaster u WHERE LOWER(u.specialityName) = LOWER(:specialityName) And u.active = true And u.deleted= false")
	SpecialityMaster findByName(@Param("specialityName") String specialityName);

}
