package org.healthchain.base;

import org.healthchain.entity.LabReportsLevel1;
import org.healthchain.entity.ReportLapApp;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface ReportLapAppRepository extends GenericRepository<ReportLapApp, Long> {

	@Query("SELECT distinct(u.labReportLevel1ID) FROM ReportLapApp u WHERE u.reportLapAppId = :reportLapAppId "
			+ "And u.active = true And u.deleted= false")
	LabReportsLevel1 findAlllabreport(@Param("reportLapAppId") Long reportLapAppId);
}
