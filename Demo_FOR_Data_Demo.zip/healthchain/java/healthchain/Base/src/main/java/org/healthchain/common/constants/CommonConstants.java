package org.healthchain.common.constants;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class CommonConstants {
	

	 public static final String TRUE="true";
	 public static final String MESSAGE=" And ";
	 public static final String FALSE="false";
	 
	 public static final String ACTIVATION_URL="/auth/authorizations?emailid_=";
	 public static final String DEVICE_ANDROID_TYPE="ANDROID";
	 public static final String DEVICE_IOS_TYPE="IOS";
	 public static final String DEVICE_WEB="WEB";
	 
	 public static final String DR_SHORT="Dr.";
	 public static final String MR_SHORT="Mr.";
	 public static final String MRS_SHORT="Mrs.";
	 public static final String MISS_SHORT="Miss.";
	 public static final String MS_SHORT="Ms.";
	 public static final String CONTENT_TYPE_APPLICATION_JSON="content-type=application/json";
	 public static final String APPLICATION_JSON="application/json";
	 
	 public static final String ATHAR = "Adhaarcard";
	 public static final String PROFILE ="Profile";
	 public static final String PANCARD ="Pancard";
	 public static final String DRIVING ="Drivinglicense";
	 public static final String REPORT = "Report";
	 
	 
	 public static final String BLOCKCHAIN_HOST="BLOCKCHAIN_BASE_HOST";
	 public static final String BLOCKCHAIN_PORT="BLOCKCHAIN_BASE_PORT";
	 
	 public static final String HYPERLEDGER_HOST="HYPERLEDGER_BASE_HOST";
	 public static final String HYPERLEDGER_PORT="HYPERLEDGER_BASE_PORT";
	 
	 public static final String CODE="200";
	 
	 public static final String HYPERLEDGER="hyperLedger";
	 public static Properties prop;
	 static {
		 prop = new Properties();
			InputStream in=CommonConstants.class.getResourceAsStream("/blockckain.properties");
			try {
				prop.load(in);
			}catch(IOException e) {
				e.printStackTrace();
			}
	 }
	 public static String getPropertiesValue(String propNName) {
		 
		 if(prop !=null) {
			 return prop.getProperty(propNName);
		 }
		 return null;
	 }
}
