package org.healthchain.base;

import java.util.List;

import org.healthchain.entity.DrugManufacturersMaster;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface DrugManufacturersRepository extends GenericRepository<DrugManufacturersMaster, Long> {

	@Query("SELECT distinct(u) FROM DrugManufacturersMaster u WHERE LOWER(u.drugMfgrName) = LOWER(:drugMfgrName) And u.active = true And u.deleted= false")
	DrugManufacturersMaster findData(@Param("drugMfgrName") String drugMfgrName);
	
	@Query("SELECT distinct(u) FROM DrugManufacturersMaster u WHERE LOWER(u.drugMfgrName) like %:drugMfgrName% "
			+"And u.active = true And u.deleted= false")
	List<DrugManufacturersMaster> findbynames(@Param("drugMfgrName") String drugMfgrName);
}
