package org.healthchain.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "AV_IP_FC_Map")
public class IpFcMap extends AuditableEntity implements BaseEntity,Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "IP_FC_MapId")
	private Long ipFcMapId;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FK_InsurancePayerID", referencedColumnName = "InsurancePayerID", nullable = true)
	private InsurancePayerCompanyMaster insurancePayerCompanyMaster;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FK_FacilityCenterID", referencedColumnName = "FacilityCenterID", nullable = true)
	private FacilityCenterMaster facilityCenterMaster;

	public IpFcMap(Long ipFcMapId, InsurancePayerCompanyMaster insurancePayerCompanyMaster,
			FacilityCenterMaster facilityCenterMaster) {
		super();
		this.ipFcMapId = ipFcMapId;
		this.insurancePayerCompanyMaster = insurancePayerCompanyMaster;
		this.facilityCenterMaster = facilityCenterMaster;
	}

	public IpFcMap() {
		
	}

	public Long getIpFcMapId() {
		return ipFcMapId;
	}

	public InsurancePayerCompanyMaster getInsurancePayerCompanyMaster() {
		return insurancePayerCompanyMaster;
	}

	public FacilityCenterMaster getFacilityCenterMaster() {
		return facilityCenterMaster;
	}

	public void setIpFcMapId(Long ipFcMapId) {
		this.ipFcMapId = ipFcMapId;
	}

	public void setInsurancePayerCompanyMaster(InsurancePayerCompanyMaster insurancePayerCompanyMaster) {
		this.insurancePayerCompanyMaster = insurancePayerCompanyMaster;
	}

	public void setFacilityCenterMaster(FacilityCenterMaster facilityCenterMaster) {
		this.facilityCenterMaster = facilityCenterMaster;
	}
}
