package org.healthchain.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "AV_FCL_Provider_Hospital_Map")
public class FCLProviderHospitalMap extends AuditableEntity implements BaseEntity,Serializable{
	
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "FCL_Provider_HospitalMapID")
	private Long fclProviderHospitalMapID;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FK_FCL_ProviderMapID", referencedColumnName = "FCL_ProviderMapID", nullable = true)
	private FCLProviderMap fclProviderMapID;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FK_Hospital", referencedColumnName = "FCL_ProviderMapID", nullable = true)
	private FCLProviderMap hospital;
	
	public FCLProviderHospitalMap() {
		
	}

	public FCLProviderHospitalMap(Long fclProviderHospitalMapID, FCLProviderMap fclProviderMapID,
			FCLProviderMap hospital) {
		super();
		this.fclProviderHospitalMapID = fclProviderHospitalMapID;
		this.fclProviderMapID = fclProviderMapID;
		this.hospital = hospital;
	}

	public Long getFclProviderHospitalMapID() {
		return fclProviderHospitalMapID;
	}

	public FCLProviderMap getFclProviderMapID() {
		return fclProviderMapID;
	}

	public FCLProviderMap getHospital() {
		return hospital;
	}

	public void setFclProviderHospitalMapID(Long fclProviderHospitalMapID) {
		this.fclProviderHospitalMapID = fclProviderHospitalMapID;
	}

	public void setFclProviderMapID(FCLProviderMap fclProviderMapID) {
		this.fclProviderMapID = fclProviderMapID;
	}

	public void setHospital(FCLProviderMap hospital) {
		this.hospital = hospital;
	}
}
