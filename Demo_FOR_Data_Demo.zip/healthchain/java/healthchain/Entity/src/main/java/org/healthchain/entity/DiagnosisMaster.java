package org.healthchain.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "AV_DiagnosisMaster")
public class DiagnosisMaster extends AuditableEntity implements BaseEntity,Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "DiagnosisID")
	private Long diagnosisID;
	
	@Column(name = "DiagnosiseName", length=40 ,nullable = true)
	private String diagnosiseName;
	
	@Column(name = "US_ICD10_CODE",nullable = true)
	private float usIcdCode;

	@Column(name = "US_ICD10_NAME", length=40 ,nullable = true)
	private String usIcdName;

	public DiagnosisMaster() {
		
	}

	public DiagnosisMaster(Long diagnosisID, String diagnosiseName, float usIcdCode, String usIcdName) {
		super();
		this.diagnosisID = diagnosisID;
		this.diagnosiseName = diagnosiseName;
		this.usIcdCode = usIcdCode;
		this.usIcdName = usIcdName;
	}

	public Long getDiagnosisID() {
		return diagnosisID;
	}

	public void setDiagnosisID(Long diagnosisID) {
		this.diagnosisID = diagnosisID;
	}

	public String getDiagnosiseName() {
		return diagnosiseName;
	}

	public void setDiagnosiseName(String diagnosiseName) {
		this.diagnosiseName = diagnosiseName;
	}

	public float getUsIcdCode() {
		return usIcdCode;
	}

	public void setUsIcdCode(float usIcdCode) {
		this.usIcdCode = usIcdCode;
	}

	public String getUsIcdName() {
		return usIcdName;
	}

	public void setUsIcdName(String usIcdName) {
		this.usIcdName = usIcdName;
	}
}
