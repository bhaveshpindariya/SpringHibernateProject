package org.healthchain.entity.enums;

import java.util.ArrayList;
import java.util.List;

public enum MaritalStatus {

	Single("Single"),
	Married("Married"),
	Divorced("Divorced"),
	Widow("Widow"),
	InRelationship("InRelationship");

    private String id;

    MaritalStatus(String id) {
        this.id = id;
    }

    public String getId() {
        return id;
    }

    public static MaritalStatus parse(String id) {
        MaritalStatus maritalStatus = null; // Default
        for (MaritalStatus item : MaritalStatus.values()) {
        	if (item.getId().equals(id)) {
                maritalStatus = item;
                break;
            }
        }
        return maritalStatus;
    }

    public static String getValue(String id) {
    	for (MaritalStatus item : MaritalStatus.values()) {
	         if (item.name() == id) {
	         		return item.getId();
	         }
    	}
    	return null;
    }
    
    public static List<String> getAllMaritalStatus() {
        MaritalStatus[] values = MaritalStatus.values();
        List<String> list = new ArrayList<>();
        for (MaritalStatus value : values) {
            list.add(value.name());
        }
        return list;
    }
}
