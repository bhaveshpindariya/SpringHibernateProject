package org.healthchain.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "AV_PatientMaster")
public class PatientMaster extends AuditableEntity implements BaseEntity,Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "PatientID")
	private Long patientID;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FK_PersonID", referencedColumnName = "PersonID", nullable = true)
	private PersonMaster personID;

	public PatientMaster(Long patientID, PersonMaster personID) {
		super();
		this.patientID = patientID;
		this.personID = personID;
	}

	public PatientMaster() {
	
	}

	public Long getPatientID() {
		return patientID;
	}

	public PersonMaster getPersonID() {
		return personID;
	}

	public void setPatientID(Long patientID) {
		this.patientID = patientID;
	}

	public void setPersonID(PersonMaster personID) {
		this.personID = personID;
	}
		
}
