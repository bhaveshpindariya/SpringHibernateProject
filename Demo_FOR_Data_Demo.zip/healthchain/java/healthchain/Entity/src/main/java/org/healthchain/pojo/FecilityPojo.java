package org.healthchain.pojo;

import java.io.Serializable;

import org.healthchain.entity.enums.FacilityCenterType;

public class FecilityPojo implements Serializable {

	private static final long serialVersionUID = 1L;
	private Long facilityCenterID;
	private String facilityCenterName;
	private FacilityCenterType facilityCenterType;
	public Object data;
	
	public FecilityPojo() {
		
	}

	public FecilityPojo(Long facilityCenterID, String facilityCenterName, FacilityCenterType facilityCenterType,
			Object data) {
		super();
		this.facilityCenterID = facilityCenterID;
		this.facilityCenterName = facilityCenterName;
		this.facilityCenterType = facilityCenterType;
		this.data = data;
	}

	@Override
	public String toString() {
		return "FecilityPojo [facilityCenterID=" + facilityCenterID + ", facilityCenterName=" + facilityCenterName
				+ ", facilityCenterType=" + facilityCenterType + ", data=" + data + "]";
	}

	public Long getFacilityCenterID() {
		return facilityCenterID;
	}

	public String getFacilityCenterName() {
		return facilityCenterName;
	}

	public FacilityCenterType getFacilityCenterType() {
		return facilityCenterType;
	}

	public Object getData() {
		return data;
	}

	public void setFacilityCenterID(Long facilityCenterID) {
		this.facilityCenterID = facilityCenterID;
	}

	public void setFacilityCenterName(String facilityCenterName) {
		this.facilityCenterName = facilityCenterName;
	}

	public void setFacilityCenterType(FacilityCenterType facilityCenterType) {
		this.facilityCenterType = facilityCenterType;
	}

	public void setData(Object data) {
		this.data = data;
	}
	
}
