package org.healthchain.pojo;

import java.io.Serializable;

import org.healthchain.entity.enums.EmploymentStatus;
import org.healthchain.entity.enums.GenderStatus;
import org.healthchain.entity.enums.MaritalStatus;
import org.healthchain.entity.enums.WorkStatus;

public class ExtendedPojo implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private Long personID;
	private Long perDOB;
	private String perDegree;
	private String perDesignation;
	private GenderStatus gender;
	private MaritalStatus marital;
	private String perBloodGroup;
	private String bodyHeight;
	private String bodyWeightInKG;
	private Integer chestInches;
	private Integer waistInches;
	private WorkStatus work;
	private EmploymentStatus employment;
	
	public ExtendedPojo() {
		
	}

	public ExtendedPojo(Long personID, Long perDOB, String perDegree, String perDesignation, GenderStatus gender,
			MaritalStatus marital, String perBloodGroup, String bodyHeight, String bodyWeightInKG, Integer chestInches,
			Integer waistInches, WorkStatus work, EmploymentStatus employment) {
		super();
		this.personID = personID;
		this.perDOB = perDOB;
		this.perDegree = perDegree;
		this.perDesignation = perDesignation;
		this.gender = gender;
		this.marital = marital;
		this.perBloodGroup = perBloodGroup;
		this.bodyHeight = bodyHeight;
		this.bodyWeightInKG = bodyWeightInKG;
		this.chestInches = chestInches;
		this.waistInches = waistInches;
		this.work = work;
		this.employment = employment;
	}

	@Override
	public String toString() {
		return "ExtendedPojo [personID=" + personID + ", perDOB=" + perDOB + ", perDegree=" + perDegree
				+ ", perDesignation=" + perDesignation + ", gender=" + gender + ", marital=" + marital
				+ ", perBloodGroup=" + perBloodGroup + ", bodyHeight=" + bodyHeight + ", bodyWeightInKG="
				+ bodyWeightInKG + ", chestInches=" + chestInches + ", waistInches=" + waistInches + ", work=" + work
				+ ", employment=" + employment + "]";
	}

	public Long getPersonID() {
		return personID;
	}

	public Long getPerDOB() {
		return perDOB;
	}

	public String getPerDegree() {
		return perDegree;
	}

	public String getPerDesignation() {
		return perDesignation;
	}

	public GenderStatus getGender() {
		return gender;
	}

	public MaritalStatus getMarital() {
		return marital;
	}

	public String getPerBloodGroup() {
		return perBloodGroup;
	}

	public String getBodyHeight() {
		return bodyHeight;
	}

	public String getBodyWeightInKG() {
		return bodyWeightInKG;
	}

	public Integer getChestInches() {
		return chestInches;
	}

	public Integer getWaistInches() {
		return waistInches;
	}

	public WorkStatus getWork() {
		return work;
	}

	public EmploymentStatus getEmployment() {
		return employment;
	}

	public void setPersonID(Long personID) {
		this.personID = personID;
	}

	public void setPerDOB(Long perDOB) {
		this.perDOB = perDOB;
	}

	public void setPerDegree(String perDegree) {
		this.perDegree = perDegree;
	}

	public void setPerDesignation(String perDesignation) {
		this.perDesignation = perDesignation;
	}

	public void setGender(GenderStatus gender) {
		this.gender = gender;
	}

	public void setMarital(MaritalStatus marital) {
		this.marital = marital;
	}

	public void setPerBloodGroup(String perBloodGroup) {
		this.perBloodGroup = perBloodGroup;
	}

	public void setBodyHeight(String bodyHeight) {
		this.bodyHeight = bodyHeight;
	}

	public void setBodyWeightInKG(String bodyWeightInKG) {
		this.bodyWeightInKG = bodyWeightInKG;
	}

	public void setChestInches(Integer chestInches) {
		this.chestInches = chestInches;
	}

	public void setWaistInches(Integer waistInches) {
		this.waistInches = waistInches;
	}

	public void setWork(WorkStatus work) {
		this.work = work;
	}

	public void setEmployment(EmploymentStatus employment) {
		this.employment = employment;
	}
}
