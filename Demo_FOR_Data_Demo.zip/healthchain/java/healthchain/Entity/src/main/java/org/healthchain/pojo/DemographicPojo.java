package org.healthchain.pojo;

import java.io.Serializable;

import org.healthchain.entity.enums.PLMLocationStatus;

public class DemographicPojo implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private Long personID;
	private String perMobilePrimary;
	private PLMLocationStatus plmLocationStatus;
	private Object perMobileList;
	public Object locationMaster;
	
	public DemographicPojo() {
		
	}

	public DemographicPojo(Long personID, String perMobilePrimary, Object perMobileList, PLMLocationStatus plmLocationStatus, Object locationMaster) {
		super();
		this.personID = personID;
		this.perMobilePrimary = perMobilePrimary;
		this.perMobileList = perMobileList;
		this.locationMaster = locationMaster;
		this.plmLocationStatus=plmLocationStatus;
	}

	public Long getPersonID() {
		return personID;
	}

	public String getPerMobilePrimary() {
		return perMobilePrimary;
	}

	public Object getPerMobileList() {
		return perMobileList;
	}

	public Object getLocationMaster() {
		return locationMaster;
	}

	public void setPersonID(Long personID) {
		this.personID = personID;
	}

	public void setPerMobilePrimary(String perMobilePrimary) {
		this.perMobilePrimary = perMobilePrimary;
	}

	public void setPerMobileList(Object perMobileList) {
		this.perMobileList = perMobileList;
	}

	public void setLocationMaster(Object locationMaster) {
		this.locationMaster = locationMaster;
	}

	public PLMLocationStatus getPlmLocationStatus() {
		return plmLocationStatus;
	}

	public void setPlmLocationStatus(PLMLocationStatus plmLocationStatus) {
		this.plmLocationStatus = plmLocationStatus;
	}
	
	
	
}
