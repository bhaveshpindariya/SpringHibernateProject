package org.healthchain.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "AV_IP_PlansMaster")
public class IpPlansMaster extends AuditableEntity implements BaseEntity,Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "IP_PlanId")
	private Long ipPlanId;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FK_InsurancePayerID", referencedColumnName = "InsurancePayerID", nullable = true)
	private InsurancePayerCompanyMaster insurancePayerCompanyMaster;
	
	@Column(name = "IP_PlanCode", length=20 , nullable = true)
	private String ipPlanCode;
	
	@Column(name = "IP_PlanName", length=60 ,nullable = true)
	private String ipPlanName;
	
	@Column(name = "IP_PlanDescription", columnDefinition="TEXT" ,nullable = true)
	private String ipPlanDescription;

	public IpPlansMaster(Long ipPlanId, InsurancePayerCompanyMaster insurancePayerCompanyMaster, String ipPlanCode,
			String ipPlanName, String ipPlanDescription) {
		super();
		this.ipPlanId = ipPlanId;
		this.insurancePayerCompanyMaster = insurancePayerCompanyMaster;
		this.ipPlanCode = ipPlanCode;
		this.ipPlanName = ipPlanName;
		this.ipPlanDescription = ipPlanDescription;
	}

	public IpPlansMaster() {
	
	}

	public Long getIpPlanId() {
		return ipPlanId;
	}

	public InsurancePayerCompanyMaster getInsurancePayerCompanyMaster() {
		return insurancePayerCompanyMaster;
	}

	public String getIpPlanCode() {
		return ipPlanCode;
	}

	public String getIpPlanName() {
		return ipPlanName;
	}

	public String getIpPlanDescription() {
		return ipPlanDescription;
	}

	public void setIpPlanId(Long ipPlanId) {
		this.ipPlanId = ipPlanId;
	}

	public void setInsurancePayerCompanyMaster(InsurancePayerCompanyMaster insurancePayerCompanyMaster) {
		this.insurancePayerCompanyMaster = insurancePayerCompanyMaster;
	}

	public void setIpPlanCode(String ipPlanCode) {
		this.ipPlanCode = ipPlanCode;
	}

	public void setIpPlanName(String ipPlanName) {
		this.ipPlanName = ipPlanName;
	}

	public void setIpPlanDescription(String ipPlanDescription) {
		this.ipPlanDescription = ipPlanDescription;
	}
	
}
