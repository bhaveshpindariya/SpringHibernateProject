package org.healthchain.pojo;

import java.io.Serializable;

public class FCLProviderReportMapPojo implements Serializable {

	private static final long serialVersionUID = 1L;
	private Long fclProviderReportMapID;
	private Long labReportLevel1ID;
	private String lrl1Name;
	
	public FCLProviderReportMapPojo() {
		
	}

	public FCLProviderReportMapPojo(Long fclProviderReportMapID, Long labReportLevel1ID, String lrl1Name) {
		super();
		this.fclProviderReportMapID = fclProviderReportMapID;
		this.labReportLevel1ID = labReportLevel1ID;
		this.lrl1Name = lrl1Name;
	}


	public Long getFclProviderReportMapID() {
		return fclProviderReportMapID;
	}

	public Long getLabReportLevel1ID() {
		return labReportLevel1ID;
	}

	public String getLrl1Name() {
		return lrl1Name;
	}

	public void setFclProviderReportMapID(Long fclProviderReportMapID) {
		this.fclProviderReportMapID = fclProviderReportMapID;
	}

	public void setLabReportLevel1ID(Long labReportLevel1ID) {
		this.labReportLevel1ID = labReportLevel1ID;
	}

	public void setLrl1Name(String lrl1Name) {
		this.lrl1Name = lrl1Name;
	}

	
}
