package org.healthchain.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "AV_PatInvestigationsOrders")
public class PatInvestigationsOrders extends AuditableEntity implements BaseEntity, Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "PatInvOrderID")
	private Long patInvOrderID;

	@Column(name = "InvOrderDate", nullable = true)
	private Date invOrderDate;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FK_PatVisitNoteID", referencedColumnName = "PatVisitNoteID", nullable = true)
	private PatVisitNote patVisitNoteOutdoor;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FK_PatAdmitID", referencedColumnName = "PatAdmitID", nullable = true)
	private PatAdmission patAdmission;
	
	@Column(name = "IsElectronicOrder", nullable = true , columnDefinition = "Boolean default false")
	private Boolean isElectronicOrder;
	
	@Column(name = "IsPrinted", nullable = true , columnDefinition = "Boolean default false")
	private Boolean isPrinted;

	public PatInvestigationsOrders() {
		
	}

	public PatInvestigationsOrders(Long patInvOrderID, Date invOrderDate, PatVisitNote patVisitNoteOutdoor,
			PatAdmission patAdmission, Boolean isElectronicOrder, Boolean isPrinted) {
		super();
		this.patInvOrderID = patInvOrderID;
		this.invOrderDate = invOrderDate;
		this.patVisitNoteOutdoor = patVisitNoteOutdoor;
		this.patAdmission = patAdmission;
		this.isElectronicOrder = isElectronicOrder;
		this.isPrinted = isPrinted;
	}

	public Long getPatInvOrderID() {
		return patInvOrderID;
	}

	public Date getInvOrderDate() {
		return invOrderDate;
	}

	public PatVisitNote getPatVisitNoteOutdoor() {
		return patVisitNoteOutdoor;
	}

	public PatAdmission getPatAdmission() {
		return patAdmission;
	}

	public Boolean getIsElectronicOrder() {
		return isElectronicOrder;
	}

	public Boolean getIsPrinted() {
		return isPrinted;
	}

	public void setPatInvOrderID(Long patInvOrderID) {
		this.patInvOrderID = patInvOrderID;
	}

	public void setInvOrderDate(Date invOrderDate) {
		this.invOrderDate = invOrderDate;
	}

	public void setPatVisitNoteOutdoor(PatVisitNote patVisitNoteOutdoor) {
		this.patVisitNoteOutdoor = patVisitNoteOutdoor;
	}

	public void setPatAdmission(PatAdmission patAdmission) {
		this.patAdmission = patAdmission;
	}

	public void setIsElectronicOrder(Boolean isElectronicOrder) {
		this.isElectronicOrder = isElectronicOrder;
	}

	public void setIsPrinted(Boolean isPrinted) {
		this.isPrinted = isPrinted;
	}
	
}