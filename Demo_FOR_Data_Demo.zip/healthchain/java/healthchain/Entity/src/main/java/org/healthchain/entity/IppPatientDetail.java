package org.healthchain.entity;

import java.io.Serializable;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.healthchain.entity.enums.PatRelationStatus;

@Entity
@Table(name = "AV_IPP_PatientDetail")
public class IppPatientDetail extends AuditableEntity implements BaseEntity,Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "PatInsuranceDetailID")
	private Long patInsuranceDetailID;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FK_PersonID", referencedColumnName = "PersonID", nullable = true)
	private PersonMaster personMaster;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FK_PatientID", referencedColumnName = "PatientID", nullable = true)
	private PatientMaster patientMaster;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FK_IP_PlanId", referencedColumnName = "IP_PlanId", nullable = true)
	private IpPlansMaster ipPlansMaster;

	@Column(name = "SumInsured", nullable = true)
	private float sumInsured;
	
	@Column(name = "SumConsumed", nullable = true)
	private float sumConsumed;
	
	@Basic
	@Column(name = "PatRelatioToInsured", length=20 ,nullable = true)
	@Enumerated(EnumType.STRING)
	private PatRelationStatus patRelationStatus;

	public IppPatientDetail(Long patInsuranceDetailID, PersonMaster personMaster, PatientMaster patientMaster,
			IpPlansMaster ipPlansMaster, float sumInsured, float sumConsumed, PatRelationStatus patRelationStatus) {
		super();
		this.patInsuranceDetailID = patInsuranceDetailID;
		this.personMaster = personMaster;
		this.patientMaster = patientMaster;
		this.ipPlansMaster = ipPlansMaster;
		this.sumInsured = sumInsured;
		this.sumConsumed = sumConsumed;
		this.patRelationStatus = patRelationStatus;
	}

	public IppPatientDetail() {
		
	}
	public Long getPatInsuranceDetailID() {
		return patInsuranceDetailID;
	}

	public PersonMaster getPersonMaster() {
		return personMaster;
	}

	public PatientMaster getPatientMaster() {
		return patientMaster;
	}

	public IpPlansMaster getIpPlansMaster() {
		return ipPlansMaster;
	}

	public float getSumInsured() {
		return sumInsured;
	}

	public float getSumConsumed() {
		return sumConsumed;
	}

	public PatRelationStatus getPatRelationStatus() {
		return patRelationStatus;
	}

	public void setPatInsuranceDetailID(Long patInsuranceDetailID) {
		this.patInsuranceDetailID = patInsuranceDetailID;
	}

	public void setPersonMaster(PersonMaster personMaster) {
		this.personMaster = personMaster;
	}

	public void setPatientMaster(PatientMaster patientMaster) {
		this.patientMaster = patientMaster;
	}

	public void setIpPlansMaster(IpPlansMaster ipPlansMaster) {
		this.ipPlansMaster = ipPlansMaster;
	}

	public void setSumInsured(float sumInsured) {
		this.sumInsured = sumInsured;
	}

	public void setSumConsumed(float sumConsumed) {
		this.sumConsumed = sumConsumed;
	}

	public void setPatRelationStatus(PatRelationStatus patRelationStatus) {
		this.patRelationStatus = patRelationStatus;
	}
		
}
