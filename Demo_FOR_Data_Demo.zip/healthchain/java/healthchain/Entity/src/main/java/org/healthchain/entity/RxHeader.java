package org.healthchain.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "AV_RxHeader")
public class RxHeader extends AuditableEntity implements BaseEntity,Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "RxID")
	private Long rxID;
	
	@Column(name = "RXDate", nullable = true)
	private Date rxDate;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FK_PatVisitNoteID", referencedColumnName = "PatVisitNoteID", nullable = true)
	private PatVisitNote patVisitNote;
	
	public RxHeader() {
		
	}

	public RxHeader(Long rxID, Date rxDate, PatVisitNote patVisitNote) {
		super();
		this.rxID = rxID;
		this.rxDate = rxDate;
		this.patVisitNote = patVisitNote;
	}

	public Long getRxID() {
		return rxID;
	}

	public Date getRxDate() {
		return rxDate;
	}

	public PatVisitNote getPatVisitNote() {
		return patVisitNote;
	}

	public void setRxID(Long rxID) {
		this.rxID = rxID;
	}

	public void setRxDate(Date rxDate) {
		this.rxDate = rxDate;
	}

	public void setPatVisitNote(PatVisitNote patVisitNote) {
		this.patVisitNote = patVisitNote;
	}
	
}
