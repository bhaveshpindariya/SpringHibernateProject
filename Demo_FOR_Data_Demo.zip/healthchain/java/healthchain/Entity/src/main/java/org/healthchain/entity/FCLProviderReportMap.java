package org.healthchain.entity;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name = "AV_FCL_Provider_Report_Map")
public class FCLProviderReportMap extends AuditableEntity implements BaseEntity,Serializable{
	
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "FCL_Provider_ReportMapID")
	private Long fclProviderReportMapID;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FK_FCL_ProviderMapID", referencedColumnName = "FCL_ProviderMapID", nullable = true)
	private FCLProviderMap fclProviderMapID;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FK_LabReportLevel1_ID", referencedColumnName = "LabReportLevel1_ID", nullable = true)
	private LabReportsLevel1 labReportLevel1ID;

	@Transient
	private Set<LabReportsLevel1> labReportsLevel1= new HashSet<LabReportsLevel1>(0);
	
	@Transient
	private Set<DrugCompoundMaster>  drugCompoundMaster= new HashSet<DrugCompoundMaster>(0);
	
	@Transient
	private Set<FCLProviderMap>  doctor= new HashSet<FCLProviderMap>(0);
	
	@Transient
	private Long fclProviderMap;
	
	public FCLProviderReportMap() {
		
	}

	public FCLProviderReportMap(Long fclProviderReportMapID, FCLProviderMap fclProviderMapID,
			LabReportsLevel1 labReportLevel1ID, Set<LabReportsLevel1> labReportsLevel1,
			Set<DrugCompoundMaster> drugCompoundMaster, Set<FCLProviderMap> doctor, Long fclProviderMap) {
		super();
		this.fclProviderReportMapID = fclProviderReportMapID;
		this.fclProviderMapID = fclProviderMapID;
		this.labReportLevel1ID = labReportLevel1ID;
		this.labReportsLevel1 = labReportsLevel1;
		this.drugCompoundMaster = drugCompoundMaster;
		this.doctor = doctor;
		this.fclProviderMap = fclProviderMap;
	}

	public Long getFclProviderReportMapID() {
		return fclProviderReportMapID;
	}

	public FCLProviderMap getFclProviderMapID() {
		return fclProviderMapID;
	}

	public LabReportsLevel1 getLabReportLevel1ID() {
		return labReportLevel1ID;
	}

	public Set<LabReportsLevel1> getLabReportsLevel1() {
		return labReportsLevel1;
	}

	public Set<DrugCompoundMaster> getDrugCompoundMaster() {
		return drugCompoundMaster;
	}

	public Set<FCLProviderMap> getDoctor() {
		return doctor;
	}

	public Long getFclProviderMap() {
		return fclProviderMap;
	}

	public void setFclProviderReportMapID(Long fclProviderReportMapID) {
		this.fclProviderReportMapID = fclProviderReportMapID;
	}

	public void setFclProviderMapID(FCLProviderMap fclProviderMapID) {
		this.fclProviderMapID = fclProviderMapID;
	}

	public void setLabReportLevel1ID(LabReportsLevel1 labReportLevel1ID) {
		this.labReportLevel1ID = labReportLevel1ID;
	}

	public void setLabReportsLevel1(Set<LabReportsLevel1> labReportsLevel1) {
		this.labReportsLevel1 = labReportsLevel1;
	}

	public void setDrugCompoundMaster(Set<DrugCompoundMaster> drugCompoundMaster) {
		this.drugCompoundMaster = drugCompoundMaster;
	}

	public void setDoctor(Set<FCLProviderMap> doctor) {
		this.doctor = doctor;
	}

	public void setFclProviderMap(Long fclProviderMap) {
		this.fclProviderMap = fclProviderMap;
	}
}
