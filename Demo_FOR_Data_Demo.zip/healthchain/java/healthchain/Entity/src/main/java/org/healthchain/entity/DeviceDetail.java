package org.healthchain.entity;

import java.io.Serializable;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="AV_DeviceDetail")
public class DeviceDetail extends AuditableEntity implements BaseEntity,Serializable{

	/**
	 * 
	 */
	
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "DeviceDetailID")
    private Long deviceDetailID;

    @Basic
    @Column(name = "DeviceToken", nullable = true, columnDefinition="TEXT")
    private String deviceToken;
    
    @Basic
    @Column(name = "DeviceID", nullable = true, columnDefinition="TEXT")
    private String deviceID;
    
    @Basic
    @Column(name = "DeviceType", nullable = true,  length=20)
    private String deviceType;
    
    @ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FK_UserID", referencedColumnName = "UserID", nullable = true)
	private UserMaster userMaster;

	public DeviceDetail(Long deviceDetailID, String deviceToken, String deviceID, String deviceType,
			UserMaster userMaster) {
		super();
		this.deviceDetailID = deviceDetailID;
		this.deviceToken = deviceToken;
		this.deviceID = deviceID;
		this.deviceType = deviceType;
		this.userMaster = userMaster;
	}

	public DeviceDetail() {
		
	}

	public Long getDeviceDetailID() {
		return deviceDetailID;
	}

	public String getDeviceToken() {
		return deviceToken;
	}

	public String getDeviceID() {
		return deviceID;
	}

	public String getDeviceType() {
		return deviceType;
	}

	public UserMaster getUserMaster() {
		return userMaster;
	}

	public void setDeviceDetailID(Long deviceDetailID) {
		this.deviceDetailID = deviceDetailID;
	}

	public void setDeviceToken(String deviceToken) {
		this.deviceToken = deviceToken;
	}

	public void setDeviceID(String deviceID) {
		this.deviceID = deviceID;
	}

	public void setDeviceType(String deviceType) {
		this.deviceType = deviceType;
	}

	public void setUserMaster(UserMaster userMaster) {
		this.userMaster = userMaster;
	}
}
