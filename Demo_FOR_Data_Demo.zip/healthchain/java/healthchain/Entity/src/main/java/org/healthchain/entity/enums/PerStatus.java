package org.healthchain.entity.enums;

import java.util.ArrayList;
import java.util.List;

public enum PerStatus {

	Mr("Mr."),
	Mrs("Mrs."),
	Ms("Ms."),
	Miss("Miss."),
	Dr("Dr.");

    private String id;

    PerStatus(String id) {
        this.id = id;
    }

    public String getId() {
        return id;
    }

    public static String getValue(String id) {
    	for (PerStatus item : PerStatus.values()) {
    		if (item.getId().equals(id)) {
	         		return item.getId();
	         }
    	}
    	return null;
    }
    
    public static PerStatus parse(String id) {
    	PerStatus maritalStatus = null; // Default
        for (PerStatus item : PerStatus.values()) {
            if (item.getId() == id) {
                maritalStatus = item;
                break;
            }
        }
        return maritalStatus;
    }

    public static List<String> getPer() {
    	PerStatus[] values = PerStatus.values();
        List<String> list = new ArrayList<>();
        for (PerStatus value : values) {
            list.add(value.name());
        }
        return list;
    }
}
