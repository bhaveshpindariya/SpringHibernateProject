package org.healthchain.entity;

import java.io.Serializable;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.healthchain.entity.enums.PatientAppointmentReason;
import org.healthchain.entity.enums.PatientAppointmentStatus;
import org.healthchain.entity.enums.PatientAppointmentType;

@Entity
@Table(name = "AV_PatAppointments")
public class PatAppointments extends AuditableEntity implements BaseEntity,Serializable{

	/**
	 * 
	 */
	
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "PatAppointmentID")
	private Long patAppointmentID;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FK_CFL_PatRegID", referencedColumnName = "CFL_PatRegID", nullable = true)
	private CFLPatRegistrationMap fclpID;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FK_FCL_ProviderMapID", referencedColumnName = "FCL_ProviderMapID", nullable = true)
	private FCLProviderMap fclProviderMapID;
	
	@Column(name = "PatApp_Date", nullable = true)
	private Long patAppDate;
	
	@Column(name = "PatApp_TimeFrom", nullable = true)
	private Long patAppTimeFrom;
	
	@Column(name = "PatApp_TimeTo", nullable = true)
	private Long patAppTimeTo;
	
	@Column(name = "PatApp_TimeUnit", length=20 ,nullable = true)
	private String patAppTimeUnit;
	
	@Column(name = "PatApp_TimeSlot", nullable = true)
	private Long patAppTimeSlot;
	
	@Basic
	@Column(name = "PatApp_Type", length=30 ,nullable = true)
	@Enumerated(EnumType.STRING)
	private PatientAppointmentType patAppType;
	
	@Basic
	@Column(name = "PatApp_Reason", length=150 , nullable = true)
	@Enumerated(EnumType.STRING)
	private PatientAppointmentReason patAppReason;
	
	@Column(name = "PatApp_Description", columnDefinition = "TEXT",nullable = true)
	private String patAppDescription;
	
	@Basic
	@Column(name = "PatApp_Status", length=30 ,nullable = true)
	@Enumerated(EnumType.STRING)
	private PatientAppointmentStatus patAppStatus;
	
	@Column(name = "ReasonIfCancelled", length=60 ,nullable = true)
	private String reasonIfCancelled;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FK_AppointmentID_IfReBooked", referencedColumnName = "PatAppointmentID", nullable = true)
	private PatAppointments patAppointments;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FK_SpecialityID", referencedColumnName = "SpecialityID", nullable = true)
	private SpecialityMaster specialityMaster;

	public PatAppointments() {
		
	}

	public PatAppointments(Long patAppointmentID, CFLPatRegistrationMap fclpID, FCLProviderMap fclProviderMapID,
			Long patAppDate, Long patAppTimeFrom, Long patAppTimeTo, String patAppTimeUnit, Long patAppTimeSlot,
			PatientAppointmentType patAppType, PatientAppointmentReason patAppReason, String patAppDescription,
			PatientAppointmentStatus patAppStatus, String reasonIfCancelled, PatAppointments patAppointments,
			SpecialityMaster specialityMaster) {
		super();
		this.patAppointmentID = patAppointmentID;
		this.fclpID = fclpID;
		this.fclProviderMapID = fclProviderMapID;
		this.patAppDate = patAppDate;
		this.patAppTimeFrom = patAppTimeFrom;
		this.patAppTimeTo = patAppTimeTo;
		this.patAppTimeUnit = patAppTimeUnit;
		this.patAppTimeSlot = patAppTimeSlot;
		this.patAppType = patAppType;
		this.patAppReason = patAppReason;
		this.patAppDescription = patAppDescription;
		this.patAppStatus = patAppStatus;
		this.reasonIfCancelled = reasonIfCancelled;
		this.patAppointments = patAppointments;
		this.specialityMaster = specialityMaster;
	}

	public Long getPatAppointmentID() {
		return patAppointmentID;
	}

	public CFLPatRegistrationMap getFclpID() {
		return fclpID;
	}

	public FCLProviderMap getFclProviderMapID() {
		return fclProviderMapID;
	}

	public Long getPatAppDate() {
		return patAppDate;
	}

	public Long getPatAppTimeFrom() {
		return patAppTimeFrom;
	}

	public Long getPatAppTimeTo() {
		return patAppTimeTo;
	}

	public String getPatAppTimeUnit() {
		return patAppTimeUnit;
	}

	public Long getPatAppTimeSlot() {
		return patAppTimeSlot;
	}

	public PatientAppointmentType getPatAppType() {
		return patAppType;
	}

	public PatientAppointmentReason getPatAppReason() {
		return patAppReason;
	}

	public String getPatAppDescription() {
		return patAppDescription;
	}

	public PatientAppointmentStatus getPatAppStatus() {
		return patAppStatus;
	}

	public String getReasonIfCancelled() {
		return reasonIfCancelled;
	}

	public PatAppointments getPatAppointments() {
		return patAppointments;
	}

	public SpecialityMaster getSpecialityMaster() {
		return specialityMaster;
	}

	public void setPatAppointmentID(Long patAppointmentID) {
		this.patAppointmentID = patAppointmentID;
	}

	public void setFclpID(CFLPatRegistrationMap fclpID) {
		this.fclpID = fclpID;
	}

	public void setFclProviderMapID(FCLProviderMap fclProviderMapID) {
		this.fclProviderMapID = fclProviderMapID;
	}

	public void setPatAppDate(Long patAppDate) {
		this.patAppDate = patAppDate;
	}

	public void setPatAppTimeFrom(Long patAppTimeFrom) {
		this.patAppTimeFrom = patAppTimeFrom;
	}

	public void setPatAppTimeTo(Long patAppTimeTo) {
		this.patAppTimeTo = patAppTimeTo;
	}

	public void setPatAppTimeUnit(String patAppTimeUnit) {
		this.patAppTimeUnit = patAppTimeUnit;
	}

	public void setPatAppTimeSlot(Long patAppTimeSlot) {
		this.patAppTimeSlot = patAppTimeSlot;
	}

	public void setPatAppType(PatientAppointmentType patAppType) {
		this.patAppType = patAppType;
	}

	public void setPatAppReason(PatientAppointmentReason patAppReason) {
		this.patAppReason = patAppReason;
	}

	public void setPatAppDescription(String patAppDescription) {
		this.patAppDescription = patAppDescription;
	}

	public void setPatAppStatus(PatientAppointmentStatus patAppStatus) {
		this.patAppStatus = patAppStatus;
	}

	public void setReasonIfCancelled(String reasonIfCancelled) {
		this.reasonIfCancelled = reasonIfCancelled;
	}

	public void setPatAppointments(PatAppointments patAppointments) {
		this.patAppointments = patAppointments;
	}

	public void setSpecialityMaster(SpecialityMaster specialityMaster) {
		this.specialityMaster = specialityMaster;
	}

	
}
