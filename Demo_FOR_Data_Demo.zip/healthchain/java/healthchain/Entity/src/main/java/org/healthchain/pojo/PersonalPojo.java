package org.healthchain.pojo;

import java.io.Serializable;

public class PersonalPojo implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private Long personID;
	private String perFname;
	private String userName;
	private String perLName;
	private String perProfile;
	private Object perEmailList;
	private String perEmailPrimary;
	
	public PersonalPojo() {
		
	}

	public PersonalPojo(Long personID, String perFname, String userName, String perLName, String perProfile,
			Object perEmailList, String perEmailPrimary) {
		super();
		this.personID = personID;
		this.perFname = perFname;
		this.userName = userName;
		this.perLName = perLName;
		this.perProfile = perProfile;
		this.perEmailList = perEmailList;
		this.perEmailPrimary = perEmailPrimary;
	}

	public Long getPersonID() {
		return personID;
	}

	public String getPerFname() {
		return perFname;
	}

	public String getUserName() {
		return userName;
	}

	public String getPerLName() {
		return perLName;
	}

	public String getPerProfile() {
		return perProfile;
	}

	public Object getPerEmailList() {
		return perEmailList;
	}

	public String getPerEmailPrimary() {
		return perEmailPrimary;
	}

	public void setPersonID(Long personID) {
		this.personID = personID;
	}

	public void setPerFname(String perFname) {
		this.perFname = perFname;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public void setPerLName(String perLName) {
		this.perLName = perLName;
	}

	public void setPerProfile(String perProfile) {
		this.perProfile = perProfile;
	}

	public void setPerEmailList(Object perEmailList) {
		this.perEmailList = perEmailList;
	}

	public void setPerEmailPrimary(String perEmailPrimary) {
		this.perEmailPrimary = perEmailPrimary;
	}
}
