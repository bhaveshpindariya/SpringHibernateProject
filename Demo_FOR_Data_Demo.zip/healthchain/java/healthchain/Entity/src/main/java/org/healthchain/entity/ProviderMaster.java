package org.healthchain.entity;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.healthchain.entity.enums.ProviderTypeStatus;

@Entity
@Table(name = "AV_ProviderMaster")
public class ProviderMaster extends AuditableEntity implements BaseEntity,Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "ProviderID")
	private Long providerID;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FK_PersonID", referencedColumnName = "PersonID", nullable = true)
	private PersonMaster personMaster;

	@Basic
	@Column(name = "ProviderType", length = 20, nullable = true)
	@Enumerated(EnumType.STRING)
	private ProviderTypeStatus providerTypeStatus;
	
	@OneToMany(cascade = CascadeType.ALL,fetch = FetchType.LAZY, mappedBy = "providerMaster")
    private Set<SpecialityProviderMaster>  specialityProviderMaster= new HashSet<SpecialityProviderMaster>(0);
	
	@Column(name = "Provider_Registration_Number", length=30 ,nullable = true)
	private String providerRegistrationNumber;
	
	@Column(name = "NPI", length=30 ,nullable = true)
	private String npi;
	
	@Column(name = "DEA", length=30 ,nullable = true)
	private String dea;
	
	@Column(name = "WebSiteURL", length=60 , nullable = true)
	private String webSiteURL;

	public ProviderMaster() {
		
	}

	public ProviderMaster(Long providerID, PersonMaster personMaster, ProviderTypeStatus providerTypeStatus,
			Set<SpecialityProviderMaster> specialityProviderMaster, String providerRegistrationNumber, String npi,
			String dea, String webSiteURL) {
		super();
		this.providerID = providerID;
		this.personMaster = personMaster;
		this.providerTypeStatus = providerTypeStatus;
		this.specialityProviderMaster = specialityProviderMaster;
		this.providerRegistrationNumber = providerRegistrationNumber;
		this.npi = npi;
		this.dea = dea;
		this.webSiteURL = webSiteURL;
	}

	public Long getProviderID() {
		return providerID;
	}

	public PersonMaster getPersonMaster() {
		return personMaster;
	}

	public ProviderTypeStatus getProviderTypeStatus() {
		return providerTypeStatus;
	}

	public Set<SpecialityProviderMaster> getSpecialityProviderMaster() {
		return specialityProviderMaster;
	}

	public String getProviderRegistrationNumber() {
		return providerRegistrationNumber;
	}

	public String getNpi() {
		return npi;
	}

	public String getDea() {
		return dea;
	}

	public String getWebSiteURL() {
		return webSiteURL;
	}

	public void setProviderID(Long providerID) {
		this.providerID = providerID;
	}

	public void setPersonMaster(PersonMaster personMaster) {
		this.personMaster = personMaster;
	}

	public void setProviderTypeStatus(ProviderTypeStatus providerTypeStatus) {
		this.providerTypeStatus = providerTypeStatus;
	}

	public void setSpecialityProviderMaster(Set<SpecialityProviderMaster> specialityProviderMaster) {
		this.specialityProviderMaster = specialityProviderMaster;
	}

	public void setProviderRegistrationNumber(String providerRegistrationNumber) {
		this.providerRegistrationNumber = providerRegistrationNumber;
	}

	public void setNpi(String npi) {
		this.npi = npi;
	}

	public void setDea(String dea) {
		this.dea = dea;
	}

	public void setWebSiteURL(String webSiteURL) {
		this.webSiteURL = webSiteURL;
	}
}
