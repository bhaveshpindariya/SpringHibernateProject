package org.healthchain.entity.enums;

import java.util.ArrayList;
import java.util.List;

public enum EmploymentStatus {

	SelfDependant("SelfDependant"),
	Employed("Employed"),
	HouseHold("Household");
    
    private String id;

    EmploymentStatus(String id) {
        this.id = id;
    }

    public String getId() {
        return id;
    }

    public static EmploymentStatus parse(String id) {
        EmploymentStatus maritalStatus = null; // Default
        for (EmploymentStatus item : EmploymentStatus.values()) {
        	if (item.getId().equals(id)) {
                maritalStatus = item;
                break;
            }
        }
        return maritalStatus;
    }

    public static String getValue(String id) {
   	 for (EmploymentStatus item : EmploymentStatus.values()) {
           if (item.name() == id) {
           		return item.getId();
           }
       }
       return null;
   }
    
   public static List<String> getAllEmploymentStatus() {
        EmploymentStatus[] values = EmploymentStatus.values();
        List<String> list = new ArrayList<>();
        for (EmploymentStatus value : values) {
            list.add(value.name());
        }
        return list;
    }
}
