package org.healthchain.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "AV_DrugCompoundMaster")
public class DrugCompoundMaster extends AuditableEntity implements BaseEntity,Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "DrugCompoundID")
	private Long drugCompoundID;
	
	@Column(name = "DrugCompoundName", length=30 , nullable = true)
	private String drugCompoundName;

	@Column(name = "DC_PackingDescription", length=60 , nullable = true)
	private String dcPackingDescription;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FK_DrugMfgrID", referencedColumnName = "DrugMfgrID", nullable = true)
	private DrugManufacturersMaster drugManufacturersMaster;
	
	@Column(name = "DCC_AvailableDose", length=20 , nullable = true)
	private String dccAvailableDose;
	
	public DrugCompoundMaster() {
		
	}

	public DrugCompoundMaster(Long drugCompoundID, String drugCompoundName, String dcPackingDescription,
			DrugManufacturersMaster drugManufacturersMaster, String dccAvailableDose) {
		super();
		this.drugCompoundID = drugCompoundID;
		this.drugCompoundName = drugCompoundName;
		this.dcPackingDescription = dcPackingDescription;
		this.drugManufacturersMaster = drugManufacturersMaster;
		this.dccAvailableDose = dccAvailableDose;
	}

	public Long getDrugCompoundID() {
		return drugCompoundID;
	}

	public String getDrugCompoundName() {
		return drugCompoundName;
	}

	public String getDcPackingDescription() {
		return dcPackingDescription;
	}

	public DrugManufacturersMaster getDrugManufacturersMaster() {
		return drugManufacturersMaster;
	}

	public String getDccAvailableDose() {
		return dccAvailableDose;
	}

	public void setDrugCompoundID(Long drugCompoundID) {
		this.drugCompoundID = drugCompoundID;
	}

	public void setDrugCompoundName(String drugCompoundName) {
		this.drugCompoundName = drugCompoundName;
	}

	public void setDcPackingDescription(String dcPackingDescription) {
		this.dcPackingDescription = dcPackingDescription;
	}

	public void setDrugManufacturersMaster(DrugManufacturersMaster drugManufacturersMaster) {
		this.drugManufacturersMaster = drugManufacturersMaster;
	}

	public void setDccAvailableDose(String dccAvailableDose) {
		this.dccAvailableDose = dccAvailableDose;
	}	
	
}
