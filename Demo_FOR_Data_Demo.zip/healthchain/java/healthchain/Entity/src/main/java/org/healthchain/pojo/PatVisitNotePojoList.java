package org.healthchain.pojo;

import java.io.Serializable;
import java.util.List;

public class PatVisitNotePojoList implements Serializable {

	private static final long serialVersionUID = 1L;
	private int totalNumber;
	private List<PatVisitNotePojo> patVisitNotePojo;
	
	public PatVisitNotePojoList() {
		
	}

	public PatVisitNotePojoList(int totalNumber, List<PatVisitNotePojo> patVisitNotePojo) {
		super();
		this.totalNumber = totalNumber;
		this.patVisitNotePojo = patVisitNotePojo;
	}

	public int getTotalNumber() {
		return totalNumber;
	}

	public List<PatVisitNotePojo> getPatVisitNotePojo() {
		return patVisitNotePojo;
	}

	public void setTotalNumber(int totalNumber) {
		this.totalNumber = totalNumber;
	}

	public void setPatVisitNotePojo(List<PatVisitNotePojo> patVisitNotePojo) {
		this.patVisitNotePojo = patVisitNotePojo;
	}

}
