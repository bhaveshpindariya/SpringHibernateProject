package org.healthchain.entity;

import java.io.Serializable;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.healthchain.entity.enums.PatientAppointmentType;

@Entity
@Table(name = "AV_PatVisitNote")
public class PatVisitNote extends AuditableEntity implements BaseEntity,Serializable{

	/**
	 * 
	 */
	
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "PatVisitNoteID")
	private Long patVisitNoteID;
	
	@Column(name = "PatVisitDate", nullable = true)
	private Date patVisitDate;
	
	@Column(name = "Pat_Symptoms", columnDefinition = "TEXT",nullable = true)
	private String patSymptoms;
	
	@Column(name = "Pat_Treatment_Provided", columnDefinition = "TEXT",nullable = true)
	private String treatmentProvided;
	
	@Column(name = "Pa_Side_Effect", columnDefinition = "TEXT",nullable = true)
	private String patSideEffect;
	
	@Column(name = "Pat_Extra_Details", columnDefinition = "TEXT",nullable = true)
	private String patExtraDetails;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FK_CFL_PatRegID", referencedColumnName = "CFL_PatRegID", nullable = true)
	private CFLPatRegistrationMap clfPatRegistrationMap;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FK_FCL_ProviderMapID", referencedColumnName = "FCL_ProviderMapID", nullable = true)
	private FCLProviderMap fclProviderMapID;
	
	@Column(name = "PatCase_PresentingComplains", columnDefinition = "TEXT",nullable = true)
	private String patCasePresentingComplains;
	
	@Column(name = "PatCase_OngoingMedications", columnDefinition = "TEXT",nullable = true)
	private String patCaseOngoingMedications;

	@Column(name = "Exists_PatVitalSign", nullable = true ,columnDefinition = "Boolean default false")
	private boolean existsPatVitalSign;
	
	@Column(name = "Exists_PatOnExaminations", nullable = true ,columnDefinition = "Boolean default false")
	private boolean existsPatOnExaminations;
	
	@Column(name = "Exists_PatInvestigationsOrders", nullable = true ,columnDefinition = "Boolean default false")
	private boolean existsPatInvestigationsOrders;
	
	@Column(name = "Exists_PatDiagnosis", nullable = true ,columnDefinition = "Boolean default false")
	private boolean existsPatDiagnosis;
	
	@Column(name = "Exists_Admission", nullable = true ,columnDefinition = "Boolean default false")
	private boolean existsAdmission;
	
	@Column(name = "Exists_PatRx", nullable = true ,columnDefinition = "Boolean default false")
	private boolean existsPatRx;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FK_AppointmentID", referencedColumnName = "PatAppointmentID", nullable = true)
	private PatAppointments appointmentID;
	
	@Column(name = "PatTransectionID", columnDefinition = "TEXT", nullable = true)
	private String patTransectionID;
	
	@Column(name = "PatHyperledgerTransectionID", columnDefinition = "TEXT", nullable = true)
	private String patHyperledgerTransectionID;
	
	@Basic
	@Column(name = "PatVisit_Type", length=20 ,nullable = true)
	@Enumerated(EnumType.STRING)
	private PatientAppointmentType patVisitType;
	
	@Column(name = "AmountBilled", nullable = true)
	private float amountBilled;
	
	@Column(name = "AmountReceived", nullable = true)
	private float amountReceived;
	
	@Transient
	private PatientMaster  patientMaster; 
	
	@Transient
	private FCLocationMap  fcLocationMap;
	
	@Transient
	private Set<DiagnosisMaster>  diagnosisMaster= new HashSet<DiagnosisMaster>(0); 
	
	@Transient
	private Set<LabReportsLevel1>  labReportsLevel1= new HashSet<LabReportsLevel1>(0);
	
	@Transient
	private Set<DrugCompoundMaster>  drugCompoundMaster= new HashSet<DrugCompoundMaster>(0);

	public PatVisitNote() {
	
	}

	public PatVisitNote(Long patVisitNoteID, Date patVisitDate, String patSymptoms, String treatmentProvided,
			String patSideEffect, String patExtraDetails, CFLPatRegistrationMap clfPatRegistrationMap,
			FCLProviderMap fclProviderMapID, String patCasePresentingComplains, String patCaseOngoingMedications,
			boolean existsPatVitalSign, boolean existsPatOnExaminations, boolean existsPatInvestigationsOrders,
			boolean existsPatDiagnosis, boolean existsAdmission, boolean existsPatRx, PatAppointments appointmentID,
			String patTransectionID, String patHyperledgerTransectionID, PatientAppointmentType patVisitType,
			float amountBilled, float amountReceived, PatientMaster patientMaster, FCLocationMap fcLocationMap,
			Set<DiagnosisMaster> diagnosisMaster, Set<LabReportsLevel1> labReportsLevel1,
			Set<DrugCompoundMaster> drugCompoundMaster) {
		super();
		this.patVisitNoteID = patVisitNoteID;
		this.patVisitDate = patVisitDate;
		this.patSymptoms = patSymptoms;
		this.treatmentProvided = treatmentProvided;
		this.patSideEffect = patSideEffect;
		this.patExtraDetails = patExtraDetails;
		this.clfPatRegistrationMap = clfPatRegistrationMap;
		this.fclProviderMapID = fclProviderMapID;
		this.patCasePresentingComplains = patCasePresentingComplains;
		this.patCaseOngoingMedications = patCaseOngoingMedications;
		this.existsPatVitalSign = existsPatVitalSign;
		this.existsPatOnExaminations = existsPatOnExaminations;
		this.existsPatInvestigationsOrders = existsPatInvestigationsOrders;
		this.existsPatDiagnosis = existsPatDiagnosis;
		this.existsAdmission = existsAdmission;
		this.existsPatRx = existsPatRx;
		this.appointmentID = appointmentID;
		this.patTransectionID = patTransectionID;
		this.patHyperledgerTransectionID = patHyperledgerTransectionID;
		this.patVisitType = patVisitType;
		this.amountBilled = amountBilled;
		this.amountReceived = amountReceived;
		this.patientMaster = patientMaster;
		this.fcLocationMap = fcLocationMap;
		this.diagnosisMaster = diagnosisMaster;
		this.labReportsLevel1 = labReportsLevel1;
		this.drugCompoundMaster = drugCompoundMaster;
	}

	public Long getPatVisitNoteID() {
		return patVisitNoteID;
	}

	public Date getPatVisitDate() {
		return patVisitDate;
	}

	public String getPatSymptoms() {
		return patSymptoms;
	}

	public String getTreatmentProvided() {
		return treatmentProvided;
	}

	public String getPatSideEffect() {
		return patSideEffect;
	}

	public String getPatExtraDetails() {
		return patExtraDetails;
	}

	public CFLPatRegistrationMap getClfPatRegistrationMap() {
		return clfPatRegistrationMap;
	}

	public FCLProviderMap getFclProviderMapID() {
		return fclProviderMapID;
	}

	public String getPatCasePresentingComplains() {
		return patCasePresentingComplains;
	}

	public String getPatCaseOngoingMedications() {
		return patCaseOngoingMedications;
	}

	public boolean isExistsPatVitalSign() {
		return existsPatVitalSign;
	}

	public boolean isExistsPatOnExaminations() {
		return existsPatOnExaminations;
	}

	public boolean isExistsPatInvestigationsOrders() {
		return existsPatInvestigationsOrders;
	}

	public boolean isExistsPatDiagnosis() {
		return existsPatDiagnosis;
	}

	public boolean isExistsAdmission() {
		return existsAdmission;
	}

	public boolean isExistsPatRx() {
		return existsPatRx;
	}

	public PatAppointments getAppointmentID() {
		return appointmentID;
	}

	public String getPatTransectionID() {
		return patTransectionID;
	}

	public String getPatHyperledgerTransectionID() {
		return patHyperledgerTransectionID;
	}

	public PatientAppointmentType getPatVisitType() {
		return patVisitType;
	}

	public float getAmountBilled() {
		return amountBilled;
	}

	public float getAmountReceived() {
		return amountReceived;
	}

	public PatientMaster getPatientMaster() {
		return patientMaster;
	}

	public FCLocationMap getFcLocationMap() {
		return fcLocationMap;
	}

	public Set<DiagnosisMaster> getDiagnosisMaster() {
		return diagnosisMaster;
	}

	public Set<LabReportsLevel1> getLabReportsLevel1() {
		return labReportsLevel1;
	}

	public Set<DrugCompoundMaster> getDrugCompoundMaster() {
		return drugCompoundMaster;
	}

	public void setPatVisitNoteID(Long patVisitNoteID) {
		this.patVisitNoteID = patVisitNoteID;
	}

	public void setPatVisitDate(Date patVisitDate) {
		this.patVisitDate = patVisitDate;
	}

	public void setPatSymptoms(String patSymptoms) {
		this.patSymptoms = patSymptoms;
	}

	public void setTreatmentProvided(String treatmentProvided) {
		this.treatmentProvided = treatmentProvided;
	}

	public void setPatSideEffect(String patSideEffect) {
		this.patSideEffect = patSideEffect;
	}

	public void setPatExtraDetails(String patExtraDetails) {
		this.patExtraDetails = patExtraDetails;
	}

	public void setClfPatRegistrationMap(CFLPatRegistrationMap clfPatRegistrationMap) {
		this.clfPatRegistrationMap = clfPatRegistrationMap;
	}

	public void setFclProviderMapID(FCLProviderMap fclProviderMapID) {
		this.fclProviderMapID = fclProviderMapID;
	}

	public void setPatCasePresentingComplains(String patCasePresentingComplains) {
		this.patCasePresentingComplains = patCasePresentingComplains;
	}

	public void setPatCaseOngoingMedications(String patCaseOngoingMedications) {
		this.patCaseOngoingMedications = patCaseOngoingMedications;
	}

	public void setExistsPatVitalSign(boolean existsPatVitalSign) {
		this.existsPatVitalSign = existsPatVitalSign;
	}

	public void setExistsPatOnExaminations(boolean existsPatOnExaminations) {
		this.existsPatOnExaminations = existsPatOnExaminations;
	}

	public void setExistsPatInvestigationsOrders(boolean existsPatInvestigationsOrders) {
		this.existsPatInvestigationsOrders = existsPatInvestigationsOrders;
	}

	public void setExistsPatDiagnosis(boolean existsPatDiagnosis) {
		this.existsPatDiagnosis = existsPatDiagnosis;
	}

	public void setExistsAdmission(boolean existsAdmission) {
		this.existsAdmission = existsAdmission;
	}

	public void setExistsPatRx(boolean existsPatRx) {
		this.existsPatRx = existsPatRx;
	}

	public void setAppointmentID(PatAppointments appointmentID) {
		this.appointmentID = appointmentID;
	}

	public void setPatTransectionID(String patTransectionID) {
		this.patTransectionID = patTransectionID;
	}

	public void setPatHyperledgerTransectionID(String patHyperledgerTransectionID) {
		this.patHyperledgerTransectionID = patHyperledgerTransectionID;
	}

	public void setPatVisitType(PatientAppointmentType patVisitType) {
		this.patVisitType = patVisitType;
	}

	public void setAmountBilled(float amountBilled) {
		this.amountBilled = amountBilled;
	}

	public void setAmountReceived(float amountReceived) {
		this.amountReceived = amountReceived;
	}

	public void setPatientMaster(PatientMaster patientMaster) {
		this.patientMaster = patientMaster;
	}

	public void setFcLocationMap(FCLocationMap fcLocationMap) {
		this.fcLocationMap = fcLocationMap;
	}

	public void setDiagnosisMaster(Set<DiagnosisMaster> diagnosisMaster) {
		this.diagnosisMaster = diagnosisMaster;
	}

	public void setLabReportsLevel1(Set<LabReportsLevel1> labReportsLevel1) {
		this.labReportsLevel1 = labReportsLevel1;
	}

	public void setDrugCompoundMaster(Set<DrugCompoundMaster> drugCompoundMaster) {
		this.drugCompoundMaster = drugCompoundMaster;
	}

}
