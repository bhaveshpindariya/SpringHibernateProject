package org.healthchain.entity.enums;

import java.util.ArrayList;
import java.util.List;

public enum ProviderTypeStatus {
	
	Doctor("Doctor"),
	HospitalUser("HospitalUser"),
	ClinicUser("ClinicUser"),
	MedicalStoreUser("MedicalStoreUser"),
	LabUser("LabUser"),
	InsurenceUser("InsurenceUser");
	
	private String id;

    ProviderTypeStatus(String id) {
        this.id = id;
    }

    public String getId() {
        return id;
    }

    public static ProviderTypeStatus parse(String id) {
        ProviderTypeStatus maritalStatus = null; // Default
        for (ProviderTypeStatus item : ProviderTypeStatus.values()) {
        	if (item.getId().equals(id)) {
                maritalStatus = item;
                break;
            }
        }
        return maritalStatus;
    }

    public static String getValue(String id) {
    	for (ProviderTypeStatus item : ProviderTypeStatus.values()) {
	         if (item.name() == id) {
	         		return item.getId();
	         }
    	}
    	return null;
    }
    
    public static List<String> getAllProviderTypeStatus() {
        ProviderTypeStatus[] values = ProviderTypeStatus.values();
        List<String> list = new ArrayList<>();
        for (ProviderTypeStatus value : values) {
            list.add(value.name());
        }
        return list;
    }
}
