package org.healthchain.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="AV_Speciality_Provider_Master")
public class SpecialityProviderMaster extends AuditableEntity implements BaseEntity,Serializable{

	
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "Spe_ProId")
	private Long speProId;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FK_SpecialityID", referencedColumnName = "SpecialityID", nullable = true)
	private SpecialityMaster specialityMaster;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FK_ProviderID", referencedColumnName = "ProviderID", nullable = true)
	private ProviderMaster providerMaster;

	public SpecialityProviderMaster() {
		
	}

	public SpecialityProviderMaster(Long speProId, SpecialityMaster specialityMaster, ProviderMaster providerMaster) {
		super();
		this.speProId = speProId;
		this.specialityMaster = specialityMaster;
		this.providerMaster = providerMaster;
	}

	public Long getSpeProId() {
		return speProId;
	}

	public SpecialityMaster getSpecialityMaster() {
		return specialityMaster;
	}

	public ProviderMaster getProviderMaster() {
		return providerMaster;
	}

	public void setSpeProId(Long speProId) {
		this.speProId = speProId;
	}

	public void setSpecialityMaster(SpecialityMaster specialityMaster) {
		this.specialityMaster = specialityMaster;
	}

	public void setProviderMaster(ProviderMaster providerMaster) {
		this.providerMaster = providerMaster;
	}
	
}
