package org.healthchain.pojo;

import java.io.Serializable;

public class UserEntityPojo implements Serializable {

	private static final long serialVersionUID = 1L;
	public Long id;
	private String name;
	private String perProfile;
	private String deviceID;
	private String deviceToken;
	private String deviceType;
	public Object data;
		
	public UserEntityPojo() {
		
	}
	
	public UserEntityPojo(Long id, String name, String perProfile, String deviceID, String deviceToken,
			String deviceType, Object data) {
		super();
		this.id = id;
		this.name = name;
		this.perProfile = perProfile;
		this.deviceID = deviceID;
		this.deviceToken = deviceToken;
		this.deviceType = deviceType;
		this.data = data;
	}
	
	public Long getId() {
		return id;
	}
	public String getName() {
		return name;
	}
	public String getPerProfile() {
		return perProfile;
	}
	public String getDeviceID() {
		return deviceID;
	}
	public String getDeviceToken() {
		return deviceToken;
	}
	public String getDeviceType() {
		return deviceType;
	}
	public Object getData() {
		return data;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public void setName(String name) {
		this.name = name;
	}
	public void setPerProfile(String perProfile) {
		this.perProfile = perProfile;
	}
	public void setDeviceID(String deviceID) {
		this.deviceID = deviceID;
	}
	public void setDeviceToken(String deviceToken) {
		this.deviceToken = deviceToken;
	}
	public void setDeviceType(String deviceType) {
		this.deviceType = deviceType;
	}
	public void setData(Object data) {
		this.data = data;
	}
	
}
