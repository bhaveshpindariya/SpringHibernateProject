package org.healthchain.pojo;

import java.io.Serializable;

public class PatientPojo implements Serializable {

	private static final long serialVersionUID = 1L;
	private Long patientID;
	private String patientName;
	
	public PatientPojo() {
		
	}

	public PatientPojo(Long patientID, String patientName) {
		super();
		this.patientID = patientID;
		this.patientName = patientName;
	}

	@Override
	public String toString() {
		return "PatientPojo [patientID=" + patientID + ", patientName=" + patientName + "]";
	}

	public Long getPatientID() {
		return patientID;
	}

	public String getPatientName() {
		return patientName;
	}

	public void setPatientID(Long patientID) {
		this.patientID = patientID;
	}

	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}
}
