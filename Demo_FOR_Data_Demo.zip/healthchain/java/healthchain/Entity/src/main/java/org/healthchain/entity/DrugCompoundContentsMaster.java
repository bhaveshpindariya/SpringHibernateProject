package org.healthchain.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "AV_DrugCompound_Contents")
public class DrugCompoundContentsMaster extends AuditableEntity implements BaseEntity,Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "DrugCompound_ContentID")
	private Long drugCompoundContentID;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FK_DrugCompoundID", referencedColumnName = "DrugCompoundID", nullable = true)
	private DrugCompoundMaster drugCompoundMaster;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FK_DrugsActiveSubstanceID", referencedColumnName = "DrugsActiveSubstanceID", nullable = true)
	private DrugsActiveSubstanceMaster drugsActiveSubstanceMaster;

	@Column(name = "DCC_AvailableDose", length=20 , nullable = true)
	private String dccAvailableDose;

	public DrugCompoundContentsMaster(Long drugCompoundContentID, DrugCompoundMaster drugCompoundMaster,
			DrugsActiveSubstanceMaster drugsActiveSubstanceMaster, String dccAvailableDose) {
		super();
		this.drugCompoundContentID = drugCompoundContentID;
		this.drugCompoundMaster = drugCompoundMaster;
		this.drugsActiveSubstanceMaster = drugsActiveSubstanceMaster;
		this.dccAvailableDose = dccAvailableDose;
	}

	public DrugCompoundContentsMaster() {

	}

	public Long getDrugCompoundContentID() {
		return drugCompoundContentID;
	}

	public void setDrugCompoundContentID(Long drugCompoundContentID) {
		this.drugCompoundContentID = drugCompoundContentID;
	}

	public DrugCompoundMaster getDrugCompoundMaster() {
		return drugCompoundMaster;
	}

	public void setDrugCompoundMaster(DrugCompoundMaster drugCompoundMaster) {
		this.drugCompoundMaster = drugCompoundMaster;
	}

	public DrugsActiveSubstanceMaster getDrugsActiveSubstanceMaster() {
		return drugsActiveSubstanceMaster;
	}

	public void setDrugsActiveSubstanceMaster(DrugsActiveSubstanceMaster drugsActiveSubstanceMaster) {
		this.drugsActiveSubstanceMaster = drugsActiveSubstanceMaster;
	}

	public String getDccAvailableDose() {
		return dccAvailableDose;
	}

	public void setDccAvailableDose(String dccAvailableDose) {
		this.dccAvailableDose = dccAvailableDose;
	}
	
}
