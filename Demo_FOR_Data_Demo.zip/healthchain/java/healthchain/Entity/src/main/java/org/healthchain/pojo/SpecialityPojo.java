package org.healthchain.pojo;

import java.io.Serializable;

public class SpecialityPojo implements Serializable {

	private static final long serialVersionUID = 1L;
	private Long specialityID;
	private String specialityName;
	private String specialityCode;
	
	public SpecialityPojo(Long specialityID, String specialityName, String specialityCode) {
		super();
		this.specialityID = specialityID;
		this.specialityName = specialityName;
		this.specialityCode = specialityCode;
	}

	public SpecialityPojo() {
		
	}

	@Override
	public String toString() {
		return "SpecialityPojo [specialityID=" + specialityID + ", specialityName=" + specialityName
				+ ", specialityCode=" + specialityCode + "]";
	}

	public Long getSpecialityID() {
		return specialityID;
	}

	public String getSpecialityName() {
		return specialityName;
	}

	public String getSpecialityCode() {
		return specialityCode;
	}

	public void setSpecialityID(Long specialityID) {
		this.specialityID = specialityID;
	}

	public void setSpecialityName(String specialityName) {
		this.specialityName = specialityName;
	}

	public void setSpecialityCode(String specialityCode) {
		this.specialityCode = specialityCode;
	}
	
	
}
