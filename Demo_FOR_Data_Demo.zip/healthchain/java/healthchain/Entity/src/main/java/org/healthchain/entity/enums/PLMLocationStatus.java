package org.healthchain.entity.enums;

import java.util.ArrayList;
import java.util.List;

public enum PLMLocationStatus {

	Resi("Resi"),
	Temp("Temp"),
	Office("Office"),
	Resi2("Resi2"),
	Office2("Office2"),
	Other("Other");
   
    private String id;

    PLMLocationStatus(String id) {
        this.id = id;
    }

    public String getId() {
        return id;
    }

    public static PLMLocationStatus parse(String id) {
        PLMLocationStatus maritalStatus = null; // Default
        for (PLMLocationStatus item : PLMLocationStatus.values()) {
        	if (item.getId().equals(id)) {
                maritalStatus = item;
                break;
            }
        }
        return maritalStatus;
    }

    public static String getValue(String id) {
    	for (PLMLocationStatus item : PLMLocationStatus.values()) {
	         if (item.name() == id) {
	         		return item.getId();
	         }
    	}
    	return null;
    }
    
    public static List<String> getAllPLMLocationStatus() {
        PLMLocationStatus[] values = PLMLocationStatus.values();
        List<String> list = new ArrayList<>();
        for (PLMLocationStatus value : values) {
            list.add(value.name());
        }
        return list;
    }
}
