package org.healthchain.pojo;

import java.io.Serializable;

public class DrugManufacturersPojo implements Serializable {

	private static final long serialVersionUID = 1L;
	private Long drugMfgrID;
	private String drugMfgrName;
	
	@Override
	public String toString() {
		return "DrugCompoundPojo [drugMfgrID=" + drugMfgrID + ", drugMfgrName=" + drugMfgrName + "]";
	}
	public DrugManufacturersPojo(Long drugMfgrID, String drugMfgrName) {
		super();
		this.drugMfgrID = drugMfgrID;
		this.drugMfgrName = drugMfgrName;
	}
	public DrugManufacturersPojo() 
	{
		
	}
	public Long getDrugMfgrID() {
		return drugMfgrID;
	}
	public void setDrugMfgrID(Long drugMfgrID) {
		this.drugMfgrID = drugMfgrID;
	}
	public String getDrugMfgrName() {
		return drugMfgrName;
	}
	public void setDrugMfgrName(String drugMfgrName) {
		this.drugMfgrName = drugMfgrName;
	}
	
	

	
}
