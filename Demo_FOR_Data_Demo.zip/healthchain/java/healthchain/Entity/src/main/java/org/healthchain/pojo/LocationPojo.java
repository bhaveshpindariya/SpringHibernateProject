package org.healthchain.pojo;

import java.io.Serializable;

public class LocationPojo implements Serializable {

	private static final long serialVersionUID = 1L;
	private Long locationID;
	private String addressLine1; 
	private String addressLine2;
	private String addressLine3;
	private String area;
	private String city;
	private String state;
	private Long zip;
	private String country;
	private String milestone1;
	private String milestone2;
	private Long fcLocationMapID;
	private String fcLocationName;
	private TimeZonePojo timeZoneMaster;
	
	public LocationPojo() {
		
	}

	public LocationPojo(Long locationID, String addressLine1, String addressLine2, String addressLine3, String area,
			String city, String state, Long zip, String country, String milestone1, String milestone2,
			Long fcLocationMapID, String fcLocationName, TimeZonePojo timeZoneMaster) {
		super();
		this.locationID = locationID;
		this.addressLine1 = addressLine1;
		this.addressLine2 = addressLine2;
		this.addressLine3 = addressLine3;
		this.area = area;
		this.city = city;
		this.state = state;
		this.zip = zip;
		this.country = country;
		this.milestone1 = milestone1;
		this.milestone2 = milestone2;
		this.fcLocationMapID = fcLocationMapID;
		this.fcLocationName = fcLocationName;
		this.timeZoneMaster = timeZoneMaster;
	}

	public Long getLocationID() {
		return locationID;
	}

	public String getAddressLine1() {
		return addressLine1;
	}

	public String getAddressLine2() {
		return addressLine2;
	}

	public String getAddressLine3() {
		return addressLine3;
	}

	public String getArea() {
		return area;
	}

	public String getCity() {
		return city;
	}

	public String getState() {
		return state;
	}

	public Long getZip() {
		return zip;
	}

	public String getCountry() {
		return country;
	}

	public String getMilestone1() {
		return milestone1;
	}

	public String getMilestone2() {
		return milestone2;
	}

	public Long getFcLocationMapID() {
		return fcLocationMapID;
	}

	public String getFcLocationName() {
		return fcLocationName;
	}

	public TimeZonePojo getTimeZoneMaster() {
		return timeZoneMaster;
	}

	public void setLocationID(Long locationID) {
		this.locationID = locationID;
	}

	public void setAddressLine1(String addressLine1) {
		this.addressLine1 = addressLine1;
	}

	public void setAddressLine2(String addressLine2) {
		this.addressLine2 = addressLine2;
	}

	public void setAddressLine3(String addressLine3) {
		this.addressLine3 = addressLine3;
	}

	public void setArea(String area) {
		this.area = area;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public void setState(String state) {
		this.state = state;
	}

	public void setZip(Long zip) {
		this.zip = zip;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public void setMilestone1(String milestone1) {
		this.milestone1 = milestone1;
	}

	public void setMilestone2(String milestone2) {
		this.milestone2 = milestone2;
	}

	public void setFcLocationMapID(Long fcLocationMapID) {
		this.fcLocationMapID = fcLocationMapID;
	}

	public void setFcLocationName(String fcLocationName) {
		this.fcLocationName = fcLocationName;
	}

	public void setTimeZoneMaster(TimeZonePojo timeZoneMaster) {
		this.timeZoneMaster = timeZoneMaster;
	}

}
