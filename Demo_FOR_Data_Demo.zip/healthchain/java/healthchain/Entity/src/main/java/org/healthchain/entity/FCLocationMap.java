package org.healthchain.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import net.sf.json.JSONArray;

@Entity
@Table(name = "AV_FC_LocationMap")
public class FCLocationMap extends AuditableEntity implements BaseEntity,Serializable{
	
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "FCLocationMapID")
	private Long fcLocationMapID;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FK_FacilityCenterID", referencedColumnName = "FacilityCenterID", nullable = true)
	private FacilityCenterMaster facilityCenterMaster;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FK_LocationID", referencedColumnName = "LocationID", nullable = true)
	private LocationMaster locationMaster;
	
	@Column(name = "FCLocation_Name", length=60 ,nullable = true)
	private String fcLocationName;
	
	@Column(name = "FCL_Land_Lines", nullable = true)
	private JSONArray fclLandLines;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FK_PersonID_FCL_Contact", referencedColumnName = "PersonID", nullable = true)
	private PersonMaster personMaster;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FK_ProviderID_Registered", referencedColumnName = "ProviderID", nullable = true)
	private ProviderMaster providerMaster;
	
	@Column(name = "FCL_CertificateNumber", length=40 ,nullable = true)
	private String fclCertificateNumber;
	
	@Column(name = "DoesOfferHomeservice", nullable = true , columnDefinition = "Boolean default false")
	private boolean doesOfferHomeservice;
	
	@Column(name = "HaveChildDepartmentsMap", nullable = true)
	private int havechildDepartmentMapCount;

	public FCLocationMap() {
		
	}

	public FCLocationMap(Long fcLocationMapID, FacilityCenterMaster facilityCenterMaster, LocationMaster locationMaster,
			String fcLocationName, JSONArray fclLandLines, PersonMaster personMaster, ProviderMaster providerMaster,
			String fclCertificateNumber, boolean doesOfferHomeservice, int havechildDepartmentMapCount) {
		super();
		this.fcLocationMapID = fcLocationMapID;
		this.facilityCenterMaster = facilityCenterMaster;
		this.locationMaster = locationMaster;
		this.fcLocationName = fcLocationName;
		this.fclLandLines = fclLandLines;
		this.personMaster = personMaster;
		this.providerMaster = providerMaster;
		this.fclCertificateNumber = fclCertificateNumber;
		this.doesOfferHomeservice = doesOfferHomeservice;
		this.havechildDepartmentMapCount = havechildDepartmentMapCount;
	}

	public Long getFcLocationMapID() {
		return fcLocationMapID;
	}

	public FacilityCenterMaster getFacilityCenterMaster() {
		return facilityCenterMaster;
	}

	public LocationMaster getLocationMaster() {
		return locationMaster;
	}

	public String getFcLocationName() {
		return fcLocationName;
	}

	public JSONArray getFclLandLines() {
		return fclLandLines;
	}

	public PersonMaster getPersonMaster() {
		return personMaster;
	}

	public ProviderMaster getProviderMaster() {
		return providerMaster;
	}

	public String getFclCertificateNumber() {
		return fclCertificateNumber;
	}

	public boolean isDoesOfferHomeservice() {
		return doesOfferHomeservice;
	}

	public int getHavechildDepartmentMapCount() {
		return havechildDepartmentMapCount;
	}

	public void setFcLocationMapID(Long fcLocationMapID) {
		this.fcLocationMapID = fcLocationMapID;
	}

	public void setFacilityCenterMaster(FacilityCenterMaster facilityCenterMaster) {
		this.facilityCenterMaster = facilityCenterMaster;
	}

	public void setLocationMaster(LocationMaster locationMaster) {
		this.locationMaster = locationMaster;
	}

	public void setFcLocationName(String fcLocationName) {
		this.fcLocationName = fcLocationName;
	}

	public void setFclLandLines(JSONArray fclLandLines) {
		this.fclLandLines = fclLandLines;
	}

	public void setPersonMaster(PersonMaster personMaster) {
		this.personMaster = personMaster;
	}

	public void setProviderMaster(ProviderMaster providerMaster) {
		this.providerMaster = providerMaster;
	}

	public void setFclCertificateNumber(String fclCertificateNumber) {
		this.fclCertificateNumber = fclCertificateNumber;
	}

	public void setDoesOfferHomeservice(boolean doesOfferHomeservice) {
		this.doesOfferHomeservice = doesOfferHomeservice;
	}

	public void setHavechildDepartmentMapCount(int havechildDepartmentMapCount) {
		this.havechildDepartmentMapCount = havechildDepartmentMapCount;
	}
	
}
