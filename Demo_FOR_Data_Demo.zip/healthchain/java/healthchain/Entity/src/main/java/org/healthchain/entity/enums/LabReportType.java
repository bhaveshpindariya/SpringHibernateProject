package org.healthchain.entity.enums;

import java.util.ArrayList;
import java.util.List;

public enum LabReportType {
	
	Pathology("Pathology"),
	RadioImaging("RadioImaging");
        
    private String id;

    LabReportType(String id) {
        this.id = id;
    }

    public String getId() {
        return id;
    }

    public static LabReportType parse(String id) {
    	LabReportType currencyType = null; // Default
        for (LabReportType item : LabReportType.values()) {
        	if (item.getId().equals(id)) {
            	currencyType = item;
                break;
            }
        }
        return currencyType;
    }
    
    public static String getValue(String id) {
   	 for (LabReportType item : LabReportType.values()) {
           if (item.name() == id) {
           		return item.getId();
           }
       }
       return null;
    }
    
    public static List<String> getAllCurrencyType() {
    	LabReportType[] values = LabReportType.values();
        List<String> list = new ArrayList<>();
        for (LabReportType value : values) {
            list.add(value.name());
        }
        return list;
    }
}
