package org.healthchain.pojo;

import java.io.Serializable;

public class ClientPojo implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private Long clientID;
	private String clientComapnyName;
	private String websiteURL;
	public Object timeZoneMaster;
	
	public ClientPojo() {
		
	}

	@Override
	public String toString() {
		return "ClientPojo [clientID=" + clientID + ", clientComapnyName=" + clientComapnyName + ", websiteURL="
				+ websiteURL + ", timeZoneMaster=" + timeZoneMaster + "]";
	}

	public ClientPojo(Long clientID, String clientComapnyName, String websiteURL, Object timeZoneMaster) {
		super();
		this.clientID = clientID;
		this.clientComapnyName = clientComapnyName;
		this.websiteURL = websiteURL;
		this.timeZoneMaster = timeZoneMaster;
	}

	public Long getClientID() {
		return clientID;
	}

	public String getClientComapnyName() {
		return clientComapnyName;
	}

	public String getWebsiteURL() {
		return websiteURL;
	}

	public Object getTimeZoneMaster() {
		return timeZoneMaster;
	}

	public void setClientID(Long clientID) {
		this.clientID = clientID;
	}

	public void setClientComapnyName(String clientComapnyName) {
		this.clientComapnyName = clientComapnyName;
	}

	public void setWebsiteURL(String websiteURL) {
		this.websiteURL = websiteURL;
	}

	public void setTimeZoneMaster(Object timeZoneMaster) {
		this.timeZoneMaster = timeZoneMaster;
	}

	
}
