package org.healthchain.entity;


public interface BaseEntity {

}
