package org.healthchain.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "AV_ClientMaster")
public class ClientMaster extends AuditableEntity implements BaseEntity,Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "ClientID")
	private Long clientID;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FK_PersonID", referencedColumnName = "PersonID", nullable = true)
	private PersonMaster personMaster;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FK_UTC_TimeZoneID", referencedColumnName = "UTC_TimeZoneID", nullable = true)
	private TimeZoneMaster timeZoneMaster;
	
	@Column(name = "ClientComapnyName", length=60 ,nullable = true)
	private String clientComapnyName;
	
	@Column(name = "WebsiteURL", length=60 ,nullable = true)
	private String websiteURL;

	public ClientMaster(Long clientID, PersonMaster personMaster, TimeZoneMaster timeZoneMaster,
			String clientComapnyName, String websiteURL) {
		super();
		this.clientID = clientID;
		this.personMaster = personMaster;
		this.timeZoneMaster = timeZoneMaster;
		this.clientComapnyName = clientComapnyName;
		this.websiteURL = websiteURL;
	}

	public ClientMaster() {
	
	}

	public Long getClientID() {
		return clientID;
	}

	public void setClientID(Long clientID) {
		this.clientID = clientID;
	}

	public PersonMaster getPersonMaster() {
		return personMaster;
	}

	public void setPersonMaster(PersonMaster personMaster) {
		this.personMaster = personMaster;
	}

	public TimeZoneMaster getTimeZoneMaster() {
		return timeZoneMaster;
	}

	public void setTimeZoneMaster(TimeZoneMaster timeZoneMaster) {
		this.timeZoneMaster = timeZoneMaster;
	}

	public String getClientComapnyName() {
		return clientComapnyName;
	}

	public void setClientComapnyName(String clientComapnyName) {
		this.clientComapnyName = clientComapnyName;
	}

	public String getWebsiteURL() {
		return websiteURL;
	}

	public void setWebsiteURL(String websiteURL) {
		this.websiteURL = websiteURL;
	}

	
}
