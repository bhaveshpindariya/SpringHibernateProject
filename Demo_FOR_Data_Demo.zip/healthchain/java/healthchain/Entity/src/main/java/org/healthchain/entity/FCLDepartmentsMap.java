package org.healthchain.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="AV_FCL_DepartmentsMap")
public class FCLDepartmentsMap extends AuditableEntity implements BaseEntity,Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "FCL_DepartmentMapID")
	private Long fclDepartmentMapID;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FK_FCLocationMapID", referencedColumnName = "FCLocationMapID", nullable = true)
	private FCLocationMap fCLocationMap;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FK_DepartmentID", referencedColumnName = "DepartmentID", nullable = true)
	private DepartmentMaster departmentMaster;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FK_SpecialityID", referencedColumnName = "SpecialityID", nullable = true)
	private SpecialityMaster specialityMaster;
	
	@Column(name = "Total_Bed_Count", nullable = true)
	private int totalBedCount;

	public FCLDepartmentsMap(Long fclDepartmentMapID, FCLocationMap fCLocationMap, DepartmentMaster departmentMaster,
			SpecialityMaster specialityMaster, int totalBedCount) {
		super();
		this.fclDepartmentMapID = fclDepartmentMapID;
		this.fCLocationMap = fCLocationMap;
		this.departmentMaster = departmentMaster;
		this.specialityMaster = specialityMaster;
		this.totalBedCount = totalBedCount;
	}

	public FCLDepartmentsMap() {
		
	}

	public Long getFclDepartmentMapID() {
		return fclDepartmentMapID;
	}

	public FCLocationMap getfCLocationMap() {
		return fCLocationMap;
	}

	public DepartmentMaster getDepartmentMaster() {
		return departmentMaster;
	}

	public SpecialityMaster getSpecialityMaster() {
		return specialityMaster;
	}

	public int getTotalBedCount() {
		return totalBedCount;
	}

	public void setFclDepartmentMapID(Long fclDepartmentMapID) {
		this.fclDepartmentMapID = fclDepartmentMapID;
	}

	public void setfCLocationMap(FCLocationMap fCLocationMap) {
		this.fCLocationMap = fCLocationMap;
	}

	public void setDepartmentMaster(DepartmentMaster departmentMaster) {
		this.departmentMaster = departmentMaster;
	}

	public void setSpecialityMaster(SpecialityMaster specialityMaster) {
		this.specialityMaster = specialityMaster;
	}

	public void setTotalBedCount(int totalBedCount) {
		this.totalBedCount = totalBedCount;
	}
}