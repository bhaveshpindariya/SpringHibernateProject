package org.healthchain.pojo;

import java.io.Serializable;

public class MedicalstorePojo implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private Long personID;
	private Object perEmailList;
	private String perEmailPrimary;
	private String perFname;
	private String userName;
	private String perLName;
	private String perProfile;
	private Long facilityCenterID;
	private String facilityCenterName;
	private String additionalInformation;
	
	public MedicalstorePojo() {
		
	}

	public MedicalstorePojo(Long personID, Object perEmailList, String perEmailPrimary, String perFname,
			String userName, String perLName, String perProfile, Long facilityCenterID, String facilityCenterName,
			String additionalInformation) {
		super();
		this.personID = personID;
		this.perEmailList = perEmailList;
		this.perEmailPrimary = perEmailPrimary;
		this.perFname = perFname;
		this.userName = userName;
		this.perLName = perLName;
		this.perProfile = perProfile;
		this.facilityCenterID = facilityCenterID;
		this.facilityCenterName = facilityCenterName;
		this.additionalInformation = additionalInformation;
	}

	public Long getPersonID() {
		return personID;
	}

	public Object getPerEmailList() {
		return perEmailList;
	}

	public String getPerEmailPrimary() {
		return perEmailPrimary;
	}

	public String getPerFname() {
		return perFname;
	}

	public String getUserName() {
		return userName;
	}

	public String getPerLName() {
		return perLName;
	}

	public String getPerProfile() {
		return perProfile;
	}

	public Long getFacilityCenterID() {
		return facilityCenterID;
	}

	public String getFacilityCenterName() {
		return facilityCenterName;
	}

	public String getAdditionalInformation() {
		return additionalInformation;
	}

	public void setPersonID(Long personID) {
		this.personID = personID;
	}

	public void setPerEmailList(Object perEmailList) {
		this.perEmailList = perEmailList;
	}

	public void setPerEmailPrimary(String perEmailPrimary) {
		this.perEmailPrimary = perEmailPrimary;
	}

	public void setPerFname(String perFname) {
		this.perFname = perFname;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public void setPerLName(String perLName) {
		this.perLName = perLName;
	}

	public void setPerProfile(String perProfile) {
		this.perProfile = perProfile;
	}

	public void setFacilityCenterID(Long facilityCenterID) {
		this.facilityCenterID = facilityCenterID;
	}

	public void setFacilityCenterName(String facilityCenterName) {
		this.facilityCenterName = facilityCenterName;
	}

	public void setAdditionalInformation(String additionalInformation) {
		this.additionalInformation = additionalInformation;
	}
}
