package org.healthchain.entity;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.healthchain.entity.enums.PatientAppointmentStatus;
import org.healthchain.entity.enums.PatientAppointmentType;

@Entity
@Table(name = "AV_PatMedicalAppointments")
public class PatMedicalAppointments extends AuditableEntity implements BaseEntity,Serializable{

	/**
	 * 
	 */
	
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "PatMedicalAppointmentID")
	private Long patMedicalAppointmentID;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FK_CFL_PatRegID", referencedColumnName = "CFL_PatRegID", nullable = true)
	private CFLPatRegistrationMap fclpID;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FK_FCL_ProviderMapID", referencedColumnName = "FCL_ProviderMapID", nullable = true)
	private FCLProviderMap fclProviderMapID;
	
	@Column(name = "PatMedicalApp_Date", nullable = true)
	private Long patMedicalAppDate;
	
	@Column(name = "PatMedicalApp_TimeFrom", nullable = true)
	private Long patMedicalAppTimeFrom;
	
	@Column(name = "PatMedicalApp_TimeTo", nullable = true)
	private Long patMedicalAppTimeTo;
	
	@Column(name = "PatMedicalApp_TimeUnit", length=20 ,nullable = true)
	private String patMedicalAppTimeUnit;
	
	@Column(name = "PatMedicalApp_TimeSlot", nullable = true)
	private Long patMedicalAppTimeSlot;
	
	@Basic
	@Column(name = "PatMedicalApp_Type", length=30 ,nullable = true)
	@Enumerated(EnumType.STRING)
	private PatientAppointmentType patAppType;
	
	@Column(name = "PatMedicalApp_Detail", columnDefinition = "TEXT",nullable = true)
	private String patMedicalAppDetail;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FK_PatVisitNoteID", referencedColumnName = "PatVisitNoteID", nullable = true)
	private PatVisitNote patVisitNote;
	
	@Column(name = "PatMedicalApp_Description", columnDefinition = "TEXT",nullable = true)
	private String patMedicalAppDescription;
	
	@Basic
	@Column(name = "PatMedicalApp_Status", length=30 ,nullable = true)
	@Enumerated(EnumType.STRING)
	private PatientAppointmentStatus patAppStatus;
	
	@Column(name = "ReasonIfCancelled", length=60 ,nullable = true)
	private String reasonIfCancelled;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FK_PatMedicalAppointmentID_IfReBooked", referencedColumnName = "PatMedicalAppointmentID", nullable = true)
	private PatMedicalAppointments patMedicalAppointments;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FK_SpecialityID", referencedColumnName = "SpecialityID", nullable = true)
	private SpecialityMaster specialityMaster;
	
	@Transient
	private Set<DrugCompoundMaster>  drugCompoundID= new HashSet<DrugCompoundMaster>(0);

	public PatMedicalAppointments() {
		
	}

	public PatMedicalAppointments(Long patMedicalAppointmentID, CFLPatRegistrationMap fclpID,
			FCLProviderMap fclProviderMapID, Long patMedicalAppDate, Long patMedicalAppTimeFrom,
			Long patMedicalAppTimeTo, String patMedicalAppTimeUnit, Long patMedicalAppTimeSlot,
			PatientAppointmentType patAppType, String patMedicalAppDetail, PatVisitNote patVisitNote,
			String patMedicalAppDescription, PatientAppointmentStatus patAppStatus, String reasonIfCancelled,
			PatMedicalAppointments patMedicalAppointments, SpecialityMaster specialityMaster,
			Set<DrugCompoundMaster> drugCompoundID) {
		super();
		this.patMedicalAppointmentID = patMedicalAppointmentID;
		this.fclpID = fclpID;
		this.fclProviderMapID = fclProviderMapID;
		this.patMedicalAppDate = patMedicalAppDate;
		this.patMedicalAppTimeFrom = patMedicalAppTimeFrom;
		this.patMedicalAppTimeTo = patMedicalAppTimeTo;
		this.patMedicalAppTimeUnit = patMedicalAppTimeUnit;
		this.patMedicalAppTimeSlot = patMedicalAppTimeSlot;
		this.patAppType = patAppType;
		this.patMedicalAppDetail = patMedicalAppDetail;
		this.patVisitNote = patVisitNote;
		this.patMedicalAppDescription = patMedicalAppDescription;
		this.patAppStatus = patAppStatus;
		this.reasonIfCancelled = reasonIfCancelled;
		this.patMedicalAppointments = patMedicalAppointments;
		this.specialityMaster = specialityMaster;
		this.drugCompoundID = drugCompoundID;
	}

	public Long getPatMedicalAppointmentID() {
		return patMedicalAppointmentID;
	}

	public CFLPatRegistrationMap getFclpID() {
		return fclpID;
	}

	public FCLProviderMap getFclProviderMapID() {
		return fclProviderMapID;
	}

	public Long getPatMedicalAppDate() {
		return patMedicalAppDate;
	}

	public Long getPatMedicalAppTimeFrom() {
		return patMedicalAppTimeFrom;
	}

	public Long getPatMedicalAppTimeTo() {
		return patMedicalAppTimeTo;
	}

	public String getPatMedicalAppTimeUnit() {
		return patMedicalAppTimeUnit;
	}

	public Long getPatMedicalAppTimeSlot() {
		return patMedicalAppTimeSlot;
	}

	public PatientAppointmentType getPatAppType() {
		return patAppType;
	}

	public String getPatMedicalAppDetail() {
		return patMedicalAppDetail;
	}

	public PatVisitNote getPatVisitNote() {
		return patVisitNote;
	}

	public String getPatMedicalAppDescription() {
		return patMedicalAppDescription;
	}

	public PatientAppointmentStatus getPatAppStatus() {
		return patAppStatus;
	}

	public String getReasonIfCancelled() {
		return reasonIfCancelled;
	}

	public PatMedicalAppointments getPatMedicalAppointments() {
		return patMedicalAppointments;
	}

	public SpecialityMaster getSpecialityMaster() {
		return specialityMaster;
	}

	public Set<DrugCompoundMaster> getDrugCompoundID() {
		return drugCompoundID;
	}

	public void setPatMedicalAppointmentID(Long patMedicalAppointmentID) {
		this.patMedicalAppointmentID = patMedicalAppointmentID;
	}

	public void setFclpID(CFLPatRegistrationMap fclpID) {
		this.fclpID = fclpID;
	}

	public void setFclProviderMapID(FCLProviderMap fclProviderMapID) {
		this.fclProviderMapID = fclProviderMapID;
	}

	public void setPatMedicalAppDate(Long patMedicalAppDate) {
		this.patMedicalAppDate = patMedicalAppDate;
	}

	public void setPatMedicalAppTimeFrom(Long patMedicalAppTimeFrom) {
		this.patMedicalAppTimeFrom = patMedicalAppTimeFrom;
	}

	public void setPatMedicalAppTimeTo(Long patMedicalAppTimeTo) {
		this.patMedicalAppTimeTo = patMedicalAppTimeTo;
	}

	public void setPatMedicalAppTimeUnit(String patMedicalAppTimeUnit) {
		this.patMedicalAppTimeUnit = patMedicalAppTimeUnit;
	}

	public void setPatMedicalAppTimeSlot(Long patMedicalAppTimeSlot) {
		this.patMedicalAppTimeSlot = patMedicalAppTimeSlot;
	}

	public void setPatAppType(PatientAppointmentType patAppType) {
		this.patAppType = patAppType;
	}

	public void setPatMedicalAppDetail(String patMedicalAppDetail) {
		this.patMedicalAppDetail = patMedicalAppDetail;
	}

	public void setPatVisitNote(PatVisitNote patVisitNote) {
		this.patVisitNote = patVisitNote;
	}

	public void setPatMedicalAppDescription(String patMedicalAppDescription) {
		this.patMedicalAppDescription = patMedicalAppDescription;
	}

	public void setPatAppStatus(PatientAppointmentStatus patAppStatus) {
		this.patAppStatus = patAppStatus;
	}

	public void setReasonIfCancelled(String reasonIfCancelled) {
		this.reasonIfCancelled = reasonIfCancelled;
	}

	public void setPatMedicalAppointments(PatMedicalAppointments patMedicalAppointments) {
		this.patMedicalAppointments = patMedicalAppointments;
	}

	public void setSpecialityMaster(SpecialityMaster specialityMaster) {
		this.specialityMaster = specialityMaster;
	}

	public void setDrugCompoundID(Set<DrugCompoundMaster> drugCompoundID) {
		this.drugCompoundID = drugCompoundID;
	}
	
}
