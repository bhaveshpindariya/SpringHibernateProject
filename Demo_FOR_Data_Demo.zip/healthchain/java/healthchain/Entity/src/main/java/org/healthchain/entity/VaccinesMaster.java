package org.healthchain.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "AV_VaccinesMaster")
public class VaccinesMaster extends AuditableEntity implements BaseEntity,Serializable{

	/**
	 * 
	 */
	
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "VaccineID")
	private Long vaccineID;
	
	@Column(name = "VaccineName", length=30 ,nullable = true)
	private String vaccineName;
	
	@Column(name = "VaccineBrand", length=30 ,nullable = true)
	private String vaccineBrand;
	
	@Column(name = "VaccineContent", length=110 ,nullable = true)
	private String vaccineContent;
	
	@Column(name = "Vaccine_Route", length=30 ,nullable = true)
	private String vaccineRoute;
	
	@Column(name = "VaccineDoseSpecifications", length=30 ,nullable = true)
	private String vaccineDoseSpecifications;

	public VaccinesMaster(Long vaccineID, String vaccineName, String vaccineBrand, String vaccineContent,
			String vaccineRoute, String vaccineDoseSpecifications) {
		super();
		this.vaccineID = vaccineID;
		this.vaccineName = vaccineName;
		this.vaccineBrand = vaccineBrand;
		this.vaccineContent = vaccineContent;
		this.vaccineRoute = vaccineRoute;
		this.vaccineDoseSpecifications = vaccineDoseSpecifications;
	}

	public VaccinesMaster() {
		
	}

	public Long getVaccineID() {
		return vaccineID;
	}

	public void setVaccineID(Long vaccineID) {
		this.vaccineID = vaccineID;
	}

	public String getVaccineName() {
		return vaccineName;
	}

	public void setVaccineName(String vaccineName) {
		this.vaccineName = vaccineName;
	}

	public String getVaccineBrand() {
		return vaccineBrand;
	}

	public void setVaccineBrand(String vaccineBrand) {
		this.vaccineBrand = vaccineBrand;
	}

	public String getVaccineContent() {
		return vaccineContent;
	}

	public void setVaccineContent(String vaccineContent) {
		this.vaccineContent = vaccineContent;
	}

	public String getVaccineRoute() {
		return vaccineRoute;
	}

	public void setVaccineRoute(String vaccineRoute) {
		this.vaccineRoute = vaccineRoute;
	}

	public String getVaccineDoseSpecifications() {
		return vaccineDoseSpecifications;
	}

	public void setVaccineDoseSpecifications(String vaccineDoseSpecifications) {
		this.vaccineDoseSpecifications = vaccineDoseSpecifications;
	}
	
}
