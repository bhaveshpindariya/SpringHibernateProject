package org.healthchain.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "AV_FCLPS_TimeAvailability_Map")
public class FCLPSTimeAvailabilityMap extends AuditableEntity implements BaseEntity,Serializable{
	
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "FCL_TimesAvailabilityID")
	private Long fclTimesAvailabilityID;
	
	@Column(name = "Provider_StaffType", nullable = true)
	private String providerStaffType;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FK_FCL_ProviderMapID", referencedColumnName = "FCL_ProviderMapID", nullable = true)
	private FCLProviderMap fclProviderMapID;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FK_FCL_StaffMapID", referencedColumnName = "FCL_StaffMapID", nullable = true)
	private FCLStaffMap fclStaffMapID;
	
	@Column(name = "FCLT_CronExpression1", length=80 , nullable = true)
	private String fcltCronExpression1;
	
	@Column(name = "FCLT_CronExpression2", length=80 ,nullable = true)
	private String fcltCronExpression2;
	
	@Column(name = "FCLT_CronExpression3", length=80 ,nullable = true)
	private String fcltCronExpression3;

	public FCLPSTimeAvailabilityMap(Long fclTimesAvailabilityID, String providerStaffType,
			FCLProviderMap fclProviderMapID, FCLStaffMap fclStaffMapID, String fcltCronExpression1,
			String fcltCronExpression2, String fcltCronExpression3) {
		super();
		this.fclTimesAvailabilityID = fclTimesAvailabilityID;
		this.providerStaffType = providerStaffType;
		this.fclProviderMapID = fclProviderMapID;
		this.fclStaffMapID = fclStaffMapID;
		this.fcltCronExpression1 = fcltCronExpression1;
		this.fcltCronExpression2 = fcltCronExpression2;
		this.fcltCronExpression3 = fcltCronExpression3;
	}

	public FCLPSTimeAvailabilityMap() {
		
	}

	public Long getFclTimesAvailabilityID() {
		return fclTimesAvailabilityID;
	}

	public void setFclTimesAvailabilityID(Long fclTimesAvailabilityID) {
		this.fclTimesAvailabilityID = fclTimesAvailabilityID;
	}

	public String getProviderStaffType() {
		return providerStaffType;
	}

	public void setProviderStaffType(String providerStaffType) {
		this.providerStaffType = providerStaffType;
	}

	public FCLProviderMap getFclProviderMapID() {
		return fclProviderMapID;
	}

	public void setFclProviderMapID(FCLProviderMap fclProviderMapID) {
		this.fclProviderMapID = fclProviderMapID;
	}

	public FCLStaffMap getFclStaffMapID() {
		return fclStaffMapID;
	}

	public void setFclStaffMapID(FCLStaffMap fclStaffMapID) {
		this.fclStaffMapID = fclStaffMapID;
	}

	public String getFcltCronExpression1() {
		return fcltCronExpression1;
	}

	public void setFcltCronExpression1(String fcltCronExpression1) {
		this.fcltCronExpression1 = fcltCronExpression1;
	}

	public String getFcltCronExpression2() {
		return fcltCronExpression2;
	}

	public void setFcltCronExpression2(String fcltCronExpression2) {
		this.fcltCronExpression2 = fcltCronExpression2;
	}

	public String getFcltCronExpression3() {
		return fcltCronExpression3;
	}

	public void setFcltCronExpression3(String fcltCronExpression3) {
		this.fcltCronExpression3 = fcltCronExpression3;
	}
	
	
	
	

	
}
