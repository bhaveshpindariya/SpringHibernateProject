package org.healthchain.entity.enums;

import java.util.ArrayList;
import java.util.List;

public enum PatientAppointmentStatus {

	Pending("Pending"),
	Approved("Approved"),
	Rejected("Rejected"),
	Cancel("Cancel"),
	Completed("Completed");

	private String id;

    PatientAppointmentStatus(String id) {
        this.id = id;
    }

    public String getId() {
        return id;
    }

    public static PatientAppointmentStatus parse(String id) {
    	PatientAppointmentStatus patAppStatus = null; // Default
        for (PatientAppointmentStatus item : PatientAppointmentStatus.values()) {
            if (item.getId().equals(id)) {
            	patAppStatus = item;
                break;
            }
        }
        return patAppStatus;
    }

    public static String getValue(String id) {
    	for (PatientAppointmentStatus item : PatientAppointmentStatus.values()) {
	         if (item.name() == id) {
	         		return item.getId();
	         }
    	}
    	return null;
    }
    
    public static List<String> getAllPatientAppointmentStatus() {
    	PatientAppointmentStatus[] values = PatientAppointmentStatus.values();
        List<String> list = new ArrayList<>();
        for (PatientAppointmentStatus value : values) {
            list.add(value.name());
        }
        return list;
    }
}
