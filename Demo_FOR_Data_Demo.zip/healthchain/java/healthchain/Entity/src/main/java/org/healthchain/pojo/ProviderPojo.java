package org.healthchain.pojo;

import java.io.Serializable;

import org.healthchain.entity.enums.ProviderTypeStatus;

public class ProviderPojo implements Serializable {

	private static final long serialVersionUID = 1L;
	private Long providerID;
	private Long fclProviderMapID;
	private String providerName;
	private ProviderTypeStatus providerTypeStatus;
	
	public ProviderPojo() {
		
	}

	public ProviderPojo(Long providerID,Long fclProviderMapID, String providerName, ProviderTypeStatus providerTypeStatus) {
		super();
		this.providerID = providerID;
		this.fclProviderMapID = fclProviderMapID;
		this.providerName = providerName;
		this.providerTypeStatus = providerTypeStatus;
	}

	@Override
	public String toString() {
		return "ProviderPojo [providerID=" + providerID + ", fclProviderMapID=" + fclProviderMapID + ", providerName=" + providerName
				+ ", providerTypeStatus=" + providerTypeStatus + "]";
	}

	public Long getProviderID() {
		return providerID;
	}

	public Long getFclProviderMapID() {
		return fclProviderMapID;
	}

	public String getProviderName() {
		return providerName;
	}

	public ProviderTypeStatus getProviderTypeStatus() {
		return providerTypeStatus;
	}

	public void setProviderID(Long providerID) {
		this.providerID = providerID;
	}

	public void setFclProviderMapID(Long fclProviderMapID) {
		this.fclProviderMapID = fclProviderMapID;
	}

	public void setProviderName(String providerName) {
		this.providerName = providerName;
	}

	public void setProviderTypeStatus(ProviderTypeStatus providerTypeStatus) {
		this.providerTypeStatus = providerTypeStatus;
	}

}
