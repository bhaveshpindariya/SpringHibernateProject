package org.healthchain.entity.enums;

import java.util.ArrayList;
import java.util.List;

public enum FacilityCenterType {

	Hospital("Hospital"),
	Clinic("Clinic"),
	MedicalStore("MedicalStore"),
	Lab("Lab"),
	Insurence("Insurence"); 
	
    private String id;

    FacilityCenterType(String id) {
        this.id = id;
    }

    public String getId() {
        return id;
    }

    public static FacilityCenterType parse(String id) {
    	FacilityCenterType facilityCenterType = null; // Default
        for (FacilityCenterType item : FacilityCenterType.values()) {
        	if (item.getId().equals(id)) {
            	facilityCenterType = item;
                break;
            }
        }
        return facilityCenterType;
    }

    
    public static String getValue(String id) {
    	 for (FacilityCenterType item : FacilityCenterType.values()) {
            if (item.name() == id) {
            		return item.getId();
            }
        }
        return null;
    }
    
    public static List<String> getFacilityCenterType() {
    	FacilityCenterType[] values = FacilityCenterType.values();
        List<String> list = new ArrayList<>();
        for (FacilityCenterType value : values) {
            list.add(value.name());
        }
        return list;
    }
}
