package org.healthchain.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "AV_DrugsActiveSubstanceMaster")
public class DrugsActiveSubstanceMaster extends AuditableEntity implements BaseEntity,Serializable{

	/**
	 * 
	 */
	
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "DrugsActiveSubstanceID")
	private Long drugsActiveSubstanceID;
	
	@Column(name = "DAS_Name", length=60 , nullable = true)
	private String dasName;
	
	@Column(name = "DAS_ATC_ClassificationCode",  length=20 ,nullable = true)
	private String actClassificationCode;
	
	@Column(name = "DAS_ATC_ClassificationDescription", columnDefinition="TEXT" ,nullable = true)
	private String actClassificationDescription;
	
	@Column(name = "DAS_CIMS_Class", length=30 ,nullable = true)
	private String cimsClass;

	public DrugsActiveSubstanceMaster(Long drugsActiveSubstanceID, String dasName, String actClassificationCode,
			String actClassificationDescription, String cimsClass) {
		super();
		this.drugsActiveSubstanceID = drugsActiveSubstanceID;
		this.dasName = dasName;
		this.actClassificationCode = actClassificationCode;
		this.actClassificationDescription = actClassificationDescription;
		this.cimsClass = cimsClass;
	}

	public DrugsActiveSubstanceMaster() {

	}

	public Long getDrugsActiveSubstanceID() {
		return drugsActiveSubstanceID;
	}

	public void setDrugsActiveSubstanceID(Long drugsActiveSubstanceID) {
		this.drugsActiveSubstanceID = drugsActiveSubstanceID;
	}

	public String getDasName() {
		return dasName;
	}

	public void setDasName(String dasName) {
		this.dasName = dasName;
	}

	public String getActClassificationCode() {
		return actClassificationCode;
	}

	public void setActClassificationCode(String actClassificationCode) {
		this.actClassificationCode = actClassificationCode;
	}

	public String getActClassificationDescription() {
		return actClassificationDescription;
	}

	public void setActClassificationDescription(String actClassificationDescription) {
		this.actClassificationDescription = actClassificationDescription;
	}

	public String getCimsClass() {
		return cimsClass;
	}

	public void setCimsClass(String cimsClass) {
		this.cimsClass = cimsClass;
	}
	
}
