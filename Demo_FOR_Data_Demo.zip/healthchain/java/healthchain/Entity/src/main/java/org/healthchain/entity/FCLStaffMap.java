package org.healthchain.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "AV_FCL_StaffMap")
public class FCLStaffMap extends AuditableEntity implements BaseEntity,Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "FCL_StaffMapID")
	private Long fclStaffMapID;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FK_StaffID", referencedColumnName = "StaffID", nullable = true)
	private StaffMaster staffMaster;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FK_FCLocationMapID", referencedColumnName = "FCLocationMapID", nullable = true)
	private FCLocationMap fcLocationMap;

	public FCLStaffMap(Long fclStaffMapID, StaffMaster staffMaster, FCLocationMap fcLocationMap) {
		super();
		this.fclStaffMapID = fclStaffMapID;
		this.staffMaster = staffMaster;
		this.fcLocationMap = fcLocationMap;
	}

	public FCLStaffMap() {
		
	}

	public Long getFclStaffMapID() {
		return fclStaffMapID;
	}

	public void setFclStaffMapID(Long fclStaffMapID) {
		this.fclStaffMapID = fclStaffMapID;
	}

	public StaffMaster getStaffMaster() {
		return staffMaster;
	}

	public void setStaffMaster(StaffMaster staffMaster) {
		this.staffMaster = staffMaster;
	}

	public FCLocationMap getFcLocationMap() {
		return fcLocationMap;
	}

	public void setFcLocationMap(FCLocationMap fcLocationMap) {
		this.fcLocationMap = fcLocationMap;
	}
	
}
