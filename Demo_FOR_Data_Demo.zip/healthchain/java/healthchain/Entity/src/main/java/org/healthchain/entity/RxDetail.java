package org.healthchain.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "AV_RxDetail")
public class RxDetail extends AuditableEntity implements BaseEntity,Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "RxDetailID")
	private Long rxDetailID;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FK_RxID", referencedColumnName = "RxID", nullable = true)
	private RxHeader rxHeader;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FK_DrugCompoundID", referencedColumnName = "DrugCompoundID", nullable = true)
	private DrugCompoundMaster drugCompoundMaster;

	public RxDetail() {
		
	}

	public RxDetail(Long rxDetailID, RxHeader rxHeader, DrugCompoundMaster drugCompoundMaster) {
		super();
		this.rxDetailID = rxDetailID;
		this.rxHeader = rxHeader;
		this.drugCompoundMaster = drugCompoundMaster;
	}

	public Long getRxDetailID() {
		return rxDetailID;
	}

	public RxHeader getRxHeader() {
		return rxHeader;
	}

	public DrugCompoundMaster getDrugCompoundMaster() {
		return drugCompoundMaster;
	}

	public void setRxDetailID(Long rxDetailID) {
		this.rxDetailID = rxDetailID;
	}

	public void setRxHeader(RxHeader rxHeader) {
		this.rxHeader = rxHeader;
	}

	public void setDrugCompoundMaster(DrugCompoundMaster drugCompoundMaster) {
		this.drugCompoundMaster = drugCompoundMaster;
	}

}
