package org.healthchain.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "AV_UserRoleMap")
public class UserRoleEntity implements BaseEntity,Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "UserRoleMapID")
	private Long userRoleMapID;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FK_UserID", referencedColumnName = "UserID", nullable = true)
	private UserMaster userMaster;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FK_RoleID", referencedColumnName = "RoleID", nullable = true)
	private RoleMaster roleMaster;
	
	@ManyToOne
	@JoinColumn(name = "created_by", referencedColumnName = "UserID", nullable = true)
	private UserMaster createdBy;

	@Column(name = "created_on", nullable = true)
	private Date createdOn;

	@ManyToOne
	@JoinColumn(name = "modified_by", referencedColumnName = "UserID", nullable = true)
	private UserMaster modifiedBy;
	
	@Column(name = "modified_on", nullable = true)
	private Date modifiedOn;
	
	@Column(name = "is_active", nullable = true ,columnDefinition = "Boolean default true")
	private boolean active;
	
	@Column(name = "is_delete", nullable = true ,columnDefinition = "Boolean default false")
	private boolean deleted;

	public UserRoleEntity() {
		
	}

	public UserRoleEntity(Long userRoleMapID, UserMaster userMaster, RoleMaster roleMaster, UserMaster createdBy,
			Date createdOn, UserMaster modifiedBy, Date modifiedOn, boolean active, boolean deleted) {
		super();
		this.userRoleMapID = userRoleMapID;
		this.userMaster = userMaster;
		this.roleMaster = roleMaster;
		this.createdBy = createdBy;
		this.createdOn = createdOn;
		this.modifiedBy = modifiedBy;
		this.modifiedOn = modifiedOn;
		this.active = active;
		this.deleted = deleted;
	}

	public Long getUserRoleMapID() {
		return userRoleMapID;
	}

	public UserMaster getUserMaster() {
		return userMaster;
	}

	public RoleMaster getRoleMaster() {
		return roleMaster;
	}

	public UserMaster getCreatedBy() {
		return createdBy;
	}

	public Date getCreatedOn() {
		return createdOn;
	}

	public UserMaster getModifiedBy() {
		return modifiedBy;
	}

	public Date getModifiedOn() {
		return modifiedOn;
	}

	public boolean getActive() {
		return active;
	}

	public boolean getDeleted() {
		return deleted;
	}

	public void setUserRoleMapID(Long userRoleMapID) {
		this.userRoleMapID = userRoleMapID;
	}

	public void setUserMaster(UserMaster userMaster) {
		this.userMaster = userMaster;
	}

	public void setRoleMaster(RoleMaster roleMaster) {
		this.roleMaster = roleMaster;
	}

	public void setCreatedBy(UserMaster createdBy) {
		this.createdBy = createdBy;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	public void setModifiedBy(UserMaster modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public void setModifiedOn(Date modifiedOn) {
		this.modifiedOn = modifiedOn;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public void setDeleted(boolean deleted) {
		this.deleted = deleted;
	}

}
