package org.healthchain.entity;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.healthchain.entity.enums.FacilityCenterType;

@Entity
@Table(name = "AV_FacilityCenterMaster")
public class FacilityCenterMaster extends AuditableEntity implements BaseEntity,Serializable{
	
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "FacilityCenterID")
	private Long facilityCenterID;
	
	@Column(name = "FacilityCenterName", length=60 ,nullable = true)
	private String facilityCenterName;
	
	@Column(name = "FacilityCentertype", length=30 ,nullable = true)
	@Enumerated(EnumType.STRING)
	private FacilityCenterType facilityCenterType;
	
	@Column(name = "FC_CertificateNumber", length=40 ,nullable = true)
	private String fcCertificateNumber;
	
	@Column(name = "HasChild_In_LocationMap", nullable = true)
	private int hasChildInLocationMap;
	
	@Column(name = "WebSiteURL", length=60 ,nullable = true)
	private String webSiteURL;
	
	@Column(name = "Additional_Information", columnDefinition = "TEXT", nullable = true)
	private String additionalInformation;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FK_ClientID", referencedColumnName = "clientID", nullable = true)
	private ClientMaster clientMaster;
	
	@Transient
	private String fcLocationName;
	
	@Transient
    private Set<LocationMaster>  locationMaster= new HashSet<LocationMaster>();

	public FacilityCenterMaster() {
		
	}

	public FacilityCenterMaster(Long facilityCenterID, String facilityCenterName, FacilityCenterType facilityCenterType,
			String fcCertificateNumber, int hasChildInLocationMap, String webSiteURL, String additionalInformation,
			ClientMaster clientMaster, String fcLocationName, Set<LocationMaster> locationMaster) {
		super();
		this.facilityCenterID = facilityCenterID;
		this.facilityCenterName = facilityCenterName;
		this.facilityCenterType = facilityCenterType;
		this.fcCertificateNumber = fcCertificateNumber;
		this.hasChildInLocationMap = hasChildInLocationMap;
		this.webSiteURL = webSiteURL;
		this.additionalInformation = additionalInformation;
		this.clientMaster = clientMaster;
		this.fcLocationName = fcLocationName;
		this.locationMaster = locationMaster;
	}

	public Long getFacilityCenterID() {
		return facilityCenterID;
	}

	public String getFacilityCenterName() {
		return facilityCenterName;
	}

	public FacilityCenterType getFacilityCenterType() {
		return facilityCenterType;
	}

	public String getFcCertificateNumber() {
		return fcCertificateNumber;
	}

	public int getHasChildInLocationMap() {
		return hasChildInLocationMap;
	}

	public String getWebSiteURL() {
		return webSiteURL;
	}

	public String getAdditionalInformation() {
		return additionalInformation;
	}

	public ClientMaster getClientMaster() {
		return clientMaster;
	}

	public String getFcLocationName() {
		return fcLocationName;
	}

	public Set<LocationMaster> getLocationMaster() {
		return locationMaster;
	}

	public void setFacilityCenterID(Long facilityCenterID) {
		this.facilityCenterID = facilityCenterID;
	}

	public void setFacilityCenterName(String facilityCenterName) {
		this.facilityCenterName = facilityCenterName;
	}

	public void setFacilityCenterType(FacilityCenterType facilityCenterType) {
		this.facilityCenterType = facilityCenterType;
	}

	public void setFcCertificateNumber(String fcCertificateNumber) {
		this.fcCertificateNumber = fcCertificateNumber;
	}

	public void setHasChildInLocationMap(int hasChildInLocationMap) {
		this.hasChildInLocationMap = hasChildInLocationMap;
	}

	public void setWebSiteURL(String webSiteURL) {
		this.webSiteURL = webSiteURL;
	}

	public void setAdditionalInformation(String additionalInformation) {
		this.additionalInformation = additionalInformation;
	}

	public void setClientMaster(ClientMaster clientMaster) {
		this.clientMaster = clientMaster;
	}

	public void setFcLocationName(String fcLocationName) {
		this.fcLocationName = fcLocationName;
	}

	public void setLocationMaster(Set<LocationMaster> locationMaster) {
		this.locationMaster = locationMaster;
	}

}
