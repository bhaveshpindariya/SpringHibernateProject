package org.healthchain.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "AV_FCL_Provider_Doctor_Map")
public class FCLProviderDoctorMap extends AuditableEntity implements BaseEntity,Serializable{
	
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "FCL_Provider_DoctorMapID")
	private Long fclProviderDoctorMapID;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FK_FCL_ProviderMapID", referencedColumnName = "FCL_ProviderMapID", nullable = true)
	private FCLProviderMap fclProviderMapID;
			
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FK_Doctor", referencedColumnName = "FCL_ProviderMapID", nullable = true)
	private FCLProviderMap doctor;
	
	public FCLProviderDoctorMap() {
		
	}

	public FCLProviderDoctorMap(Long fclProviderDoctorMapID, FCLProviderMap doctor, FCLProviderMap fclProviderMapID) {
		super();
		this.fclProviderDoctorMapID = fclProviderDoctorMapID;
		this.doctor = doctor;
		this.fclProviderMapID = fclProviderMapID;
	}

	public Long getFclProviderDoctorMapID() {
		return fclProviderDoctorMapID;
	}

	public FCLProviderMap getDoctor() {
		return doctor;
	}

	public FCLProviderMap getFclProviderMapID() {
		return fclProviderMapID;
	}

	public void setFclProviderDoctorMapID(Long fclProviderDoctorMapID) {
		this.fclProviderDoctorMapID = fclProviderDoctorMapID;
	}

	public void setDoctor(FCLProviderMap doctor) {
		this.doctor = doctor;
	}

	public void setFclProviderMapID(FCLProviderMap fclProviderMapID) {
		this.fclProviderMapID = fclProviderMapID;
	}

}
