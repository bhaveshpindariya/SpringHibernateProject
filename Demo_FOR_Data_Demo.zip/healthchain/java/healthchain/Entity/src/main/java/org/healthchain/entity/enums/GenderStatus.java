package org.healthchain.entity.enums;

import java.util.ArrayList;
import java.util.List;

public enum GenderStatus {

	Male("Male"),
    Female("Female"),
	Other("Other");

    private String id;

    GenderStatus(String id) {
        this.id = id;
    }

    public String getId() {
        return id;
    }

    public static GenderStatus parse(String id) {
    	GenderStatus maritalStatus = null; // Default
        for (GenderStatus item : GenderStatus.values()) {
        	if (item.getId().equals(id)) {
                maritalStatus = item;
                break;
            }
        }
        return maritalStatus;
    }

    public static String getValue(String id) {
   	 for (GenderStatus item : GenderStatus.values()) {
           if (item.name() == id) {
           		return item.getId();
           }
       }
       return null;
    }
    
    public static List<String> getAllGenderStatus() {
    	GenderStatus[] values = GenderStatus.values();
        List<String> list = new ArrayList<>();
        for (GenderStatus value : values) {
            list.add(value.name());
        }
        return list;
    }
}
