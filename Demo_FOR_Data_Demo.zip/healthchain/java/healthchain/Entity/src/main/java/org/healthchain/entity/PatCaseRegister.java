package org.healthchain.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "AV_PatCaseRegister")
public class PatCaseRegister extends AuditableEntity implements BaseEntity,Serializable{

	/**
	 * 
	 */
	
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "PatCaseRegID")
	private Long patCaseRegID;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FK_CFL_PatRegID", referencedColumnName = "CFL_PatRegID", nullable = true)
	private CFLPatRegistrationMap fclpID;

	@Column(name = "PatCase_RegDate", nullable = true)
	private Date patCaseRegDate;
	
	@Column(name = "PatCase_PresentingComplains", columnDefinition = "TEXT",nullable = true)
	private String patCasePresentingComplains;
	
	@Column(name = "PatCase_OngoingMedications", columnDefinition = "TEXT",nullable = true)
	private String patCaseOngoingMedications;

	public PatCaseRegister(Long patCaseRegID, CFLPatRegistrationMap fclpID, Date patCaseRegDate,
			String patCasePresentingComplains, String patCaseOngoingMedications) {
		super();
		this.patCaseRegID = patCaseRegID;
		this.fclpID = fclpID;
		this.patCaseRegDate = patCaseRegDate;
		this.patCasePresentingComplains = patCasePresentingComplains;
		this.patCaseOngoingMedications = patCaseOngoingMedications;
	}

	public PatCaseRegister() {
		
	}

	public Long getPatCaseRegID() {
		return patCaseRegID;
	}

	public void setPatCaseRegID(Long patCaseRegID) {
		this.patCaseRegID = patCaseRegID;
	}

	public CFLPatRegistrationMap getFclpID() {
		return fclpID;
	}

	public void setFclpID(CFLPatRegistrationMap fclpID) {
		this.fclpID = fclpID;
	}

	public Date getPatCaseRegDate() {
		return patCaseRegDate;
	}

	public void setPatCaseRegDate(Date patCaseRegDate) {
		this.patCaseRegDate = patCaseRegDate;
	}

	public String getPatCasePresentingComplains() {
		return patCasePresentingComplains;
	}

	public void setPatCasePresentingComplains(String patCasePresentingComplains) {
		this.patCasePresentingComplains = patCasePresentingComplains;
	}

	public String getPatCaseOngoingMedications() {
		return patCaseOngoingMedications;
	}

	public void setPatCaseOngoingMedications(String patCaseOngoingMedications) {
		this.patCaseOngoingMedications = patCaseOngoingMedications;
	}
	
}
