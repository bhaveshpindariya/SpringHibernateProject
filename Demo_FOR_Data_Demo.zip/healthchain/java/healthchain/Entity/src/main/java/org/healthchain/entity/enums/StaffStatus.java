package org.healthchain.entity.enums;

import java.util.ArrayList;
import java.util.List;

public enum StaffStatus {
	
	Administrator("Administrator"),
	Nurse("Nurse"),
	Receptionist("Receptionist"),
	Secretary("Secretary"),
	Assistant("Assistant");
    
    private String id;

    StaffStatus(String id) {
        this.id = id;
    }

    public String getId() {
        return id;
    }

    public static StaffStatus parse(String id) {
        StaffStatus maritalStatus = null; // Default
        for (StaffStatus item : StaffStatus.values()) {
        	if (item.getId().equals(id)) {
                maritalStatus = item;
                break;
            }
        }
        return maritalStatus;
    }
    
    public static String getValue(String id) {
  	 for (StaffStatus item : StaffStatus.values()) {
          if (item.name() == id) {
          		return item.getId();
          }
      }
      return null;
    }
    
    public static List<String> getAllEmploymentStatus() {
        StaffStatus[] values = StaffStatus.values();
        List<String> list = new ArrayList<>();
        for (StaffStatus value : values) {
            list.add(value.name());
        }
        return list;
    }
}
