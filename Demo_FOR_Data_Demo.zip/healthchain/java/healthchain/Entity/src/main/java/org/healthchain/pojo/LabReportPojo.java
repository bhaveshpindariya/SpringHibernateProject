package org.healthchain.pojo;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

public class LabReportPojo implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private Long patientMaster;
	private String patientName;
	private Long providerID;
	private String providerName;
	private String reportDetail;
	private String additionalDetail;
	private String time;
	private String date;
	private Long reportPatLapAppId;
	private Long patLabAppointmentID;
	private Long patVisitNoteID;
	private Set<ReportLapPojo> reportLapdata = new HashSet<ReportLapPojo>(0);
	
	public LabReportPojo() {
		
	}

	public LabReportPojo(Long patientMaster, String patientName, Long providerID, String providerName,
			String reportDetail, String additionalDetail, String time, String date, Long reportPatLapAppId,
			Long patLabAppointmentID,Long patVisitNoteID, Set<ReportLapPojo> reportLapdata) {
		super();
		this.patientMaster = patientMaster;
		this.patientName = patientName;
		this.providerID = providerID;
		this.providerName = providerName;
		this.reportDetail = reportDetail;
		this.additionalDetail = additionalDetail;
		this.time = time;
		this.date = date;
		this.reportPatLapAppId = reportPatLapAppId;
		this.patLabAppointmentID = patLabAppointmentID;
		this.reportLapdata = reportLapdata;
		this.patVisitNoteID = patVisitNoteID;
	}

	public Long getPatientMaster() {
		return patientMaster;
	}

	public String getPatientName() {
		return patientName;
	}

	public Long getProviderID() {
		return providerID;
	}

	public String getProviderName() {
		return providerName;
	}

	public String getReportDetail() {
		return reportDetail;
	}

	public String getAdditionalDetail() {
		return additionalDetail;
	}

	public String getTime() {
		return time;
	}

	public String getDate() {
		return date;
	}

	public Long getReportPatLapAppId() {
		return reportPatLapAppId;
	}

	public Long getPatLabAppointmentID() {
		return patLabAppointmentID;
	}

	public Set<ReportLapPojo> getReportLapdata() {
		return reportLapdata;
	}

	public void setPatientMaster(Long patientMaster) {
		this.patientMaster = patientMaster;
	}

	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}

	public void setProviderID(Long providerID) {
		this.providerID = providerID;
	}

	public void setProviderName(String providerName) {
		this.providerName = providerName;
	}

	public void setReportDetail(String reportDetail) {
		this.reportDetail = reportDetail;
	}

	public void setAdditionalDetail(String additionalDetail) {
		this.additionalDetail = additionalDetail;
	}

	public void setTime(String time) {
		this.time = time;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public void setReportPatLapAppId(Long reportPatLapAppId) {
		this.reportPatLapAppId = reportPatLapAppId;
	}

	public void setPatLabAppointmentID(Long patLabAppointmentID) {
		this.patLabAppointmentID = patLabAppointmentID;
	}

	public void setReportLapdata(Set<ReportLapPojo> reportLapdata) {
		this.reportLapdata = reportLapdata;
	}

	public Long getPatVisitNoteID() {
		return patVisitNoteID;
	}

	public void setPatVisitNoteID(Long patVisitNoteID) {
		this.patVisitNoteID = patVisitNoteID;
	}
	
}
