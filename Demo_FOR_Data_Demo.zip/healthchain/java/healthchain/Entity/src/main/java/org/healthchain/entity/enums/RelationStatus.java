package org.healthchain.entity.enums;

import java.util.ArrayList;
import java.util.List;

public enum RelationStatus {

	Self("Self"),
	Wife("Wife"),
	Son("Son"),
	Daughter("Daughter"),
	Husband("Husband");
    
    private String id;

    RelationStatus(String id) {
        this.id = id;
    }

    public String getId() {
        return id;
    }

    public static RelationStatus parse(String id) {
        RelationStatus maritalStatus = null; // Default
        for (RelationStatus item : RelationStatus.values()) {
        	if (item.getId().equals(id)) {
                maritalStatus = item;
                break;
            }
        }
        return maritalStatus;
    }

    public static String getValue(String id) {
    	for (RelationStatus item : RelationStatus.values()) {
	         if (item.name() == id) {
	         		return item.getId();
	         }
    	}
    	return null;
    }
    
    public static List<String> getAllMaritalStatus() {
        RelationStatus[] values = RelationStatus.values();
        List<String> list = new ArrayList<>();
        for (RelationStatus value : values) {
            list.add(value.name());
        }
        return list;
    }
}
