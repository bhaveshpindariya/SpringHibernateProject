package org.healthchain.pojo;

import java.io.Serializable;

public class DiseasePojo implements Serializable {

	private static final long serialVersionUID = 1L;
	private Long diagnosisID;
	private String diagnosiseName;
	
	public DiseasePojo() {
		
	}

	@Override
	public String toString() {
		return "DiseasePojo [diagnosisID=" + diagnosisID + ", diagnosiseName=" + diagnosiseName + "]";
	}

	public DiseasePojo(Long diagnosisID, String diagnosiseName) {
		super();
		this.diagnosisID = diagnosisID;
		this.diagnosiseName = diagnosiseName;
	}

	public Long getDiagnosisID() {
		return diagnosisID;
	}

	public String getDiagnosiseName() {
		return diagnosiseName;
	}

	public void setDiagnosisID(Long diagnosisID) {
		this.diagnosisID = diagnosisID;
	}

	public void setDiagnosiseName(String diagnosiseName) {
		this.diagnosiseName = diagnosiseName;
	}
}
