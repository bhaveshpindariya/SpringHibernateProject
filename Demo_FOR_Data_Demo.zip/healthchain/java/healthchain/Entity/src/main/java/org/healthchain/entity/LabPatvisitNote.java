package org.healthchain.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "AV_LabPatvisitNote")
public class LabPatvisitNote extends AuditableEntity implements BaseEntity,Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "LabPatvisitNoteId")
	private Long labPatvisitNoteId;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FK_PatVisitNoteID", referencedColumnName = "PatVisitNoteID", nullable = true)
	private PatVisitNote patVisitNote;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FK_LabReportLevel1_ID", referencedColumnName = "LabReportLevel1_ID", nullable = true)
	private LabReportsLevel1 labReportsLevel1;
	
	public LabPatvisitNote() {
		
	}

	public LabPatvisitNote(Long labPatvisitNoteId, PatVisitNote patVisitNote, LabReportsLevel1 labReportsLevel1) {
		super();
		this.labPatvisitNoteId = labPatvisitNoteId;
		this.patVisitNote = patVisitNote;
		this.labReportsLevel1 = labReportsLevel1;
	}

	public Long getLabPatvisitNoteId() {
		return labPatvisitNoteId;
	}

	public PatVisitNote getPatVisitNote() {
		return patVisitNote;
	}

	public LabReportsLevel1 getLabReportsLevel1() {
		return labReportsLevel1;
	}

	public void setLabPatvisitNoteId(Long labPatvisitNoteId) {
		this.labPatvisitNoteId = labPatvisitNoteId;
	}

	public void setPatVisitNote(PatVisitNote patVisitNote) {
		this.patVisitNote = patVisitNote;
	}

	public void setLabReportsLevel1(LabReportsLevel1 labReportsLevel1) {
		this.labReportsLevel1 = labReportsLevel1;
	}

}
