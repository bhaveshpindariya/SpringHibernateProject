package org.healthchain.entity;

import java.io.Serializable;
import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;



@Entity
@Table(name = "AV_PatAdmission")
public class PatAdmission extends AuditableEntity implements BaseEntity, Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "PatAdmitID")
	private Long patAdmitID;

	@Column(name = "PatAdmitDate", nullable = true)
	private Date patAdmitDate;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FK_PatVisitNoteID", referencedColumnName = "PatVisitNoteID", nullable = true)
	private PatVisitNote patVisitNoteOutdoor;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FK_PatCaseRegID", referencedColumnName = "PatCaseRegID", nullable = true)
	private PatCaseRegister patCaseRegister;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FK_FCL_ProviderMapID", referencedColumnName = "FCL_ProviderMapID", nullable = true)
	private FCLProviderMap fclProviderMap;
	
	@Column(name = "PatDischargeDate", nullable = true)
	private Date patDischargeDate;
		
	@Column(name = "IsExists_PatVitalSign", nullable = true , columnDefinition = "Boolean default false")
	private Boolean isExistsPatVitalSign;

	public PatAdmission(Long patAdmitID, Date patAdmitDate, PatVisitNote patVisitNoteOutdoor,
			PatCaseRegister patCaseRegister, FCLProviderMap fclProviderMap, Date patDischargeDate,
			Boolean isExistsPatVitalSign) {
		super();
		this.patAdmitID = patAdmitID;
		this.patAdmitDate = patAdmitDate;
		this.patVisitNoteOutdoor = patVisitNoteOutdoor;
		this.patCaseRegister = patCaseRegister;
		this.fclProviderMap = fclProviderMap;
		this.patDischargeDate = patDischargeDate;
		this.isExistsPatVitalSign = isExistsPatVitalSign;
	}

	public PatAdmission() {
		
	}

	public Long getPatAdmitID() {
		return patAdmitID;
	}

	public Date getPatAdmitDate() {
		return patAdmitDate;
	}

	public PatVisitNote getPatVisitNoteOutdoor() {
		return patVisitNoteOutdoor;
	}

	public PatCaseRegister getPatCaseRegister() {
		return patCaseRegister;
	}

	public FCLProviderMap getFclProviderMap() {
		return fclProviderMap;
	}

	public Date getPatDischargeDate() {
		return patDischargeDate;
	}

	public Boolean getIsExistsPatVitalSign() {
		return isExistsPatVitalSign;
	}

	public void setPatAdmitID(Long patAdmitID) {
		this.patAdmitID = patAdmitID;
	}

	public void setPatAdmitDate(Date patAdmitDate) {
		this.patAdmitDate = patAdmitDate;
	}

	public void setPatVisitNoteOutdoor(PatVisitNote patVisitNoteOutdoor) {
		this.patVisitNoteOutdoor = patVisitNoteOutdoor;
	}

	public void setPatCaseRegister(PatCaseRegister patCaseRegister) {
		this.patCaseRegister = patCaseRegister;
	}

	public void setFclProviderMap(FCLProviderMap fclProviderMap) {
		this.fclProviderMap = fclProviderMap;
	}

	public void setPatDischargeDate(Date patDischargeDate) {
		this.patDischargeDate = patDischargeDate;
	}

	public void setIsExistsPatVitalSign(Boolean isExistsPatVitalSign) {
		this.isExistsPatVitalSign = isExistsPatVitalSign;
	}
}