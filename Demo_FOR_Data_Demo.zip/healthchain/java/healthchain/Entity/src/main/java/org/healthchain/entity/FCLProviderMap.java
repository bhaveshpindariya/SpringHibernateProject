package org.healthchain.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "AV_FCL_Provider_Map")
public class FCLProviderMap extends AuditableEntity implements BaseEntity,Serializable{
	
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "FCL_ProviderMapID")
	private Long fclProviderMapID;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FK_ProviderID", referencedColumnName = "ProviderID", nullable = true)
	private ProviderMaster providerID;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FK_FCLocationMapID", referencedColumnName = "FCLocationMapID", nullable = true)
	private FCLocationMap locationMapID;

	public FCLProviderMap(Long fclProviderMapID, ProviderMaster providerID, FCLocationMap locationMapID) {
		super();
		this.fclProviderMapID = fclProviderMapID;
		this.providerID = providerID;
		this.locationMapID = locationMapID;
	}

	public FCLProviderMap() {
		
	}

	public Long getFclProviderMapID() {
		return fclProviderMapID;
	}

	public void setFclProviderMapID(Long fclProviderMapID) {
		this.fclProviderMapID = fclProviderMapID;
	}

	public ProviderMaster getProviderID() {
		return providerID;
	}

	public void setProviderID(ProviderMaster providerID) {
		this.providerID = providerID;
	}

	public FCLocationMap getLocationMapID() {
		return locationMapID;
	}

	public void setLocationMapID(FCLocationMap locationMapID) {
		this.locationMapID = locationMapID;
	}
	
}
