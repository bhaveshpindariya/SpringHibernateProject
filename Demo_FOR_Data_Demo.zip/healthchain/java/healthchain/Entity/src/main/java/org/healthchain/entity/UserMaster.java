package org.healthchain.entity;

import java.io.Serializable;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.healthchain.entity.enums.ProviderTypeStatus;

@Entity
@Table(name = "AV_UserMaster")
public class UserMaster implements BaseEntity, Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "UserID")
	private Long userID;

	@Column(name = "UserName", length = 60, nullable = true, unique=true)
	private String userName;
	
	@Column(name = "UserEmail", length = 60, nullable = true, unique=true)
	private String userEmail;

	@Column(name = "UserPassword", length = 60, nullable = true)
	private String userPassword;

	@Column(name = "UserBlockChainID", columnDefinition = "TEXT", nullable = true)
	private String userBlockChainID;
	
	@Column(name = "UserHyperledgerID", columnDefinition = "TEXT", nullable = true)
	private String userHyperledgerID;
	
	@Column(name = "UserTransectionID", columnDefinition = "TEXT", nullable = true)
	private String userTransectionID;
	
	@ManyToOne
	@JoinColumn(name = "created_by", referencedColumnName = "UserID", nullable = true)
	private UserMaster createdBy;

	@Column(name = "created_on", nullable = true)
	private Date createdOn;

	@ManyToOne
	@JoinColumn(name = "modified_by", referencedColumnName = "UserID", nullable = true)
	private UserMaster modifiedBy;

	@Column(name = "modified_on", nullable = true)
	private Date modifiedOn;

	@Column(name = "is_active", nullable = true ,columnDefinition = "Boolean default true")
	private boolean active;

	@Column(name = "is_delete", nullable = true ,columnDefinition = "Boolean default false")
	private boolean deleted;

	@OneToMany(cascade = CascadeType.ALL,fetch = FetchType.LAZY, mappedBy = "userMaster")
    private Set<UserRoleEntity>  userRoleEntity= new HashSet<UserRoleEntity>(0);
	
	@OneToOne(cascade = CascadeType.ALL,fetch = FetchType.LAZY, mappedBy = "userMaster")
    private PersonMaster personMaster = new PersonMaster();
	
	@OneToMany(cascade = CascadeType.ALL,fetch = FetchType.LAZY, mappedBy = "userMaster")
    private Set<DeviceDetail>  deviceDetail= new HashSet<DeviceDetail>(0);
	
	@Transient
	private String deviceToken;
	
	@Transient
	private String oldPassword;
	
	@Transient
	private String roleName;
	
	@Transient
	private String deviceID;
	
	@Transient
	private String deviceType;
	
	@Transient
	private String perLname;

	@Transient
	private String perFname;
	
	@Transient
	private String perContactNumber;
	
	@Transient
	private Set<SpecialityMaster>  specialityMaster= new HashSet<SpecialityMaster>(); 
	
	@Transient
	private Set<FCLocationMap>  fcLocationMap= new HashSet<FCLocationMap>(0);
	
	@Transient
	private ProviderTypeStatus providerTypeStatus;

	public UserMaster() {
		
	}

	public UserMaster(Long userID, String userName, String userEmail, String userPassword, String userBlockChainID,
			String userHyperledgerID, String userTransectionID, UserMaster createdBy, Date createdOn,
			UserMaster modifiedBy, Date modifiedOn, boolean active, boolean deleted, Set<UserRoleEntity> userRoleEntity,
			PersonMaster personMaster, Set<DeviceDetail> deviceDetail, String deviceToken, String oldPassword,
			String roleName, String deviceID, String deviceType, String perLname, String perFname,
			String perContactNumber, Set<SpecialityMaster> specialityMaster, Set<FCLocationMap> fcLocationMap,
			ProviderTypeStatus providerTypeStatus) {
		super();
		this.userID = userID;
		this.userName = userName;
		this.userEmail = userEmail;
		this.userPassword = userPassword;
		this.userBlockChainID = userBlockChainID;
		this.userHyperledgerID = userHyperledgerID;
		this.userTransectionID = userTransectionID;
		this.createdBy = createdBy;
		this.createdOn = createdOn;
		this.modifiedBy = modifiedBy;
		this.modifiedOn = modifiedOn;
		this.active = active;
		this.deleted = deleted;
		this.userRoleEntity = userRoleEntity;
		this.personMaster = personMaster;
		this.deviceDetail = deviceDetail;
		this.deviceToken = deviceToken;
		this.oldPassword = oldPassword;
		this.roleName = roleName;
		this.deviceID = deviceID;
		this.deviceType = deviceType;
		this.perLname = perLname;
		this.perFname = perFname;
		this.perContactNumber = perContactNumber;
		this.specialityMaster = specialityMaster;
		this.fcLocationMap = fcLocationMap;
		this.providerTypeStatus = providerTypeStatus;
	}

	public Long getUserID() {
		return userID;
	}

	public String getUserName() {
		return userName;
	}

	public String getUserEmail() {
		return userEmail;
	}

	public String getUserPassword() {
		return userPassword;
	}

	public String getUserBlockChainID() {
		return userBlockChainID;
	}

	public String getUserHyperledgerID() {
		return userHyperledgerID;
	}

	public String getUserTransectionID() {
		return userTransectionID;
	}

	public UserMaster getCreatedBy() {
		return createdBy;
	}

	public Date getCreatedOn() {
		return createdOn;
	}

	public UserMaster getModifiedBy() {
		return modifiedBy;
	}

	public Date getModifiedOn() {
		return modifiedOn;
	}

	public boolean isActive() {
		return active;
	}

	public boolean isDeleted() {
		return deleted;
	}

	public Set<UserRoleEntity> getUserRoleEntity() {
		return userRoleEntity;
	}

	public PersonMaster getPersonMaster() {
		return personMaster;
	}

	public Set<DeviceDetail> getDeviceDetail() {
		return deviceDetail;
	}

	public String getDeviceToken() {
		return deviceToken;
	}

	public String getOldPassword() {
		return oldPassword;
	}

	public String getRoleName() {
		return roleName;
	}

	public String getDeviceID() {
		return deviceID;
	}

	public String getDeviceType() {
		return deviceType;
	}

	public String getPerLname() {
		return perLname;
	}

	public String getPerFname() {
		return perFname;
	}

	public String getPerContactNumber() {
		return perContactNumber;
	}

	public Set<SpecialityMaster> getSpecialityMaster() {
		return specialityMaster;
	}

	public Set<FCLocationMap> getFcLocationMap() {
		return fcLocationMap;
	}

	public ProviderTypeStatus getProviderTypeStatus() {
		return providerTypeStatus;
	}

	public void setUserID(Long userID) {
		this.userID = userID;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}

	public void setUserPassword(String userPassword) {
		this.userPassword = userPassword;
	}

	public void setUserBlockChainID(String userBlockChainID) {
		this.userBlockChainID = userBlockChainID;
	}

	public void setUserHyperledgerID(String userHyperledgerID) {
		this.userHyperledgerID = userHyperledgerID;
	}

	public void setUserTransectionID(String userTransectionID) {
		this.userTransectionID = userTransectionID;
	}

	public void setCreatedBy(UserMaster createdBy) {
		this.createdBy = createdBy;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	public void setModifiedBy(UserMaster modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public void setModifiedOn(Date modifiedOn) {
		this.modifiedOn = modifiedOn;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public void setDeleted(boolean deleted) {
		this.deleted = deleted;
	}

	public void setUserRoleEntity(Set<UserRoleEntity> userRoleEntity) {
		this.userRoleEntity = userRoleEntity;
	}

	public void setPersonMaster(PersonMaster personMaster) {
		this.personMaster = personMaster;
	}

	public void setDeviceDetail(Set<DeviceDetail> deviceDetail) {
		this.deviceDetail = deviceDetail;
	}

	public void setDeviceToken(String deviceToken) {
		this.deviceToken = deviceToken;
	}

	public void setOldPassword(String oldPassword) {
		this.oldPassword = oldPassword;
	}

	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}

	public void setDeviceID(String deviceID) {
		this.deviceID = deviceID;
	}

	public void setDeviceType(String deviceType) {
		this.deviceType = deviceType;
	}

	public void setPerLname(String perLname) {
		this.perLname = perLname;
	}

	public void setPerFname(String perFname) {
		this.perFname = perFname;
	}

	public void setPerContactNumber(String perContactNumber) {
		this.perContactNumber = perContactNumber;
	}

	public void setSpecialityMaster(Set<SpecialityMaster> specialityMaster) {
		this.specialityMaster = specialityMaster;
	}

	public void setFcLocationMap(Set<FCLocationMap> fcLocationMap) {
		this.fcLocationMap = fcLocationMap;
	}

	public void setProviderTypeStatus(ProviderTypeStatus providerTypeStatus) {
		this.providerTypeStatus = providerTypeStatus;
	}
}
