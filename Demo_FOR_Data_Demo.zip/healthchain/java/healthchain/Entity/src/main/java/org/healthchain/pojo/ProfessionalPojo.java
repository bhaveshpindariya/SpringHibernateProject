package org.healthchain.pojo;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

public class ProfessionalPojo implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private Long fclProviderMap;
	private String locationName;
	private Set<DrugCompoundPojo> drugCompoundMaster = new HashSet<DrugCompoundPojo>(0);
	private Set<LabReportsLevel1Pojo> labReportLevel1ID = new HashSet<LabReportsLevel1Pojo>(0);
	private Set<ProviderPojo> doctor = new HashSet<ProviderPojo>(0);
	
	public ProfessionalPojo() {
		
	}

	public ProfessionalPojo(Long fclProviderMap, String locationName, Set<DrugCompoundPojo> drugCompoundMaster,
			Set<LabReportsLevel1Pojo> labReportLevel1ID, Set<ProviderPojo> doctor) {
		super();
		this.fclProviderMap = fclProviderMap;
		this.locationName = locationName;
		this.drugCompoundMaster = drugCompoundMaster;
		this.labReportLevel1ID = labReportLevel1ID;
		this.doctor = doctor;
	}

	public Long getFclProviderMap() {
		return fclProviderMap;
	}

	public String getLocationName() {
		return locationName;
	}

	public Set<DrugCompoundPojo> getDrugCompoundMaster() {
		return drugCompoundMaster;
	}

	public Set<LabReportsLevel1Pojo> getLabReportLevel1ID() {
		return labReportLevel1ID;
	}

	public Set<ProviderPojo> getDoctor() {
		return doctor;
	}

	public void setFclProviderMap(Long fclProviderMap) {
		this.fclProviderMap = fclProviderMap;
	}

	public void setLocationName(String locationName) {
		this.locationName = locationName;
	}

	public void setDrugCompoundMaster(Set<DrugCompoundPojo> drugCompoundMaster) {
		this.drugCompoundMaster = drugCompoundMaster;
	}

	public void setLabReportLevel1ID(Set<LabReportsLevel1Pojo> labReportLevel1ID) {
		this.labReportLevel1ID = labReportLevel1ID;
	}

	public void setDoctor(Set<ProviderPojo> doctor) {
		this.doctor = doctor;
	}

}
