package org.healthchain.entity.enums;

import java.util.ArrayList;
import java.util.List;

public enum PatientAppointmentReason {

	Other("Other"),
	Fever("Fever"),
	Thyroid("Thyroid"),
	BP("BP"),
	Diabetes("Diabetes");
	
	private String id;

    PatientAppointmentReason(String id) {
        this.id = id;
    }

    public String getId() {
        return id;
    }

    public static PatientAppointmentReason parse(String id) {
    	PatientAppointmentReason patAppReason = null; // Default
        for (PatientAppointmentReason item : PatientAppointmentReason.values()) {
        	if (item.getId().equals(id)) {
            	patAppReason = item;
                break;
            }
        }
        return patAppReason;
    }

    public static String getValue(String id) {
    	for (PatientAppointmentReason item : PatientAppointmentReason.values()) {
	         if (item.name() == id) {
	         		return item.getId();
	         }
    	}
    	return null;
    }
    
    public static List<String> getAllPatientAppointmentReason() {
    	PatientAppointmentReason[] values = PatientAppointmentReason.values();
        List<String> list = new ArrayList<>();
        for (PatientAppointmentReason value : values) {
            list.add(value.name());
        }
        return list;
    }
}
