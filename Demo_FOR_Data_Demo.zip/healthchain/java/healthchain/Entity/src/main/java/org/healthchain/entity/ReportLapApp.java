package org.healthchain.entity;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name = "AV_ReportLapApp")
public class ReportLapApp extends AuditableEntity implements BaseEntity,Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "ReportLapAppId")
	private Long reportLapAppId;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FK_LabReportLevel1_ID", referencedColumnName = "LabReportLevel1_ID", nullable = true)
	private LabReportsLevel1 labReportLevel1ID;
	
	@Column(name = "Report_Path", columnDefinition = "TEXT",nullable = true)
	private String reportPath;
	
	@Column(name = "Extra_Detail", columnDefinition = "TEXT",nullable = true)
	private String extraDetail;
	
	@Column(name = "PatTransectionID", columnDefinition = "TEXT", nullable = true)
	private String patTransectionID;
	
	@Transient
	private Set<DiagnosisMaster> diagnosisMaster = new HashSet<DiagnosisMaster>(0);
	
	@Transient
	private Long reportPatLapAppId;
	
	public ReportLapApp() {
		
	}

	public ReportLapApp(Long reportLapAppId, LabReportsLevel1 labReportLevel1ID, String reportPath, String extraDetail,
			String patTransectionID, Set<DiagnosisMaster> diagnosisMaster, Long reportPatLapAppId) {
		super();
		this.reportLapAppId = reportLapAppId;
		this.labReportLevel1ID = labReportLevel1ID;
		this.reportPath = reportPath;
		this.extraDetail = extraDetail;
		this.patTransectionID = patTransectionID;
		this.diagnosisMaster = diagnosisMaster;
		this.reportPatLapAppId = reportPatLapAppId;
	}



	public Long getReportLapAppId() {
		return reportLapAppId;
	}

	public LabReportsLevel1 getLabReportLevel1ID() {
		return labReportLevel1ID;
	}

	public String getReportPath() {
		return reportPath;
	}

	public String getExtraDetail() {
		return extraDetail;
	}

	public String getPatTransectionID() {
		return patTransectionID;
	}

	public Set<DiagnosisMaster> getDiagnosisMaster() {
		return diagnosisMaster;
	}

	public Long getReportPatLapAppId() {
		return reportPatLapAppId;
	}

	public void setReportLapAppId(Long reportLapAppId) {
		this.reportLapAppId = reportLapAppId;
	}

	public void setLabReportLevel1ID(LabReportsLevel1 labReportLevel1ID) {
		this.labReportLevel1ID = labReportLevel1ID;
	}

	public void setReportPath(String reportPath) {
		this.reportPath = reportPath;
	}

	public void setExtraDetail(String extraDetail) {
		this.extraDetail = extraDetail;
	}

	public void setPatTransectionID(String patTransectionID) {
		this.patTransectionID = patTransectionID;
	}

	public void setDiagnosisMaster(Set<DiagnosisMaster> diagnosisMaster) {
		this.diagnosisMaster = diagnosisMaster;
	}

	public void setReportPatLapAppId(Long reportPatLapAppId) {
		this.reportPatLapAppId = reportPatLapAppId;
	}
}
