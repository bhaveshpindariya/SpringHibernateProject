package org.healthchain.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "AV_PatOnExamination")
public class PatOnExamination extends AuditableEntity implements BaseEntity, Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "PatOnExaminationID")
	private Long patOnExaminationID;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FK_PatAdmitID", referencedColumnName = "PatAdmitID", nullable = true)
	private PatAdmission patAdmission;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FK_PatVisitNoteID", referencedColumnName = "PatVisitNoteID", nullable = true)
	private PatVisitNote patVisitNoteOutdoor;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FK_FCL_ProviderMapID", referencedColumnName = "FCL_ProviderMapID", nullable = true)
	private FCLProviderMap fclProviderMapID;
	
	@Column(name = "ChiefComplains", columnDefinition = "TEXT",nullable = true)
	private String chiefComplains;
	
	@Column(name = "On_Examination", columnDefinition = "TEXT", nullable = true)
	private String onExamination;

	public PatOnExamination(Long patOnExaminationID, PatAdmission patAdmission, PatVisitNote patVisitNoteOutdoor,
			FCLProviderMap fclProviderMapID, String chiefComplains, String onExamination) {
		super();
		this.patOnExaminationID = patOnExaminationID;
		this.patAdmission = patAdmission;
		this.patVisitNoteOutdoor = patVisitNoteOutdoor;
		this.fclProviderMapID = fclProviderMapID;
		this.chiefComplains = chiefComplains;
		this.onExamination = onExamination;
	}

	public PatOnExamination() {
	
	}

	public Long getPatOnExaminationID() {
		return patOnExaminationID;
	}

	public PatAdmission getPatAdmission() {
		return patAdmission;
	}

	public PatVisitNote getPatVisitNoteOutdoor() {
		return patVisitNoteOutdoor;
	}

	public FCLProviderMap getFclProviderMapID() {
		return fclProviderMapID;
	}

	public String getChiefComplains() {
		return chiefComplains;
	}

	public String getOnExamination() {
		return onExamination;
	}

	public void setPatOnExaminationID(Long patOnExaminationID) {
		this.patOnExaminationID = patOnExaminationID;
	}

	public void setPatAdmission(PatAdmission patAdmission) {
		this.patAdmission = patAdmission;
	}

	public void setPatVisitNoteOutdoor(PatVisitNote patVisitNoteOutdoor) {
		this.patVisitNoteOutdoor = patVisitNoteOutdoor;
	}

	public void setFclProviderMapID(FCLProviderMap fclProviderMapID) {
		this.fclProviderMapID = fclProviderMapID;
	}

	public void setChiefComplains(String chiefComplains) {
		this.chiefComplains = chiefComplains;
	}

	public void setOnExamination(String onExamination) {
		this.onExamination = onExamination;
	}
}