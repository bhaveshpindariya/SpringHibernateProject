package org.healthchain.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "AV_InsurancePayerCompanyMaster")
public class InsurancePayerCompanyMaster extends AuditableEntity implements BaseEntity,Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "InsurancePayerID")
	private Long insurancePayerID;
	
	@Column(name = "IP_Name", length=60 , nullable = true)
	private String ipName;

	@Column(name = "WebSiteURL", length=60 , nullable = true)
	private String webSiteURL;

	public InsurancePayerCompanyMaster(Long insurancePayerID, String ipName, String webSiteURL) {
		super();
		this.insurancePayerID = insurancePayerID;
		this.ipName = ipName;
		this.webSiteURL = webSiteURL;
	}

	public InsurancePayerCompanyMaster() {
	
	}

	public Long getInsurancePayerID() {
		return insurancePayerID;
	}

	public void setInsurancePayerID(Long insurancePayerID) {
		this.insurancePayerID = insurancePayerID;
	}

	public String getIpName() {
		return ipName;
	}

	public void setIpName(String ipName) {
		this.ipName = ipName;
	}

	public String getWebSiteURL() {
		return webSiteURL;
	}

	public void setWebSiteURL(String webSiteURL) {
		this.webSiteURL = webSiteURL;
	}

}
