package org.healthchain.entity;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name = "AV_ReportLapReportPatLap")
public class ReportLapReportPatLap extends AuditableEntity implements BaseEntity,Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "ReportLapReportPatLapId")
	private Long reportLapReportPatLapId;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FK_ReportLapAppId", referencedColumnName = "ReportLapAppId", nullable = true)
	private ReportLapApp reportLapApp;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FK_ReportPatLapAppId", referencedColumnName = "ReportPatLapAppId", nullable = true)
	private ReportPatLapApp reportPatLapApp;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FK_DiagnosisID", referencedColumnName = "DiagnosisID", nullable = true)
	private DiagnosisMaster diagnosisMaster;
	
	@Transient
	private Set<ReportPatLapApp> reportPatLapAppdata = new HashSet<ReportPatLapApp>(0);
	
	@Transient
	private Set<ReportLapApp> reportLapAppdata = new HashSet<ReportLapApp>(0);
	
	@Transient
	private Set<DiagnosisMaster> diagnosisMasterdata = new HashSet<DiagnosisMaster>(0);
	
	public ReportLapReportPatLap() {
		
	}

	public ReportLapReportPatLap(Long reportLapReportPatLapId, ReportLapApp reportLapApp,
			ReportPatLapApp reportPatLapApp, DiagnosisMaster diagnosisMaster,
			Set<ReportPatLapApp> reportPatLapAppdata,
			Set<ReportLapApp> reportLapAppdata, Set<DiagnosisMaster> diagnosisMasterdata) {
		super();
		this.reportLapReportPatLapId = reportLapReportPatLapId;
		this.reportLapApp = reportLapApp;
		this.reportPatLapApp = reportPatLapApp;
		this.diagnosisMaster = diagnosisMaster;
		this.reportPatLapAppdata = reportPatLapAppdata;
		this.reportLapAppdata = reportLapAppdata;
		this.diagnosisMasterdata = diagnosisMasterdata;
	}

	public Long getReportLapReportPatLapId() {
		return reportLapReportPatLapId;
	}

	public ReportLapApp getReportLapApp() {
		return reportLapApp;
	}

	public ReportPatLapApp getReportPatLapApp() {
		return reportPatLapApp;
	}

	public DiagnosisMaster getDiagnosisMaster() {
		return diagnosisMaster;
	}

	public Set<ReportLapApp> getReportLapAppdata() {
		return reportLapAppdata;
	}

	public Set<DiagnosisMaster> getDiagnosisMasterdata() {
		return diagnosisMasterdata;
	}

	public void setReportLapReportPatLapId(Long reportLapReportPatLapId) {
		this.reportLapReportPatLapId = reportLapReportPatLapId;
	}

	public void setReportLapApp(ReportLapApp reportLapApp) {
		this.reportLapApp = reportLapApp;
	}

	public void setReportPatLapApp(ReportPatLapApp reportPatLapApp) {
		this.reportPatLapApp = reportPatLapApp;
	}

	public void setDiagnosisMaster(DiagnosisMaster diagnosisMaster) {
		this.diagnosisMaster = diagnosisMaster;
	}

	public void setReportPatLapAppdata(Set<ReportPatLapApp> reportPatLapAppdata) {
		this.reportPatLapAppdata = reportPatLapAppdata;
	}

	public void setReportLapAppdata(Set<ReportLapApp> reportLapAppdata) {
		this.reportLapAppdata = reportLapAppdata;
	}

	public void setDiagnosisMasterdata(Set<DiagnosisMaster> diagnosisMasterdata) {
		this.diagnosisMasterdata = diagnosisMasterdata;
	}
}
