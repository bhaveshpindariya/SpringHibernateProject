package org.healthchain.entity;

import java.io.Serializable;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.healthchain.entity.enums.LabReportType;

@Entity
@Table(name = "AV_LabReportsLevel1")
public class LabReportsLevel1 extends AuditableEntity implements BaseEntity,Serializable{

	/**
	 * 
	 */
	
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "LabReportLevel1_ID")
	private Long labReportLevel1ID;
	
	@Basic
	@Column(name = "LabReportType", length=30 ,nullable = true)
	@Enumerated(EnumType.STRING)
	private LabReportType labReportType;
	
	@Column(name = "LRL1_Category", length=40 ,nullable = true)
	private String lrl1Category;
	
	@Column(name = "LRL1_Name", length=40 ,nullable = true)
	private String lrl1Name;
	
	@Column(name = "GenericTestcode", length=30 ,nullable = true)
	private String genericTestcode;
	
	@Column(name = "Generic_Source_Name", length=30 ,nullable = true)
	private String genericSourceName;

	public LabReportsLevel1(Long labReportLevel1ID, LabReportType labReportType, String lrl1Category, String lrl1Name,
			String genericTestcode, String genericSourceName) {
		super();
		this.labReportLevel1ID = labReportLevel1ID;
		this.labReportType = labReportType;
		this.lrl1Category = lrl1Category;
		this.lrl1Name = lrl1Name;
		this.genericTestcode = genericTestcode;
		this.genericSourceName = genericSourceName;
	}

	public LabReportsLevel1() {
		
	}

	public Long getLabReportLevel1ID() {
		return labReportLevel1ID;
	}

	public LabReportType getLabReportType() {
		return labReportType;
	}

	public String getLrl1Category() {
		return lrl1Category;
	}

	public String getLrl1Name() {
		return lrl1Name;
	}

	public String getGenericTestcode() {
		return genericTestcode;
	}

	public String getGenericSourceName() {
		return genericSourceName;
	}

	public void setLabReportLevel1ID(Long labReportLevel1ID) {
		this.labReportLevel1ID = labReportLevel1ID;
	}

	public void setLabReportType(LabReportType labReportType) {
		this.labReportType = labReportType;
	}

	public void setLrl1Category(String lrl1Category) {
		this.lrl1Category = lrl1Category;
	}

	public void setLrl1Name(String lrl1Name) {
		this.lrl1Name = lrl1Name;
	}

	public void setGenericTestcode(String genericTestcode) {
		this.genericTestcode = genericTestcode;
	}

	public void setGenericSourceName(String genericSourceName) {
		this.genericSourceName = genericSourceName;
	}
}
