package org.healthchain.pojo;

import java.io.Serializable;
import java.util.List;

public class LabReportPojoList implements Serializable {

	private static final long serialVersionUID = 1L;
	private int totalNumber;
	private List<LabReportPojo> labReportPojo;
	
	public LabReportPojoList() {
		
	}

	public LabReportPojoList(int totalNumber, List<LabReportPojo> labReportPojo) {
		super();
		this.totalNumber = totalNumber;
		this.labReportPojo = labReportPojo;
	}

	public int getTotalNumber() {
		return totalNumber;
	}

	public List<LabReportPojo> getLabReportPojo() {
		return labReportPojo;
	}

	public void setTotalNumber(int totalNumber) {
		this.totalNumber = totalNumber;
	}

	public void setLabReportPojo(List<LabReportPojo> labReportPojo) {
		this.labReportPojo = labReportPojo;
	}

}
