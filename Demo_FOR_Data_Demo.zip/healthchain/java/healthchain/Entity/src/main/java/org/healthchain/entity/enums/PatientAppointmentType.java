package org.healthchain.entity.enums;

import java.util.ArrayList;
import java.util.List;

public enum PatientAppointmentType {

	New("New"),
	/*Labtest("Labtest"),
	Xray("X-ray"),*/
	Followup("Followup");

	private String id;

    PatientAppointmentType(String id) {
        this.id = id;
    }

    public String getId() {
        return id;
    }

    public static String getValue(String id) {
    	for (PatientAppointmentType item : PatientAppointmentType.values()) {
    		if (item.getId().equals(id)) {
	         		return item.getId();
	         }
    	}
    	return null;
    }
    
    public static PatientAppointmentType parse(String id) {
    	PatientAppointmentType patAppType = null; // Default
        for (PatientAppointmentType item : PatientAppointmentType.values()) {
            if (item.getId() == id) {
            	patAppType = item;
                break;
            }
        }
        return patAppType;
    }

    public static List<String> getAllPatientAppointmentType() {
    	PatientAppointmentType[] values = PatientAppointmentType.values();
        List<String> list = new ArrayList<>();
        for (PatientAppointmentType value : values) {
            list.add(value.name());
        }
        return list;
    }
}
