package org.healthchain.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
	

@Entity
@Table(name="AV_Client_FacilityLocation_RegistrationMap")
public class ClientFacilityLocationRegistrationMap extends AuditableEntity implements BaseEntity,Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "ClientFL_RegID")
	private Long clientFL_RegID;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FK_LocationID", referencedColumnName = "LocationID", nullable = true)
	private LocationMaster locationMaster;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FK_ClientID", referencedColumnName = "clientID", nullable = true)
	private ClientMaster clientMaster;

	@Column(name = "DateRegistered", nullable = true)
	private Date dateRegistered;

	public ClientFacilityLocationRegistrationMap() {
		
	}

	public ClientFacilityLocationRegistrationMap(Long clientFL_RegID, LocationMaster locationMaster,
			ClientMaster clientMaster, Date dateRegistered) {
		super();
		this.clientFL_RegID = clientFL_RegID;
		this.locationMaster = locationMaster;
		this.clientMaster = clientMaster;
		this.dateRegistered = dateRegistered;
	}

	public Long getClientFL_RegID() {
		return clientFL_RegID;
	}

	public LocationMaster getLocationMaster() {
		return locationMaster;
	}

	public ClientMaster getClientMaster() {
		return clientMaster;
	}

	public Date getDateRegistered() {
		return dateRegistered;
	}

	public void setClientFL_RegID(Long clientFL_RegID) {
		this.clientFL_RegID = clientFL_RegID;
	}

	public void setLocationMaster(LocationMaster locationMaster) {
		this.locationMaster = locationMaster;
	}

	public void setClientMaster(ClientMaster clientMaster) {
		this.clientMaster = clientMaster;
	}

	public void setDateRegistered(Date dateRegistered) {
		this.dateRegistered = dateRegistered;
	}
	
}