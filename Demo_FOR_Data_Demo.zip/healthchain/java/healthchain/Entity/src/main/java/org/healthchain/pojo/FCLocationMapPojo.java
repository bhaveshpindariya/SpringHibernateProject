package org.healthchain.pojo;

import java.io.Serializable;

public class FCLocationMapPojo implements Serializable {

	private static final long serialVersionUID = 1L;
	private Long fcLocationMapID;
	private String fcLocationName;
	
	public FCLocationMapPojo() {
		
	}

	public FCLocationMapPojo(Long fcLocationMapID, String fcLocationName) {
		super();
		this.fcLocationMapID = fcLocationMapID;
		this.fcLocationName = fcLocationName;
	}

	@Override
	public String toString() {
		return "FCLocationMapPojo [fcLocationMapID=" + fcLocationMapID + ", fcLocationName=" + fcLocationName + "]";
	}

	public Long getFcLocationMapID() {
		return fcLocationMapID;
	}

	public String getFcLocationName() {
		return fcLocationName;
	}

	public void setFcLocationMapID(Long fcLocationMapID) {
		this.fcLocationMapID = fcLocationMapID;
	}

	public void setFcLocationName(String fcLocationName) {
		this.fcLocationName = fcLocationName;
	}
	
	
	
}
