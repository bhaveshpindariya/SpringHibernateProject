package org.healthchain.pojo;

import java.io.Serializable;
import java.util.List;

public class PatLabAppointmentsPojoList implements Serializable {

	private static final long serialVersionUID = 1L;
	private int totalNumber;
	private List<PatLabAppointmentsPojo> patLabAppointmentsPojo;
	
	public PatLabAppointmentsPojoList() {
		
	}

	public PatLabAppointmentsPojoList(int totalNumber, List<PatLabAppointmentsPojo> patLabAppointmentsPojo) {
		super();
		this.totalNumber = totalNumber;
		this.patLabAppointmentsPojo = patLabAppointmentsPojo;
	}

	public int getTotalNumber() {
		return totalNumber;
	}

	public List<PatLabAppointmentsPojo> getPatLabAppointmentsPojo() {
		return patLabAppointmentsPojo;
	}

	public void setTotalNumber(int totalNumber) {
		this.totalNumber = totalNumber;
	}

	public void setPatLabAppointmentsPojo(List<PatLabAppointmentsPojo> patLabAppointmentsPojo) {
		this.patLabAppointmentsPojo = patLabAppointmentsPojo;
	}

}
