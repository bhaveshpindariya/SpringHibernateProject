package org.healthchain.pojo;

import java.io.Serializable;

public class ResponseAllData implements Serializable {

	private static final long serialVersionUID = 1L;
	public String status;
	public Object data;

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Object getData() {
		return data;
	}

	public void setData(Object data) {
		this.data = data;
	}

	@Override
	public String toString() {
		return "Response [status=" + status + ", data=" + data + "]";
	}

	public ResponseAllData(String status,  Object data) {
		super();
		this.status = status;
		this.data = data;
	}

	public ResponseAllData() {

	}

}
