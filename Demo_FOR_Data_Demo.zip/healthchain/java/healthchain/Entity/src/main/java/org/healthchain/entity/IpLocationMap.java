package org.healthchain.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import net.sf.json.JSONArray;

@Entity
@Table(name = "AV_IP_LocationMap")
public class IpLocationMap extends AuditableEntity implements BaseEntity,Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "IP_LocationMapId")
	private Long ipLocationMapId;
	
	@Column(name = "IP_LandLines", nullable = true)
	private JSONArray ipLandLines;

	@Column(name = "IP_ContactPersonID", nullable = true)
	private JSONArray ipContactPersonID;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FK_LocationID", referencedColumnName = "LocationID", nullable = true)
	private LocationMaster locationMaster;

	public IpLocationMap(Long ipLocationMapId, JSONArray ipLandLines, JSONArray ipContactPersonID,
			LocationMaster locationMaster) {
		super();
		this.ipLocationMapId = ipLocationMapId;
		this.ipLandLines = ipLandLines;
		this.ipContactPersonID = ipContactPersonID;
		this.locationMaster = locationMaster;
	}
	
	public IpLocationMap() {
		
	}

	public Long getIpLocationMapId() {
		return ipLocationMapId;
	}

	public void setIpLocationMapId(Long ipLocationMapId) {
		this.ipLocationMapId = ipLocationMapId;
	}

	public JSONArray getIpLandLines() {
		return ipLandLines;
	}

	public void setIpLandLines(JSONArray ipLandLines) {
		this.ipLandLines = ipLandLines;
	}

	public JSONArray getIpContactPersonID() {
		return ipContactPersonID;
	}

	public void setIpContactPersonID(JSONArray ipContactPersonID) {
		this.ipContactPersonID = ipContactPersonID;
	}

	public LocationMaster getLocationMaster() {
		return locationMaster;
	}

	public void setLocationMaster(LocationMaster locationMaster) {
		this.locationMaster = locationMaster;
	}

	
}
