package org.healthchain.pojo;

import java.io.Serializable;

public class CommonPojo implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private Long reportPatLapAppId;
	
	public CommonPojo() {
		
	}

	public CommonPojo(Long reportPatLapAppId) {
		super();
		this.reportPatLapAppId = reportPatLapAppId;
	}

	public Long getReportPatLapAppId() {
		return reportPatLapAppId;
	}

	public void setReportPatLapAppId(Long reportPatLapAppId) {
		this.reportPatLapAppId = reportPatLapAppId;
	}

	
}
