package org.healthchain.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "AV_ReportPatLapApp")
public class ReportPatLapApp extends AuditableEntity implements BaseEntity,Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "ReportPatLapAppId")
	private Long reportPatLapAppId;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FK_PatientID", referencedColumnName = "PatientID", nullable = true)
	private PatientMaster patientMaster;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FK_PatLabAppointmentID", referencedColumnName = "PatLabAppointmentID", nullable = true)
	private PatLabAppointments patLabAppointments;
	
	@Column(name = "Report_Detail", columnDefinition = "TEXT",nullable = true)
	private String reportDetail;
	
	@Column(name = "Additional_Detail", columnDefinition = "TEXT",nullable = true)
	private String additionalDetail;
	
	public ReportPatLapApp() {
		
	}

	public ReportPatLapApp(Long reportPatLapAppId, PatientMaster patientMaster, PatLabAppointments patLabAppointments,
			String reportDetail, String additionalDetail) {
		super();
		this.reportPatLapAppId = reportPatLapAppId;
		this.patientMaster = patientMaster;
		this.patLabAppointments = patLabAppointments;
		this.reportDetail = reportDetail;
		this.additionalDetail = additionalDetail;
	}

	public Long getReportPatLapAppId() {
		return reportPatLapAppId;
	}

	public PatientMaster getPatientMaster() {
		return patientMaster;
	}

	public PatLabAppointments getPatLabAppointments() {
		return patLabAppointments;
	}

	public String getReportDetail() {
		return reportDetail;
	}

	public String getAdditionalDetail() {
		return additionalDetail;
	}

	public void setReportPatLapAppId(Long reportPatLapAppId) {
		this.reportPatLapAppId = reportPatLapAppId;
	}

	public void setPatientMaster(PatientMaster patientMaster) {
		this.patientMaster = patientMaster;
	}

	public void setPatLabAppointments(PatLabAppointments patLabAppointments) {
		this.patLabAppointments = patLabAppointments;
	}

	public void setReportDetail(String reportDetail) {
		this.reportDetail = reportDetail;
	}

	public void setAdditionalDetail(String additionalDetail) {
		this.additionalDetail = additionalDetail;
	}

}
