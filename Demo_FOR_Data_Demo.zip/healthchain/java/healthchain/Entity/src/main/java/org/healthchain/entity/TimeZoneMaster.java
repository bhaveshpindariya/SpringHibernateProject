package org.healthchain.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "AV_UTC_TimeZoneMaster")
public class TimeZoneMaster extends AuditableEntity implements BaseEntity,Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "UTC_TimeZoneID")
	private Long utcTimeZoneId;
	
	@Column(name = "CountryCode", length=5 ,unique=true,nullable = true)
	private String countryCode; 
	
	@Column(name = "CountryName", length=50 , nullable = true)
	private String countryName;
	
	@Column(name = "TimezoneAbbreviation", length=10 ,nullable = true)
	private String timezoneAbbreviation; 
	
	@Column(name = "TimezoneName", length=80 ,nullable = true)
	private String timezoneName;
	
	@Column(name = "UTC_Offset", length=10 ,nullable = true)
	private String utcOffset;

	public TimeZoneMaster(Long utcTimeZoneId, String countryCode, String countryName, String timezoneAbbreviation,
			String timezoneName, String utcOffset) {
		super();
		this.utcTimeZoneId = utcTimeZoneId;
		this.countryCode = countryCode;
		this.countryName = countryName;
		this.timezoneAbbreviation = timezoneAbbreviation;
		this.timezoneName = timezoneName;
		this.utcOffset = utcOffset;
	}

	public TimeZoneMaster() {
		
	}

	public Long getUtcTimeZoneId() {
		return utcTimeZoneId;
	}

	public void setUtcTimeZoneId(Long utcTimeZoneId) {
		this.utcTimeZoneId = utcTimeZoneId;
	}

	public String getCountryCode() {
		return countryCode;
	}

	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}

	public String getCountryName() {
		return countryName;
	}

	public void setCountryName(String countryName) {
		this.countryName = countryName;
	}

	public String getTimezoneAbbreviation() {
		return timezoneAbbreviation;
	}

	public void setTimezoneAbbreviation(String timezoneAbbreviation) {
		this.timezoneAbbreviation = timezoneAbbreviation;
	}

	public String getTimezoneName() {
		return timezoneName;
	}

	public void setTimezoneName(String timezoneName) {
		this.timezoneName = timezoneName;
	}

	public String getUtcOffset() {
		return utcOffset;
	}

	public void setUtcOffset(String utcOffset) {
		this.utcOffset = utcOffset;
	}
	
}
