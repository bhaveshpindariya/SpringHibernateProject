package org.healthchain.entity;

import java.io.Serializable;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.Basic;
import javax.persistence.CollectionTable;
import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.OrderColumn;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.healthchain.entity.enums.EmploymentStatus;
import org.healthchain.entity.enums.GenderStatus;
import org.healthchain.entity.enums.MaritalStatus;
import org.healthchain.entity.enums.PLMLocationStatus;
import org.healthchain.entity.enums.PatRelationStatus;
import org.healthchain.entity.enums.PerStatus;
import org.healthchain.entity.enums.WorkStatus;

@Entity
@Table(name = "AV_PersonMaster")
public class PersonMaster extends AuditableEntity implements BaseEntity, Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "PersonID")
	private Long personID;

	@Column(name = "PersonKey", length = 60, nullable = true)
	private String personKey;

	@Basic
	@Column(name = "PerSalute", length = 10, nullable = true)
	@Enumerated(EnumType.STRING)
	private PerStatus perStatus;

	@Column(name = "PerFname", length = 60, nullable = true)
	private String perFname;

	@Column(name = "PerMname", length = 60, nullable = true)
	private String perMname;

	@Column(name = "PerLname", length = 60, nullable = true)
	private String perLName;

	@Column(name = "PerDOB", nullable = true)
	private Long perDOB;

	@Column(name = "PerAge", nullable = true)
	private Integer perAge;

	@Column(name = "PerDegree", nullable = true)
	private String perDegree;

	@Column(name = "PerDesignation", nullable = true)
	private String perDesignation;

	@Column(name = "IsAgeEstimated", nullable = true, columnDefinition = "Boolean default false")
	private Boolean isAgeEstimated;

	@Basic
	@Column(name = "PerGender", length = 10, nullable = true)
	@Enumerated(EnumType.STRING)
	private GenderStatus gender;

	@Column(name = "PerMobilePrimary", length = 20, nullable = true)
	private String perMobilePrimary;

	@ElementCollection(fetch=FetchType.LAZY)
	@CollectionTable(name = "PersonMobileList", joinColumns = @JoinColumn(name = "PersonID"))
	@OrderColumn
	private List<String> perMobileList;

	@Column(name = "PerEmailPrimary", length = 30, nullable = true)
	private String perEmailPrimary;

	@ElementCollection(fetch=FetchType.LAZY)
	@CollectionTable(name = "PersonEmailList", joinColumns = @JoinColumn(name = "PersonID"))
    @OrderColumn
	private List<String> perEmailList;

	@Column(name = "PerWhatsappID", length = 30, nullable = true)
	private String perWhatsappID;

	@Column(name = "BodyHeight", nullable = true)
	private String bodyHeight;

	@Column(name = "BodyWeightIn_KG", nullable = true)
	private String bodyWeightInKG;

	@Column(name = "BMI", nullable = true)
	private Integer bmi;

	@Column(name = "Chest_Inches", nullable = true)
	private Integer chestInches;

	@Column(name = "Waist_Inches", nullable = true)
	private Integer waistInches;

	@Column(name = "IsWearingGlasses", nullable = true, columnDefinition = "Boolean default false")
	private Boolean isWearingGlasses;

	@Column(name = "IsWearingHearing_Aid", nullable = true, columnDefinition = "Boolean default false")
	private Boolean isWearingHearingAid;

	@Column(name = "IsWearingDenture", nullable = true, columnDefinition = "Boolean default false")
	private Boolean isWearingDenture;

	@Column(name = "IsWearingOrthoPedicDevice", nullable = true, columnDefinition = "Boolean default false")
	private Boolean isWearingOrthoPedicDevice;

	@Column(name = "PerRace", length = 30, nullable = true)
	private String perRace;

	@Column(name = "PerEthnicity", length = 30, nullable = true)
	private String perEthnicity;

	@Column(name = "HasSmokingHistory", nullable = true, columnDefinition = "Boolean default false")
	private Boolean hasSmokingHistory;

	@Column(name = "HasDrinkingHistory", nullable = true, columnDefinition = "Boolean default false")
	private Boolean hasDrinkingHistory;

	@Column(name = "PerAadhaarCardNo", length = 30, nullable = true)
	private String perAadhaarCardNo;
	
	@Column(name = "PerPANcardNo", length = 30, nullable = true)
	private String perPANcardNo;
	
	@Column(name = "PerDrivingLicenseNo", length = 30, nullable = true)
	private String perDrivingLicenseNo;
	
	@Basic
	@Column(name = "Maritus_Status", length = 20, nullable = true)
	@Enumerated(EnumType.STRING)
	private MaritalStatus marital;

	@Basic
	@Column(name = "Work_Status", length = 20, nullable = true)
	@Enumerated(EnumType.STRING)
	private WorkStatus work;

	@Basic
	@Column(name = "EmploymentStatus", length = 20, nullable = true)
	@Enumerated(EnumType.STRING)
	private EmploymentStatus employment;

	@Column(name = "EmployerName", length = 60, nullable = true)
	private String employerName;

	@Basic
	@Column(name = "RelationwithPrimaryBilled", length = 20, nullable = true)
	@Enumerated(EnumType.STRING)
	private PatRelationStatus relations;

	@Column(name = "WebSiteURL", length = 60, nullable = true)
	private String webSiteURL;

	@Column(name = "IsInsured", nullable = true, columnDefinition = "Boolean default false")
	private Boolean isInsured;

	@Column(name = "PerAadhaarCardID", columnDefinition = "TEXT", nullable = true)
	private String perAadhaarCardID;

	@Column(name = "IsAadhaarverified", nullable = true, columnDefinition = "Boolean default false")
	private Boolean isAadhaarverified;

	@Column(name = "PerPANcardID", columnDefinition = "TEXT", nullable = true)
	private String perPANcardID;

	@Column(name = "IsPerPANCardverified", nullable = true, columnDefinition = "Boolean default false")
	private Boolean isPerPANCardverified;

	@Column(name = "PerDrivingLicenseID", columnDefinition = "TEXT", nullable = true)
	private String perDrivingLicenseID;

	@Column(name = "IsPerDrivingLicense", nullable = true, columnDefinition = "Boolean default false")
	private Boolean isPerDrivingLicense;

	@Column(name = "PerSSN", length = 60, nullable = true)
	private String perSSN;

	@Column(name = "PerSIN", length = 60, nullable = true)
	private String perSIN;

	@Column(name = "PerProfile", columnDefinition = "TEXT", nullable = true)
	private String perProfile;

	@Column(name = "PerBloodGroup", length = 10, nullable = true)
	private String perBloodGroup;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FK_PersonID_Primary", referencedColumnName = "PersonID", nullable = true)
	private PersonMaster personMaster;

	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FK_UserID", referencedColumnName = "UserID", nullable = true)
	private UserMaster userMaster;

	@Transient
	private Set<LocationMaster> locationMasterdata = new HashSet<LocationMaster>(0);

	@Transient
	private PLMLocationStatus plmLocationStatus;
	
	@Transient
	private FacilityCenterMaster facilityCenterMaster;
	
	public PersonMaster() {

	}

	public PersonMaster(Long personID, String personKey, PerStatus perStatus, String perFname, String perMname,
			String perLName, Long perDOB, Integer perAge, String perDegree, String perDesignation,
			Boolean isAgeEstimated, GenderStatus gender, String perMobilePrimary, List<String> perMobileList,
			String perEmailPrimary, List<String> perEmailList, String perWhatsappID, String bodyHeight,
			String bodyWeightInKG, Integer bmi, Integer chestInches, Integer waistInches, Boolean isWearingGlasses,
			Boolean isWearingHearingAid, Boolean isWearingDenture, Boolean isWearingOrthoPedicDevice, String perRace,
			String perEthnicity, Boolean hasSmokingHistory, Boolean hasDrinkingHistory, String perAadhaarCardNo,
			String perPANcardNo, String perDrivingLicenseNo, MaritalStatus marital, WorkStatus work,
			EmploymentStatus employment, String employerName, PatRelationStatus relations, String webSiteURL,
			Boolean isInsured, String perAadhaarCardID, Boolean isAadhaarverified, String perPANcardID,
			Boolean isPerPANCardverified, String perDrivingLicenseID, Boolean isPerDrivingLicense, String perSSN,
			String perSIN, String perProfile, String perBloodGroup, PersonMaster personMaster, UserMaster userMaster,
			Set<LocationMaster> locationMasterdata, PLMLocationStatus plmLocationStatus,
			FacilityCenterMaster facilityCenterMaster) {
		super();
		this.personID = personID;
		this.personKey = personKey;
		this.perStatus = perStatus;
		this.perFname = perFname;
		this.perMname = perMname;
		this.perLName = perLName;
		this.perDOB = perDOB;
		this.perAge = perAge;
		this.perDegree = perDegree;
		this.perDesignation = perDesignation;
		this.isAgeEstimated = isAgeEstimated;
		this.gender = gender;
		this.perMobilePrimary = perMobilePrimary;
		this.perMobileList = perMobileList;
		this.perEmailPrimary = perEmailPrimary;
		this.perEmailList = perEmailList;
		this.perWhatsappID = perWhatsappID;
		this.bodyHeight = bodyHeight;
		this.bodyWeightInKG = bodyWeightInKG;
		this.bmi = bmi;
		this.chestInches = chestInches;
		this.waistInches = waistInches;
		this.isWearingGlasses = isWearingGlasses;
		this.isWearingHearingAid = isWearingHearingAid;
		this.isWearingDenture = isWearingDenture;
		this.isWearingOrthoPedicDevice = isWearingOrthoPedicDevice;
		this.perRace = perRace;
		this.perEthnicity = perEthnicity;
		this.hasSmokingHistory = hasSmokingHistory;
		this.hasDrinkingHistory = hasDrinkingHistory;
		this.perAadhaarCardNo = perAadhaarCardNo;
		this.perPANcardNo = perPANcardNo;
		this.perDrivingLicenseNo = perDrivingLicenseNo;
		this.marital = marital;
		this.work = work;
		this.employment = employment;
		this.employerName = employerName;
		this.relations = relations;
		this.webSiteURL = webSiteURL;
		this.isInsured = isInsured;
		this.perAadhaarCardID = perAadhaarCardID;
		this.isAadhaarverified = isAadhaarverified;
		this.perPANcardID = perPANcardID;
		this.isPerPANCardverified = isPerPANCardverified;
		this.perDrivingLicenseID = perDrivingLicenseID;
		this.isPerDrivingLicense = isPerDrivingLicense;
		this.perSSN = perSSN;
		this.perSIN = perSIN;
		this.perProfile = perProfile;
		this.perBloodGroup = perBloodGroup;
		this.personMaster = personMaster;
		this.userMaster = userMaster;
		this.locationMasterdata = locationMasterdata;
		this.plmLocationStatus = plmLocationStatus;
		this.facilityCenterMaster = facilityCenterMaster;
	}

	public Long getPersonID() {
		return personID;
	}

	public String getPersonKey() {
		return personKey;
	}

	public PerStatus getPerStatus() {
		return perStatus;
	}

	public String getPerFname() {
		return perFname;
	}

	public String getPerMname() {
		return perMname;
	}

	public String getPerLName() {
		return perLName;
	}

	public Long getPerDOB() {
		return perDOB;
	}

	public Integer getPerAge() {
		return perAge;
	}

	public String getPerDegree() {
		return perDegree;
	}

	public String getPerDesignation() {
		return perDesignation;
	}

	public Boolean getIsAgeEstimated() {
		return isAgeEstimated;
	}

	public GenderStatus getGender() {
		return gender;
	}

	public String getPerMobilePrimary() {
		return perMobilePrimary;
	}

	public List<String> getPerMobileList() {
		return perMobileList;
	}

	public String getPerEmailPrimary() {
		return perEmailPrimary;
	}

	public List<String> getPerEmailList() {
		return perEmailList;
	}

	public String getPerWhatsappID() {
		return perWhatsappID;
	}

	public String getBodyHeight() {
		return bodyHeight;
	}

	public String getBodyWeightInKG() {
		return bodyWeightInKG;
	}

	public Integer getBmi() {
		return bmi;
	}

	public Integer getChestInches() {
		return chestInches;
	}

	public Integer getWaistInches() {
		return waistInches;
	}

	public Boolean getIsWearingGlasses() {
		return isWearingGlasses;
	}

	public Boolean getIsWearingHearingAid() {
		return isWearingHearingAid;
	}

	public Boolean getIsWearingDenture() {
		return isWearingDenture;
	}

	public Boolean getIsWearingOrthoPedicDevice() {
		return isWearingOrthoPedicDevice;
	}

	public String getPerRace() {
		return perRace;
	}

	public String getPerEthnicity() {
		return perEthnicity;
	}

	public Boolean getHasSmokingHistory() {
		return hasSmokingHistory;
	}

	public Boolean getHasDrinkingHistory() {
		return hasDrinkingHistory;
	}

	public String getPerAadhaarCardNo() {
		return perAadhaarCardNo;
	}

	public String getPerPANcardNo() {
		return perPANcardNo;
	}

	public String getPerDrivingLicenseNo() {
		return perDrivingLicenseNo;
	}

	public MaritalStatus getMarital() {
		return marital;
	}

	public WorkStatus getWork() {
		return work;
	}

	public EmploymentStatus getEmployment() {
		return employment;
	}

	public String getEmployerName() {
		return employerName;
	}

	public PatRelationStatus getRelations() {
		return relations;
	}

	public String getWebSiteURL() {
		return webSiteURL;
	}

	public Boolean getIsInsured() {
		return isInsured;
	}

	public String getPerAadhaarCardID() {
		return perAadhaarCardID;
	}

	public Boolean getIsAadhaarverified() {
		return isAadhaarverified;
	}

	public String getPerPANcardID() {
		return perPANcardID;
	}

	public Boolean getIsPerPANCardverified() {
		return isPerPANCardverified;
	}

	public String getPerDrivingLicenseID() {
		return perDrivingLicenseID;
	}

	public Boolean getIsPerDrivingLicense() {
		return isPerDrivingLicense;
	}

	public String getPerSSN() {
		return perSSN;
	}

	public String getPerSIN() {
		return perSIN;
	}

	public String getPerProfile() {
		return perProfile;
	}

	public String getPerBloodGroup() {
		return perBloodGroup;
	}

	public PersonMaster getPersonMaster() {
		return personMaster;
	}

	public UserMaster getUserMaster() {
		return userMaster;
	}

	public Set<LocationMaster> getLocationMasterdata() {
		return locationMasterdata;
	}

	public PLMLocationStatus getPlmLocationStatus() {
		return plmLocationStatus;
	}

	public FacilityCenterMaster getFacilityCenterMaster() {
		return facilityCenterMaster;
	}

	public void setPersonID(Long personID) {
		this.personID = personID;
	}

	public void setPersonKey(String personKey) {
		this.personKey = personKey;
	}

	public void setPerStatus(PerStatus perStatus) {
		this.perStatus = perStatus;
	}

	public void setPerFname(String perFname) {
		this.perFname = perFname;
	}

	public void setPerMname(String perMname) {
		this.perMname = perMname;
	}

	public void setPerLName(String perLName) {
		this.perLName = perLName;
	}

	public void setPerDOB(Long perDOB) {
		this.perDOB = perDOB;
	}

	public void setPerAge(Integer perAge) {
		this.perAge = perAge;
	}

	public void setPerDegree(String perDegree) {
		this.perDegree = perDegree;
	}

	public void setPerDesignation(String perDesignation) {
		this.perDesignation = perDesignation;
	}

	public void setIsAgeEstimated(Boolean isAgeEstimated) {
		this.isAgeEstimated = isAgeEstimated;
	}

	public void setGender(GenderStatus gender) {
		this.gender = gender;
	}

	public void setPerMobilePrimary(String perMobilePrimary) {
		this.perMobilePrimary = perMobilePrimary;
	}

	public void setPerMobileList(List<String> perMobileList) {
		this.perMobileList = perMobileList;
	}

	public void setPerEmailPrimary(String perEmailPrimary) {
		this.perEmailPrimary = perEmailPrimary;
	}

	public void setPerEmailList(List<String> perEmailList) {
		this.perEmailList = perEmailList;
	}

	public void setPerWhatsappID(String perWhatsappID) {
		this.perWhatsappID = perWhatsappID;
	}

	public void setBodyHeight(String bodyHeight) {
		this.bodyHeight = bodyHeight;
	}

	public void setBodyWeightInKG(String bodyWeightInKG) {
		this.bodyWeightInKG = bodyWeightInKG;
	}

	public void setBmi(Integer bmi) {
		this.bmi = bmi;
	}

	public void setChestInches(Integer chestInches) {
		this.chestInches = chestInches;
	}

	public void setWaistInches(Integer waistInches) {
		this.waistInches = waistInches;
	}

	public void setIsWearingGlasses(Boolean isWearingGlasses) {
		this.isWearingGlasses = isWearingGlasses;
	}

	public void setIsWearingHearingAid(Boolean isWearingHearingAid) {
		this.isWearingHearingAid = isWearingHearingAid;
	}

	public void setIsWearingDenture(Boolean isWearingDenture) {
		this.isWearingDenture = isWearingDenture;
	}

	public void setIsWearingOrthoPedicDevice(Boolean isWearingOrthoPedicDevice) {
		this.isWearingOrthoPedicDevice = isWearingOrthoPedicDevice;
	}

	public void setPerRace(String perRace) {
		this.perRace = perRace;
	}

	public void setPerEthnicity(String perEthnicity) {
		this.perEthnicity = perEthnicity;
	}

	public void setHasSmokingHistory(Boolean hasSmokingHistory) {
		this.hasSmokingHistory = hasSmokingHistory;
	}

	public void setHasDrinkingHistory(Boolean hasDrinkingHistory) {
		this.hasDrinkingHistory = hasDrinkingHistory;
	}

	public void setPerAadhaarCardNo(String perAadhaarCardNo) {
		this.perAadhaarCardNo = perAadhaarCardNo;
	}

	public void setPerPANcardNo(String perPANcardNo) {
		this.perPANcardNo = perPANcardNo;
	}

	public void setPerDrivingLicenseNo(String perDrivingLicenseNo) {
		this.perDrivingLicenseNo = perDrivingLicenseNo;
	}

	public void setMarital(MaritalStatus marital) {
		this.marital = marital;
	}

	public void setWork(WorkStatus work) {
		this.work = work;
	}

	public void setEmployment(EmploymentStatus employment) {
		this.employment = employment;
	}

	public void setEmployerName(String employerName) {
		this.employerName = employerName;
	}

	public void setRelations(PatRelationStatus relations) {
		this.relations = relations;
	}

	public void setWebSiteURL(String webSiteURL) {
		this.webSiteURL = webSiteURL;
	}

	public void setIsInsured(Boolean isInsured) {
		this.isInsured = isInsured;
	}

	public void setPerAadhaarCardID(String perAadhaarCardID) {
		this.perAadhaarCardID = perAadhaarCardID;
	}

	public void setIsAadhaarverified(Boolean isAadhaarverified) {
		this.isAadhaarverified = isAadhaarverified;
	}

	public void setPerPANcardID(String perPANcardID) {
		this.perPANcardID = perPANcardID;
	}

	public void setIsPerPANCardverified(Boolean isPerPANCardverified) {
		this.isPerPANCardverified = isPerPANCardverified;
	}

	public void setPerDrivingLicenseID(String perDrivingLicenseID) {
		this.perDrivingLicenseID = perDrivingLicenseID;
	}

	public void setIsPerDrivingLicense(Boolean isPerDrivingLicense) {
		this.isPerDrivingLicense = isPerDrivingLicense;
	}

	public void setPerSSN(String perSSN) {
		this.perSSN = perSSN;
	}

	public void setPerSIN(String perSIN) {
		this.perSIN = perSIN;
	}

	public void setPerProfile(String perProfile) {
		this.perProfile = perProfile;
	}

	public void setPerBloodGroup(String perBloodGroup) {
		this.perBloodGroup = perBloodGroup;
	}

	public void setPersonMaster(PersonMaster personMaster) {
		this.personMaster = personMaster;
	}

	public void setUserMaster(UserMaster userMaster) {
		this.userMaster = userMaster;
	}

	public void setLocationMasterdata(Set<LocationMaster> locationMasterdata) {
		this.locationMasterdata = locationMasterdata;
	}

	public void setPlmLocationStatus(PLMLocationStatus plmLocationStatus) {
		this.plmLocationStatus = plmLocationStatus;
	}

	public void setFacilityCenterMaster(FacilityCenterMaster facilityCenterMaster) {
		this.facilityCenterMaster = facilityCenterMaster;
	}
}