package org.healthchain.entity.enums;

import java.util.ArrayList;
import java.util.List;

public enum PatientLabAppointmentReason {

	Other("Other"),
	CBC("CBC"),
	MajorLipidProfile("MajorLipidProfile"),
	MinorLipidProfile("MinorLipidProfile"),
	Diabetes("Diabetes");
	
	private String id;

    PatientLabAppointmentReason(String id) {
        this.id = id;
    }

    public String getId() {
        return id;
    }

    public static PatientLabAppointmentReason parse(String id) {
    	PatientLabAppointmentReason patAppReason = null; // Default
        for (PatientLabAppointmentReason item : PatientLabAppointmentReason.values()) {
        	if (item.getId().equals(id)) {
            	patAppReason = item;
                break;
            }
        }
        return patAppReason;
    }

    public static String getValue(String id) {
    	for (PatientLabAppointmentReason item : PatientLabAppointmentReason.values()) {
	         if (item.name() == id) {
	         		return item.getId();
	         }
    	}
    	return null;
    }
    
    public static List<String> getAllPatientLabAppointmentReason() {
    	PatientLabAppointmentReason[] values = PatientLabAppointmentReason.values();
        List<String> list = new ArrayList<>();
        for (PatientLabAppointmentReason value : values) {
            list.add(value.name());
        }
        return list;
    }
}
