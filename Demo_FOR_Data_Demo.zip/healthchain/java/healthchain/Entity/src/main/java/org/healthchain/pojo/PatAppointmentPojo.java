package org.healthchain.pojo;

import java.io.Serializable;

import org.healthchain.entity.enums.FacilityCenterType;
import org.healthchain.entity.enums.PatientAppointmentReason;
import org.healthchain.entity.enums.PatientAppointmentStatus;
import org.healthchain.entity.enums.PatientAppointmentType;

public class PatAppointmentPojo implements Serializable {

	private static final long serialVersionUID = 1L;
	private Long patAppointmentID;
	private Long fclProviderMapID;
	private Long providerID;
	private String providerName;
	private Long patAppDate;
	private Long patAppTimeFrom;
	private Long patAppTimeTo;
	private Long fcLocationMapID;
	private String fcLocationName;
	private Long facilityCenterID;
	private FacilityCenterType facilityCenterType;
	private PatientAppointmentType patAppType;
	private PatientAppointmentStatus patAppStatus;
	private PatientAppointmentReason patAppReason;
	private String patAppDescription;
	private Long specialityID;
	private String specialityName;
	private String  facilityCenterName;
	private Long patientID;
	private String name;
	
	public PatAppointmentPojo() {
		
	}

	public PatAppointmentPojo(Long patAppointmentID, Long fclProviderMapID, Long providerID, String providerName,
			Long patAppDate, Long patAppTimeFrom, Long patAppTimeTo, Long fcLocationMapID, String fcLocationName,
			Long facilityCenterID, FacilityCenterType facilityCenterType, PatientAppointmentType patAppType,
			PatientAppointmentStatus patAppStatus, PatientAppointmentReason patAppReason, String patAppDescription,
			Long specialityID, String specialityName, String facilityCenterName, Long patientID, String name) {
		super();
		this.patAppointmentID = patAppointmentID;
		this.fclProviderMapID = fclProviderMapID;
		this.providerID = providerID;
		this.providerName = providerName;
		this.patAppDate = patAppDate;
		this.patAppTimeFrom = patAppTimeFrom;
		this.patAppTimeTo = patAppTimeTo;
		this.fcLocationMapID = fcLocationMapID;
		this.fcLocationName = fcLocationName;
		this.facilityCenterID = facilityCenterID;
		this.facilityCenterType = facilityCenterType;
		this.patAppType = patAppType;
		this.patAppStatus = patAppStatus;
		this.patAppReason = patAppReason;
		this.patAppDescription = patAppDescription;
		this.specialityID = specialityID;
		this.specialityName = specialityName;
		this.facilityCenterName = facilityCenterName;
		this.patientID = patientID;
		this.name = name;
	}

	public Long getPatAppointmentID() {
		return patAppointmentID;
	}

	public Long getFclProviderMapID() {
		return fclProviderMapID;
	}

	public Long getProviderID() {
		return providerID;
	}

	public String getProviderName() {
		return providerName;
	}

	public Long getPatAppDate() {
		return patAppDate;
	}

	public Long getPatAppTimeFrom() {
		return patAppTimeFrom;
	}

	public Long getPatAppTimeTo() {
		return patAppTimeTo;
	}

	public Long getFcLocationMapID() {
		return fcLocationMapID;
	}

	public String getFcLocationName() {
		return fcLocationName;
	}

	public Long getFacilityCenterID() {
		return facilityCenterID;
	}

	public FacilityCenterType getFacilityCenterType() {
		return facilityCenterType;
	}

	public PatientAppointmentType getPatAppType() {
		return patAppType;
	}

	public PatientAppointmentStatus getPatAppStatus() {
		return patAppStatus;
	}

	public PatientAppointmentReason getPatAppReason() {
		return patAppReason;
	}

	public String getPatAppDescription() {
		return patAppDescription;
	}

	public Long getSpecialityID() {
		return specialityID;
	}

	public String getSpecialityName() {
		return specialityName;
	}

	public String getFacilityCenterName() {
		return facilityCenterName;
	}

	public Long getPatientID() {
		return patientID;
	}

	public String getName() {
		return name;
	}

	public void setPatAppointmentID(Long patAppointmentID) {
		this.patAppointmentID = patAppointmentID;
	}

	public void setFclProviderMapID(Long fclProviderMapID) {
		this.fclProviderMapID = fclProviderMapID;
	}

	public void setProviderID(Long providerID) {
		this.providerID = providerID;
	}

	public void setProviderName(String providerName) {
		this.providerName = providerName;
	}

	public void setPatAppDate(Long patAppDate) {
		this.patAppDate = patAppDate;
	}

	public void setPatAppTimeFrom(Long patAppTimeFrom) {
		this.patAppTimeFrom = patAppTimeFrom;
	}

	public void setPatAppTimeTo(Long patAppTimeTo) {
		this.patAppTimeTo = patAppTimeTo;
	}

	public void setFcLocationMapID(Long fcLocationMapID) {
		this.fcLocationMapID = fcLocationMapID;
	}

	public void setFcLocationName(String fcLocationName) {
		this.fcLocationName = fcLocationName;
	}

	public void setFacilityCenterID(Long facilityCenterID) {
		this.facilityCenterID = facilityCenterID;
	}

	public void setFacilityCenterType(FacilityCenterType facilityCenterType) {
		this.facilityCenterType = facilityCenterType;
	}

	public void setPatAppType(PatientAppointmentType patAppType) {
		this.patAppType = patAppType;
	}

	public void setPatAppStatus(PatientAppointmentStatus patAppStatus) {
		this.patAppStatus = patAppStatus;
	}

	public void setPatAppReason(PatientAppointmentReason patAppReason) {
		this.patAppReason = patAppReason;
	}

	public void setPatAppDescription(String patAppDescription) {
		this.patAppDescription = patAppDescription;
	}

	public void setSpecialityID(Long specialityID) {
		this.specialityID = specialityID;
	}

	public void setSpecialityName(String specialityName) {
		this.specialityName = specialityName;
	}

	public void setFacilityCenterName(String facilityCenterName) {
		this.facilityCenterName = facilityCenterName;
	}

	public void setPatientID(Long patientID) {
		this.patientID = patientID;
	}

	public void setName(String name) {
		this.name = name;
	}

}
