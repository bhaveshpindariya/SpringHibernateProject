package org.healthchain.entity.enums;

import java.util.ArrayList;
import java.util.List;

public enum SpecialityCode {

	GeneralPractice("General Practice"),
	GeneralSurgery("General Surgery"),
	AllErgyorimmunology("All Ergyorimmunolog"),
	LabSpeciality("Lab Speciality"),
	Otolaryngology("Otolaryngology");
        
    private String id;

    SpecialityCode(String id) {
        this.id = id;
    }

    public String getId() {
        return id;
    }

    public static SpecialityCode parse(String id) {
        SpecialityCode specialityCode = null; // Default
        for (SpecialityCode item : SpecialityCode.values()) {
        	if (item.getId().equals(id)) {
            	specialityCode = item;
                break;
            }
        }
        return specialityCode;
    }
    
    public static String getValue(String id) {
    	for (SpecialityCode item : SpecialityCode.values()) {
	         if (item.name() == id) {
	         		return item.getId();
	         }
    	}
    	return null;
    }

    public static List<String> getAllSpecialityCode() {
        SpecialityCode[] values = SpecialityCode.values();
        List<String> list = new ArrayList<>();
        for (SpecialityCode value : values) {
            list.add(value.name());
        }
        return list;
    }
}
