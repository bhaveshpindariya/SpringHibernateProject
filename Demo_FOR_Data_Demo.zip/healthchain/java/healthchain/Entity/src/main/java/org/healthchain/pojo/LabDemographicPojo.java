package org.healthchain.pojo;

import java.io.Serializable;

public class LabDemographicPojo implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private Long personID;
	private Long facilityCenterID;
	private String perMobilePrimary;
	private Object perMobileList;
	public Object locationMasterdata;
	
	public LabDemographicPojo() {
		
	}

	public LabDemographicPojo(Long personID, Long facilityCenterID, String perMobilePrimary, Object perMobileList,
			Object locationMasterdata) {
		super();
		this.personID = personID;
		this.facilityCenterID = facilityCenterID;
		this.perMobilePrimary = perMobilePrimary;
		this.perMobileList = perMobileList;
		this.locationMasterdata = locationMasterdata;
	}

	public Long getPersonID() {
		return personID;
	}

	public Long getFacilityCenterID() {
		return facilityCenterID;
	}

	public String getPerMobilePrimary() {
		return perMobilePrimary;
	}

	public Object getPerMobileList() {
		return perMobileList;
	}

	public Object getLocationMasterdata() {
		return locationMasterdata;
	}

	public void setPersonID(Long personID) {
		this.personID = personID;
	}

	public void setFacilityCenterID(Long facilityCenterID) {
		this.facilityCenterID = facilityCenterID;
	}

	public void setPerMobilePrimary(String perMobilePrimary) {
		this.perMobilePrimary = perMobilePrimary;
	}

	public void setPerMobileList(Object perMobileList) {
		this.perMobileList = perMobileList;
	}

	public void setLocationMasterdata(Object locationMasterdata) {
		this.locationMasterdata = locationMasterdata;
	}

		
}
