package org.healthchain.pojo;

import java.io.Serializable;

import org.healthchain.entity.enums.LabReportType;

public class LabReportsLevel1Pojo implements Serializable {

	private static final long serialVersionUID = 1L;
	private Long labReportLevel1ID;
	private LabReportType labReportType;
	private String lrl1Category;
	private String lrl1Name;
	private String genericTestcode;
	private String genericSourceName;
	
	public LabReportsLevel1Pojo() {
		
	}

	@Override
	public String toString() {
		return "LabReportsLevel1Pojo [labReportLevel1ID=" + labReportLevel1ID + ", labReportType=" + labReportType
				+ ", lrl1Category=" + lrl1Category + ", lrl1Name=" + lrl1Name + ", genericTestcode=" + genericTestcode
				+ ", genericSourceName=" + genericSourceName + "]";
	}

	public LabReportsLevel1Pojo(Long labReportLevel1ID, LabReportType labReportType, String lrl1Category,
			String lrl1Name, String genericTestcode, String genericSourceName) {
		super();
		this.labReportLevel1ID = labReportLevel1ID;
		this.labReportType = labReportType;
		this.lrl1Category = lrl1Category;
		this.lrl1Name = lrl1Name;
		this.genericTestcode = genericTestcode;
		this.genericSourceName = genericSourceName;
	}

	public Long getLabReportLevel1ID() {
		return labReportLevel1ID;
	}

	public LabReportType getLabReportType() {
		return labReportType;
	}

	public String getLrl1Category() {
		return lrl1Category;
	}

	public String getLrl1Name() {
		return lrl1Name;
	}

	public String getGenericTestcode() {
		return genericTestcode;
	}

	public String getGenericSourceName() {
		return genericSourceName;
	}

	public void setLabReportLevel1ID(Long labReportLevel1ID) {
		this.labReportLevel1ID = labReportLevel1ID;
	}

	public void setLabReportType(LabReportType labReportType) {
		this.labReportType = labReportType;
	}

	public void setLrl1Category(String lrl1Category) {
		this.lrl1Category = lrl1Category;
	}

	public void setLrl1Name(String lrl1Name) {
		this.lrl1Name = lrl1Name;
	}

	public void setGenericTestcode(String genericTestcode) {
		this.genericTestcode = genericTestcode;
	}

	public void setGenericSourceName(String genericSourceName) {
		this.genericSourceName = genericSourceName;
	}
}
