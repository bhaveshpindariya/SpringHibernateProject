package org.healthchain.pojo;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

public class ReportLapPojo implements Serializable {

	private static final long serialVersionUID = 1L;
	private Long reportLapAppId;
	private String reportPath;
	private String extraDetail;
	private Set<DiseasePojo> diagnosisMasterdata = new HashSet<DiseasePojo>(0);
	private LabReportsLevel1Pojo labReportsLevel1Pojo;
		
	public ReportLapPojo() {
		
	}

	public ReportLapPojo(Long reportLapAppId, String reportPath, String extraDetail,
			Set<DiseasePojo> diagnosisMasterdata, LabReportsLevel1Pojo labReportsLevel1Pojo) {
		super();
		this.reportLapAppId = reportLapAppId;
		this.reportPath = reportPath;
		this.extraDetail = extraDetail;
		this.diagnosisMasterdata = diagnosisMasterdata;
		this.labReportsLevel1Pojo = labReportsLevel1Pojo;
	}

	public Long getReportLapAppId() {
		return reportLapAppId;
	}

	public String getReportPath() {
		return reportPath;
	}

	public String getExtraDetail() {
		return extraDetail;
	}

	public Set<DiseasePojo> getDiagnosisMasterdata() {
		return diagnosisMasterdata;
	}

	public LabReportsLevel1Pojo getLabReportsLevel1Pojo() {
		return labReportsLevel1Pojo;
	}

	public void setReportLapAppId(Long reportLapAppId) {
		this.reportLapAppId = reportLapAppId;
	}

	public void setReportPath(String reportPath) {
		this.reportPath = reportPath;
	}

	public void setExtraDetail(String extraDetail) {
		this.extraDetail = extraDetail;
	}

	public void setDiagnosisMasterdata(Set<DiseasePojo> diagnosisMasterdata) {
		this.diagnosisMasterdata = diagnosisMasterdata;
	}

	public void setLabReportsLevel1Pojo(LabReportsLevel1Pojo labReportsLevel1Pojo) {
		this.labReportsLevel1Pojo = labReportsLevel1Pojo;
	}
}
