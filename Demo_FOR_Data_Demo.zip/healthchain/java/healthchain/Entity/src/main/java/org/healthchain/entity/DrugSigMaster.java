package org.healthchain.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "AV_DrugSigMaster")
public class DrugSigMaster extends AuditableEntity implements BaseEntity,Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "DrugSigID")
	private Long drugSigID;
	
	@Column(name = "DrugSigAbbreviation", length=30 , nullable = true)
	private String drugSigAbbreviation;

	@Column(name = "DrugSigDetail", length=60 , nullable = true)
	private String drugSigDetail;

	public DrugSigMaster(Long drugSigID, String drugSigAbbreviation, String drugSigDetail) {
		super();
		this.drugSigID = drugSigID;
		this.drugSigAbbreviation = drugSigAbbreviation;
		this.drugSigDetail = drugSigDetail;
	}

	public DrugSigMaster() {
	
	}

	public Long getDrugSigID() {
		return drugSigID;
	}

	public void setDrugSigID(Long drugSigID) {
		this.drugSigID = drugSigID;
	}

	public String getDrugSigAbbreviation() {
		return drugSigAbbreviation;
	}

	public void setDrugSigAbbreviation(String drugSigAbbreviation) {
		this.drugSigAbbreviation = drugSigAbbreviation;
	}

	public String getDrugSigDetail() {
		return drugSigDetail;
	}

	public void setDrugSigDetail(String drugSigDetail) {
		this.drugSigDetail = drugSigDetail;
	}

}
