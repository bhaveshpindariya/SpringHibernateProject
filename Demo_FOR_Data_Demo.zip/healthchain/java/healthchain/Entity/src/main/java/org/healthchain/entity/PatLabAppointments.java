package org.healthchain.entity;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.healthchain.entity.enums.PatientAppointmentStatus;
import org.healthchain.entity.enums.PatientAppointmentType;
import org.healthchain.entity.enums.PatientLabAppointmentReason;

@Entity
@Table(name = "AV_PatLabAppointments")
public class PatLabAppointments extends AuditableEntity implements BaseEntity,Serializable{

	/**
	 * 
	 */
	
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "PatLabAppointmentID")
	private Long patLabAppointmentID;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FK_CFL_PatRegID", referencedColumnName = "CFL_PatRegID", nullable = true)
	private CFLPatRegistrationMap fclpID;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FK_FCL_ProviderMapID", referencedColumnName = "FCL_ProviderMapID", nullable = true)
	private FCLProviderMap fclProviderMapID;
	
	@Column(name = "PatLabApp_Date", nullable = true)
	private Long patLabAppDate;
	
	@Column(name = "PatLabApp_TimeFrom", nullable = true)
	private Long patLabAppTimeFrom;
	
	@Column(name = "PatLabApp_TimeTo", nullable = true)
	private Long patLabAppTimeTo;
	
	@Column(name = "PatLabApp_TimeUnit", length=20 ,nullable = true)
	private String patLabAppTimeUnit;
	
	@Column(name = "PatLabApp_TimeSlot", nullable = true)
	private Long patLabAppTimeSlot;
	
	@Basic
	@Column(name = "PatLabApp_Type", length=30 ,nullable = true)
	@Enumerated(EnumType.STRING)
	private PatientAppointmentType patAppType;
	
	@Column(name = "PatLab_Detail", columnDefinition = "TEXT",nullable = true)
	private String patLabDetail;
	
	@Column(name = "PatLab_AtHome", nullable = true ,columnDefinition = "Boolean default false")
	private boolean athome;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FK_PatVisitNoteID", referencedColumnName = "PatVisitNoteID", nullable = true)
	private PatVisitNote patVisitNote;
	
	@Basic
	@Column(name = "PatLabApp_Reason", length=150 , nullable = true)
	@Enumerated(EnumType.STRING)
	private PatientLabAppointmentReason patientLabAppointmentReason;
	
	@Column(name = "PatLabApp_Description", columnDefinition = "TEXT",nullable = true)
	private String patLabAppDescription;
	
	@Basic
	@Column(name = "PatLabApp_Status", length=30 ,nullable = true)
	@Enumerated(EnumType.STRING)
	private PatientAppointmentStatus patAppStatus;
	
	@Column(name = "ReasonIfCancelled", length=60 ,nullable = true)
	private String reasonIfCancelled;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FK_LabAppointmentID_IfReBooked", referencedColumnName = "PatLabAppointmentID", nullable = true)
	private PatLabAppointments patLabAppointments;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FK_SpecialityID", referencedColumnName = "SpecialityID", nullable = true)
	private SpecialityMaster specialityMaster;
	
	@Transient
	private Set<LabReportsLevel1>  labReportsLevel1= new HashSet<LabReportsLevel1>(0);

	public PatLabAppointments() {
		
	}

	public PatLabAppointments(Long patLabAppointmentID, CFLPatRegistrationMap fclpID, FCLProviderMap fclProviderMapID,
			Long patLabAppDate, Long patLabAppTimeFrom, Long patLabAppTimeTo, String patLabAppTimeUnit,
			Long patLabAppTimeSlot, PatientAppointmentType patAppType, String patLabDetail, boolean athome,
			PatVisitNote patVisitNote, PatientLabAppointmentReason patientLabAppointmentReason,
			String patLabAppDescription, PatientAppointmentStatus patAppStatus, String reasonIfCancelled,
			PatLabAppointments patLabAppointments, SpecialityMaster specialityMaster,
			Set<LabReportsLevel1> labReportsLevel1) {
		super();
		this.patLabAppointmentID = patLabAppointmentID;
		this.fclpID = fclpID;
		this.fclProviderMapID = fclProviderMapID;
		this.patLabAppDate = patLabAppDate;
		this.patLabAppTimeFrom = patLabAppTimeFrom;
		this.patLabAppTimeTo = patLabAppTimeTo;
		this.patLabAppTimeUnit = patLabAppTimeUnit;
		this.patLabAppTimeSlot = patLabAppTimeSlot;
		this.patAppType = patAppType;
		this.patLabDetail = patLabDetail;
		this.athome = athome;
		this.patVisitNote = patVisitNote;
		this.patientLabAppointmentReason = patientLabAppointmentReason;
		this.patLabAppDescription = patLabAppDescription;
		this.patAppStatus = patAppStatus;
		this.reasonIfCancelled = reasonIfCancelled;
		this.patLabAppointments = patLabAppointments;
		this.specialityMaster = specialityMaster;
		this.labReportsLevel1 = labReportsLevel1;
	}

	public Long getPatLabAppointmentID() {
		return patLabAppointmentID;
	}

	public CFLPatRegistrationMap getFclpID() {
		return fclpID;
	}

	public FCLProviderMap getFclProviderMapID() {
		return fclProviderMapID;
	}

	public Long getPatLabAppDate() {
		return patLabAppDate;
	}

	public Long getPatLabAppTimeFrom() {
		return patLabAppTimeFrom;
	}

	public Long getPatLabAppTimeTo() {
		return patLabAppTimeTo;
	}

	public String getPatLabAppTimeUnit() {
		return patLabAppTimeUnit;
	}

	public Long getPatLabAppTimeSlot() {
		return patLabAppTimeSlot;
	}

	public PatientAppointmentType getPatAppType() {
		return patAppType;
	}

	public String getPatLabDetail() {
		return patLabDetail;
	}

	public boolean isAthome() {
		return athome;
	}

	public PatVisitNote getPatVisitNote() {
		return patVisitNote;
	}

	public PatientLabAppointmentReason getPatientLabAppointmentReason() {
		return patientLabAppointmentReason;
	}

	public String getPatLabAppDescription() {
		return patLabAppDescription;
	}

	public PatientAppointmentStatus getPatAppStatus() {
		return patAppStatus;
	}

	public String getReasonIfCancelled() {
		return reasonIfCancelled;
	}

	public PatLabAppointments getPatLabAppointments() {
		return patLabAppointments;
	}

	public SpecialityMaster getSpecialityMaster() {
		return specialityMaster;
	}

	public Set<LabReportsLevel1> getLabReportsLevel1() {
		return labReportsLevel1;
	}

	public void setPatLabAppointmentID(Long patLabAppointmentID) {
		this.patLabAppointmentID = patLabAppointmentID;
	}

	public void setFclpID(CFLPatRegistrationMap fclpID) {
		this.fclpID = fclpID;
	}

	public void setFclProviderMapID(FCLProviderMap fclProviderMapID) {
		this.fclProviderMapID = fclProviderMapID;
	}

	public void setPatLabAppDate(Long patLabAppDate) {
		this.patLabAppDate = patLabAppDate;
	}

	public void setPatLabAppTimeFrom(Long patLabAppTimeFrom) {
		this.patLabAppTimeFrom = patLabAppTimeFrom;
	}

	public void setPatLabAppTimeTo(Long patLabAppTimeTo) {
		this.patLabAppTimeTo = patLabAppTimeTo;
	}

	public void setPatLabAppTimeUnit(String patLabAppTimeUnit) {
		this.patLabAppTimeUnit = patLabAppTimeUnit;
	}

	public void setPatLabAppTimeSlot(Long patLabAppTimeSlot) {
		this.patLabAppTimeSlot = patLabAppTimeSlot;
	}

	public void setPatAppType(PatientAppointmentType patAppType) {
		this.patAppType = patAppType;
	}

	public void setPatLabDetail(String patLabDetail) {
		this.patLabDetail = patLabDetail;
	}

	public void setAthome(boolean athome) {
		this.athome = athome;
	}

	public void setPatVisitNote(PatVisitNote patVisitNote) {
		this.patVisitNote = patVisitNote;
	}

	public void setPatientLabAppointmentReason(PatientLabAppointmentReason patientLabAppointmentReason) {
		this.patientLabAppointmentReason = patientLabAppointmentReason;
	}

	public void setPatLabAppDescription(String patLabAppDescription) {
		this.patLabAppDescription = patLabAppDescription;
	}

	public void setPatAppStatus(PatientAppointmentStatus patAppStatus) {
		this.patAppStatus = patAppStatus;
	}

	public void setReasonIfCancelled(String reasonIfCancelled) {
		this.reasonIfCancelled = reasonIfCancelled;
	}

	public void setPatLabAppointments(PatLabAppointments patLabAppointments) {
		this.patLabAppointments = patLabAppointments;
	}

	public void setSpecialityMaster(SpecialityMaster specialityMaster) {
		this.specialityMaster = specialityMaster;
	}

	public void setLabReportsLevel1(Set<LabReportsLevel1> labReportsLevel1) {
		this.labReportsLevel1 = labReportsLevel1;
	}
	
}
