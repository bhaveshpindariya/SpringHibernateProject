package org.healthchain.pojo;

import java.io.Serializable;

import org.healthchain.entity.PatLabAppointments;
import org.healthchain.entity.enums.FacilityCenterType;
import org.healthchain.entity.enums.PatientAppointmentStatus;
import org.healthchain.entity.enums.PatientAppointmentType;
import org.healthchain.entity.enums.PatientLabAppointmentReason;

public class PatLabAppointmentsPojo implements Serializable {

	private static final long serialVersionUID = 1L;
	private Long patLabAppointmentID;
	private Long fclProviderMapID;
	private Long providerID;
	private String providerName;
	private Long patLabAppDate;
	private Long patLabAppTimeFrom;
	private Long patLabAppTimeTo;
	private Long fcLocationMapID;
	private Long patVisitNoteID;
	private String fcLocationName;
	private Long facilityCenterID;
	private FacilityCenterType facilityCenterType;
	private PatientAppointmentStatus patAppStatus;
	private PatientAppointmentType patAppType;
	private PatLabAppointments patLabAppointments;
	private PatientLabAppointmentReason patientLabAppointmentReason;
	private String patLabDetail;
	private boolean athome;
	private Long patientID;
	private String  facilityCenterName;
	private String name;
	private Object data;
	
	public PatLabAppointmentsPojo() {
		
	}

	public PatLabAppointmentsPojo(Long patLabAppointmentID, Long fclProviderMapID, Long providerID, String providerName,
			Long patLabAppDate, Long patLabAppTimeFrom, Long patLabAppTimeTo, Long fcLocationMapID,
			String fcLocationName, Long facilityCenterID, FacilityCenterType facilityCenterType,
			PatientAppointmentStatus patAppStatus, PatientAppointmentType patAppType,
			PatLabAppointments patLabAppointments, PatientLabAppointmentReason patientLabAppointmentReason,
			String patLabDetail, boolean athome, Long patientID, String facilityCenterName, String name, Long patVisitNoteID,Object data) {
		super();
		this.patLabAppointmentID = patLabAppointmentID;
		this.fclProviderMapID = fclProviderMapID;
		this.providerID = providerID;
		this.providerName = providerName;
		this.patLabAppDate = patLabAppDate;
		this.patLabAppTimeFrom = patLabAppTimeFrom;
		this.patLabAppTimeTo = patLabAppTimeTo;
		this.fcLocationMapID = fcLocationMapID;
		this.fcLocationName = fcLocationName;
		this.facilityCenterID = facilityCenterID;
		this.facilityCenterType = facilityCenterType;
		this.patAppStatus = patAppStatus;
		this.patAppType = patAppType;
		this.patLabAppointments = patLabAppointments;
		this.patientLabAppointmentReason = patientLabAppointmentReason;
		this.patLabDetail = patLabDetail;
		this.athome = athome;
		this.patientID = patientID;
		this.facilityCenterName = facilityCenterName;
		this.name = name;
		this.data = data;
		this.patVisitNoteID=patVisitNoteID;
	}

	public Long getPatLabAppointmentID() {
		return patLabAppointmentID;
	}

	public Long getFclProviderMapID() {
		return fclProviderMapID;
	}

	public Long getProviderID() {
		return providerID;
	}

	public String getProviderName() {
		return providerName;
	}

	public Long getPatLabAppDate() {
		return patLabAppDate;
	}

	public Long getPatLabAppTimeFrom() {
		return patLabAppTimeFrom;
	}

	public Long getPatLabAppTimeTo() {
		return patLabAppTimeTo;
	}

	public Long getFcLocationMapID() {
		return fcLocationMapID;
	}

	public String getFcLocationName() {
		return fcLocationName;
	}

	public Long getFacilityCenterID() {
		return facilityCenterID;
	}

	public FacilityCenterType getFacilityCenterType() {
		return facilityCenterType;
	}

	public PatientAppointmentStatus getPatAppStatus() {
		return patAppStatus;
	}

	public PatientAppointmentType getPatAppType() {
		return patAppType;
	}

	public PatLabAppointments getPatLabAppointments() {
		return patLabAppointments;
	}

	public PatientLabAppointmentReason getPatientLabAppointmentReason() {
		return patientLabAppointmentReason;
	}

	public String getPatLabDetail() {
		return patLabDetail;
	}

	public boolean isAthome() {
		return athome;
	}

	public Long getPatientID() {
		return patientID;
	}

	public String getFacilityCenterName() {
		return facilityCenterName;
	}

	public String getName() {
		return name;
	}

	public Object getData() {
		return data;
	}

	public void setPatLabAppointmentID(Long patLabAppointmentID) {
		this.patLabAppointmentID = patLabAppointmentID;
	}

	public void setFclProviderMapID(Long fclProviderMapID) {
		this.fclProviderMapID = fclProviderMapID;
	}

	public void setProviderID(Long providerID) {
		this.providerID = providerID;
	}

	public void setProviderName(String providerName) {
		this.providerName = providerName;
	}

	public void setPatLabAppDate(Long patLabAppDate) {
		this.patLabAppDate = patLabAppDate;
	}

	public void setPatLabAppTimeFrom(Long patLabAppTimeFrom) {
		this.patLabAppTimeFrom = patLabAppTimeFrom;
	}

	public void setPatLabAppTimeTo(Long patLabAppTimeTo) {
		this.patLabAppTimeTo = patLabAppTimeTo;
	}

	public void setFcLocationMapID(Long fcLocationMapID) {
		this.fcLocationMapID = fcLocationMapID;
	}

	public void setFcLocationName(String fcLocationName) {
		this.fcLocationName = fcLocationName;
	}

	public void setFacilityCenterID(Long facilityCenterID) {
		this.facilityCenterID = facilityCenterID;
	}

	public void setFacilityCenterType(FacilityCenterType facilityCenterType) {
		this.facilityCenterType = facilityCenterType;
	}

	public void setPatAppStatus(PatientAppointmentStatus patAppStatus) {
		this.patAppStatus = patAppStatus;
	}

	public void setPatAppType(PatientAppointmentType patAppType) {
		this.patAppType = patAppType;
	}

	public void setPatLabAppointments(PatLabAppointments patLabAppointments) {
		this.patLabAppointments = patLabAppointments;
	}

	public void setPatientLabAppointmentReason(PatientLabAppointmentReason patientLabAppointmentReason) {
		this.patientLabAppointmentReason = patientLabAppointmentReason;
	}

	public void setPatLabDetail(String patLabDetail) {
		this.patLabDetail = patLabDetail;
	}

	public void setAthome(boolean athome) {
		this.athome = athome;
	}

	public void setPatientID(Long patientID) {
		this.patientID = patientID;
	}

	public void setFacilityCenterName(String facilityCenterName) {
		this.facilityCenterName = facilityCenterName;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setData(Object data) {
		this.data = data;
	}

	public Long getPatVisitNoteID() {
		return patVisitNoteID;
	}

	public void setPatVisitNoteID(Long patVisitNoteID) {
		this.patVisitNoteID = patVisitNoteID;
	}
	
	
}
