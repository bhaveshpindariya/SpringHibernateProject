package org.healthchain.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "AV_PatDiagnosis")
public class PatDiagnosis extends AuditableEntity implements BaseEntity, Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "PatDiagnosisID")
	private Long patDiagnosisID;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FK_PatVisitNoteID", referencedColumnName = "PatVisitNoteID", nullable = true)
	private PatVisitNote patVisitNoteOutdoor;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FK_PatAdmitID", referencedColumnName = "PatAdmitID", nullable = true)
	private PatAdmission patAdmission;

	@Column(name = "Diagnosis_Type", nullable = true)
	private String diagnosisType;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FK_DiagnosisID", referencedColumnName = "DiagnosisID", nullable = true)
	private DiagnosisMaster diagnosisMaster;

	public PatDiagnosis() {
		
	}

	public PatDiagnosis(Long patDiagnosisID, PatVisitNote patVisitNoteOutdoor, PatAdmission patAdmission,
			String diagnosisType, DiagnosisMaster diagnosisMaster) {
		super();
		this.patDiagnosisID = patDiagnosisID;
		this.patVisitNoteOutdoor = patVisitNoteOutdoor;
		this.patAdmission = patAdmission;
		this.diagnosisType = diagnosisType;
		this.diagnosisMaster = diagnosisMaster;
	}

	public Long getPatDiagnosisID() {
		return patDiagnosisID;
	}

	public PatVisitNote getPatVisitNoteOutdoor() {
		return patVisitNoteOutdoor;
	}

	public PatAdmission getPatAdmission() {
		return patAdmission;
	}

	public String getDiagnosisType() {
		return diagnosisType;
	}

	public DiagnosisMaster getDiagnosisMaster() {
		return diagnosisMaster;
	}

	public void setPatDiagnosisID(Long patDiagnosisID) {
		this.patDiagnosisID = patDiagnosisID;
	}

	public void setPatVisitNoteOutdoor(PatVisitNote patVisitNoteOutdoor) {
		this.patVisitNoteOutdoor = patVisitNoteOutdoor;
	}

	public void setPatAdmission(PatAdmission patAdmission) {
		this.patAdmission = patAdmission;
	}

	public void setDiagnosisType(String diagnosisType) {
		this.diagnosisType = diagnosisType;
	}

	public void setDiagnosisMaster(DiagnosisMaster diagnosisMaster) {
		this.diagnosisMaster = diagnosisMaster;
	}

	

}