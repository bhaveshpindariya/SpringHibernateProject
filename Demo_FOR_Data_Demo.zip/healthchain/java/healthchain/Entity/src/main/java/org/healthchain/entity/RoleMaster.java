package org.healthchain.entity;

import java.io.Serializable;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "AV_RoleMaster")
public class RoleMaster implements BaseEntity,Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "RoleID")
	private Long roleID;

	@Column(name = "RoleName", length=30 ,nullable = true, unique=true)
	private String roleName;

	@OneToMany(mappedBy = "roleMaster")
	private Set<UserRoleEntity> userRoleEntity = new HashSet<UserRoleEntity>();

	@ManyToOne
	@JoinColumn(name = "created_by", referencedColumnName = "UserID", nullable = true)
	private UserMaster createdBy;

	@Column(name = "created_on", nullable = true)
	private Date createdOn;

	@ManyToOne
	@JoinColumn(name = "modified_by", referencedColumnName = "UserID", nullable = true)
	private UserMaster modifiedBy;

	@Column(name = "modified_on", nullable = true)
	private Date modifiedOn;

	@Column(name = "is_active", nullable = true ,columnDefinition = "Boolean default true")
	private boolean active;

	@Column(name = "is_delete", nullable = true ,columnDefinition = "Boolean default false")
	private boolean deleted;

	public RoleMaster() {
	
	}

	public RoleMaster(Long roleID, String roleName, Set<UserRoleEntity> userRoleEntity, UserMaster createdBy,
			Date createdOn, UserMaster modifiedBy, Date modifiedOn, boolean active, boolean deleted) {
		super();
		this.roleID = roleID;
		this.roleName = roleName;
		this.userRoleEntity = userRoleEntity;
		this.createdBy = createdBy;
		this.createdOn = createdOn;
		this.modifiedBy = modifiedBy;
		this.modifiedOn = modifiedOn;
		this.active = active;
		this.deleted = deleted;
	}

	public Long getRoleID() {
		return roleID;
	}

	public String getRoleName() {
		return roleName;
	}

	public Set<UserRoleEntity> getUserRoleEntity() {
		return userRoleEntity;
	}

	public UserMaster getCreatedBy() {
		return createdBy;
	}

	public Date getCreatedOn() {
		return createdOn;
	}

	public UserMaster getModifiedBy() {
		return modifiedBy;
	}

	public Date getModifiedOn() {
		return modifiedOn;
	}

	public boolean getActive() {
		return active;
	}

	public boolean getDeleted() {
		return deleted;
	}

	public void setRoleID(Long roleID) {
		this.roleID = roleID;
	}

	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}

	public void setUserRoleEntity(Set<UserRoleEntity> userRoleEntity) {
		this.userRoleEntity = userRoleEntity;
	}

	public void setCreatedBy(UserMaster createdBy) {
		this.createdBy = createdBy;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	public void setModifiedBy(UserMaster modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public void setModifiedOn(Date modifiedOn) {
		this.modifiedOn = modifiedOn;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public void setDeleted(boolean deleted) {
		this.deleted = deleted;
	}
	
}
