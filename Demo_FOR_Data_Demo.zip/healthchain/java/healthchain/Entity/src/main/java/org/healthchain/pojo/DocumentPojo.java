package org.healthchain.pojo;

import java.io.Serializable;

public class DocumentPojo implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private Long personID;
	private Boolean isAadhaarverified;
	private Boolean isPerPANCardverified;
	private Boolean isPerDrivingLicense;
	private String perAadhaarCardID;
	private String perPANcardID;
	private String perDrivingLicenseID;
	private String perAadhaarCardNo;
	private String perPANcardNo;
	private String perDrivingLicenseNo;
	private String perSSN;
	private String perSIN;
	
	public DocumentPojo() {
		
	}

	public DocumentPojo(Long personID, Boolean isAadhaarverified, Boolean isPerPANCardverified,
			Boolean isPerDrivingLicense, String perAadhaarCardID, String perPANcardID, String perDrivingLicenseID,
			String perAadhaarCardNo, String perPANcardNo, String perDrivingLicenseNo, String perSSN, String perSIN) {
		super();
		this.personID = personID;
		this.isAadhaarverified = isAadhaarverified;
		this.isPerPANCardverified = isPerPANCardverified;
		this.isPerDrivingLicense = isPerDrivingLicense;
		this.perAadhaarCardID = perAadhaarCardID;
		this.perPANcardID = perPANcardID;
		this.perDrivingLicenseID = perDrivingLicenseID;
		this.perAadhaarCardNo = perAadhaarCardNo;
		this.perPANcardNo = perPANcardNo;
		this.perDrivingLicenseNo = perDrivingLicenseNo;
		this.perSSN = perSSN;
		this.perSIN = perSIN;
	}

	public Long getPersonID() {
		return personID;
	}

	public Boolean getIsAadhaarverified() {
		return isAadhaarverified;
	}

	public Boolean getIsPerPANCardverified() {
		return isPerPANCardverified;
	}

	public Boolean getIsPerDrivingLicense() {
		return isPerDrivingLicense;
	}

	public String getPerAadhaarCardID() {
		return perAadhaarCardID;
	}

	public String getPerPANcardID() {
		return perPANcardID;
	}

	public String getPerDrivingLicenseID() {
		return perDrivingLicenseID;
	}

	public String getPerAadhaarCardNo() {
		return perAadhaarCardNo;
	}

	public String getPerPANcardNo() {
		return perPANcardNo;
	}

	public String getPerDrivingLicenseNo() {
		return perDrivingLicenseNo;
	}

	public String getPerSSN() {
		return perSSN;
	}

	public String getPerSIN() {
		return perSIN;
	}

	public void setPersonID(Long personID) {
		this.personID = personID;
	}

	public void setIsAadhaarverified(Boolean isAadhaarverified) {
		this.isAadhaarverified = isAadhaarverified;
	}

	public void setIsPerPANCardverified(Boolean isPerPANCardverified) {
		this.isPerPANCardverified = isPerPANCardverified;
	}

	public void setIsPerDrivingLicense(Boolean isPerDrivingLicense) {
		this.isPerDrivingLicense = isPerDrivingLicense;
	}

	public void setPerAadhaarCardID(String perAadhaarCardID) {
		this.perAadhaarCardID = perAadhaarCardID;
	}

	public void setPerPANcardID(String perPANcardID) {
		this.perPANcardID = perPANcardID;
	}

	public void setPerDrivingLicenseID(String perDrivingLicenseID) {
		this.perDrivingLicenseID = perDrivingLicenseID;
	}

	public void setPerAadhaarCardNo(String perAadhaarCardNo) {
		this.perAadhaarCardNo = perAadhaarCardNo;
	}

	public void setPerPANcardNo(String perPANcardNo) {
		this.perPANcardNo = perPANcardNo;
	}

	public void setPerDrivingLicenseNo(String perDrivingLicenseNo) {
		this.perDrivingLicenseNo = perDrivingLicenseNo;
	}

	public void setPerSSN(String perSSN) {
		this.perSSN = perSSN;
	}

	public void setPerSIN(String perSIN) {
		this.perSIN = perSIN;
	}

}
