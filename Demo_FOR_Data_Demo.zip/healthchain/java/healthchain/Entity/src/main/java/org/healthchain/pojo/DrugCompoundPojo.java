package org.healthchain.pojo;

import java.io.Serializable;

public class DrugCompoundPojo implements Serializable {

	private static final long serialVersionUID = 1L;
	private Long drugCompoundID;
	private String drugCompoundName;
	
	public DrugCompoundPojo() {
		
	}

	public DrugCompoundPojo(Long drugCompoundID, String drugCompoundName) {
		super();
		this.drugCompoundID = drugCompoundID;
		this.drugCompoundName = drugCompoundName;
	}

	@Override
	public String toString() {
		return "DrugCompoundPojo [drugCompoundID=" + drugCompoundID + ", drugCompoundName=" + drugCompoundName + "]";
	}

	public Long getDrugCompoundID() {
		return drugCompoundID;
	}

	public String getDrugCompoundName() {
		return drugCompoundName;
	}

	public void setDrugCompoundID(Long drugCompoundID) {
		this.drugCompoundID = drugCompoundID;
	}

	public void setDrugCompoundName(String drugCompoundName) {
		this.drugCompoundName = drugCompoundName;
	}

	
}
