package org.healthchain.pojo;

import java.io.Serializable;

import org.healthchain.entity.enums.FacilityCenterType;

public class FacilityCenterPojo implements Serializable {

	private static final long serialVersionUID = 1L;
	private Long facilityCenterID;
	private String facilityCenterName;
	private FacilityCenterType facilityCenterType;
	private String fcCertificateNumber;
	
	public FacilityCenterPojo() {
		
	}

	public FacilityCenterPojo(Long facilityCenterID, String facilityCenterName, FacilityCenterType facilityCenterType,
			String fcCertificateNumber) {
		super();
		this.facilityCenterID = facilityCenterID;
		this.facilityCenterName = facilityCenterName;
		this.facilityCenterType = facilityCenterType;
		this.fcCertificateNumber = fcCertificateNumber;
	}

	@Override
	public String toString() {
		return "FacilityCenterPojo [facilityCenterID=" + facilityCenterID + ", facilityCenterName=" + facilityCenterName
				+ ", facilityCenterType=" + facilityCenterType + ", fcCertificateNumber=" + fcCertificateNumber + "]";
	}

	public Long getFacilityCenterID() {
		return facilityCenterID;
	}

	public String getFacilityCenterName() {
		return facilityCenterName;
	}

	public FacilityCenterType getFacilityCenterType() {
		return facilityCenterType;
	}

	public String getFcCertificateNumber() {
		return fcCertificateNumber;
	}

	public void setFacilityCenterID(Long facilityCenterID) {
		this.facilityCenterID = facilityCenterID;
	}

	public void setFacilityCenterName(String facilityCenterName) {
		this.facilityCenterName = facilityCenterName;
	}

	public void setFacilityCenterType(FacilityCenterType facilityCenterType) {
		this.facilityCenterType = facilityCenterType;
	}

	public void setFcCertificateNumber(String fcCertificateNumber) {
		this.fcCertificateNumber = fcCertificateNumber;
	}
	
}
