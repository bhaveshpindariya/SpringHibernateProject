package org.healthchain.pojo;

import java.io.Serializable;
import java.util.List;

public class PatAppointmentPojoList implements Serializable {

	private static final long serialVersionUID = 1L;
	private int totalNumber;
	private List<PatAppointmentPojo> patAppointmentPojo;
	
	public PatAppointmentPojoList() {
		
	}

	public PatAppointmentPojoList(int totalNumber, List<PatAppointmentPojo> patAppointmentPojo) {
		super();
		this.totalNumber = totalNumber;
		this.patAppointmentPojo = patAppointmentPojo;
	}

	public int getTotalNumber() {
		return totalNumber;
	}

	public List<PatAppointmentPojo> getPatAppointmentPojo() {
		return patAppointmentPojo;
	}

	public void setTotalNumber(int totalNumber) {
		this.totalNumber = totalNumber;
	}

	public void setPatAppointmentPojo(List<PatAppointmentPojo> patAppointmentPojo) {
		this.patAppointmentPojo = patAppointmentPojo;
	}

}
