package org.healthchain.entity.enums;

import java.util.ArrayList;
import java.util.List;

public enum PatRelationStatus {

	Self("Self"),
	Spouse("Spouse"),
	Child("Child"),
	Parent("Parent"),
	Sibling("Sibling"),
	Other("Other");
	
	private String id;

    PatRelationStatus(String id) {
        this.id = id;
    }

    public String getId() {
        return id;
    }

    public static String getValue(String id) {
    	for (PatRelationStatus item : PatRelationStatus.values()) {
    		if (item.getId().equals(id)) {
	         		return item.getId();
	         }
    	}
    	return null;
    }
    
    public static PatRelationStatus parse(String id) {
        PatRelationStatus maritalStatus = null; // Default
        for (PatRelationStatus item : PatRelationStatus.values()) {
            if (item.getId() == id) {
                maritalStatus = item;
                break;
            }
        }
        return maritalStatus;
    }

    public static List<String> getAllMaritalStatus() {
        PatRelationStatus[] values = PatRelationStatus.values();
        List<String> list = new ArrayList<>();
        for (PatRelationStatus value : values) {
            list.add(value.name());
        }
        return list;
    }
}
