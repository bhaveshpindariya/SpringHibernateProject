package org.healthchain.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "AV_FCL_Provider_Lab_Doctor_Map")
public class FCLProviderLabDoctorMap extends AuditableEntity implements BaseEntity,Serializable{
	
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "FCL_Provider_Lab_Doctor_MapID")
	private Long fclProviderLabDoctorMapID;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FK_FCL_ProviderMapID", referencedColumnName = "FCL_ProviderMapID", nullable = true)
	private FCLProviderMap fclProviderMapID;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FK_Doctor", referencedColumnName = "FCL_ProviderMapID", nullable = true)
	private FCLProviderMap doctor;
	
	public FCLProviderLabDoctorMap() {
		
	}

	public FCLProviderLabDoctorMap(Long fclProviderLabDoctorMapID, FCLProviderMap fclProviderMapID,
			FCLProviderMap doctor) {
		super();
		this.fclProviderLabDoctorMapID = fclProviderLabDoctorMapID;
		this.fclProviderMapID = fclProviderMapID;
		this.doctor = doctor;
	}

	public Long getFclProviderLabDoctorMapID() {
		return fclProviderLabDoctorMapID;
	}

	public FCLProviderMap getFclProviderMapID() {
		return fclProviderMapID;
	}

	public FCLProviderMap getDoctor() {
		return doctor;
	}

	public void setFclProviderLabDoctorMapID(Long fclProviderLabDoctorMapID) {
		this.fclProviderLabDoctorMapID = fclProviderLabDoctorMapID;
	}

	public void setFclProviderMapID(FCLProviderMap fclProviderMapID) {
		this.fclProviderMapID = fclProviderMapID;
	}

	public void setDoctor(FCLProviderMap doctor) {
		this.doctor = doctor;
	}
}
