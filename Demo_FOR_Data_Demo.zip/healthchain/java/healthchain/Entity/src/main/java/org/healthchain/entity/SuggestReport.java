package org.healthchain.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "AV_SuggestReport")
public class SuggestReport extends AuditableEntity implements BaseEntity,Serializable{

	/**
	 * 
	 */
	
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "SuggestReportID")
	private Long suggestReportId;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FK_PatLabAppointmentID", referencedColumnName = "PatLabAppointmentID", nullable = true)
	private PatLabAppointments patLabAppointments;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FK_LabReportLevel1_ID", referencedColumnName = "LabReportLevel1_ID", nullable = true)
	private LabReportsLevel1 labReportsLevel1;

	public SuggestReport() {
	
	}

	public SuggestReport(Long suggestReportId, PatLabAppointments patLabAppointments, LabReportsLevel1 labReportsLevel1) {
		super();
		this.suggestReportId = suggestReportId;
		this.patLabAppointments = patLabAppointments;
		this.labReportsLevel1 = labReportsLevel1;
	}

	public Long getSuggestReportId() {
		return suggestReportId;
	}

	public PatLabAppointments getPatLabAppointments() {
		return patLabAppointments;
	}

	public LabReportsLevel1 getLabReportsLevel1() {
		return labReportsLevel1;
	}

	public void setSuggestReportId(Long suggestReportId) {
		this.suggestReportId = suggestReportId;
	}

	public void setPatLabAppointments(PatLabAppointments patLabAppointments) {
		this.patLabAppointments = patLabAppointments;
	}

	public void setLabReportsLevel1(LabReportsLevel1 labReportsLevel1) {
		this.labReportsLevel1 = labReportsLevel1;
	}
	
}
