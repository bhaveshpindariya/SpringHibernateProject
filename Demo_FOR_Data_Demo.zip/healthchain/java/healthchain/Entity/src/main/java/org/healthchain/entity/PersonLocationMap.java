package org.healthchain.entity;

import java.io.Serializable;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.healthchain.entity.enums.PLMLocationStatus;

@Entity
@Table(name = "AV_PersonLocationMap")
public class PersonLocationMap extends AuditableEntity implements BaseEntity,Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "PersonLocationMapID")
	private Long personLocationMapID;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FK_PersonID", referencedColumnName = "PersonID", nullable = true)
	private PersonMaster personMaster;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FK_LocationID", referencedColumnName = "LocationID", nullable = true)
	private LocationMaster locationMaster;
	
	@Basic
	@Column(name = "PLM_LocationType", length=25 ,nullable = true)
	@Enumerated(EnumType.STRING)
	private PLMLocationStatus plmLocationStatus;
	
	public PersonLocationMap() {
		
	}

	public PersonLocationMap(Long personLocationMapID, PersonMaster personMaster, LocationMaster locationMaster,
			PLMLocationStatus plmLocationStatus) {
		super();
		this.personLocationMapID = personLocationMapID;
		this.personMaster = personMaster;
		this.locationMaster = locationMaster;
		this.plmLocationStatus = plmLocationStatus;
	}

	public Long getPersonLocationMapID() {
		return personLocationMapID;
	}

	public PersonMaster getPersonMaster() {
		return personMaster;
	}

	public LocationMaster getLocationMaster() {
		return locationMaster;
	}

	public PLMLocationStatus getPlmLocationStatus() {
		return plmLocationStatus;
	}

	public void setPersonLocationMapID(Long personLocationMapID) {
		this.personLocationMapID = personLocationMapID;
	}

	public void setPersonMaster(PersonMaster personMaster) {
		this.personMaster = personMaster;
	}

	public void setLocationMaster(LocationMaster locationMaster) {
		this.locationMaster = locationMaster;
	}

	public void setPlmLocationStatus(PLMLocationStatus plmLocationStatus) {
		this.plmLocationStatus = plmLocationStatus;
	}

}
