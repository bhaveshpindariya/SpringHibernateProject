package org.healthchain.pojo;

import java.io.Serializable;

public class RoleEntityPojo implements Serializable {

	private static final long serialVersionUID = 1L;
	public Long id;
	private String name;
	
	@Override
	public String toString() {
		return "RoleEntityPojo [id=" + id + ", name=" + name + "]";
	}

	public RoleEntityPojo(Long id, String name) {
		super();
		this.id = id;
		this.name = name;
	}

	public RoleEntityPojo() {
		
	}

	public Long getId() {
		return id;
	}

	public String getName() {
		return name;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public void setName(String name) {
		this.name = name;
	}
	
}
