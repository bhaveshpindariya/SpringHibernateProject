package org.healthchain.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "AV_HealthCareServiceMaster")
public class HealthCareServiceMaster extends AuditableEntity implements BaseEntity,Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "HealthCareServiceMaster")
	private Long healthCareServiceMaster;
	
	@Column(name = "HCS_Name", length=40 ,nullable = true)
	private String hscName;
	
	@Column(name = "US_CPT_CODE", nullable = true)
	private float usCptCode;

	@Column(name = "US_CPT_NAME", length=40 ,nullable = true)
	private String usCptName;

	public HealthCareServiceMaster(Long healthCareServiceMaster, String hscName, float usCptCode, String usCptName) {
		super();
		this.healthCareServiceMaster = healthCareServiceMaster;
		this.hscName = hscName;
		this.usCptCode = usCptCode;
		this.usCptName = usCptName;
	}

	public HealthCareServiceMaster() {
		
	}

	public Long getHealthCareServiceMaster() {
		return healthCareServiceMaster;
	}

	public void setHealthCareServiceMaster(Long healthCareServiceMaster) {
		this.healthCareServiceMaster = healthCareServiceMaster;
	}

	public String getHscName() {
		return hscName;
	}

	public void setHscName(String hscName) {
		this.hscName = hscName;
	}

	public float getUsCptCode() {
		return usCptCode;
	}

	public void setUsCptCode(float usCptCode) {
		this.usCptCode = usCptCode;
	}

	public String getUsCptName() {
		return usCptName;
	}

	public void setUsCptName(String usCptName) {
		this.usCptName = usCptName;
	}

}
