package org.healthchain.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.healthchain.entity.enums.StaffStatus;

@Entity
@Table(name = "AV_StaffMaster")
public class StaffMaster extends AuditableEntity implements BaseEntity,Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "StaffID")
	private Long staffID;
	
	@Column(name = "Staff_Type", length=30 ,nullable = true)
	@Enumerated(EnumType.STRING)
	private StaffStatus staffType;

	@Column(name = "StaffCertificationId",length=30 ,nullable = true)
	private String staffCertificationId;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FK_PersonID", referencedColumnName = "PersonID", nullable = true)
	private PersonMaster personMaster;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FK_SpecialityID", referencedColumnName = "SpecialityID", nullable = true)
	private SpecialityMaster specialityMaster;

	public StaffMaster(Long staffID, StaffStatus staffType, String staffCertificationId, PersonMaster personMaster,
			SpecialityMaster specialityMaster) {
		super();
		this.staffID = staffID;
		this.staffType = staffType;
		this.staffCertificationId = staffCertificationId;
		this.personMaster = personMaster;
		this.specialityMaster = specialityMaster;
	}

	public StaffMaster() {
		
	}

	public Long getStaffID() {
		return staffID;
	}

	public StaffStatus getStaffType() {
		return staffType;
	}

	public String getStaffCertificationId() {
		return staffCertificationId;
	}

	public PersonMaster getPersonMaster() {
		return personMaster;
	}

	public SpecialityMaster getSpecialityMaster() {
		return specialityMaster;
	}

	public void setStaffID(Long staffID) {
		this.staffID = staffID;
	}

	public void setStaffType(StaffStatus staffType) {
		this.staffType = staffType;
	}

	public void setStaffCertificationId(String staffCertificationId) {
		this.staffCertificationId = staffCertificationId;
	}

	public void setPersonMaster(PersonMaster personMaster) {
		this.personMaster = personMaster;
	}

	public void setSpecialityMaster(SpecialityMaster specialityMaster) {
		this.specialityMaster = specialityMaster;
	}

}
