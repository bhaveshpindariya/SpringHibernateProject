package org.healthchain.entity.enums;

import java.util.ArrayList;
import java.util.List;

public enum CurrencyType {

	RS("RS"),
	Dollar("Dollar"),
	CAD("CAD");
        
    private String id;

    CurrencyType(String id) {
        this.id = id;
    }

    public String getId() {
        return id;
    }

    public static CurrencyType parse(String id) {
    	CurrencyType currencyType = null; // Default
        for (CurrencyType item : CurrencyType.values()) {
        	if (item.getId().equals(id)) {
            	currencyType = item;
                break;
            }
        }
        return currencyType;
    }
    
    public static String getValue(String id) {
    	 for (CurrencyType item : CurrencyType.values()) {
            if (item.name() == id) {
            		return item.getId();
            }
        }
        return null;
    }
    
    public static List<String> getAllCurrencyType() {
    	CurrencyType[] values = CurrencyType.values();
        List<String> list = new ArrayList<>();
        for (CurrencyType value : values) {
            list.add(value.name());
        }
        return list;
    }
}
