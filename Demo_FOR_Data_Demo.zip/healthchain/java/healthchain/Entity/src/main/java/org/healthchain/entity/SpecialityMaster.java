package org.healthchain.entity;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.healthchain.entity.enums.SpecialityCode;

@Entity
@Table(name="AV_SpecialityMaster")
public class SpecialityMaster extends AuditableEntity implements BaseEntity,Serializable{

	
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "SpecialityID")
	private Long specialityID;
	
	@Column(name = "Speciality_Name", length=50 ,unique=true,nullable = true)
	private String specialityName;
	
	@Column(name = "US_Speciality_Code", length=30 ,nullable = true)
	@Enumerated(EnumType.STRING)
	private SpecialityCode specialityCode;
	
	@OneToMany(cascade = CascadeType.ALL,fetch = FetchType.LAZY, mappedBy = "specialityMaster")
    private Set<SpecialityProviderMaster>  specialityProviderMaster= new HashSet<SpecialityProviderMaster>(0);

	public SpecialityMaster() {
		
	}

	public SpecialityMaster(Long specialityID, String specialityName, SpecialityCode specialityCode,
			Set<SpecialityProviderMaster> specialityProviderMaster) {
		super();
		this.specialityID = specialityID;
		this.specialityName = specialityName;
		this.specialityCode = specialityCode;
		this.specialityProviderMaster = specialityProviderMaster;
	}

	public Long getSpecialityID() {
		return specialityID;
	}

	public String getSpecialityName() {
		return specialityName;
	}

	public SpecialityCode getSpecialityCode() {
		return specialityCode;
	}

	public Set<SpecialityProviderMaster> getSpecialityProviderMaster() {
		return specialityProviderMaster;
	}

	public void setSpecialityID(Long specialityID) {
		this.specialityID = specialityID;
	}

	public void setSpecialityName(String specialityName) {
		this.specialityName = specialityName;
	}

	public void setSpecialityCode(SpecialityCode specialityCode) {
		this.specialityCode = specialityCode;
	}

	public void setSpecialityProviderMaster(Set<SpecialityProviderMaster> specialityProviderMaster) {
		this.specialityProviderMaster = specialityProviderMaster;
	}
	
}
