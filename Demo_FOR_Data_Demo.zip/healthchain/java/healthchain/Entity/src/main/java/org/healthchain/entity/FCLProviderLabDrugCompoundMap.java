package org.healthchain.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "AV_FCL_Provider_DrugCompound_Map")
public class FCLProviderLabDrugCompoundMap extends AuditableEntity implements BaseEntity,Serializable{
	
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "FCLProvider_Lab_DrugCompoundID")
	private Long fclProviderLabDrugCompoundMapID;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FK_FCL_ProviderMapID", referencedColumnName = "FCL_ProviderMapID", nullable = true)
	private FCLProviderMap fclProviderMapID;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FK_DrugCompoundID", referencedColumnName = "DrugCompoundID", nullable = true)
	private DrugCompoundMaster drugCompoundID;

	public FCLProviderLabDrugCompoundMap() {
		
	}

	public FCLProviderLabDrugCompoundMap(Long fclProviderLabDrugCompoundMapID, FCLProviderMap fclProviderMapID,
			DrugCompoundMaster drugCompoundID) {
		super();
		this.fclProviderLabDrugCompoundMapID = fclProviderLabDrugCompoundMapID;
		this.fclProviderMapID = fclProviderMapID;
		this.drugCompoundID = drugCompoundID;
	}

	public Long getFclProviderLabDrugCompoundMapID() {
		return fclProviderLabDrugCompoundMapID;
	}

	public FCLProviderMap getFclProviderMapID() {
		return fclProviderMapID;
	}

	public DrugCompoundMaster getDrugCompoundID() {
		return drugCompoundID;
	}

	public void setFclProviderLabDrugCompoundMapID(Long fclProviderLabDrugCompoundMapID) {
		this.fclProviderLabDrugCompoundMapID = fclProviderLabDrugCompoundMapID;
	}

	public void setFclProviderMapID(FCLProviderMap fclProviderMapID) {
		this.fclProviderMapID = fclProviderMapID;
	}

	public void setDrugCompoundID(DrugCompoundMaster drugCompoundID) {
		this.drugCompoundID = drugCompoundID;
	}

}
