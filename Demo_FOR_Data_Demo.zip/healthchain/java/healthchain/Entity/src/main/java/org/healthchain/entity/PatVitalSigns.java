package org.healthchain.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "AV_PatVitalSigns")
public class PatVitalSigns extends AuditableEntity implements BaseEntity, Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "PatVitalSignID")
	private Long patVitalSignID;

	@Column(name = "PatVitalSignDate", nullable = true)
	private Date patVitalSignDate;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "PatVitalSignTime", nullable = true)
	private Date PatVitalSignTime;;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FCL_StaffMapID", referencedColumnName = "FCL_StaffMapID", nullable = true)
	private FCLStaffMap fclStaffMapID;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FK_PatVisitNoteID", referencedColumnName = "PatVisitNoteID", nullable = true)
	private PatVisitNote patVisitNoteOutdoor;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FK_PatAdmitID", referencedColumnName = "PatAdmitID", nullable = true)
	private PatAdmission patAdmission;

	@Column(name = "BodyWeightIn_KG", nullable = true)
	private float bodyWeightInKG;
	
	@Column(name = "BodyHeightIn_Inches", nullable = true)
	private float bodyHeightInInches;
	
	@Column(name = "BMR", nullable = true)
	private int bmr;
	
	@Column(name = "Chest", nullable = true)
	private float chest;
	
	@Column(name = "Waist", nullable = true)
	private float waist;
	
	@Column(name = "PVS_Pulse", nullable = true)
	private String pvsPulse;
	
	@Column(name = "PVS_TemperatureIn_C", nullable = true)
	private float pvsTemperatureInC;
	
	@Column(name = "PVS_TemperatureIn_F", nullable = true)
	private float pvsTemperatureInF;
	
	@Column(name = "PVS_BP_Systolic", nullable = true)
	private int pvsBPSystolic;
	
	@Column(name = "PVS_BP_Diastolic", nullable = true)
	private int pvsBPDiastolic;
	
	@Column(name = "PVS_RR", nullable = true)
	private int pvsRR;

	public PatVitalSigns() {
		
	}

	public PatVitalSigns(Long patVitalSignID, Date patVitalSignDate, Date patVitalSignTime, FCLStaffMap fclStaffMapID,
			PatVisitNote patVisitNoteOutdoor, PatAdmission patAdmission, float bodyWeightInKG,
			float bodyHeightInInches, int bmr, float chest, float waist, String pvsPulse, float pvsTemperatureInC,
			float pvsTemperatureInF, int pvsBPSystolic, int pvsBPDiastolic, int pvsRR) {
		super();
		this.patVitalSignID = patVitalSignID;
		this.patVitalSignDate = patVitalSignDate;
		PatVitalSignTime = patVitalSignTime;
		this.fclStaffMapID = fclStaffMapID;
		this.patVisitNoteOutdoor = patVisitNoteOutdoor;
		this.patAdmission = patAdmission;
		this.bodyWeightInKG = bodyWeightInKG;
		this.bodyHeightInInches = bodyHeightInInches;
		this.bmr = bmr;
		this.chest = chest;
		this.waist = waist;
		this.pvsPulse = pvsPulse;
		this.pvsTemperatureInC = pvsTemperatureInC;
		this.pvsTemperatureInF = pvsTemperatureInF;
		this.pvsBPSystolic = pvsBPSystolic;
		this.pvsBPDiastolic = pvsBPDiastolic;
		this.pvsRR = pvsRR;
	}

	public Long getPatVitalSignID() {
		return patVitalSignID;
	}

	public Date getPatVitalSignDate() {
		return patVitalSignDate;
	}

	public Date getPatVitalSignTime() {
		return PatVitalSignTime;
	}

	public FCLStaffMap getFclStaffMapID() {
		return fclStaffMapID;
	}

	public PatVisitNote getPatVisitNoteOutdoor() {
		return patVisitNoteOutdoor;
	}

	public PatAdmission getPatAdmission() {
		return patAdmission;
	}

	public float getBodyWeightInKG() {
		return bodyWeightInKG;
	}

	public float getBodyHeightInInches() {
		return bodyHeightInInches;
	}

	public int getBmr() {
		return bmr;
	}

	public float getChest() {
		return chest;
	}

	public float getWaist() {
		return waist;
	}

	public String getPvsPulse() {
		return pvsPulse;
	}

	public float getPvsTemperatureInC() {
		return pvsTemperatureInC;
	}

	public float getPvsTemperatureInF() {
		return pvsTemperatureInF;
	}

	public int getPvsBPSystolic() {
		return pvsBPSystolic;
	}

	public int getPvsBPDiastolic() {
		return pvsBPDiastolic;
	}

	public int getPvsRR() {
		return pvsRR;
	}

	public void setPatVitalSignID(Long patVitalSignID) {
		this.patVitalSignID = patVitalSignID;
	}

	public void setPatVitalSignDate(Date patVitalSignDate) {
		this.patVitalSignDate = patVitalSignDate;
	}

	public void setPatVitalSignTime(Date patVitalSignTime) {
		PatVitalSignTime = patVitalSignTime;
	}

	public void setFclStaffMapID(FCLStaffMap fclStaffMapID) {
		this.fclStaffMapID = fclStaffMapID;
	}

	public void setPatVisitNoteOutdoor(PatVisitNote patVisitNoteOutdoor) {
		this.patVisitNoteOutdoor = patVisitNoteOutdoor;
	}

	public void setPatAdmission(PatAdmission patAdmission) {
		this.patAdmission = patAdmission;
	}

	public void setBodyWeightInKG(float bodyWeightInKG) {
		this.bodyWeightInKG = bodyWeightInKG;
	}

	public void setBodyHeightInInches(float bodyHeightInInches) {
		this.bodyHeightInInches = bodyHeightInInches;
	}

	public void setBmr(int bmr) {
		this.bmr = bmr;
	}

	public void setChest(float chest) {
		this.chest = chest;
	}

	public void setWaist(float waist) {
		this.waist = waist;
	}

	public void setPvsPulse(String pvsPulse) {
		this.pvsPulse = pvsPulse;
	}

	public void setPvsTemperatureInC(float pvsTemperatureInC) {
		this.pvsTemperatureInC = pvsTemperatureInC;
	}

	public void setPvsTemperatureInF(float pvsTemperatureInF) {
		this.pvsTemperatureInF = pvsTemperatureInF;
	}

	public void setPvsBPSystolic(int pvsBPSystolic) {
		this.pvsBPSystolic = pvsBPSystolic;
	}

	public void setPvsBPDiastolic(int pvsBPDiastolic) {
		this.pvsBPDiastolic = pvsBPDiastolic;
	}

	public void setPvsRR(int pvsRR) {
		this.pvsRR = pvsRR;
	}
}