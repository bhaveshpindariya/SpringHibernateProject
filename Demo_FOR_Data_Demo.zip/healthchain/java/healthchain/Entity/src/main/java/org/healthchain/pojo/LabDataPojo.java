package org.healthchain.pojo;

import java.io.Serializable;
import java.util.List;

import org.healthchain.entity.LabReportsLevel1;

public class LabDataPojo implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private List<LabReportsLevel1> labReportsLevelData;

	public LabDataPojo() {
		
	}

	public LabDataPojo(List<LabReportsLevel1> labReportsLevelData) {
		super();
		this.labReportsLevelData = labReportsLevelData;
	}

	public List<LabReportsLevel1> getLabReportsLevelData() {
		return labReportsLevelData;
	}

	public void setLabReportsLevelData(List<LabReportsLevel1> labReportsLevelData) {
		this.labReportsLevelData = labReportsLevelData;
	}
	
}
