package org.healthchain.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "AV_AllergiesMaster")
public class AllergiesMaster extends AuditableEntity implements BaseEntity,Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "AllergyID")
	private Long allergyID;
	
	@Column(name = "AllergyName", length=30 , nullable = true)
	private String allergyName;

	@Column(name = "AllergyDescription", columnDefinition="TEXT" ,nullable = true)
	private String allergyDescription;

	public AllergiesMaster(Long allergyID, String allergyName, String allergyDescription) {
		super();
		this.allergyID = allergyID;
		this.allergyName = allergyName;
		this.allergyDescription = allergyDescription;
	}

	public AllergiesMaster() {
		
	}

	public Long getAllergyID() {
		return allergyID;
	}

	public void setAllergyID(Long allergyID) {
		this.allergyID = allergyID;
	}

	public String getAllergyName() {
		return allergyName;
	}

	public void setAllergyName(String allergyName) {
		this.allergyName = allergyName;
	}

	public String getAllergyDescription() {
		return allergyDescription;
	}

	public void setAllergyDescription(String allergyDescription) {
		this.allergyDescription = allergyDescription;
	}
}
