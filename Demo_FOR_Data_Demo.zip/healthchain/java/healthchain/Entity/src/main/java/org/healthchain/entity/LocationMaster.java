package org.healthchain.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name = "AV_LocationMaster")
public class LocationMaster extends AuditableEntity implements BaseEntity,Serializable{

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "LocationID")
	private Long locationID;
	
	@Column(name = "AddressLine1", length=60 ,nullable = true)
	private String addressLine1; 
	
	@Column(name = "AddressLine2", length=60 ,nullable = true)
	private String addressLine2;
	
	@Column(name = "AddressLine3", length=60 ,nullable = true)
	private String addressLine3;
	
	@Column(name = "Area", length=60 ,nullable = true)
	private String area;
	
	@Column(name = "City", length=60 ,nullable = true)
	private String city;
	
	@Column(name = "State", length=60 ,nullable = true)
	private String state;
	
	@Column(name = "Zip", nullable = true)
	private Long zip;
	
	@Column(name = "Country", length=60 ,nullable = true)
	private String country;
	
	@Column(name = "Milestone1", length=60 ,nullable = true)
	private String milestone1;
	
	@Column(name = "Milestone2", length=60 ,nullable = true)
	private String milestone2;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FK_UTC_TimeZoneID", referencedColumnName = "UTC_TimeZoneID", nullable = true)
	private TimeZoneMaster timeZoneMaster;
	
	@Transient
	private String fcLocationName;

	public LocationMaster() {
		
	}

	public LocationMaster(Long locationID, String addressLine1, String addressLine2, String addressLine3, String area,
			String city, String state, Long zip, String country, String milestone1, String milestone2,
			TimeZoneMaster timeZoneMaster, String fcLocationName) {
		super();
		this.locationID = locationID;
		this.addressLine1 = addressLine1;
		this.addressLine2 = addressLine2;
		this.addressLine3 = addressLine3;
		this.area = area;
		this.city = city;
		this.state = state;
		this.zip = zip;
		this.country = country;
		this.milestone1 = milestone1;
		this.milestone2 = milestone2;
		this.timeZoneMaster = timeZoneMaster;
		this.fcLocationName = fcLocationName;
	}

	public Long getLocationID() {
		return locationID;
	}

	public String getAddressLine1() {
		return addressLine1;
	}

	public String getAddressLine2() {
		return addressLine2;
	}

	public String getAddressLine3() {
		return addressLine3;
	}

	public String getArea() {
		return area;
	}

	public String getCity() {
		return city;
	}

	public String getState() {
		return state;
	}

	public Long getZip() {
		return zip;
	}

	public String getCountry() {
		return country;
	}

	public String getMilestone1() {
		return milestone1;
	}

	public String getMilestone2() {
		return milestone2;
	}

	public TimeZoneMaster getTimeZoneMaster() {
		return timeZoneMaster;
	}

	public String getFcLocationName() {
		return fcLocationName;
	}

	public void setLocationID(Long locationID) {
		this.locationID = locationID;
	}

	public void setAddressLine1(String addressLine1) {
		this.addressLine1 = addressLine1;
	}

	public void setAddressLine2(String addressLine2) {
		this.addressLine2 = addressLine2;
	}

	public void setAddressLine3(String addressLine3) {
		this.addressLine3 = addressLine3;
	}

	public void setArea(String area) {
		this.area = area;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public void setState(String state) {
		this.state = state;
	}

	public void setZip(Long zip) {
		this.zip = zip;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public void setMilestone1(String milestone1) {
		this.milestone1 = milestone1;
	}

	public void setMilestone2(String milestone2) {
		this.milestone2 = milestone2;
	}

	public void setTimeZoneMaster(TimeZoneMaster timeZoneMaster) {
		this.timeZoneMaster = timeZoneMaster;
	}

	public void setFcLocationName(String fcLocationName) {
		this.fcLocationName = fcLocationName;
	}

}
