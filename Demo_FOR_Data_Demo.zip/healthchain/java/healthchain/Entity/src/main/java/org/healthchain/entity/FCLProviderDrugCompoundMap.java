package org.healthchain.entity;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name = "AV_FCL_Provider_DrugCompound_Map")
public class FCLProviderDrugCompoundMap extends AuditableEntity implements BaseEntity,Serializable{
	
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "FCLProvider_DrugCompoundID")
	private Long fclProviderDrugCompoundMapID;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FK_FCL_ProviderMapID", referencedColumnName = "FCL_ProviderMapID", nullable = true)
	private FCLProviderMap fclProviderMapID;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FK_DrugCompoundID", referencedColumnName = "DrugCompoundID", nullable = true)
	private DrugCompoundMaster drugCompoundID;

	@Transient
	private Set<DrugCompoundMaster>  drugCompoundMaster= new HashSet<DrugCompoundMaster>(0);
	
	@Transient
	private Set<FCLProviderMap>  hospital= new HashSet<FCLProviderMap>(0);
	
	@Transient
	private Set<FCLProviderMap>  doctor= new HashSet<FCLProviderMap>(0);
	
	@Transient
	private Long fclProviderMap;
	
	public FCLProviderDrugCompoundMap() {
		
	}

	public FCLProviderDrugCompoundMap(Long fclProviderDrugCompoundMapID, FCLProviderMap fclProviderMapID,
			DrugCompoundMaster drugCompoundID, Set<DrugCompoundMaster> drugCompoundMaster, Set<FCLProviderMap> hospital,
			Set<FCLProviderMap> doctor, Long fclProviderMap) {
		super();
		this.fclProviderDrugCompoundMapID = fclProviderDrugCompoundMapID;
		this.fclProviderMapID = fclProviderMapID;
		this.drugCompoundID = drugCompoundID;
		this.drugCompoundMaster = drugCompoundMaster;
		this.hospital = hospital;
		this.doctor = doctor;
		this.fclProviderMap = fclProviderMap;
	}

	public Long getFclProviderDrugCompoundMapID() {
		return fclProviderDrugCompoundMapID;
	}

	public FCLProviderMap getFclProviderMapID() {
		return fclProviderMapID;
	}

	public DrugCompoundMaster getDrugCompoundID() {
		return drugCompoundID;
	}

	public Set<DrugCompoundMaster> getDrugCompoundMaster() {
		return drugCompoundMaster;
	}

	public Set<FCLProviderMap> getHospital() {
		return hospital;
	}

	public Set<FCLProviderMap> getDoctor() {
		return doctor;
	}

	public Long getFclProviderMap() {
		return fclProviderMap;
	}

	public void setFclProviderDrugCompoundMapID(Long fclProviderDrugCompoundMapID) {
		this.fclProviderDrugCompoundMapID = fclProviderDrugCompoundMapID;
	}

	public void setFclProviderMapID(FCLProviderMap fclProviderMapID) {
		this.fclProviderMapID = fclProviderMapID;
	}

	public void setDrugCompoundID(DrugCompoundMaster drugCompoundID) {
		this.drugCompoundID = drugCompoundID;
	}

	public void setDrugCompoundMaster(Set<DrugCompoundMaster> drugCompoundMaster) {
		this.drugCompoundMaster = drugCompoundMaster;
	}

	public void setHospital(Set<FCLProviderMap> hospital) {
		this.hospital = hospital;
	}

	public void setDoctor(Set<FCLProviderMap> doctor) {
		this.doctor = doctor;
	}

	public void setFclProviderMap(Long fclProviderMap) {
		this.fclProviderMap = fclProviderMap;
	}
	
}
