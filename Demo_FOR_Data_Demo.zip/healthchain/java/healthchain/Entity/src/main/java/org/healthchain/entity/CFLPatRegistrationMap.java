package org.healthchain.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "AV_CFL_Pat_RegistrationMap")
public class CFLPatRegistrationMap extends AuditableEntity implements BaseEntity,Serializable{

	/**
	 * 
	 */
	
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "CFL_PatRegID")
	private Long patRegID;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FK_ClientFL_RegID", referencedColumnName = "ClientFL_RegID", nullable = true)
	private ClientFacilityLocationRegistrationMap clientFLRegID;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FK_FCLocationMapID", referencedColumnName = "FCLocationMapID", nullable = true)
	private FCLocationMap fcLocationMap;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FK_PatientID", referencedColumnName = "PatientID", nullable = true)
	private PatientMaster patientID;
	
	@Column(name = "DateRegistered", nullable = true)
	private Date dateRegistered;
	
	@Column(name = "IsInsured", nullable = true ,columnDefinition = "Boolean default false")
	private boolean isInsured;
	
	@Column(name = "IsInsuranceProcCompleted", nullable = true , columnDefinition = "Boolean default false")
	private boolean isInsuranceProcCompleted;
	
	@Column(name = "AmountDeposited", nullable = true)
	private float amountDeposited;
	
	@Column(name = "AmountConsumed", nullable = true)
	private float amountConsumed;

	public CFLPatRegistrationMap() {
		
	}

	public CFLPatRegistrationMap(Long patRegID, ClientFacilityLocationRegistrationMap clientFLRegID,
			FCLocationMap fcLocationMap, PatientMaster patientID, Date dateRegistered, boolean isInsured,
			boolean isInsuranceProcCompleted, float amountDeposited, float amountConsumed) {
		super();
		this.patRegID = patRegID;
		this.clientFLRegID = clientFLRegID;
		this.fcLocationMap = fcLocationMap;
		this.patientID = patientID;
		this.dateRegistered = dateRegistered;
		this.isInsured = isInsured;
		this.isInsuranceProcCompleted = isInsuranceProcCompleted;
		this.amountDeposited = amountDeposited;
		this.amountConsumed = amountConsumed;
	}

	public Long getPatRegID() {
		return patRegID;
	}

	public ClientFacilityLocationRegistrationMap getClientFLRegID() {
		return clientFLRegID;
	}

	public FCLocationMap getFcLocationMap() {
		return fcLocationMap;
	}

	public PatientMaster getPatientID() {
		return patientID;
	}

	public Date getDateRegistered() {
		return dateRegistered;
	}

	public boolean isInsured() {
		return isInsured;
	}

	public boolean isInsuranceProcCompleted() {
		return isInsuranceProcCompleted;
	}

	public float getAmountDeposited() {
		return amountDeposited;
	}

	public float getAmountConsumed() {
		return amountConsumed;
	}

	public void setPatRegID(Long patRegID) {
		this.patRegID = patRegID;
	}

	public void setClientFLRegID(ClientFacilityLocationRegistrationMap clientFLRegID) {
		this.clientFLRegID = clientFLRegID;
	}

	public void setFcLocationMap(FCLocationMap fcLocationMap) {
		this.fcLocationMap = fcLocationMap;
	}

	public void setPatientID(PatientMaster patientID) {
		this.patientID = patientID;
	}

	public void setDateRegistered(Date dateRegistered) {
		this.dateRegistered = dateRegistered;
	}

	public void setInsured(boolean isInsured) {
		this.isInsured = isInsured;
	}

	public void setInsuranceProcCompleted(boolean isInsuranceProcCompleted) {
		this.isInsuranceProcCompleted = isInsuranceProcCompleted;
	}

	public void setAmountDeposited(float amountDeposited) {
		this.amountDeposited = amountDeposited;
	}

	public void setAmountConsumed(float amountConsumed) {
		this.amountConsumed = amountConsumed;
	}

}
