package org.healthchain.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "AV_DrugManufacturersMaster")
public class DrugManufacturersMaster extends AuditableEntity implements BaseEntity,Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "DrugMfgrID")
	private Long drugMfgrID;
	
	@Column(name = "DrugMfgr_Name", length=60 ,nullable = true)
	private String drugMfgrName;

	@Column(name = "WebsiteURL", length=60 ,nullable = true)
	private String websiteURL;

	public DrugManufacturersMaster(Long drugMfgrID, String drugMfgrName, String websiteURL) {
		super();
		this.drugMfgrID = drugMfgrID;
		this.drugMfgrName = drugMfgrName;
		this.websiteURL = websiteURL;
	}

	public DrugManufacturersMaster() {
		
	}

	public Long getDrugMfgrID() {
		return drugMfgrID;
	}

	public void setDrugMfgrID(Long drugMfgrID) {
		this.drugMfgrID = drugMfgrID;
	}

	public String getDrugMfgrName() {
		return drugMfgrName;
	}

	public void setDrugMfgrName(String drugMfgrName) {
		this.drugMfgrName = drugMfgrName;
	}

	public String getWebsiteURL() {
		return websiteURL;
	}

	public void setWebsiteURL(String websiteURL) {
		this.websiteURL = websiteURL;
	}
}
