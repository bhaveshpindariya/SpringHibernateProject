package org.healthchain.entity;

import java.io.Serializable;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.healthchain.entity.enums.CurrencyType;

@Entity
@Table(name = "AV_LabReportsLevel2")
public class LabReportsLevel2 extends AuditableEntity implements BaseEntity,Serializable{

	/**
	 * 
	 */
	
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "LabReportLevel2_ID")
	private Long labReportLevel2ID;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FK_LabReportLevel1_ID", referencedColumnName = "LabReportLevel1_ID", nullable = true)
	private LabReportsLevel1 labReportLevel1ID;

	@Column(name = "LRL2_Name", length=40 ,nullable = true)
	private String lrl2_Name;
	
	@Column(name = "Lrl1_Abbreviation", length=20 ,nullable = true)
	private String lrl1Abbreviation;
	
	@Column(name = "NormalValue_Range", length=40 ,nullable = true)
	private String normalValueRange;
	
	@Column(name = "ValueUnit", length=20 ,nullable = true)
	private String valueUnit;
	
	@Column(name = "Speciman_Source", length=30 ,nullable = true)
	private String specimanSource;
	
	@Column(name = "GenericTestResultcode", length=30 ,nullable = true)
	private String genericTestResultcode;
	
	@Column(name = "Generic_Source_Name", length=40 ,nullable = true)
	private String genericSourceName;
	
	@Column(name = "Billable", nullable = true)
	private int billable;
	
	@Column(name = "FeeChargable", nullable = true)
	private float FeeChargable;
	
	@Basic
	@Column(name = "FeeInCurrency", length=10 ,nullable = true)
	@Enumerated(EnumType.STRING)
	private CurrencyType FeeInCurrency;

	public LabReportsLevel2(Long labReportLevel2ID, LabReportsLevel1 labReportLevel1ID, String lrl2_Name,
			String lrl1Abbreviation, String normalValueRange, String valueUnit, String specimanSource,
			String genericTestResultcode, String genericSourceName, int billable, float feeChargable,
			CurrencyType feeInCurrency) {
		
		super();
		this.labReportLevel2ID = labReportLevel2ID;
		this.labReportLevel1ID = labReportLevel1ID;
		this.lrl2_Name = lrl2_Name;
		this.lrl1Abbreviation = lrl1Abbreviation;
		this.normalValueRange = normalValueRange;
		this.valueUnit = valueUnit;
		this.specimanSource = specimanSource;
		this.genericTestResultcode = genericTestResultcode;
		this.genericSourceName = genericSourceName;
		this.billable = billable;
		FeeChargable = feeChargable;
		FeeInCurrency = feeInCurrency;
	}

	public LabReportsLevel2() {
		
	}

	public Long getLabReportLevel2ID() {
		return labReportLevel2ID;
	}

	public void setLabReportLevel2ID(Long labReportLevel2ID) {
		this.labReportLevel2ID = labReportLevel2ID;
	}

	public LabReportsLevel1 getLabReportLevel1ID() {
		return labReportLevel1ID;
	}

	public void setLabReportLevel1ID(LabReportsLevel1 labReportLevel1ID) {
		this.labReportLevel1ID = labReportLevel1ID;
	}

	public String getLrl2_Name() {
		return lrl2_Name;
	}

	public void setLrl2_Name(String lrl2_Name) {
		this.lrl2_Name = lrl2_Name;
	}

	public String getLrl1Abbreviation() {
		return lrl1Abbreviation;
	}

	public void setLrl1Abbreviation(String lrl1Abbreviation) {
		this.lrl1Abbreviation = lrl1Abbreviation;
	}

	public String getNormalValueRange() {
		return normalValueRange;
	}

	public void setNormalValueRange(String normalValueRange) {
		this.normalValueRange = normalValueRange;
	}

	public String getValueUnit() {
		return valueUnit;
	}

	public void setValueUnit(String valueUnit) {
		this.valueUnit = valueUnit;
	}

	public String getSpecimanSource() {
		return specimanSource;
	}

	public void setSpecimanSource(String specimanSource) {
		this.specimanSource = specimanSource;
	}

	public String getGenericTestResultcode() {
		return genericTestResultcode;
	}

	public void setGenericTestResultcode(String genericTestResultcode) {
		this.genericTestResultcode = genericTestResultcode;
	}

	public String getGenericSourceName() {
		return genericSourceName;
	}

	public void setGenericSourceName(String genericSourceName) {
		this.genericSourceName = genericSourceName;
	}

	public int getBillable() {
		return billable;
	}

	public void setBillable(int billable) {
		this.billable = billable;
	}

	public float getFeeChargable() {
		return FeeChargable;
	}

	public void setFeeChargable(float feeChargable) {
		FeeChargable = feeChargable;
	}

	public CurrencyType getFeeInCurrency() {
		return FeeInCurrency;
	}

	public void setFeeInCurrency(CurrencyType feeInCurrency) {
		FeeInCurrency = feeInCurrency;
	}
	
}
