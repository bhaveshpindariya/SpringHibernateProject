package org.healthchain.pojo;

import java.io.Serializable;

import org.healthchain.entity.enums.FacilityCenterType;
import org.healthchain.entity.enums.PatientAppointmentType;

public class PatVisitNotePojo implements Serializable {

	private static final long serialVersionUID = 1L;
	private Long patVisitNoteID;
	private String patVisitDate;
	private String times;
	private Long providerID;
	private String providerName;
	private Long patientID;
	private String name;
	private String patSymptoms;
	private String patSideEffect;
	private String patExtraDetails;
	private String treatmentProvided;
	public Object diagnosisMaster;
	public Object labReportsLevel1;
	public Object drugCompoundMaster;
	public Long appointmentID;
	public PatientAppointmentType patVisitType;
	private Long fcLocationMapID;
	private String fcLocationName;
	private Long facilityCenterID;
	private FacilityCenterType facilityCenterType;
	private String  facilityCenterName;
		
	public PatVisitNotePojo() {
		
	}

	public PatVisitNotePojo(Long patVisitNoteID, String patVisitDate, String times, Long providerID,
			String providerName, Long patientID, String name, String patSymptoms, String patSideEffect,
			String patExtraDetails, String treatmentProvided, Object diagnosisMaster, Object labReportsLevel1,
			Object drugCompoundMaster, Long appointmentID, PatientAppointmentType patVisitType,
			Long fcLocationMapID, String fcLocationName, Long facilityCenterID, FacilityCenterType facilityCenterType,
			String facilityCenterName) {
		super();
		this.patVisitNoteID = patVisitNoteID;
		this.patVisitDate = patVisitDate;
		this.times = times;
		this.providerID = providerID;
		this.providerName = providerName;
		this.patientID = patientID;
		this.name = name;
		this.patSymptoms = patSymptoms;
		this.patSideEffect = patSideEffect;
		this.patExtraDetails = patExtraDetails;
		this.treatmentProvided = treatmentProvided;
		this.diagnosisMaster = diagnosisMaster;
		this.labReportsLevel1 = labReportsLevel1;
		this.drugCompoundMaster = drugCompoundMaster;
		this.appointmentID = appointmentID;
		this.patVisitType = patVisitType;
		this.fcLocationMapID = fcLocationMapID;
		this.fcLocationName = fcLocationName;
		this.facilityCenterID = facilityCenterID;
		this.facilityCenterType = facilityCenterType;
		this.facilityCenterName = facilityCenterName;
	}

	public Long getPatVisitNoteID() {
		return patVisitNoteID;
	}

	public String getPatVisitDate() {
		return patVisitDate;
	}

	public String getTimes() {
		return times;
	}

	public Long getProviderID() {
		return providerID;
	}

	public String getProviderName() {
		return providerName;
	}

	public Long getPatientID() {
		return patientID;
	}

	public String getName() {
		return name;
	}

	public String getPatSymptoms() {
		return patSymptoms;
	}

	public String getPatSideEffect() {
		return patSideEffect;
	}

	public String getPatExtraDetails() {
		return patExtraDetails;
	}

	public String getTreatmentProvided() {
		return treatmentProvided;
	}

	public Object getDiagnosisMaster() {
		return diagnosisMaster;
	}

	public Object getLabReportsLevel1() {
		return labReportsLevel1;
	}

	public Object getDrugCompoundMaster() {
		return drugCompoundMaster;
	}

	public Long getAppointmentID() {
		return appointmentID;
	}

	public PatientAppointmentType getPatVisitType() {
		return patVisitType;
	}

	public Long getFcLocationMapID() {
		return fcLocationMapID;
	}

	public String getFcLocationName() {
		return fcLocationName;
	}

	public Long getFacilityCenterID() {
		return facilityCenterID;
	}

	public FacilityCenterType getFacilityCenterType() {
		return facilityCenterType;
	}

	public String getFacilityCenterName() {
		return facilityCenterName;
	}

	public void setPatVisitNoteID(Long patVisitNoteID) {
		this.patVisitNoteID = patVisitNoteID;
	}

	public void setPatVisitDate(String patVisitDate) {
		this.patVisitDate = patVisitDate;
	}

	public void setTimes(String times) {
		this.times = times;
	}

	public void setProviderID(Long providerID) {
		this.providerID = providerID;
	}

	public void setProviderName(String providerName) {
		this.providerName = providerName;
	}

	public void setPatientID(Long patientID) {
		this.patientID = patientID;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setPatSymptoms(String patSymptoms) {
		this.patSymptoms = patSymptoms;
	}

	public void setPatSideEffect(String patSideEffect) {
		this.patSideEffect = patSideEffect;
	}

	public void setPatExtraDetails(String patExtraDetails) {
		this.patExtraDetails = patExtraDetails;
	}

	public void setTreatmentProvided(String treatmentProvided) {
		this.treatmentProvided = treatmentProvided;
	}

	public void setDiagnosisMaster(Object diagnosisMaster) {
		this.diagnosisMaster = diagnosisMaster;
	}

	public void setLabReportsLevel1(Object labReportsLevel1) {
		this.labReportsLevel1 = labReportsLevel1;
	}

	public void setDrugCompoundMaster(Object drugCompoundMaster) {
		this.drugCompoundMaster = drugCompoundMaster;
	}

	public void setAppointmentID(Long appointmentID) {
		this.appointmentID = appointmentID;
	}

	public void setPatVisitType(PatientAppointmentType patVisitType) {
		this.patVisitType = patVisitType;
	}

	public void setFcLocationMapID(Long fcLocationMapID) {
		this.fcLocationMapID = fcLocationMapID;
	}

	public void setFcLocationName(String fcLocationName) {
		this.fcLocationName = fcLocationName;
	}

	public void setFacilityCenterID(Long facilityCenterID) {
		this.facilityCenterID = facilityCenterID;
	}

	public void setFacilityCenterType(FacilityCenterType facilityCenterType) {
		this.facilityCenterType = facilityCenterType;
	}

	public void setFacilityCenterName(String facilityCenterName) {
		this.facilityCenterName = facilityCenterName;
	}

	
}
