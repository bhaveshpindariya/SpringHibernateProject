package org.healthchain.pojo;

import java.io.Serializable;

public class TimeZonePojo implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private Long utcTimeZoneId;
	private String countryCode; 
	private String countryName;
	private String timezoneAbbreviation; 
	private String timezoneName;
	private String utcOffset;
	
	public TimeZonePojo() {
	
	}

	public TimeZonePojo(Long utcTimeZoneId, String countryCode, String countryName, String timezoneAbbreviation,
			String timezoneName, String utcOffset) {
		super();
		this.utcTimeZoneId = utcTimeZoneId;
		this.countryCode = countryCode;
		this.countryName = countryName;
		this.timezoneAbbreviation = timezoneAbbreviation;
		this.timezoneName = timezoneName;
		this.utcOffset = utcOffset;
	}

	@Override
	public String toString() {
		return "TimeZonePojo [utcTimeZoneId=" + utcTimeZoneId + ", countryCode=" + countryCode + ", countryName="
				+ countryName + ", timezoneAbbreviation=" + timezoneAbbreviation + ", timezoneName=" + timezoneName
				+ ", utcOffset=" + utcOffset + "]";
	}

	public Long getUtcTimeZoneId() {
		return utcTimeZoneId;
	}

	public String getCountryCode() {
		return countryCode;
	}

	public String getCountryName() {
		return countryName;
	}

	public String getTimezoneAbbreviation() {
		return timezoneAbbreviation;
	}

	public String getTimezoneName() {
		return timezoneName;
	}

	public String getUtcOffset() {
		return utcOffset;
	}

	public void setUtcTimeZoneId(Long utcTimeZoneId) {
		this.utcTimeZoneId = utcTimeZoneId;
	}

	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}

	public void setCountryName(String countryName) {
		this.countryName = countryName;
	}

	public void setTimezoneAbbreviation(String timezoneAbbreviation) {
		this.timezoneAbbreviation = timezoneAbbreviation;
	}

	public void setTimezoneName(String timezoneName) {
		this.timezoneName = timezoneName;
	}

	public void setUtcOffset(String utcOffset) {
		this.utcOffset = utcOffset;
	}	
}
