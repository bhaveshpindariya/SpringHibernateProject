package org.healthchain.entity.enums;

import java.util.ArrayList;
import java.util.List;

public enum WorkStatus {

	Student("Student"),
	HouseHold("HouseHold"),
	UnEmployed("UnEmployed");
    
    private String id;

    WorkStatus(String id) {
        this.id = id;
    }

    public String getId() {
        return id;
    }

    public static WorkStatus parse(String id) {
        WorkStatus maritalStatus = null; // Default
        for (WorkStatus item : WorkStatus.values()) {
        	if (item.getId().equals(id)) {
                maritalStatus = item;
                break;
            }
        }
        return maritalStatus;
    }
    
    public static String getValue(String id) {
   	 for (WorkStatus item : WorkStatus.values()) {
           if (item.name() == id) {
           		return item.getId();
           }
       }
       return null;
    }
    
    public static List<String> getAllWorkStatus() {
        WorkStatus[] values = WorkStatus.values();
        List<String> list = new ArrayList<>();
        for (WorkStatus value : values) {
            list.add(value.name());
        }
        return list;
    }
}
