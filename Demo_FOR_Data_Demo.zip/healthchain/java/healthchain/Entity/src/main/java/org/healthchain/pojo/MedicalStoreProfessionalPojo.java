package org.healthchain.pojo;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

public class MedicalStoreProfessionalPojo implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private Long fclProviderMap;
	private String locationName;
	private Set<DrugCompoundPojo> drugCompoundMaster = new HashSet<DrugCompoundPojo>(0);
	private Set<ProviderPojo> hospital = new HashSet<ProviderPojo>(0);
	private Set<ProviderPojo> doctor = new HashSet<ProviderPojo>(0);
	
	public MedicalStoreProfessionalPojo() {
		
	}

	public MedicalStoreProfessionalPojo(Long fclProviderMap, String locationName,
			Set<DrugCompoundPojo> drugCompoundMaster, Set<ProviderPojo> hospital, Set<ProviderPojo> doctor) {
		super();
		this.fclProviderMap = fclProviderMap;
		this.locationName = locationName;
		this.drugCompoundMaster = drugCompoundMaster;
		this.hospital = hospital;
		this.doctor = doctor;
	}

	public Long getFclProviderMap() {
		return fclProviderMap;
	}

	public String getLocationName() {
		return locationName;
	}

	public Set<DrugCompoundPojo> getDrugCompoundMaster() {
		return drugCompoundMaster;
	}

	public Set<ProviderPojo> getHospital() {
		return hospital;
	}

	public Set<ProviderPojo> getDoctor() {
		return doctor;
	}

	public void setFclProviderMap(Long fclProviderMap) {
		this.fclProviderMap = fclProviderMap;
	}

	public void setLocationName(String locationName) {
		this.locationName = locationName;
	}

	public void setDrugCompoundMaster(Set<DrugCompoundPojo> drugCompoundMaster) {
		this.drugCompoundMaster = drugCompoundMaster;
	}

	public void setHospital(Set<ProviderPojo> hospital) {
		this.hospital = hospital;
	}

	public void setDoctor(Set<ProviderPojo> doctor) {
		this.doctor = doctor;
	}

}
