package org.healthchain.medicalStore.constants;

public class MEDICALSTOREURLConstant {
	public static final String GET_IMAGES_URL="/getImages";
	public static final String ADD_TYPE="Add";
	public static final String EDIT_TYPE="Update";
	
	public static final String MEDICALSTORE_PROFILE_ROOT_URL="/medicalcenter/profile";
	public static final String MEDICALSTORE_ROOT_URL="/medicalcenter";
	public static final String MEDICALSTORE_IMAGE_ROOT_URL="/image";
	
	public static final String PROFILE_MEDICALSTORE_GETDATA_URL="/getPharmacy";
	public static final String PROFILE_MEDICALSTORE_URL="/pharmacy";
	
	public static final String PROFESSIONAL_MEDICALSTORE_GETDATA_URL="/getProfessional";
	public static final String PROFESSIONAL_MEDICALSTORE_LOCATION_GETDATA_URL="/getProfessionalByLocation";
	public static final String PROFESSIONAL_MEDICALSTORE_URL="/professional";
	
	public static final String MEDICALSTORE_SUCCESS="pharmacy.success";
	public static final String MEDICALSTORE_UPDATE="pharmacy.update";
	public static final String MEDICALSTORE_ERROR="pharmacy.error";
	public static final String MEDICALSTORE_UPDATE_ERROR="pharmacy.update.error";
	public static final String MEDICALSTORE_EXCEPTION="pharmacy.exception";
	
	public static final String PROFESSIONAL_SUCCESS="medicalprofessional.success";
	public static final String PROFESSIONAL_UPDATE="medicalprofessional.update";
	public static final String PROFESSIONAL_ERROR="medicalprofessional.error";
	public static final String PROFESSIONAL_UPDATE_ERROR="medicalprofessional.update.error";
	public static final String PROFESSIONAL_EXCEPTION="medicalprofessional.exception";
	
	public static final String DEMOGRAPHIC_SUCCESS="demographic.success";
	public static final String DEMOGRAPHIC_UPDATE="demographic.update";
	public static final String DEMOGRAPHIC_ERROR="demographic.error";
	public static final String DEMOGRAPHIC_UPDATE_ERROR="demographic.update.error";
	public static final String DEMOGRAPHIC_EXCEPTION="demographic.exception";
	
	public static final String PROFILE_DEMOGRAPHIC_URL="/demographic";
	public static final String PROFILE_DEMOGRAPHIC_GETDATA_URL="/getDemographicData";
	

}
