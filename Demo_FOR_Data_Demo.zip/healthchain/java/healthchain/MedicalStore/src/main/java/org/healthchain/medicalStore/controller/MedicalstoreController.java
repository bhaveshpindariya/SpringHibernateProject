package org.healthchain.medicalStore.controller;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.healthchain.medicalStore.constants.MEDICALSTOREURLConstant;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@CrossOrigin
@RestController
@RequestMapping(MEDICALSTOREURLConstant.MEDICALSTORE_ROOT_URL)
public class MedicalstoreController {

	private static final Log logger = LogFactory.getLog(MedicalstoreController.class);
	
}
