package org.healthchain.medicalStore.controller;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.healthchain.medicalStore.constants.MEDICALSTOREURLConstant;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@CrossOrigin
@RestController
@RequestMapping(MEDICALSTOREURLConstant.MEDICALSTORE_IMAGE_ROOT_URL)
public class ImageController {

	private static final Log logger = LogFactory.getLog(ImageController.class);
	
	@RequestMapping(MEDICALSTOREURLConstant.GET_IMAGES_URL)
	public ResponseEntity<byte[]> decryptImages(HttpServletRequest request,@RequestParam(required=true)String filepath) throws IOException {
		final HttpHeaders headers = new HttpHeaders();
	    headers.setContentType(MediaType.IMAGE_JPEG);
		if(new File(filepath).exists()) {
			try {
				FileInputStream fis=new FileInputStream(filepath);
				byte[] media = new byte[fis.available()];
				fis.read(media);
				ByteArrayOutputStream resultdata=new ByteArrayOutputStream();
				resultdata.write(media);
				resultdata.flush();
				fis.close();
				return new ResponseEntity<byte[]>(resultdata.toByteArray(),headers,HttpStatus.OK);
			} catch (IOException io) {
				logger.debug(io.getMessage());
				io.printStackTrace();
			}
		}
		return null;
	}
}
