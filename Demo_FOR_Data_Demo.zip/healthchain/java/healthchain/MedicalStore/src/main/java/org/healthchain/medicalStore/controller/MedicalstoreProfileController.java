package org.healthchain.medicalStore.controller;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.healthchain.common.constants.CommonConstants;
import org.healthchain.common.constants.ResponseConstant;
import org.healthchain.common.utils.OperationsUtil;
import org.healthchain.entity.DrugCompoundMaster;
import org.healthchain.entity.FCLProviderDoctorMap;
import org.healthchain.entity.FCLProviderDrugCompoundMap;
import org.healthchain.entity.FCLProviderHospitalMap;
import org.healthchain.entity.FCLProviderMap;
import org.healthchain.entity.FCLocationMap;
import org.healthchain.entity.FacilityCenterMaster;
import org.healthchain.entity.LocationMaster;
import org.healthchain.entity.PersonMaster;
import org.healthchain.entity.ProviderMaster;
import org.healthchain.entity.TimeZoneMaster;
import org.healthchain.entity.UserMaster;
import org.healthchain.entity.enums.ProviderTypeStatus;
import org.healthchain.medicalStore.constants.MEDICALSTOREURLConstant;
import org.healthchain.pojo.DrugCompoundPojo;
import org.healthchain.pojo.LabDemographicPojo;
import org.healthchain.pojo.LocationPojo;
import org.healthchain.pojo.MedicalStoreProfessionalPojo;
import org.healthchain.pojo.MedicalstorePojo;
import org.healthchain.pojo.ProviderPojo;
import org.healthchain.pojo.Response;
import org.healthchain.pojo.TimeZonePojo;
import org.healthchain.services.FCLProviderDoctorMapService;
import org.healthchain.services.FCLProviderDrugCompoundMapService;
import org.healthchain.services.FCLProviderHospitalMapService;
import org.healthchain.services.FCLProviderService;
import org.healthchain.services.FCLocationMapService;
import org.healthchain.services.FacilityCenterService;
import org.healthchain.services.LocationService;
import org.healthchain.services.MessageByLocaleService;
import org.healthchain.services.PersonService;
import org.healthchain.services.ProviderService;
import org.healthchain.services.TimeZoneService;
import org.healthchain.services.UserService;
import org.healthchain.services.constants.ServiceConstant;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

@CrossOrigin
@RestController
@RequestMapping(MEDICALSTOREURLConstant.MEDICALSTORE_PROFILE_ROOT_URL)
public class MedicalstoreProfileController {

	private static final Log logger = LogFactory.getLog(MedicalstoreProfileController.class);
	
	@Autowired
	private ProviderService providerService;

	@Autowired
	private UserService userService;
	
	@Autowired
	private TimeZoneService timeZoneService;
	
	@Autowired
	private PersonService personService;
	
	@Autowired
	private LocationService locationService;
	
	@Autowired
    private FCLProviderService fclProviderService;
	
	@Autowired
	private FacilityCenterService facilityCenterService;
	
	@Autowired
	private FCLocationMapService fcLocationMapService;
	
	@Autowired
	private FCLProviderDrugCompoundMapService fclProviderDrugCompoundMapService;
	
	@Autowired
	private FCLProviderHospitalMapService fclProviderHospitalMapService;
	
	@Autowired
	private FCLProviderDoctorMapService fclProviderDoctorMapService;

	@Autowired
	private MessageByLocaleService messageByLocaleService;

	@RequestMapping(value = MEDICALSTOREURLConstant.PROFILE_MEDICALSTORE_GETDATA_URL, method = RequestMethod.POST, headers = CommonConstants.CONTENT_TYPE_APPLICATION_JSON)
	public ResponseEntity<Response> getPharmacy(Locale locale,HttpServletRequest request) {
		Response response = new Response();
		UserDetails userDetails = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		UserMaster userEntity = userService.findByUserName(userDetails.getUsername());
		try {
			MedicalstorePojo laboratoryPojo=new MedicalstorePojo();
			PersonMaster person = personService.findByPerEmailPrimary(userEntity.getUserEmail());
			ProviderMaster providerMaster=providerService.getProvider(userEntity.getUserEmail(),ProviderTypeStatus.MedicalStoreUser);
			List<FCLProviderMap> fclProviderMap=fclProviderService.getFclDataforDoctor(providerMaster.getProviderID(),providerMaster.getProviderTypeStatus());
			List<String> mlist = person.getPerEmailList();
			List<Map<String, String>> providerMapList = new ArrayList<Map<String, String>>(0);
			for (int i=0;i<mlist.size();i++) {
				Map<String, String> providerMap = new HashMap<String, String>(0);
				providerMap.put("value", mlist.get(i));
				providerMapList.add(providerMap);
			}
			laboratoryPojo.setPerFname(person.getPerFname());
			laboratoryPojo.setPerLName(person.getPerLName());
			laboratoryPojo.setUserName(person.getUserMaster().getUserName());
			laboratoryPojo.setPersonID(person.getPersonID());
			laboratoryPojo.setPerEmailList(providerMapList);
			laboratoryPojo.setPerEmailPrimary(person.getPerEmailPrimary());
			laboratoryPojo.setPerProfile(request.getScheme() + "://" + request.getServerName() + ":"
					+ request.getServerPort() + request.getContextPath() + MEDICALSTOREURLConstant.MEDICALSTORE_IMAGE_ROOT_URL + MEDICALSTOREURLConstant.GET_IMAGES_URL
					+ "?filepath=" +  person.getPerProfile());
			if(laboratoryPojo.getPerProfile().equalsIgnoreCase("/getImages?filepath=null")) {
				laboratoryPojo.setPerProfile(null);
			}
			laboratoryPojo.setFacilityCenterID(fclProviderMap.get(0).getLocationMapID().getFacilityCenterMaster().getFacilityCenterID());
			laboratoryPojo.setFacilityCenterName(fclProviderMap.get(0).getLocationMapID().getFacilityCenterMaster().getFacilityCenterName());
			laboratoryPojo.setAdditionalInformation(fclProviderMap.get(0).getLocationMapID().getFacilityCenterMaster().getAdditionalInformation());
			response.setStatus(ResponseConstant.SUCCESS);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_SUCCESS));
			response.setData(laboratoryPojo);
		} catch (Exception e) {
			logger.error("Error:--", e);
			response.setStatus(ResponseConstant.ERROR);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			response.setData(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Response>(response, HttpStatus.OK);
	}
	
	@RequestMapping(value = MEDICALSTOREURLConstant.PROFILE_MEDICALSTORE_URL, method = RequestMethod.POST)
	public ResponseEntity<Response> pharmacy(Locale locale, @RequestParam(value = "perProfile", required = false) MultipartFile files,HttpServletRequest request) {
		Response response = new Response();
		UserDetails userDetails = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		UserMaster userEntity = userService.findByUserName(userDetails.getUsername());
		try {
			PersonMaster person = personService.get(Long.parseLong(request.getParameter("personID")));
			personService.deletePersonEmailList(person.getPersonID());
			person.setPerFname(request.getParameter("perFname"));
			person.setPerLName(request.getParameter("perLName"));
			person.setPerEmailPrimary(request.getParameter("perEmailPrimary"));
			if(request.getParameter("perEmailList").length()>0) {
				String[] perEmailList = request.getParameter("perEmailList").split(",");
				if(perEmailList != null && perEmailList.length > 0) {
					List<String> list = new ArrayList<String>(0); 
					for(String s:perEmailList) {
						list.add(s);
					}
					person.getPerEmailList().addAll(list);
				}else {
					String perEmailLists = request.getParameter("perEmailList");
					List<String> list = new ArrayList<String>(0); 
					list.add(perEmailLists);
					person.getPerEmailList().addAll(list);
				}
			}
			person.setActive(true);
			person.setModifiedBy(userEntity);
			person.setModifiedOn(new Date());
			person.setDeleted(false);
			if (!files.isEmpty()) {
				String fileName=OperationsUtil.uploadFile(files,person,CommonConstants.PROFILE);
				if(fileName == null) {
					response.setStatus(ResponseConstant.ERROR);
					response.setMessage(messageByLocaleService.getMessage(MEDICALSTOREURLConstant.MEDICALSTORE_ERROR));
					response.setData(messageByLocaleService.getMessage(MEDICALSTOREURLConstant.MEDICALSTORE_ERROR));
					return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
				}else {
					person.setPerProfile(fileName);
				}
			}else {
				person.setPerProfile(person.getPerProfile());
			}
			try {
				personService.saveOrUpdate(person);
			}catch (Exception e) {
				logger.error("Error:--", e);
				response.setStatus(ResponseConstant.ERROR);
				response.setMessage(messageByLocaleService.getMessage(MEDICALSTOREURLConstant.MEDICALSTORE_ERROR));
				response.setData(messageByLocaleService.getMessage(MEDICALSTOREURLConstant.MEDICALSTORE_ERROR));
				return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
			}
			FacilityCenterMaster facilityCenterMaster=facilityCenterService.get(Long.parseLong(request.getParameter("facilityCenterID")));
			facilityCenterMaster.setAdditionalInformation(request.getParameter("additionalInformation"));
			facilityCenterMaster.setActive(true);
			facilityCenterMaster.setModifiedBy(userEntity);
			facilityCenterMaster.setModifiedOn(new Date());
			facilityCenterMaster.setDeleted(false);
			try {
				facilityCenterService.saveOrUpdate(facilityCenterMaster);
			}catch (Exception e) {
				logger.error("Error:--", e);
				response.setStatus(ResponseConstant.ERROR);
				response.setMessage(messageByLocaleService.getMessage(MEDICALSTOREURLConstant.MEDICALSTORE_ERROR));
				response.setData(messageByLocaleService.getMessage(MEDICALSTOREURLConstant.MEDICALSTORE_ERROR));
				return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
			}
			response.setStatus(ResponseConstant.SUCCESS);
			response.setMessage(messageByLocaleService.getMessage(MEDICALSTOREURLConstant.MEDICALSTORE_UPDATE));
			response.setData(messageByLocaleService.getMessage(MEDICALSTOREURLConstant.MEDICALSTORE_UPDATE));
		} catch (Exception e) {
			logger.error("Error:--", e);
			response.setStatus(ResponseConstant.ERROR);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			response.setData(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Response>(response, HttpStatus.OK);
	}
	
	@RequestMapping(value = MEDICALSTOREURLConstant.PROFILE_DEMOGRAPHIC_GETDATA_URL, method = RequestMethod.POST, headers = CommonConstants.CONTENT_TYPE_APPLICATION_JSON)
	public ResponseEntity<Response> getDemographicData(Locale locale) {
		Response response = new Response();
		UserDetails userDetails = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		UserMaster userEntity = userService.findByUserName(userDetails.getUsername());
		try {
			PersonMaster person = personService.findByPerEmailPrimary(userEntity.getUserEmail());
			ProviderMaster providerMaster=providerService.getProvider(userEntity.getUserEmail(),ProviderTypeStatus.MedicalStoreUser);
			List<FCLProviderMap> fclProviderMap=fclProviderService.getFclDataforDoctor(providerMaster.getProviderID(),providerMaster.getProviderTypeStatus());
			LabDemographicPojo demographicPojo = new LabDemographicPojo();
			List<String> mlist = person.getPerMobileList(); 
			List<Map<String, String>> providerMapList = new ArrayList<Map<String, String>>(0);
			for (int i=0;i<mlist.size();i++) {
				Map<String, String> providerMap = new HashMap<String, String>(0);
				providerMap.put("value", mlist.get(i));
				providerMapList.add(providerMap);
			}
			demographicPojo.setPerMobileList(providerMapList);
			demographicPojo.setPersonID(person.getPersonID());
			demographicPojo.setPerMobilePrimary(person.getPerMobilePrimary());
			demographicPojo.setFacilityCenterID(fclProviderMap.get(0).getLocationMapID().getFacilityCenterMaster().getFacilityCenterID());
			List<LocationPojo> locationPojo=new ArrayList<LocationPojo>();
			for(FCLProviderMap fcl:fclProviderMap) {
				LocationMaster lm=locationService.get(fcl.getLocationMapID().getLocationMaster().getLocationID());
				LocationPojo lp=new LocationPojo();
				lp.setFcLocationName(fcl.getLocationMapID().getFcLocationName());
				lp.setFcLocationMapID(fcl.getLocationMapID().getFcLocationMapID());
				lp.setLocationID(lm.getLocationID());
				lp.setAddressLine1(lm.getAddressLine1());
				lp.setAddressLine2(lm.getAddressLine2());
				lp.setAddressLine3(lm.getAddressLine3());
				lp.setArea(lm.getArea());
				lp.setCity(lm.getCity());
				lp.setState(lm.getState());
				lp.setZip(lm.getZip());
				lp.setCountry(lm.getCountry());
				lp.setMilestone1(lm.getMilestone1());
				lp.setMilestone2(lm.getMilestone2());
				TimeZoneMaster tzm = timeZoneService.get(lm.getTimeZoneMaster().getUtcTimeZoneId());
				TimeZonePojo tzp = new TimeZonePojo();
				tzp.setUtcTimeZoneId(tzm.getUtcTimeZoneId());
				tzp.setCountryCode(tzm.getCountryCode());
				tzp.setCountryName(tzm.getCountryName());
				tzp.setTimezoneAbbreviation(tzm.getTimezoneAbbreviation());
				tzp.setTimezoneName(tzm.getTimezoneName());
				tzp.setUtcOffset(tzm.getUtcOffset());
				lp.setTimeZoneMaster(tzp);
				locationPojo.add(lp);
			}
			demographicPojo.setLocationMasterdata(locationPojo);
			response.setStatus(ResponseConstant.SUCCESS);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_SUCCESS));
			response.setData(demographicPojo);
		}catch (Exception e) {
			logger.error("Error:--", e);
			response.setStatus(ResponseConstant.ERROR);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			response.setData(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Response>(response, HttpStatus.OK);
	}
	
	@RequestMapping(value = MEDICALSTOREURLConstant.PROFILE_DEMOGRAPHIC_URL, method = RequestMethod.POST, headers = CommonConstants.CONTENT_TYPE_APPLICATION_JSON)
	public ResponseEntity<Response> demographic(Locale locale, @RequestBody PersonMaster personMaster) {
		Response response = new Response();
		UserDetails userDetails = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		UserMaster userEntity = userService.findByUserName(userDetails.getUsername());
		try {
			    PersonMaster person = personService.get(personMaster.getPersonID());
			    personService.deletePersonMobileList(personMaster.getPersonID());
			    person.setPerMobilePrimary(personMaster.getPerMobilePrimary());
				person.setPerMobileList(personMaster.getPerMobileList());
				person.setActive(true);
				person.setModifiedBy(userEntity);
				person.setModifiedOn(new Date());
				person.setDeleted(false);
				try {
					person=personService.saveOrUpdate(person);
				}catch (Exception e) {
					logger.error("Error:--", e);
					response.setStatus(ResponseConstant.ERROR);
					response.setMessage(messageByLocaleService.getMessage(MEDICALSTOREURLConstant.DEMOGRAPHIC_ERROR));
					response.setData(messageByLocaleService.getMessage(MEDICALSTOREURLConstant.DEMOGRAPHIC_ERROR));
					return new ResponseEntity<Response>(response, HttpStatus.NOT_ACCEPTABLE);
				}
				List<FCLocationMap> fcLocationMaps=fcLocationMapService.getLocation(personMaster.getFacilityCenterMaster());
				for(FCLocationMap fcl:fcLocationMaps) {
					fcl.setActive(false);
					fcl.setModifiedOn(new Date());
					fcl.setModifiedBy(userEntity);
					fcl.setDeleted(true);
					try {
						fcLocationMapService.saveOrUpdate(fcl);
					}catch (Exception e) {
						logger.error("Error:--", e);
						response.setStatus(ResponseConstant.ERROR);
						response.setMessage(messageByLocaleService.getMessage(MEDICALSTOREURLConstant.DEMOGRAPHIC_ERROR));
						response.setData(messageByLocaleService.getMessage(MEDICALSTOREURLConstant.DEMOGRAPHIC_ERROR));
						return new ResponseEntity<Response>(response, HttpStatus.NOT_ACCEPTABLE);
					}
				}
				ProviderMaster providerMaster=providerService.getProvider(userEntity.getUserEmail(),ProviderTypeStatus.LabUser);
				for(LocationMaster lm:personMaster.getLocationMasterdata()) {
					if(lm.getLocationID() == null || lm.getLocationID().equals(0L)) {
						String fcmlocationName=lm.getFcLocationName();
						lm.setActive(true);
						lm.setCreatedOn(new Date());
						lm.setModifiedOn(new Date());
						lm.setCreatedBy(userEntity);
						lm.setModifiedBy(userEntity);
						lm.setDeleted(false);
						try {
							lm = locationService.saveOrUpdate(lm);
						}catch (Exception e) {
							logger.error("Error:--", e);
							response.setStatus(ResponseConstant.ERROR);
							response.setMessage(messageByLocaleService.getMessage(MEDICALSTOREURLConstant.DEMOGRAPHIC_ERROR));
							response.setData(messageByLocaleService.getMessage(MEDICALSTOREURLConstant.DEMOGRAPHIC_ERROR));
							return new ResponseEntity<Response>(response, HttpStatus.NOT_ACCEPTABLE);
						}
						FCLocationMap fcLocationMap = new FCLocationMap();
						fcLocationMap.setActive(true);
						fcLocationMap.setCreatedOn(new Date());
						fcLocationMap.setModifiedOn(new Date());
						fcLocationMap.setCreatedBy(userEntity);
						fcLocationMap.setModifiedBy(userEntity);
						fcLocationMap.setDeleted(false);
						fcLocationMap.setFacilityCenterMaster(personMaster.getFacilityCenterMaster());
						fcLocationMap.setLocationMaster(lm);
						fcLocationMap.setFcLocationName(fcmlocationName);
						fcLocationMap.setDoesOfferHomeservice(false);
						fcLocationMap.setHavechildDepartmentMapCount(0);
						try {
							fcLocationMapService.saveOrUpdate(fcLocationMap);
						}catch (Exception e) {
							logger.error("Error:--", e);
							response.setStatus(ResponseConstant.ERROR);
							response.setMessage(messageByLocaleService.getMessage(MEDICALSTOREURLConstant.DEMOGRAPHIC_ERROR));
							response.setData(messageByLocaleService.getMessage(MEDICALSTOREURLConstant.DEMOGRAPHIC_ERROR));
							return new ResponseEntity<Response>(response, HttpStatus.NOT_ACCEPTABLE);
						}
						FCLProviderMap fclProviderMap=new FCLProviderMap();
						fclProviderMap.setProviderID(providerMaster);
						fclProviderMap.setLocationMapID(fcLocationMap);
						fclProviderMap.setActive(true);
						fclProviderMap.setDeleted(false);
						fclProviderMap.setCreatedOn(new Date());
						fclProviderMap.setCreatedBy(userEntity);
						fclProviderMap.setModifiedOn(new Date());
						fclProviderMap.setModifiedBy(userEntity);
						try {
							fclProviderService.saveOrUpdate(fclProviderMap);
						}catch (Exception e) {
							logger.error("Error:--", e);
							response.setStatus(ResponseConstant.ERROR);
							response.setMessage(messageByLocaleService.getMessage(ServiceConstant.EMAIL_EXCEPTION));
							response.setData(messageByLocaleService.getMessage(ServiceConstant.EMAIL_EXCEPTION));
							return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
						}
					}else {
						String fcmlocationName=lm.getFcLocationName();
						LocationMaster lms=locationService.get(lm.getLocationID());
						lm.setLocationID(lms.getLocationID());
						lm.setActive(true);
						lm.setCreatedOn(lms.getCreatedOn());
						lm.setModifiedOn(new Date());
						lm.setCreatedBy(lms.getCreatedBy());
						lm.setModifiedBy(userEntity);
						lm.setDeleted(false);
						try {
							lm = locationService.saveOrUpdate(lm);
						}catch (Exception e) {
							logger.error("Error:--", e);
							response.setStatus(ResponseConstant.ERROR);
							response.setMessage(messageByLocaleService.getMessage(MEDICALSTOREURLConstant.DEMOGRAPHIC_ERROR));
							response.setData(messageByLocaleService.getMessage(MEDICALSTOREURLConstant.DEMOGRAPHIC_ERROR));
							return new ResponseEntity<Response>(response, HttpStatus.NOT_ACCEPTABLE);
						}
						FCLocationMap fcm=fcLocationMapService.getdata(personMaster.getFacilityCenterMaster().getFacilityCenterID(),lm.getLocationID());
						fcm.setFacilityCenterMaster(personMaster.getFacilityCenterMaster());
						fcm.setLocationMaster(lm);
						fcm.setDoesOfferHomeservice(false);
						fcm.setHavechildDepartmentMapCount(0);
						fcm.setFcLocationName(fcmlocationName);
						fcm.setActive(true);
						fcm.setModifiedOn(new Date());
						fcm.setModifiedBy(userEntity);
						fcm.setDeleted(false);
						try {
							fcm=fcLocationMapService.saveOrUpdate(fcm);
						}catch (Exception e) {
							logger.error("Error:--", e);
							response.setStatus(ResponseConstant.ERROR);
							response.setMessage(messageByLocaleService.getMessage(MEDICALSTOREURLConstant.DEMOGRAPHIC_ERROR));
							response.setData(messageByLocaleService.getMessage(MEDICALSTOREURLConstant.DEMOGRAPHIC_ERROR));
							return new ResponseEntity<Response>(response, HttpStatus.NOT_ACCEPTABLE);
						}
						FCLProviderMap fclProviderMap=fclProviderService.getdata(providerMaster.getProviderID(),fcm.getFcLocationMapID());
						fclProviderMap.setProviderID(providerMaster);
						fclProviderMap.setLocationMapID(fcm);
						fclProviderMap.setActive(true);
						fclProviderMap.setDeleted(false);
						fclProviderMap.setModifiedOn(new Date());
						fclProviderMap.setModifiedBy(userEntity);
						try {
							fclProviderService.saveOrUpdate(fclProviderMap);
						}catch (Exception e) {
							logger.error("Error:--", e);
							response.setStatus(ResponseConstant.ERROR);
							response.setMessage(messageByLocaleService.getMessage(ServiceConstant.EMAIL_EXCEPTION));
							response.setData(messageByLocaleService.getMessage(ServiceConstant.EMAIL_EXCEPTION));
							return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
						}						
					}
				}
				response.setStatus(ResponseConstant.SUCCESS);
				response.setMessage(messageByLocaleService.getMessage(MEDICALSTOREURLConstant.DEMOGRAPHIC_SUCCESS));
				response.setData(messageByLocaleService.getMessage(MEDICALSTOREURLConstant.DEMOGRAPHIC_SUCCESS));
		} catch (Exception e) {
			logger.error("Error:--", e);
			response.setStatus(ResponseConstant.ERROR);
			response.setMessage(messageByLocaleService.getMessage(MEDICALSTOREURLConstant.DEMOGRAPHIC_ERROR));
			response.setData(messageByLocaleService.getMessage(MEDICALSTOREURLConstant.DEMOGRAPHIC_ERROR));
			return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Response>(response, HttpStatus.OK);
	}
	
	@RequestMapping(value = MEDICALSTOREURLConstant.PROFESSIONAL_MEDICALSTORE_GETDATA_URL, method = RequestMethod.POST, headers = CommonConstants.CONTENT_TYPE_APPLICATION_JSON)
	public ResponseEntity<Response> getProfessional(Locale locale) {
		Response response = new Response();
		UserDetails userDetails = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		UserMaster userEntity = userService.findByUserName(userDetails.getUsername());
		try {
			List<MedicalStoreProfessionalPojo> medicalStoreProfessionalPojoData=new ArrayList<MedicalStoreProfessionalPojo>(0);
			Set<DrugCompoundPojo> drugCompoundMaster = new HashSet<DrugCompoundPojo>(0);
			Set<ProviderPojo> hospital = new HashSet<ProviderPojo>(0);
			Set<ProviderPojo> doctor = new HashSet<ProviderPojo>(0);
			ProviderMaster providerMaster=providerService.getProvider(userEntity.getUserEmail(),ProviderTypeStatus.MedicalStoreUser);
			List<FCLProviderMap> fclProviderMap=fclProviderService.getFclDataforDoctor(providerMaster.getProviderID(),providerMaster.getProviderTypeStatus());
			for(FCLProviderMap fpm:fclProviderMap) {
				MedicalStoreProfessionalPojo medicalStoreProfessionalPojo=new MedicalStoreProfessionalPojo();
				medicalStoreProfessionalPojo.setFclProviderMap(fpm.getFclProviderMapID());
				medicalStoreProfessionalPojo.setLocationName(fpm.getLocationMapID().getFcLocationName());
				List<FCLProviderDrugCompoundMap> fcLProviderDrugCompoundMap=fclProviderDrugCompoundMapService.getAllData(fpm.getFclProviderMapID());
				if(fcLProviderDrugCompoundMap.size()>0) {
					for(FCLProviderDrugCompoundMap fcLProviderDrugCompound:fcLProviderDrugCompoundMap) {
						DrugCompoundPojo drugCompoundPojo=new DrugCompoundPojo();
						drugCompoundPojo.setDrugCompoundID(fcLProviderDrugCompound.getDrugCompoundID().getDrugCompoundID());
						drugCompoundPojo.setDrugCompoundName(fcLProviderDrugCompound.getDrugCompoundID().getDrugCompoundName());
						drugCompoundMaster.add(drugCompoundPojo);
					}
					List<FCLProviderHospitalMap> hospitals=fclProviderHospitalMapService.getAllData(fpm.getFclProviderMapID());
					for(FCLProviderHospitalMap fclHospitalMap:hospitals) {
						ProviderPojo pp=new ProviderPojo();
						pp.setFclProviderMapID(fclHospitalMap.getHospital().getFclProviderMapID());
						pp.setProviderID(fclHospitalMap.getHospital().getLocationMapID().getFacilityCenterMaster().getFacilityCenterID());
						pp.setProviderName(fclHospitalMap.getHospital().getLocationMapID().getFacilityCenterMaster().getFacilityCenterName());
						hospital.add(pp);
					}
					
					List<FCLProviderDoctorMap> doctors=fclProviderDoctorMapService.getAllData(fpm.getFclProviderMapID());
					for(FCLProviderDoctorMap fcldoctorMap:doctors) {
						ProviderPojo pp=new ProviderPojo();
						pp.setFclProviderMapID(fcldoctorMap.getDoctor().getFclProviderMapID());
						pp.setProviderID(fcldoctorMap.getDoctor().getLocationMapID().getFacilityCenterMaster().getFacilityCenterID());
						pp.setProviderName(fcldoctorMap.getDoctor().getLocationMapID().getFacilityCenterMaster().getFacilityCenterName());
						doctor.add(pp);
					}
				}
				medicalStoreProfessionalPojoData.add(medicalStoreProfessionalPojo);
			}
			response.setStatus(ResponseConstant.SUCCESS);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_SUCCESS));
			response.setData(medicalStoreProfessionalPojoData);
		} catch (Exception e) {
			logger.error("Error:--", e);
			response.setStatus(ResponseConstant.ERROR);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			response.setData(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Response>(response, HttpStatus.OK);
	}
	
	@RequestMapping(value = MEDICALSTOREURLConstant.PROFESSIONAL_MEDICALSTORE_LOCATION_GETDATA_URL, method = RequestMethod.POST, headers = CommonConstants.CONTENT_TYPE_APPLICATION_JSON)
	public ResponseEntity<Response> getProfessionalByLocation(Locale locale,@RequestBody MedicalStoreProfessionalPojo medicalStoreProfessionalPojo) {
		Response response = new Response();
		try {
			Set<DrugCompoundPojo> drugCompoundMaster = new HashSet<DrugCompoundPojo>(0);
			Set<ProviderPojo> hospital = new HashSet<ProviderPojo>(0);
			Set<ProviderPojo> doctor = new HashSet<ProviderPojo>(0);
			List<FCLProviderDrugCompoundMap> fcLProviderDrugCompoundMap=fclProviderDrugCompoundMapService.getAllData(medicalStoreProfessionalPojo.getFclProviderMap());
			if(fcLProviderDrugCompoundMap.size()>0) {
				for(FCLProviderDrugCompoundMap fcLProviderDrugCompound:fcLProviderDrugCompoundMap) {
					DrugCompoundPojo drugCompoundPojo=new DrugCompoundPojo();
					drugCompoundPojo.setDrugCompoundID(fcLProviderDrugCompound.getDrugCompoundID().getDrugCompoundID());
					drugCompoundPojo.setDrugCompoundName(fcLProviderDrugCompound.getDrugCompoundID().getDrugCompoundName());
					drugCompoundMaster.add(drugCompoundPojo);
				}
				List<FCLProviderHospitalMap> hospitals=fclProviderHospitalMapService.getAllData(medicalStoreProfessionalPojo.getFclProviderMap());
				for(FCLProviderHospitalMap fclHospitalMap:hospitals) {
					ProviderPojo pp=new ProviderPojo();
					pp.setFclProviderMapID(fclHospitalMap.getHospital().getFclProviderMapID());
					pp.setProviderID(fclHospitalMap.getHospital().getLocationMapID().getFacilityCenterMaster().getFacilityCenterID());
					pp.setProviderName(fclHospitalMap.getHospital().getLocationMapID().getFacilityCenterMaster().getFacilityCenterName());
					hospital.add(pp);
				}
				
				List<FCLProviderDoctorMap> doctors=fclProviderDoctorMapService.getAllData(medicalStoreProfessionalPojo.getFclProviderMap());
				for(FCLProviderDoctorMap fcldoctorMap:doctors) {
					ProviderPojo pp=new ProviderPojo();
					pp.setFclProviderMapID(fcldoctorMap.getDoctor().getFclProviderMapID());
					pp.setProviderID(fcldoctorMap.getDoctor().getLocationMapID().getFacilityCenterMaster().getFacilityCenterID());
					pp.setProviderName(fcldoctorMap.getDoctor().getLocationMapID().getFacilityCenterMaster().getFacilityCenterName());
					doctor.add(pp);
				}
			}
			response.setStatus(ResponseConstant.SUCCESS);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_SUCCESS));
			response.setData(medicalStoreProfessionalPojo);
		} catch (Exception e) {
			logger.error("Error:--", e);
			response.setStatus(ResponseConstant.ERROR);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			response.setData(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Response>(response, HttpStatus.OK);
	}
	
	@RequestMapping(value = MEDICALSTOREURLConstant.PROFESSIONAL_MEDICALSTORE_URL, method = RequestMethod.POST, headers = CommonConstants.CONTENT_TYPE_APPLICATION_JSON)
	public ResponseEntity<Response> professional(Locale locale,@RequestBody FCLProviderDrugCompoundMap fclProviderDrugCompoundMap) {
		Response response = new Response();
		UserDetails userDetails = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		UserMaster userEntity = userService.findByUserName(userDetails.getUsername());
		String type = null;
		Boolean isEmpty = OperationsUtil.checkNull(fclProviderDrugCompoundMap);
		if (!isEmpty) {
			try {
				Set<DrugCompoundMaster> drugCompoundMaster = fclProviderDrugCompoundMap.getDrugCompoundMaster();
				Set<FCLProviderMap> hospita = fclProviderDrugCompoundMap.getHospital();
				Set<FCLProviderMap> doctor = fclProviderDrugCompoundMap.getDoctor();
				List<FCLProviderDrugCompoundMap> fclPDrugCompoundMap=fclProviderDrugCompoundMapService.getAllDatas(fclProviderDrugCompoundMap.getFclProviderMap());
				if(fclPDrugCompoundMap.size()>0) {
					for(FCLProviderDrugCompoundMap fprm:fclPDrugCompoundMap) {
						fprm.setModifiedOn(new Date());
						fprm.setModifiedBy(userEntity);
						fprm.setActive(false);
						fprm.setDeleted(true);
						try {
							fclProviderDrugCompoundMapService.saveOrUpdate(fprm);
						}catch (Exception e) {
							logger.error("Error:--", e);
							response.setStatus(ResponseConstant.ERROR);
							response.setMessage(messageByLocaleService.getMessage(MEDICALSTOREURLConstant.PROFESSIONAL_ERROR));
							response.setData(messageByLocaleService.getMessage(MEDICALSTOREURLConstant.PROFESSIONAL_ERROR));
							return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
						}
					}
				}
				List<FCLProviderDoctorMap> doctors=fclProviderDoctorMapService.getAllDatas(fclProviderDrugCompoundMap.getFclProviderMap());
				if(doctors.size()>0) {
					for(FCLProviderDoctorMap fprm:doctors) {
						fprm.setModifiedOn(new Date());
						fprm.setModifiedBy(userEntity);
						fprm.setActive(false);
						fprm.setDeleted(true);
						try {
							fclProviderDoctorMapService.saveOrUpdate(fprm);
						}catch (Exception e) {
							logger.error("Error:--", e);
							response.setStatus(ResponseConstant.ERROR);
							response.setMessage(messageByLocaleService.getMessage(MEDICALSTOREURLConstant.PROFESSIONAL_ERROR));
							response.setData(messageByLocaleService.getMessage(MEDICALSTOREURLConstant.PROFESSIONAL_ERROR));
							return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
						}
					}
				}
				
				List<FCLProviderHospitalMap> hospitals=fclProviderHospitalMapService.getAllDatas(fclProviderDrugCompoundMap.getFclProviderMap());
				if(hospitals.size()>0) {
					for(FCLProviderHospitalMap fprm:hospitals) {
						fprm.setModifiedOn(new Date());
						fprm.setModifiedBy(userEntity);
						fprm.setActive(false);
						fprm.setDeleted(true);
						try {
							fclProviderHospitalMapService.saveOrUpdate(fprm);
						}catch (Exception e) {
							logger.error("Error:--", e);
							response.setStatus(ResponseConstant.ERROR);
							response.setMessage(messageByLocaleService.getMessage(MEDICALSTOREURLConstant.PROFESSIONAL_ERROR));
							response.setData(messageByLocaleService.getMessage(MEDICALSTOREURLConstant.PROFESSIONAL_ERROR));
							return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
						}
					}
				}
				for(DrugCompoundMaster dcm:drugCompoundMaster) {
					FCLProviderDrugCompoundMap fclpr=fclProviderDrugCompoundMapService.getData(fclProviderDrugCompoundMap.getFclProviderMap(),dcm.getDrugCompoundID());
					if(fclpr == null) {
						FCLProviderDrugCompoundMap fdc=new FCLProviderDrugCompoundMap();
						type = MEDICALSTOREURLConstant.ADD_TYPE;
						fdc.setActive(true);
						fdc.setCreatedOn(new Date());
						fdc.setCreatedBy(userEntity);
						fdc.setModifiedBy(userEntity);
						fdc.setDeleted(false);
						FCLProviderMap fclProviderMapID=fclProviderService.get(fclProviderDrugCompoundMap.getFclProviderMap());
						fdc.setFclProviderMapID(fclProviderMapID);
						fdc.setDrugCompoundID(dcm);
						try {
							fclProviderDrugCompoundMapService.saveOrUpdate(fdc);
						}catch (Exception e) {
							logger.error("Error:--", e);
							response.setStatus(ResponseConstant.ERROR);
							response.setMessage(messageByLocaleService.getMessage(MEDICALSTOREURLConstant.PROFESSIONAL_ERROR));
							response.setData(messageByLocaleService.getMessage(MEDICALSTOREURLConstant.PROFESSIONAL_ERROR));
							return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
						}
						response.setStatus(ResponseConstant.SUCCESS);
						response.setMessage(messageByLocaleService.getMessage(MEDICALSTOREURLConstant.PROFESSIONAL_SUCCESS));
						response.setData(messageByLocaleService.getMessage(MEDICALSTOREURLConstant.PROFESSIONAL_SUCCESS));
					}else {
						fclpr.setActive(true);
						fclpr.setDeleted(false);
						fclpr.setModifiedBy(userEntity);
						fclpr.setModifiedOn(new Date());
						type = MEDICALSTOREURLConstant.EDIT_TYPE;
						fclpr.setFclProviderDrugCompoundMapID(fclpr.getFclProviderDrugCompoundMapID());
						FCLProviderMap fclProviderMapID=fclProviderService.get(fclProviderDrugCompoundMap.getFclProviderMap());
						fclpr.setFclProviderMapID(fclProviderMapID);
						fclpr.setDrugCompoundID(dcm);
						try {
							fclProviderDrugCompoundMapService.saveOrUpdate(fclpr);
						}catch (Exception e) {
							logger.error("Error:--", e);
							response.setStatus(ResponseConstant.ERROR);
							response.setMessage(messageByLocaleService.getMessage(MEDICALSTOREURLConstant.PROFESSIONAL_ERROR));
							response.setData(messageByLocaleService.getMessage(MEDICALSTOREURLConstant.PROFESSIONAL_ERROR));
							return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
						}
					}
				}
				for(FCLProviderMap doct:doctor) {
					FCLProviderDoctorMap fclpr=fclProviderDoctorMapService.getData(fclProviderDrugCompoundMap.getFclProviderMap(),doct.getFclProviderMapID());
					if(fclpr == null) {
						FCLProviderDoctorMap fdc=new FCLProviderDoctorMap();
						type = MEDICALSTOREURLConstant.ADD_TYPE;
						fdc.setActive(true);
						fdc.setCreatedOn(new Date());
						fdc.setCreatedBy(userEntity);
						fdc.setModifiedBy(userEntity);
						fdc.setDeleted(false);
						FCLProviderMap fclProviderMapID=fclProviderService.get(fclProviderDrugCompoundMap.getFclProviderMap());
						fdc.setFclProviderMapID(fclProviderMapID);
						fdc.setDoctor(doct);
						try {
							fclProviderDoctorMapService.saveOrUpdate(fdc);
						}catch (Exception e) {
							logger.error("Error:--", e);
							response.setStatus(ResponseConstant.ERROR);
							response.setMessage(messageByLocaleService.getMessage(MEDICALSTOREURLConstant.PROFESSIONAL_ERROR));
							response.setData(messageByLocaleService.getMessage(MEDICALSTOREURLConstant.PROFESSIONAL_ERROR));
							return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
						}
						response.setStatus(ResponseConstant.SUCCESS);
						response.setMessage(messageByLocaleService.getMessage(MEDICALSTOREURLConstant.PROFESSIONAL_SUCCESS));
						response.setData(messageByLocaleService.getMessage(MEDICALSTOREURLConstant.PROFESSIONAL_SUCCESS));
					}else {
						fclpr.setActive(true);
						fclpr.setDeleted(false);
						fclpr.setModifiedBy(userEntity);
						fclpr.setModifiedOn(new Date());
						type = MEDICALSTOREURLConstant.EDIT_TYPE;
						fclpr.setFclProviderDoctorMapID(fclpr.getFclProviderDoctorMapID());
						FCLProviderMap fclProviderMapID=fclProviderService.get(fclProviderDrugCompoundMap.getFclProviderMap());
						fclpr.setFclProviderMapID(fclProviderMapID);
						fclpr.setDoctor(doct);
						try {
							fclProviderDoctorMapService.saveOrUpdate(fclpr);
						}catch (Exception e) {
							logger.error("Error:--", e);
							response.setStatus(ResponseConstant.ERROR);
							response.setMessage(messageByLocaleService.getMessage(MEDICALSTOREURLConstant.PROFESSIONAL_ERROR));
							response.setData(messageByLocaleService.getMessage(MEDICALSTOREURLConstant.PROFESSIONAL_ERROR));
							return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
						}
					}
				}
				for(FCLProviderMap hos:hospita) {
					FCLProviderHospitalMap fclpr=fclProviderHospitalMapService.getData(fclProviderDrugCompoundMap.getFclProviderMap(),hos.getFclProviderMapID());
					if(fclpr == null) {
						FCLProviderHospitalMap fdc=new FCLProviderHospitalMap();
						type = MEDICALSTOREURLConstant.ADD_TYPE;
						fdc.setActive(true);
						fdc.setCreatedOn(new Date());
						fdc.setCreatedBy(userEntity);
						fdc.setModifiedBy(userEntity);
						fdc.setDeleted(false);
						FCLProviderMap fclProviderMapID=fclProviderService.get(fclProviderDrugCompoundMap.getFclProviderMap());
						fdc.setFclProviderMapID(fclProviderMapID);
						fdc.setHospital(hos);
						try {
							fclProviderHospitalMapService.saveOrUpdate(fdc);
						}catch (Exception e) {
							logger.error("Error:--", e);
							response.setStatus(ResponseConstant.ERROR);
							response.setMessage(messageByLocaleService.getMessage(MEDICALSTOREURLConstant.PROFESSIONAL_ERROR));
							response.setData(messageByLocaleService.getMessage(MEDICALSTOREURLConstant.PROFESSIONAL_ERROR));
							return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
						}
						response.setStatus(ResponseConstant.SUCCESS);
						response.setMessage(messageByLocaleService.getMessage(MEDICALSTOREURLConstant.PROFESSIONAL_SUCCESS));
						response.setData(messageByLocaleService.getMessage(MEDICALSTOREURLConstant.PROFESSIONAL_SUCCESS));
					}else {
						fclpr.setActive(true);
						fclpr.setDeleted(false);
						fclpr.setModifiedBy(userEntity);
						fclpr.setModifiedOn(new Date());
						type = MEDICALSTOREURLConstant.EDIT_TYPE;
						fclpr.setFclProviderHospitalMapID(fclpr.getFclProviderHospitalMapID());
						FCLProviderMap fclProviderMapID=fclProviderService.get(fclProviderDrugCompoundMap.getFclProviderMap());
						fclpr.setFclProviderMapID(fclProviderMapID);
						fclpr.setHospital(hos);
						try {
							fclProviderHospitalMapService.saveOrUpdate(fclpr);
						}catch (Exception e) {
							logger.error("Error:--", e);
							response.setStatus(ResponseConstant.ERROR);
							response.setMessage(messageByLocaleService.getMessage(MEDICALSTOREURLConstant.PROFESSIONAL_ERROR));
							response.setData(messageByLocaleService.getMessage(MEDICALSTOREURLConstant.PROFESSIONAL_ERROR));
							return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
						}
					}
				}
				response.setStatus(ResponseConstant.SUCCESS);
				response.setMessage(messageByLocaleService.getMessage(MEDICALSTOREURLConstant.PROFESSIONAL_UPDATE));
				response.setData(messageByLocaleService.getMessage(MEDICALSTOREURLConstant.PROFESSIONAL_UPDATE));
			} catch (Exception e) {
				logger.error("Error:--", e);
				response.setStatus(ResponseConstant.ERROR);
				response.setMessage(messageByLocaleService.getMessage(MEDICALSTOREURLConstant.PROFESSIONAL_ERROR));
				response.setData(messageByLocaleService.getMessage(MEDICALSTOREURLConstant.PROFESSIONAL_ERROR));
				return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
			}
		} else {
			response.setStatus(ResponseConstant.ERROR);
			response.setMessage(messageByLocaleService.getMessage(MEDICALSTOREURLConstant.PROFESSIONAL_EXCEPTION));
			response.setData(messageByLocaleService.getMessage(MEDICALSTOREURLConstant.PROFESSIONAL_EXCEPTION));
			return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		if(type.equalsIgnoreCase(MEDICALSTOREURLConstant.ADD_TYPE)) {
			return new ResponseEntity<Response>(response, HttpStatus.CREATED);
		}else {
			return new ResponseEntity<Response>(response, HttpStatus.OK);
		}
	}
	
	@RequestMapping(MEDICALSTOREURLConstant.GET_IMAGES_URL)
	public ResponseEntity<byte[]> decryptImages(HttpServletRequest request,@RequestParam(required=true)String filepath) throws IOException {
		final HttpHeaders headers = new HttpHeaders();
	    headers.setContentType(MediaType.IMAGE_JPEG);
		if(new File(filepath).exists()) {
			try {
				FileInputStream fis=new FileInputStream(filepath);
				byte[] media = new byte[fis.available()];
				fis.read(media);
				ByteArrayOutputStream resultdata=new ByteArrayOutputStream();
				resultdata.write(media);
				resultdata.flush();
				fis.close();
				return new ResponseEntity<byte[]>(resultdata.toByteArray(),headers,HttpStatus.OK);
			} catch (IOException io) {
				logger.debug(io.getMessage());
				io.printStackTrace();
			}
		}
		return null;
	}
}
