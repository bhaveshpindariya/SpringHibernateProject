package org.healthchain.services;

import java.util.List;

import org.healthchain.entity.FCLocationMap;
import org.healthchain.entity.FacilityCenterMaster;

public interface FCLocationMapService extends GenericService<FCLocationMap, Long> {
	
	public List<FCLocationMap> getLocation(FacilityCenterMaster facilityCenterMaster);
	
	public FCLocationMap getdata(Long fId,Long lId);
	
}
