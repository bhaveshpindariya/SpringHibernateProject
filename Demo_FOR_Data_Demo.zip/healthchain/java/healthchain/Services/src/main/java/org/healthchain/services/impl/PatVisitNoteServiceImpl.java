package org.healthchain.services.impl;

import java.util.List;

import org.healthchain.base.PatVisitRepository;
import org.healthchain.entity.PatVisitNote;
import org.healthchain.services.PatVisitNoteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

@Service
public class PatVisitNoteServiceImpl extends GenericServiceImpl<PatVisitNote, Long> implements PatVisitNoteService {

	@Autowired
	private PatVisitRepository patVisitRepository;

	@Override
	public PatVisitNote findData(Long appointmentId){
		// TODO Auto-generated method stub
		return patVisitRepository.findData(appointmentId);
	}
	
	@Override
	public List<PatVisitNote> findPatientData(Long patientID,Pageable pageable){
		// TODO Auto-generated method stub
		return patVisitRepository.findPatientData(patientID,pageable);
	}
	
	@Override
	public List<PatVisitNote> findProviderData(Long providerID,Pageable pageable){
		// TODO Auto-generated method stub
		return patVisitRepository.findProviderData(providerID,pageable);
	}
	
	@Override
	public List<PatVisitNote> findPatientDatas(Long patientID){
		// TODO Auto-generated method stub
		return patVisitRepository.findPatientDatas(patientID);
	}
	
	@Override
	public List<PatVisitNote> findProviderDatas(Long providerID){
		// TODO Auto-generated method stub
		return patVisitRepository.findProviderDatas(providerID);
	}
}
