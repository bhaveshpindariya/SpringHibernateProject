package org.healthchain.validate;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.healthchain.base.UserRepository;
import org.healthchain.entity.FCLocationMap;
import org.healthchain.entity.SpecialityMaster;
import org.healthchain.entity.UserMaster;
import org.healthchain.services.MessageByLocaleService;
import org.healthchain.services.constants.ServiceConstant;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

@Component
public class DoctorRegistrationValidator implements Validator {

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private MessageByLocaleService messageByLocaleService;
	
	@Override
	public boolean supports(Class<?> clazz) {
		return UserMaster.class.isAssignableFrom(clazz);
	}

	@Override
	public void validate(Object target, Errors errors) {
		
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "userEmail", "error.field.empty",messageByLocaleService.getMessage(ServiceConstant.EMAIL));
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "userPassword", "error.field.empty",messageByLocaleService.getMessage(ServiceConstant.PASSWORD));
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "perFname", "error.field.empty",messageByLocaleService.getMessage(ServiceConstant.FIRSTNAME));
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "perLname", "error.field.empty",messageByLocaleService.getMessage(ServiceConstant.LASTNAME));
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "perContactNumber", "error.field.empty",messageByLocaleService.getMessage(ServiceConstant.NUMBER));
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "userName", "error.field.empty",messageByLocaleService.getMessage(ServiceConstant.USERNAME));
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "roleName", "error.field.empty",messageByLocaleService.getMessage(ServiceConstant.ROLENAME));
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "deviceType", "error.field.empty",messageByLocaleService.getMessage(ServiceConstant.DEVICETYPE));
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "providerTypeStatus", "error.field.empty",messageByLocaleService.getMessage(ServiceConstant.PROVIDERTYPESTATUS));

		UserMaster user = (UserMaster) target;
		
		String email = user.getUserEmail();
		String userName = user.getUserName();
		String number = user.getPerContactNumber();
		if (!isValidNumber(number))
			errors.rejectValue("perContactNumber", "error.perContactNumber.Wrong",messageByLocaleService.getMessage(ServiceConstant.NUMBER_WRONG));
		if (!isValid(email))
			errors.rejectValue("userEmail", "error.userEmail.Wrong",messageByLocaleService.getMessage(ServiceConstant.EMAIL_WRONG));
		if (email != null && userRepository.findByUserEmail(email) != null)
			errors.rejectValue("userEmail", "error.userEmail.exists",messageByLocaleService.getMessage(ServiceConstant.EMAIL_EXISTS));
		if (userName != null && userRepository.findByUserName(userName) != null)
			errors.rejectValue("userName", "error.userName.exists",messageByLocaleService.getMessage(ServiceConstant.USERNAME_EXISTS));
		for(FCLocationMap flm:user.getFcLocationMap()) {
			if(flm == null) {
				errors.rejectValue("fcLocationMapID", "error.field.empty",messageByLocaleService.getMessage(ServiceConstant.FCLOCATIONMAP));
			}
		}
		for(SpecialityMaster sm:user.getSpecialityMaster()) {
			if(sm == null) {
				errors.rejectValue("specialityID", "error.field.empty",messageByLocaleService.getMessage(ServiceConstant.SPECIALITY));
			}
		}
	}

	public static boolean isValid(String email) {
		String emailRegex = "^[a-zA-Z0-9_+&*-]+(?:\\." + "[a-zA-Z0-9_+&*-]+)*@" + "(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,7}$";
		Pattern pat = Pattern.compile(emailRegex);
		if (email == null)
			return false;
		return pat.matcher(email).matches();
	}
	
	public static boolean isValidNumber(String number){
        Pattern p = Pattern.compile("(0/91)?[7-9][0-9]{9}");
        Matcher m = p.matcher(number);
        return (m.find() && m.group().equals(number));
    }

}
