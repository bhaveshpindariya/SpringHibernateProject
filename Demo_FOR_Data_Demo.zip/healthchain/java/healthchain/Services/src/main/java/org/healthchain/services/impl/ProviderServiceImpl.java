package org.healthchain.services.impl;

import java.util.List;

import org.healthchain.base.ProviderRepository;
import org.healthchain.entity.ProviderMaster;
import org.healthchain.entity.enums.ProviderTypeStatus;
import org.healthchain.services.ProviderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ProviderServiceImpl extends GenericServiceImpl<ProviderMaster, Long> implements ProviderService {

	@Autowired
	private ProviderRepository providerRepository;

	@Override
	public List<ProviderMaster> getAllActiveDoctor(ProviderTypeStatus providerTypeStatus) {
		// TODO Auto-generated method stub
		return providerRepository.getAllActiveDoctor(providerTypeStatus);
	}
	
	@Override
	public List<ProviderMaster> getAllDoctorByperameter(ProviderTypeStatus providerTypeStatus,String name) {
		// TODO Auto-generated method stub
		return providerRepository.getAllDoctorByperameter(providerTypeStatus,name);
	}

	@Override
	public List<ProviderMaster> getAllperson(Long perId){
		// TODO Auto-generated method stub
		return providerRepository.getAllperson(perId);
	}
	
	@Override
	public ProviderMaster getProvider(String perEmailPrimary,ProviderTypeStatus type){
		// TODO Auto-generated method stub
		return providerRepository.getProvider(perEmailPrimary,type);
	}
}
