package org.healthchain.services;

import java.util.List;

import org.healthchain.entity.ProviderMaster;
import org.healthchain.entity.enums.ProviderTypeStatus;

public interface ProviderService extends GenericService<ProviderMaster, Long> {
	
	public List<ProviderMaster> getAllActiveDoctor(ProviderTypeStatus type);
	
	public List<ProviderMaster> getAllDoctorByperameter(ProviderTypeStatus type,String name);
	
	public List<ProviderMaster> getAllperson(Long perId);
	
	public ProviderMaster getProvider(String perEmailPrimary,ProviderTypeStatus type);
	
}