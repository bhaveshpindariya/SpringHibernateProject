package org.healthchain.services;

import org.healthchain.entity.UserMaster;

public interface UserService extends GenericService<UserMaster, Long> {
	
	public UserMaster findByUser(String userName,String email);
	
	public UserMaster findByUserEmail(String email);
	
	public UserMaster findByUserName(String userName);

}
