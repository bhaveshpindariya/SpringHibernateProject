package org.healthchain.services.impl;

import org.healthchain.base.DeviceDetailRepository;
import org.healthchain.entity.DeviceDetail;
import org.healthchain.services.DeviceDetailService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class DeviceDetailServiceImpl extends GenericServiceImpl<DeviceDetail, Long> implements DeviceDetailService {

	@Autowired
	private DeviceDetailRepository deviceDetailRepository;

	@Override
	public synchronized DeviceDetail findByUserForDevice(DeviceDetail token) {
		// TODO Auto-generated method stub
		return deviceDetailRepository.findByUserForDevice(token.getDeviceToken(),token.getDeviceType()
					,token.getDeviceID(),token.getUserMaster().getUserID());
	}
	
	
	

}
