package org.healthchain.services;

import java.util.List;

import org.healthchain.entity.FacilityCenterMaster;
import org.healthchain.entity.enums.FacilityCenterType;

public interface FacilityCenterService extends GenericService<FacilityCenterMaster, Long> {
	
	public FacilityCenterMaster findByCenterName(String name,FacilityCenterType facilityCenterType);
	
	public List<FacilityCenterMaster> getAllActiveRecordByPerameter(FacilityCenterType facilityCenterType);
	
	public List<FacilityCenterMaster> getAllActiveRecordByPerameterData(FacilityCenterType facilityCenterType,String name);
	
}
