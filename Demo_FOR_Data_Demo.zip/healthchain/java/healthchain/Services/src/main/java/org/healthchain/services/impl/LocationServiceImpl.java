package org.healthchain.services.impl;

import org.healthchain.base.LocationRepository;
import org.healthchain.entity.LocationMaster;
import org.healthchain.services.LocationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class LocationServiceImpl extends GenericServiceImpl<LocationMaster, Long> implements LocationService {

	@Autowired
	private LocationRepository locationRepository;


}
