package org.healthchain.services.impl;

import java.util.List;

import org.healthchain.base.ReportPatLapAppRepository;
import org.healthchain.entity.ReportPatLapApp;
import org.healthchain.services.ReportPatLapAppService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

@Service
public class ReportPatLapAppServiceImpl extends GenericServiceImpl<ReportPatLapApp, Long> implements ReportPatLapAppService {

	@Autowired
	private ReportPatLapAppRepository reportPatLapAppRepository;
	
	@Override
	public ReportPatLapApp findReport(Long patLabAppointmentID){
		return reportPatLapAppRepository.findReport(patLabAppointmentID);
	}
	
	@Override
	public List<ReportPatLapApp> findReportAll(Long userID,Pageable pageable){
		return reportPatLapAppRepository.findReportAll(userID,pageable);
	}
	
	@Override
	public List<ReportPatLapApp> findReportAllpatient(Long patientID,Pageable pageable){
		return reportPatLapAppRepository.findReportAllpatient(patientID,pageable);
	}
	
	@Override
	public List<ReportPatLapApp> findReportAlls(Long userID){
		return reportPatLapAppRepository.findReportAlls(userID);
	}
	
	@Override
	public List<ReportPatLapApp> findReportAllpatients(Long patientID){
		return reportPatLapAppRepository.findReportAllpatients(patientID);
	}
}
