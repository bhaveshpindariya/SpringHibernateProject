package org.healthchain.services.impl;

import java.util.List;

import org.healthchain.base.FacilityCenterRepository;
import org.healthchain.entity.FacilityCenterMaster;
import org.healthchain.entity.enums.FacilityCenterType;
import org.healthchain.services.FacilityCenterService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class FacilityCenterServiceImpl extends GenericServiceImpl<FacilityCenterMaster, Long> implements FacilityCenterService {

	@Autowired
	private FacilityCenterRepository facilityCenterRepository;

	@Override
	public FacilityCenterMaster findByCenterName(String name,FacilityCenterType facilityCenterType){
		// TODO Auto-generated method stub
		return facilityCenterRepository.findByCenterName(name,facilityCenterType);
	}
	
	@Override
	public List<FacilityCenterMaster> getAllActiveRecordByPerameterData(FacilityCenterType facilityCenterType,String name){
		return facilityCenterRepository.getAllActiveRecordByPerameterData(facilityCenterType,name.toLowerCase());
	}
	
	@Override
	public List<FacilityCenterMaster> getAllActiveRecordByPerameter(FacilityCenterType facilityCenterType){
		return facilityCenterRepository.getAllActiveRecordByPerameter(facilityCenterType);
	}

}
