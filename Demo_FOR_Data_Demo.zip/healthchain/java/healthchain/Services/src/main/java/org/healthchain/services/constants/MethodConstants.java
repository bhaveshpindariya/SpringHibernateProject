package org.healthchain.services.constants;

import org.healthchain.common.constants.CommonConstants;
import org.healthchain.entity.PatAppointments;
import org.healthchain.pojo.PatAppointmentPojo;

public class MethodConstants {

	public static PatAppointmentPojo SetPatAppointmentPojo(PatAppointments pa) {
		PatAppointmentPojo pap=new PatAppointmentPojo();
		pap.setPatAppointmentID(pa.getPatAppointmentID());
		pap.setPatientID(pa.getFclpID().getPatientID().getPatientID());
		pap.setName(pa.getFclpID().getPatientID().getPersonID().getPerFname()+" "+pa.getFclpID().getPatientID().getPersonID().getPerLName());
		pap.setFclProviderMapID(pa.getFclProviderMapID().getFclProviderMapID());
		pap.setProviderID(pa.getFclProviderMapID().getProviderID().getProviderID());
		pap.setProviderName(CommonConstants.DR_SHORT+" "+pa.getFclProviderMapID().getProviderID().getPersonMaster().getPerFname()+" "+pa.getFclProviderMapID().getProviderID().getPersonMaster().getPerLName());
		pap.setPatAppDate(pa.getPatAppDate());
		pap.setPatAppTimeFrom(pa.getPatAppTimeFrom());
		pap.setPatAppTimeTo(pa.getPatAppTimeTo());
		pap.setSpecialityID(pa.getSpecialityMaster().getSpecialityID());
		pap.setSpecialityName(pa.getSpecialityMaster().getSpecialityName());
		pap.setFcLocationMapID(pa.getFclProviderMapID().getLocationMapID().getFcLocationMapID());
		pap.setFcLocationName(pa.getFclProviderMapID().getLocationMapID().getFcLocationName());
		pap.setFacilityCenterID(pa.getFclProviderMapID().getLocationMapID().getFacilityCenterMaster().getFacilityCenterID());
		pap.setFacilityCenterName(pa.getFclProviderMapID().getLocationMapID().getFacilityCenterMaster().getFacilityCenterName());
		pap.setFacilityCenterType(pa.getFclProviderMapID().getLocationMapID().getFacilityCenterMaster().getFacilityCenterType());
		pap.setPatAppType(pa.getPatAppType());
		pap.setPatAppStatus(pa.getPatAppStatus());
		pap.setPatAppReason(pa.getPatAppReason());
		pap.setPatAppDescription(pa.getPatAppDescription());
		return pap;
	}
	
}
