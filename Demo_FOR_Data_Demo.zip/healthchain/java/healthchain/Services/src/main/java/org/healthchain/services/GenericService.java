package org.healthchain.services;

import java.util.List;

public interface GenericService<E, K> {

	public E saveOrUpdate(E entity);

	public List<E> getAll();
	
	public List<E> getAllActiveRecord();
	
	public List<E> getAllDeletedRecord();
	
	public List<E> getAllInActiveRecord();
	
	public List<E> getAllDeletedAndActiveRecord();

	public E get(K id);

	public void remove(E entity);

}
