package org.healthchain.services.impl;

import java.util.List;

import org.healthchain.base.FCLocationMapRepository;
import org.healthchain.entity.FCLocationMap;
import org.healthchain.entity.FacilityCenterMaster;
import org.healthchain.services.FCLocationMapService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class FCLocationMapServiceImpl extends GenericServiceImpl<FCLocationMap, Long> implements FCLocationMapService {

	@Autowired
	private FCLocationMapRepository fcLocationMapRepository;

	@Override
	public List<FCLocationMap> getLocation(FacilityCenterMaster facilityCenterMaster) {
		// TODO Auto-generated method stub
		return fcLocationMapRepository.getLocation(facilityCenterMaster.getFacilityCenterID());
	}
	
	@Override
	public FCLocationMap getdata(Long fId,Long lId) {
		// TODO Auto-generated method stub
		return fcLocationMapRepository.getdata(fId,lId);
	}
	

}
