package org.healthchain.services;

import org.healthchain.entity.TimeZoneMaster;

public interface TimeZoneService extends GenericService<TimeZoneMaster, Long> {
	
	public TimeZoneMaster findByAbbreviation(String name);
	
}
