package org.healthchain.services;

import org.healthchain.entity.RoleMaster;

public interface RoleService extends GenericService<RoleMaster, Long> {
	
	public RoleMaster findByroleName(String roleName);
}
