package org.healthchain.services.impl;

import org.healthchain.base.RxHeaderRepository;
import org.healthchain.entity.RxHeader;
import org.healthchain.services.RxHeaderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class RxHeaderServiceImpl extends GenericServiceImpl<RxHeader, Long> implements RxHeaderService {

	@Autowired
	private RxHeaderRepository rxHeaderRepository;

	@Override
	public RxHeader findData(Long patVisitNoteID) {
		return rxHeaderRepository.findData(patVisitNoteID);
	}
}
