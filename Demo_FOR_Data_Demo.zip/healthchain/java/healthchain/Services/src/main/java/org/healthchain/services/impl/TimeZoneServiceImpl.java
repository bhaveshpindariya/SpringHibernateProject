package org.healthchain.services.impl;

import org.healthchain.base.TimeZoneRepository;
import org.healthchain.entity.TimeZoneMaster;
import org.healthchain.services.TimeZoneService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class TimeZoneServiceImpl extends GenericServiceImpl<TimeZoneMaster, Long> implements TimeZoneService {

	@Autowired
	private TimeZoneRepository timeZoneRepository;

	@Override
	public TimeZoneMaster findByAbbreviation(String name){
		// TODO Auto-generated method stub
		return timeZoneRepository.findByAbbreviation(name);
	}
	

}
