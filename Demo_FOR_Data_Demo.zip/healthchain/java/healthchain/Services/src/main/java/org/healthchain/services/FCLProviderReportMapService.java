package org.healthchain.services;

import java.util.List;

import org.healthchain.entity.FCLProviderReportMap;
import org.healthchain.entity.FacilityCenterMaster;

public interface FCLProviderReportMapService extends GenericService<FCLProviderReportMap, Long> {
	
	public List<FCLProviderReportMap> getAllData(Long fclProviderMapID);
	
	public List<FCLProviderReportMap> getAllDatas(Long fclProviderMapID);
	
	public List<FCLProviderReportMap> getAllFacility(Long fclProviderMapID);
	
	public List<FacilityCenterMaster> getAllFacilitybyLocation(List<Long> labReportLevel1ID);
	
	public FCLProviderReportMap getData(Long providerId,Long labId);
		
}