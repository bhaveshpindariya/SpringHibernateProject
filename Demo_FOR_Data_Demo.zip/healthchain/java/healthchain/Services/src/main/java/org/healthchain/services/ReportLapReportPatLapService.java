package org.healthchain.services;

import java.util.List;

import org.healthchain.entity.DiagnosisMaster;
import org.healthchain.entity.ReportLapApp;
import org.healthchain.entity.ReportLapReportPatLap;

public interface ReportLapReportPatLapService extends GenericService<ReportLapReportPatLap, Long> {
	
	public List<ReportLapReportPatLap> findData(Long reportPatLapAppId);
	
	public List<ReportLapReportPatLap> findDatas(Long reportLapAppId);
	
	public ReportLapReportPatLap findAllPerameterData(Long reportLapApp,Long diagnosisID);
	
	public List<DiagnosisMaster> findDisease(Long reportLapApp);
	
	public List<ReportLapApp> findReport(Long reportPatLapAppId);
}