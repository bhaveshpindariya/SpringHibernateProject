package org.healthchain.services;

import java.util.List;

import org.healthchain.entity.SuggestReport;

public interface SuggestReportService extends GenericService<SuggestReport, Long> {
	
	public SuggestReport findData(Long labId,Long patLabAppointmentID);
	
	public List<SuggestReport> findAll(Long patLabAppointmentID);
	
	public List<SuggestReport> findAllData(Long patLabAppointmentID);
	
}