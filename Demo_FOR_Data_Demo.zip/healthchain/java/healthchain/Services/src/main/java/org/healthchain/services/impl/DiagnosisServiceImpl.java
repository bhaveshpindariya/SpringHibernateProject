package org.healthchain.services.impl;

import java.util.List;

import org.healthchain.base.DiagnosisRepository;
import org.healthchain.entity.DiagnosisMaster;
import org.healthchain.services.DiagnosisService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class DiagnosisServiceImpl extends GenericServiceImpl<DiagnosisMaster, Long> implements DiagnosisService {

	@Autowired
	private DiagnosisRepository diagnosisRepository;

	@Override
	public DiagnosisMaster findName(String name) {
		return diagnosisRepository.findName(name);
	}
	
	@Override
	public List<DiagnosisMaster> findbynames(String name) {
		return diagnosisRepository.findbynames(name.toLowerCase());
	}
}
