package org.healthchain.services.impl;

import java.util.List;

import org.healthchain.base.RxDetailRepository;
import org.healthchain.entity.DrugCompoundMaster;
import org.healthchain.entity.RxDetail;
import org.healthchain.services.RxDetailService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class RxDetailServiceImpl extends GenericServiceImpl<RxDetail, Long> implements RxDetailService {

	@Autowired
	private RxDetailRepository rxDetailRepository;

	@Override
	public RxDetail findData(Long drugCompoundID,Long rxID) {
		return rxDetailRepository.findData(drugCompoundID,rxID);
	}
	
	@Override
	public List<DrugCompoundMaster> findAll(Long patVisitNoteID){
		return rxDetailRepository.findAll(patVisitNoteID);
	}
	
	@Override
	public List<RxDetail> findAllData(Long rxID) {
		return rxDetailRepository.findAllData(rxID);
	}
}
