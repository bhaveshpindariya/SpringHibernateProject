package org.healthchain.services.impl;

import org.healthchain.base.SpecialityRepository;
import org.healthchain.entity.SpecialityMaster;
import org.healthchain.services.SpecialityService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class SpecialityServiceImpl extends GenericServiceImpl<SpecialityMaster, Long> implements SpecialityService {

	@Autowired
	private SpecialityRepository specialityRepository;

	@Override
	public SpecialityMaster findByName(String name){
		// TODO Auto-generated method stub
		return specialityRepository.findByName(name);
	}
	

}
