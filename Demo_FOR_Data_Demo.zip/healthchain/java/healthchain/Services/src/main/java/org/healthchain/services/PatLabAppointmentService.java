package org.healthchain.services;

import java.util.List;

import org.healthchain.entity.PatLabAppointments;
import org.healthchain.entity.PatientMaster;
import org.springframework.data.domain.Pageable;

public interface PatLabAppointmentService extends GenericService<PatLabAppointments, Long> {
	
	public List<PatLabAppointments> findPatientData(PatientMaster patientMaster,Pageable pageable);
	
	public List<PatLabAppointments> findProviderData(Long providerID,Pageable pageable);
	
	public List<PatLabAppointments> findPatientDatas(PatientMaster patientMaster);
	
	public List<PatLabAppointments> findPatient(PatientMaster patientMaster,Long date);
	
	public List<PatLabAppointments> findProviderDatas(Long providerID);
}