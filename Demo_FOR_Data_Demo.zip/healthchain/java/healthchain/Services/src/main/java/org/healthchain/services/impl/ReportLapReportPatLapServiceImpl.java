package org.healthchain.services.impl;

import java.util.List;

import org.healthchain.base.ReportLapReportPatLapRepository;
import org.healthchain.entity.DiagnosisMaster;
import org.healthchain.entity.ReportLapApp;
import org.healthchain.entity.ReportLapReportPatLap;
import org.healthchain.services.ReportLapReportPatLapService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ReportLapReportPatLapServiceImpl extends GenericServiceImpl<ReportLapReportPatLap, Long> implements ReportLapReportPatLapService {

	@Autowired
	private ReportLapReportPatLapRepository reportLapReportPatLapRepository;
	
	@Override
	public List<ReportLapReportPatLap> findData(Long reportPatLapAppId){
		return reportLapReportPatLapRepository.findData(reportPatLapAppId);
	}
	
	@Override
	public List<ReportLapReportPatLap> findDatas(Long reportLapAppId){
		return reportLapReportPatLapRepository.findDatas(reportLapAppId);
	}
	
	@Override
	public ReportLapReportPatLap findAllPerameterData(Long reportLapApp,Long diagnosisID){
		return reportLapReportPatLapRepository.findAllPerameterData(reportLapApp,diagnosisID);
	}
	
	@Override
	public List<DiagnosisMaster> findDisease(Long reportLapApp){
		return reportLapReportPatLapRepository.findDisease(reportLapApp);
	}
	
	@Override
	public List<ReportLapApp> findReport(Long reportPatLapAppId){
		return reportLapReportPatLapRepository.findReport(reportPatLapAppId);
	}
	
}
