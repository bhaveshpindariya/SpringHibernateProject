package org.healthchain.services.impl;

import java.util.List;

import org.healthchain.base.FCLProviderDoctorMapRepository;
import org.healthchain.entity.FCLProviderDoctorMap;
import org.healthchain.services.FCLProviderDoctorMapService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class FCLProviderDoctorMapServiceImpl extends GenericServiceImpl<FCLProviderDoctorMap, Long> implements FCLProviderDoctorMapService {

	@Autowired
	private FCLProviderDoctorMapRepository fclProviderDoctorMapRepository;
	
	@Override
	public List<FCLProviderDoctorMap> getAllData(Long fclProviderMapID){
		return fclProviderDoctorMapRepository.getAllData(fclProviderMapID);
	}
	
	@Override
	public List<FCLProviderDoctorMap> getAllDatas(Long fclProviderMapID){
		return fclProviderDoctorMapRepository.getAllDatas(fclProviderMapID);
	}

	@Override
	public FCLProviderDoctorMap getData(Long providerId,Long doctorId){
		return fclProviderDoctorMapRepository.getData(providerId,doctorId);
	}
}
