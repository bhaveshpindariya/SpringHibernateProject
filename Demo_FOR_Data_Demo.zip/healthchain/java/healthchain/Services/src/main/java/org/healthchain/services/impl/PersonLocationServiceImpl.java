package org.healthchain.services.impl;

import java.util.List;

import org.healthchain.base.PersonLocationRepository;
import org.healthchain.entity.PersonLocationMap;
import org.healthchain.services.PersonLocationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class PersonLocationServiceImpl extends GenericServiceImpl<PersonLocationMap, Long> implements PersonLocationService {

	@Autowired
	private PersonLocationRepository personLocationRepository;

	@Override
	public List<PersonLocationMap> getPersonData(Long personID,Long locationID) {
		// TODO Auto-generated method stub
		return personLocationRepository.getPersonData(personID,locationID);
	}
	
	@Override
	public List<PersonLocationMap> getPersonDatas(Long personID) {
		// TODO Auto-generated method stub
		return personLocationRepository.getPersonDatas(personID);
	}
}
