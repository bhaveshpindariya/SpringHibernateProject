package org.healthchain.services;

import org.healthchain.entity.DrugsActiveSubstanceMaster;

public interface DrugsActiveSubstanceService extends GenericService<DrugsActiveSubstanceMaster, Long> {
	
	public DrugsActiveSubstanceMaster findData(String dasName);
	
}