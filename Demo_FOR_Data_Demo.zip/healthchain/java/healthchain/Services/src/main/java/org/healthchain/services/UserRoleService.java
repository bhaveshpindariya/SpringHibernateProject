package org.healthchain.services;

import org.healthchain.entity.UserRoleEntity;

public interface UserRoleService extends GenericService<UserRoleEntity, Long> {

}
