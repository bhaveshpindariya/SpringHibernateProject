package org.healthchain.services;

import java.util.List;

import org.healthchain.entity.PersonLocationMap;

public interface PersonLocationService extends GenericService<PersonLocationMap, Long> {
	
	public List<PersonLocationMap> getPersonData(Long personID,Long locationID);
	
	public List<PersonLocationMap> getPersonDatas(Long personID);
}
