package org.healthchain.services.impl;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.healthchain.base.UserRepository;
import org.healthchain.entity.UserMaster;
import org.healthchain.entity.UserRoleEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service("myUserDetailsServiceImpl")
public class MyUserDetailsServiceImpl implements UserDetailsService {

	@Autowired
	private UserRepository userRepository;

	@Transactional
	@Override
	public UserDetails loadUserByUsername(final String username) throws UsernameNotFoundException {
		
		UserMaster user = userRepository.searchByuserName(username);
		List<GrantedAuthority> authorities = buildUserAuthority(user.getUserRoleEntity());
		return buildUserForAuthentication(user, authorities);

	}

	private User buildUserForAuthentication(UserMaster user, List<GrantedAuthority> authorities) {
		for (GrantedAuthority grantedAuthority : authorities) {
			System.out.println("Authorities " + grantedAuthority.getAuthority().toString());	
		}
		return new User(user.getUserName(), user.getUserPassword(), true, true, true, true, authorities);
	}

	private List<GrantedAuthority> buildUserAuthority(Set<UserRoleEntity> userRoles) {

		Set<GrantedAuthority> setAuths = new HashSet<GrantedAuthority>();

		// Build user's authorities
		for (UserRoleEntity userRole : userRoles) {
			setAuths.add(new SimpleGrantedAuthority(userRole.getRoleMaster().getRoleName().toString()));
		}

		List<GrantedAuthority> Result = new ArrayList<GrantedAuthority>(setAuths);

		return Result;
	}
}