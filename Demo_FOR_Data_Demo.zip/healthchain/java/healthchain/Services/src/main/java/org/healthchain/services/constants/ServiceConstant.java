package org.healthchain.services.constants;

public class ServiceConstant {

	public static final String ALPHA_CAPS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
	public static final String ALPHA = "abcdefghijklmnopqrstuvwxyz";
	public static final String NUMERIC = "0123456789";
	public static final String SPECIAL_CHARS = "!@#$%^&*_=+-/";
	
	public static final String USER_ACTIVATION_SUBJECT="Healthchain account activation";
	public static final String USER_PASSWORD_SUBJECT="Healthchain user password";
	
	public static final String EMAIL_EXCEPTION="email.exception";
	
	public static final String REGISTRATION_MATCHER = "/auth/userRegistration";
	public static final String AUTHORIZATION_USER="/authorizations";
	public static final String DOWNLOAD="/download";
	public static final String LOGIN_MATCHER = "/auth/login";
	public static final String FORGOT_MATCHER = "/auth/forgotPassword";
	
	public static final String ADMIN_MATCHER="/admin/**";
	public static final String ROLE_MATCHER = "/role/**";
	public static final String AUTHORITY_ADMIN = "Admin";

	public static final String PATIENT_MATCHER = "/patient/**";
	public static final String PATIENT_AUTHORITY = "Patient";
	
	public static final String PROFILE_MATCHER = "/profile/**";
	public static final String COMMON_MATCHER = "/common/**";
	
	public static final String DOCTOR_MATCHER = "/doctor/**";
	public static final String DOCTOR_AUTHORITY = "Doctor";

	public static final String LABORATORY_MATCHER = "/laboratory/**";
	public static final String LAB_PROFILE_MATCHER = "/labProfile/**";
	public static final String LABORATORY_AUTHORITY = "Laboratory";

	public static final String CLINIC_MATCHER = "/clinic/**";
	public static final String CLINIC_AUTHORITY = "Clinic";

	public static final String HOSPITAL_MATCHER = "/hospital/**";
	public static final String HOSPITAL_AUTHORITY = "Hospital";

	public static final String INSURANCE_MATCHER = "/insurance/**";
	public static final String INSURANCE_AUTHORITY = "Insurance";

	public static final String MEDICALCENTER_MATCHER = "/medicalcenter/**";
	public static final String MEDICALCENTER_AUTHORITY = "MedicalCenter";
	
	public static final String GET_DATA_SUCCESS = "retrive.success";
	public static final String GET_DATA_ERROR = "retrive.error";
	public static final String NOT_DATA = "retrive.nodata";
	
	public static final String LAB_IMAGE = "/image/getImages";
	public static final String MEDICALCENTER_IMAGE = "/image/getImages";
	public static final String PATIENT_IMAGE = "/image/getImages";
	
	public static final String EMAIL = "user.userEmail";
	public static final String EMAIL_EXISTS = "user.userEmail.exists";
	public static final String EMAIL_WRONG= "user.userEmail.wrong";
	public static final String PASSWORD = "user.userPassword";
	public static final String FIRSTNAME = "user.perFname";
	public static final String LASTNAME = "user.perLname";
	public static final String NUMBER = "user.perContactNumber";
	public static final String NUMBER_WRONG = "user.perContactNumber.wrong";
	public static final String USERNAME = "user.userName";
	public static final String USERNAME_EXISTS = "user.userName.exists";
	public static final String ROLENAME = "user.roleName";
	public static final String DEVICETYPE = "user.deviceType";
	public static final String OLDPASSWORD = "user.oldPassword";
	public static final String PROVIDERTYPESTATUS = "user.providertypestatus";
	public static final String SPECIALITY = "user.speciality";
	public static final String FCLOCATIONMAP = "user.fclocationmap";
	public static final String ROLE_NAME = "role.roleName";
	public static final String ROLE_ID = "role.id";
	public static final String CLIENT_NAME = "client.clientComapnyName";
	public static final String CLIENT_ID = "client.id";
	public static final String CLIENT_TIMEZONE = "client.timeZone";

}