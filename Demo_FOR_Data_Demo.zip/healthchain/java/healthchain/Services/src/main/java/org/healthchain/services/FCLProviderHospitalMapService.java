package org.healthchain.services;

import java.util.List;

import org.healthchain.entity.FCLProviderHospitalMap;

public interface FCLProviderHospitalMapService extends GenericService<FCLProviderHospitalMap, Long> {
	
	public List<FCLProviderHospitalMap> getAllData(Long fclProviderMapID);
	
    public List<FCLProviderHospitalMap> getAllDatas(Long fclProviderMapID);
	
	public FCLProviderHospitalMap getData(Long providerId,Long hospitalId);
		
}