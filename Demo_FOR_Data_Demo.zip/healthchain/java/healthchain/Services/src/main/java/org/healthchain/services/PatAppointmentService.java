package org.healthchain.services;

import java.util.List;

import org.healthchain.entity.PatAppointments;
import org.healthchain.entity.PatientMaster;
import org.springframework.data.domain.Pageable;

public interface PatAppointmentService extends GenericService<PatAppointments, Long> {
	
	public List<PatAppointments> findPatientData(PatientMaster patientMaster,Pageable pageable);
	
	public List<PatAppointments> findProviderData(Long providerID,Pageable pageable);
	
	public List<PatAppointments> findPatientDatas(PatientMaster patientMaster);
	
	public List<PatAppointments> findPatient(PatientMaster patientMaster,Long dates);
	
	public List<PatAppointments> findProviderDatas(Long providerID);
}