package org.healthchain.services.impl;

import java.util.List;

import org.healthchain.base.LabPatvisitNoteRepository;
import org.healthchain.entity.LabPatvisitNote;
import org.healthchain.services.LabPatvisitNoteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class LabPatvisitNoteServiceImpl extends GenericServiceImpl<LabPatvisitNote, Long> implements LabPatvisitNoteService {

	@Autowired
	private LabPatvisitNoteRepository labPatvisitNoteRepository;

	@Override
	public LabPatvisitNote findData(Long labId,Long patVisitNoteID) {
		return labPatvisitNoteRepository.findData(labId,patVisitNoteID);
	}
	
	@Override
	public List<LabPatvisitNote> findAll(Long patVisitNoteID){
		return labPatvisitNoteRepository.findAll(patVisitNoteID);
	}
	
	@Override
	public List<LabPatvisitNote> findAllData(Long patVisitNoteID){
		return labPatvisitNoteRepository.findAllData(patVisitNoteID);
	}
}
