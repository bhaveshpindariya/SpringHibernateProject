package org.healthchain.services;

import org.healthchain.entity.CFLPatRegistrationMap;

public interface CFLPatRegistrationMapService extends GenericService<CFLPatRegistrationMap, Long> {
	
	public CFLPatRegistrationMap findCflData(Long patientID,Long fcLocationMapID);
	
}

