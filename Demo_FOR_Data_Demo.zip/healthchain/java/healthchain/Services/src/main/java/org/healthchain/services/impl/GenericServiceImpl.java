package org.healthchain.services.impl;

import java.util.List;

import javax.transaction.Transactional;

import org.healthchain.base.GenericRepository;
import org.healthchain.services.GenericService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public abstract class GenericServiceImpl<E, K> implements GenericService<E, K> {

	@Autowired
	private GenericRepository<E, K> genericRepository;
	 
    @Transactional
    public E saveOrUpdate(E entity) {
    	return genericRepository.save(entity);
    }
 
    @Transactional
    public List<E> getAll() {
        return genericRepository.findAll();
    }
    
    @Transactional
    public List<E> getAllActiveRecord() {
        return genericRepository.getAllActiveRecord();
    }
    
    @Transactional
    public List<E> getAllDeletedRecord() {
        return genericRepository.getAllDeletedRecord();
    }
    
    @Transactional
    public List<E> getAllInActiveRecord() {
        return genericRepository.getAllInActiveRecord();
    }
    
    @Transactional
    public List<E> getAllDeletedAndActiveRecord() {
        return genericRepository.getAllDeletedAndActiveRecord();
    }
 
    @Transactional
    public E get(K id) {
        return genericRepository.getOne(id);
    }
 
    @Transactional
    public void remove(E entity) {
    	genericRepository.delete(entity);
    }
	
}
