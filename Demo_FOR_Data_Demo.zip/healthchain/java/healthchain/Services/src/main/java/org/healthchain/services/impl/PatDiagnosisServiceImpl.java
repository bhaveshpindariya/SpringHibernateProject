package org.healthchain.services.impl;

import java.util.List;

import org.healthchain.base.PatDiagnosisRepository;
import org.healthchain.entity.PatDiagnosis;
import org.healthchain.services.PatDiagnosisService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class PatDiagnosisServiceImpl extends GenericServiceImpl<PatDiagnosis, Long> implements PatDiagnosisService {

	@Autowired
	private PatDiagnosisRepository patDiagnosisRepository;

	@Override
	public PatDiagnosis findData(Long diagnosisID,Long patVisitNoteID) {
		return patDiagnosisRepository.findData(diagnosisID,patVisitNoteID);
	}
	
	@Override
	public List<PatDiagnosis> findAll(Long patVisitNoteID){
		return patDiagnosisRepository.findAll(patVisitNoteID);
	}
	
	@Override
	public List<PatDiagnosis> findAllData(Long patVisitNoteID){
		return patDiagnosisRepository.findAllData(patVisitNoteID);
	}
}
