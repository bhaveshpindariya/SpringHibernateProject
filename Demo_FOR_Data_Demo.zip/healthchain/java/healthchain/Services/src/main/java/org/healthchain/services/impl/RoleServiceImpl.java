package org.healthchain.services.impl;

import org.healthchain.base.RoleRepository;
import org.healthchain.entity.RoleMaster;
import org.healthchain.services.RoleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class RoleServiceImpl extends GenericServiceImpl<RoleMaster, Long> implements RoleService {

	@Autowired
	private RoleRepository roleRepository;

	@Override
	public RoleMaster findByroleName(String roleName) {
		// TODO Auto-generated method stub
		return roleRepository.findByroleName(roleName);
	}

}
