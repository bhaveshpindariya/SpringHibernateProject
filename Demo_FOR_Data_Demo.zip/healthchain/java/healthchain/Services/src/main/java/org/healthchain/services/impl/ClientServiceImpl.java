package org.healthchain.services.impl;

import org.healthchain.base.ClientRepository;
import org.healthchain.entity.ClientMaster;
import org.healthchain.services.ClientService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ClientServiceImpl extends GenericServiceImpl<ClientMaster, Long> implements ClientService {

	@Autowired
	private ClientRepository clientRepository;

	@Override
	public ClientMaster findByCenterName(String name){
		// TODO Auto-generated method stub
		return clientRepository.findByCenterName(name);
	}
	

}
