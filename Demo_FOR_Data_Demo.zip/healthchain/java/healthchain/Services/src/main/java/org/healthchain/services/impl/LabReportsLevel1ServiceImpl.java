package org.healthchain.services.impl;

import java.util.List;

import org.healthchain.base.LabReportsLevel1Repository;
import org.healthchain.entity.LabReportsLevel1;
import org.healthchain.services.LabReportsLevel1Service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class LabReportsLevel1ServiceImpl extends GenericServiceImpl<LabReportsLevel1, Long> implements LabReportsLevel1Service {

	@Autowired
	private LabReportsLevel1Repository labReportsLevel1Repository;

	@Override
	public LabReportsLevel1 findData(String Lrl1Category,String Lrl1Name) {
		return labReportsLevel1Repository.findData(Lrl1Category,Lrl1Name);
	}
	
	@Override
	public LabReportsLevel1 findNames(String Lrl1Name) {
		return labReportsLevel1Repository.findNames(Lrl1Name);
	}
	
	@Override
	public List<LabReportsLevel1> findbynames(String Lrl1Name) {
		return labReportsLevel1Repository.findbynames(Lrl1Name.toLowerCase());
	}
}
