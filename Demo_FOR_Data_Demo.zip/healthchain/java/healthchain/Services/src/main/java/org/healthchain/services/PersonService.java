package org.healthchain.services;

import org.healthchain.entity.PersonMaster;

public interface PersonService extends GenericService<PersonMaster, Long> {
	
	public PersonMaster findByPerEmailPrimary(String email);
	
	public void deletePersonEmailList(Long personid);
	
	public void deletePersonMobileList(Long personid);
	
}
