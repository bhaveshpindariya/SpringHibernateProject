package org.healthchain.services;

import org.healthchain.entity.RxHeader;

public interface RxHeaderService extends GenericService<RxHeader, Long> {
	
	public RxHeader findData(Long patVisitNoteID);
}