package org.healthchain.validate;

import org.healthchain.entity.RoleMaster;
import org.healthchain.services.MessageByLocaleService;
import org.healthchain.services.constants.ServiceConstant;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

@Component
public class RoleEditValidator implements Validator {

	@Autowired
	private MessageByLocaleService messageByLocaleService;
	
	@Override
	public boolean supports(Class<?> clazz) {
		return RoleMaster.class.isAssignableFrom(clazz);
	}

	@Override
	public void validate(Object target, Errors errors) {
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "roleName", "error.field.empty",messageByLocaleService.getMessage(ServiceConstant.ROLE_NAME));
		
		RoleMaster role = (RoleMaster) target;
		
		if(role.getRoleID() == null || role.getRoleID().equals(0L)) 
			errors.rejectValue("roleID", "error.field.empty",messageByLocaleService.getMessage(ServiceConstant.ROLE_ID));
			
	}

}
