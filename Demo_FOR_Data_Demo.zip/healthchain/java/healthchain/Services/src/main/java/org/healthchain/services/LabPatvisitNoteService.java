package org.healthchain.services;

import java.util.List;

import org.healthchain.entity.LabPatvisitNote;

public interface LabPatvisitNoteService extends GenericService<LabPatvisitNote, Long> {
	
	public LabPatvisitNote findData(Long labId,Long patVisitNoteID);
	
	public List<LabPatvisitNote> findAll(Long patVisitNoteID);
	
	public List<LabPatvisitNote> findAllData(Long patVisitNoteID);
	
}