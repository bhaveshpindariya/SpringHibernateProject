package org.healthchain.services;

import java.util.List;

import org.healthchain.entity.FCLProviderLabDrugCompoundMap;

public interface FCLProviderLabDrugCompoundMapService extends GenericService<FCLProviderLabDrugCompoundMap, Long> {
	
	public List<FCLProviderLabDrugCompoundMap> getAllData(Long providerId);
	
	public List<FCLProviderLabDrugCompoundMap> getAllDatas(Long fclProviderMapID);
	
	public List<FCLProviderLabDrugCompoundMap> getAllFacility(Long fclProviderMapID);
	
	public FCLProviderLabDrugCompoundMap getData(Long providerId,Long drugCompoundID);
		
}