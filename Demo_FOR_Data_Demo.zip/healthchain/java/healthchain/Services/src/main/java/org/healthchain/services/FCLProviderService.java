package org.healthchain.services;

import java.util.List;

import org.healthchain.entity.FCLProviderMap;
import org.healthchain.entity.FCLocationMap;
import org.healthchain.entity.FacilityCenterMaster;
import org.healthchain.entity.enums.ProviderTypeStatus;

public interface FCLProviderService extends GenericService<FCLProviderMap, Long> {
	
	public List<FCLProviderMap> getAllProvider(FCLocationMap fcLocationMap);
	
	public FCLProviderMap getdata(Long providerId,Long fcLocationMapID);
	
	public List<FacilityCenterMaster> getAllFacilityByDoctor(Long providerId);
	
	public List<FCLocationMap> getAllLocationByDoctorAndFacility(Long providerId,Long facilityId);
	
	public  List<FCLProviderMap> getFclDataforDoctor(Long providerId,ProviderTypeStatus providerTypeStatus);
	
}