package org.healthchain.services.impl;

import java.util.List;

import org.healthchain.base.FCLProviderLabDoctorMapRepository;
import org.healthchain.entity.FCLProviderLabDoctorMap;
import org.healthchain.services.FCLProviderLabDoctorMapService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class FCLProviderLabDoctorMapServiceImpl extends GenericServiceImpl<FCLProviderLabDoctorMap, Long> implements FCLProviderLabDoctorMapService {

	@Autowired
	private FCLProviderLabDoctorMapRepository fclProviderLabDoctorMapRepository;
	
	@Override
	public List<FCLProviderLabDoctorMap> getAllData(Long fclProviderMapID){
		return fclProviderLabDoctorMapRepository.getAllData(fclProviderMapID);
	}
	
	@Override
	public List<FCLProviderLabDoctorMap> getAllDatas(Long fclProviderMapID){
		return fclProviderLabDoctorMapRepository.getAllDatas(fclProviderMapID);
	}

	@Override
	public FCLProviderLabDoctorMap getData(Long providerId,Long doctorId){
		return fclProviderLabDoctorMapRepository.getData(providerId,doctorId);
	}
}
