package org.healthchain.services.impl;

import org.healthchain.base.SpecialityProviderRepository;
import org.healthchain.entity.SpecialityProviderMaster;
import org.healthchain.services.SpecialityProviderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class SpecialityProviderServiceImpl extends GenericServiceImpl<SpecialityProviderMaster, Long> implements SpecialityProviderService {

	@Autowired
	private SpecialityProviderRepository specialityProviderRepository;

}
