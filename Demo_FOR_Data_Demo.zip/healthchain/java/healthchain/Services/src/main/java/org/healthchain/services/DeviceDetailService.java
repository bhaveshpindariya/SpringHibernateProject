package org.healthchain.services;

import org.healthchain.entity.DeviceDetail;

public interface DeviceDetailService extends GenericService<DeviceDetail, Long> {
	
	public DeviceDetail findByUserForDevice(DeviceDetail token);

}
