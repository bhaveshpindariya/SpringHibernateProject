package org.healthchain.services.impl;

import java.util.List;

import org.healthchain.base.FCLProviderMapRepository;
import org.healthchain.entity.FCLProviderMap;
import org.healthchain.entity.FCLocationMap;
import org.healthchain.entity.FacilityCenterMaster;
import org.healthchain.entity.enums.ProviderTypeStatus;
import org.healthchain.services.FCLProviderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class FCLProviderServiceImpl extends GenericServiceImpl<FCLProviderMap, Long> implements FCLProviderService {

	@Autowired
	private FCLProviderMapRepository fclProviderMapRepository;
	
	@Override
	public List<FCLProviderMap> getAllProvider(FCLocationMap fcLocationMap) {
		// TODO Auto-generated method stub
		return fclProviderMapRepository.getAllProvider(fcLocationMap.getFcLocationMapID());
	}
	
	@Override
	public FCLProviderMap getdata(Long providerId,Long fcLocationMapID) {
		// TODO Auto-generated method stub
		return fclProviderMapRepository.getdata(providerId,fcLocationMapID);
	}
	
	@Override
	public  List<FCLProviderMap> getFclDataforDoctor(Long providerId,ProviderTypeStatus providerTypeStatus) {
		// TODO Auto-generated method stub
		return fclProviderMapRepository.getFclDataforDoctor(providerId,providerTypeStatus);
	}
	
	@Override
	public List<FacilityCenterMaster> getAllFacilityByDoctor(Long providerId){
		return fclProviderMapRepository.getAllFacilityByDoctor(providerId);
	}
	
	@Override
	public List<FCLocationMap> getAllLocationByDoctorAndFacility(Long providerId,Long facilityId){
		return fclProviderMapRepository.getAllLocationByDoctorAndFacility(providerId,facilityId);
	}

}
