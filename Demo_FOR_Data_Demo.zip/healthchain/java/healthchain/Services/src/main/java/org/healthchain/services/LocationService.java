package org.healthchain.services;

import org.healthchain.entity.LocationMaster;

public interface LocationService extends GenericService<LocationMaster, Long> {
	
}
