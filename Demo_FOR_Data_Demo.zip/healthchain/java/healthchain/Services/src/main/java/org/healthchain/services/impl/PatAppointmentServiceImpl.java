package org.healthchain.services.impl;

import java.util.List;

import org.healthchain.base.PatAppointmentRepository;
import org.healthchain.entity.PatAppointments;
import org.healthchain.entity.PatientMaster;
import org.healthchain.services.PatAppointmentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

@Service
public class PatAppointmentServiceImpl extends GenericServiceImpl<PatAppointments, Long> implements PatAppointmentService {

	@Autowired
	private PatAppointmentRepository patAppointmentRepository;
	
	@Override
	public List<PatAppointments> findPatientData(PatientMaster patientMaster,Pageable pageable){
		return patAppointmentRepository.findPatientData(patientMaster.getPatientID(),pageable);
	}
	
	@Override
	public List<PatAppointments> findProviderData(Long providerID,Pageable pageable){
		return patAppointmentRepository.findProviderData(providerID,pageable);
	}

	@Override
	public List<PatAppointments> findPatientDatas(PatientMaster patientMaster){
		return patAppointmentRepository.findPatientDatas(patientMaster.getPatientID());
	}
	
	@Override
	public List<PatAppointments> findProviderDatas(Long providerID){
		return patAppointmentRepository.findProviderDatas(providerID);
	}
	
	@Override
	public List<PatAppointments> findPatient(PatientMaster patientMaster,Long dates){
		return patAppointmentRepository.findPatient(patientMaster.getPatientID(),dates);
	}
	
}
