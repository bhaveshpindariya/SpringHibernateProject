package org.healthchain.services.impl;

import javax.transaction.Transactional;

import org.healthchain.base.PersonRepository;
import org.healthchain.entity.PersonMaster;
import org.healthchain.services.PersonService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class PersonServiceImpl extends GenericServiceImpl<PersonMaster, Long> implements PersonService {

	@Autowired
	private PersonRepository personRepository;

	@Override
	public PersonMaster findByPerEmailPrimary(String email){
		// TODO Auto-generated method stub
		return personRepository.findByPerEmailPrimary(email);
	}
	
	@Override
	@Transactional
	public void deletePersonEmailList(Long personid){
		// TODO Auto-generated method stub
		personRepository.deletePersonEmailList(personid);
	}
	
	@Override
	@Transactional
	public void deletePersonMobileList(Long personid){
		// TODO Auto-generated method stub
		personRepository.deletePersonMobileList(personid);
	}
	

}
