package org.healthchain.services.impl;

import java.util.List;

import org.healthchain.base.FCLProviderReportMapRepository;
import org.healthchain.entity.FCLProviderReportMap;
import org.healthchain.entity.FacilityCenterMaster;
import org.healthchain.services.FCLProviderReportMapService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class FCLProviderReportMapServiceImpl extends GenericServiceImpl<FCLProviderReportMap, Long> implements FCLProviderReportMapService {

	@Autowired
	private FCLProviderReportMapRepository fclProviderReportMapRepository;
	
	@Override
	public List<FCLProviderReportMap> getAllData(Long fclProviderMapID){
		return fclProviderReportMapRepository.getAllData(fclProviderMapID);
	}
	
	@Override
	public List<FCLProviderReportMap> getAllDatas(Long fclProviderMapID){
		return fclProviderReportMapRepository.getAllDatas(fclProviderMapID);
	}
	
	@Override
	public List<FCLProviderReportMap> getAllFacility(Long fclProviderMapID){
		return fclProviderReportMapRepository.getAllFacility(fclProviderMapID);
	}
	
	@Override
	public FCLProviderReportMap getData(Long providerId,Long labId){
		return fclProviderReportMapRepository.getData(providerId,labId);
	}
	
	@Override
	public List<FacilityCenterMaster> getAllFacilitybyLocation(List<Long> labReportLevel1ID){
		return fclProviderReportMapRepository.getAllFacilitybyLocation(labReportLevel1ID);
	}
	
}
