package org.healthchain.services.impl;

import org.healthchain.base.UserRepository;
import org.healthchain.entity.UserMaster;
import org.healthchain.services.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserServiceImpl extends GenericServiceImpl<UserMaster, Long> implements UserService {

	@Autowired
	private UserRepository userRepository;

	@Override
	public UserMaster findByUser(String userName,String email) {
		// TODO Auto-generated method stub
		return userRepository.serarchByUser(userName,email);
	}
	
	@Override
	public UserMaster findByUserEmail(String email) {
		// TODO Auto-generated method stub
		return userRepository.findByUserEmail(email);
	}
	
	@Override
	public UserMaster findByUserName(String userName){
		// TODO Auto-generated method stub
		return userRepository.findByUserName(userName);
	}
	

}
