package org.healthchain.services;

import java.util.List;

import org.healthchain.entity.FCLProviderLabDoctorMap;

public interface FCLProviderLabDoctorMapService extends GenericService<FCLProviderLabDoctorMap, Long> {
	
	public List<FCLProviderLabDoctorMap> getAllData(Long fclProviderMapID);
	
	public List<FCLProviderLabDoctorMap> getAllDatas(Long fclProviderMapID);
	
	public FCLProviderLabDoctorMap getData(Long providerId,Long doctorId);
		
}