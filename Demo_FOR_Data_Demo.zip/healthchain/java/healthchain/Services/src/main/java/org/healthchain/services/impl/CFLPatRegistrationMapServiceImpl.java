package org.healthchain.services.impl;

import org.healthchain.base.CFLPatRegistrationMapRepository;
import org.healthchain.entity.CFLPatRegistrationMap;
import org.healthchain.services.CFLPatRegistrationMapService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CFLPatRegistrationMapServiceImpl extends GenericServiceImpl<CFLPatRegistrationMap, Long> implements CFLPatRegistrationMapService {

	@Autowired
	private CFLPatRegistrationMapRepository cfLPatRegistrationMapRepository;

	@Override
	public CFLPatRegistrationMap findCflData(Long patientID,Long fcLocationMapID){
		// TODO Auto-generated method stub
		return cfLPatRegistrationMapRepository.findCflData(patientID,fcLocationMapID);
	}

}
