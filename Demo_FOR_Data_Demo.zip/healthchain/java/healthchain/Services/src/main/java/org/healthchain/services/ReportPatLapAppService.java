package org.healthchain.services;

import java.util.List;

import org.healthchain.entity.ReportPatLapApp;
import org.springframework.data.domain.Pageable;

public interface ReportPatLapAppService extends GenericService<ReportPatLapApp, Long> {

	public ReportPatLapApp findReport(Long patLabAppointmentID);
	
	public List<ReportPatLapApp> findReportAll(Long userID,Pageable pageable);
	
	public List<ReportPatLapApp> findReportAllpatient(Long userID,Pageable pageable);
	
	public List<ReportPatLapApp> findReportAllpatients(Long patientID);
	
	public List<ReportPatLapApp> findReportAlls(Long userID);

}