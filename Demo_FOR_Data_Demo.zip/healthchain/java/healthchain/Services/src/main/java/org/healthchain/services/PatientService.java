package org.healthchain.services;

import java.util.List;

import org.healthchain.entity.PatientMaster;

public interface PatientService extends GenericService<PatientMaster, Long> {
	
	public PatientMaster findByPatient(String email);
	
	public List<PatientMaster> findbynames(String name);
	
}