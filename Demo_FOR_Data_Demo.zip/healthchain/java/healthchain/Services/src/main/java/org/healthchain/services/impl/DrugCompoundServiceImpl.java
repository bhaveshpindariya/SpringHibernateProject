package org.healthchain.services.impl;

import java.util.List;

import org.healthchain.base.DrugCompoundRepository;
import org.healthchain.entity.DrugCompoundMaster;
import org.healthchain.services.DrugCompoundService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class DrugCompoundServiceImpl extends GenericServiceImpl<DrugCompoundMaster, Long> implements DrugCompoundService {

	@Autowired
	private DrugCompoundRepository drugCompoundRepository ;

	@Override
	public DrugCompoundMaster findData(String drugCompoundName) {
		return drugCompoundRepository.findData(drugCompoundName);
	}
	
	@Override
	public List<DrugCompoundMaster> findbynames(String drugCompoundName) {
		return drugCompoundRepository.findbynames(drugCompoundName.toLowerCase());
	}
}
