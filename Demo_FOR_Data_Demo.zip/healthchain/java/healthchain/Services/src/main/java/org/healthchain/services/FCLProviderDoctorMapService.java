package org.healthchain.services;

import java.util.List;

import org.healthchain.entity.FCLProviderDoctorMap;

public interface FCLProviderDoctorMapService extends GenericService<FCLProviderDoctorMap, Long> {
	
	public List<FCLProviderDoctorMap> getAllData(Long fclProviderMapID);
	
	public List<FCLProviderDoctorMap> getAllDatas(Long fclProviderMapID);
	
	public FCLProviderDoctorMap getData(Long providerId,Long doctorId);
		
}