package org.healthchain.services;

import java.util.List;

import org.healthchain.entity.PatDiagnosis;

public interface PatDiagnosisService extends GenericService<PatDiagnosis, Long> {
	
	public PatDiagnosis findData(Long diagnosisID,Long patVisitNoteID);
	
	public List<PatDiagnosis> findAll(Long patVisitNoteID);
	
	public List<PatDiagnosis> findAllData(Long patVisitNoteID);
	
}