package org.healthchain.services;

import org.healthchain.entity.SpecialityProviderMaster;

public interface SpecialityProviderService extends GenericService<SpecialityProviderMaster, Long> {

}
