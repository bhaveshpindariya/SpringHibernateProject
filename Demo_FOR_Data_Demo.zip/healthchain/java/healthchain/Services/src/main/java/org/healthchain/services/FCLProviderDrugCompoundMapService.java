package org.healthchain.services;

import java.util.List;

import org.healthchain.entity.FCLProviderDrugCompoundMap;

public interface FCLProviderDrugCompoundMapService extends GenericService<FCLProviderDrugCompoundMap, Long> {
	
	public List<FCLProviderDrugCompoundMap> getAllData(Long fclProviderMapID);
	
	public List<FCLProviderDrugCompoundMap> getAllDatas(Long fclProviderMapID);
	
	public List<FCLProviderDrugCompoundMap> getAllFacility(Long fclProviderMapID);
	
	public FCLProviderDrugCompoundMap getData(Long providerId,Long drugCompoundID);
		
}