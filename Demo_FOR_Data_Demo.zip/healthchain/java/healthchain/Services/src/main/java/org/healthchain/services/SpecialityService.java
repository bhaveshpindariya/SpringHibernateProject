package org.healthchain.services;

import org.healthchain.entity.SpecialityMaster;

public interface SpecialityService extends GenericService<SpecialityMaster, Long> {
	
	public SpecialityMaster findByName(String name);
	
}
