package org.healthchain.services.impl;

import java.util.List;

import org.healthchain.base.FCLProviderDrugCompoundMapRepository;
import org.healthchain.entity.FCLProviderDrugCompoundMap;
import org.healthchain.services.FCLProviderDrugCompoundMapService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class FCLProviderDrugCompoundMapServiceImpl extends GenericServiceImpl<FCLProviderDrugCompoundMap, Long> implements FCLProviderDrugCompoundMapService {

	@Autowired
	private FCLProviderDrugCompoundMapRepository fclLProviderDrugCompoundMapRepository;
	
	@Override
	public List<FCLProviderDrugCompoundMap> getAllData(Long fclProviderMapID){
		return fclLProviderDrugCompoundMapRepository.getAllData(fclProviderMapID);
	}
	
	@Override
	public List<FCLProviderDrugCompoundMap> getAllDatas(Long fclProviderMapID){
		return fclLProviderDrugCompoundMapRepository.getAllDatas(fclProviderMapID);
	}
	
	@Override
	public List<FCLProviderDrugCompoundMap> getAllFacility(Long fclProviderMapID){
		return fclLProviderDrugCompoundMapRepository.getAllFacility(fclProviderMapID);
	}
	
	@Override
	public FCLProviderDrugCompoundMap getData(Long providerId,Long drugCompoundID){
		return fclLProviderDrugCompoundMapRepository.getData(providerId,drugCompoundID);
	}
	
}
