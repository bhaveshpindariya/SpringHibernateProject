package org.healthchain.services.impl;

import java.util.List;

import org.healthchain.base.SuggestReportRepository;
import org.healthchain.entity.SuggestReport;
import org.healthchain.services.SuggestReportService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class SuggestReportServiceImpl extends GenericServiceImpl<SuggestReport, Long> implements SuggestReportService {

	@Autowired
	private SuggestReportRepository suggestReportRepository;

	@Override
	public SuggestReport findData(Long labId,Long patLabAppointmentID) {
		return suggestReportRepository.findData(labId,patLabAppointmentID);
	}
	
	@Override
	public List<SuggestReport> findAll(Long patLabAppointmentID){
		return suggestReportRepository.findAll(patLabAppointmentID);
	}
	
	@Override
	public List<SuggestReport> findAllData(Long patLabAppointmentID){
		return suggestReportRepository.findAllData(patLabAppointmentID);
	}
}
