package org.healthchain.services.impl;

import org.healthchain.base.DrugsActiveSubstanceRepository;
import org.healthchain.entity.DrugsActiveSubstanceMaster;
import org.healthchain.services.DrugsActiveSubstanceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class DrugsActiveSubstanceServiceImpl extends GenericServiceImpl<DrugsActiveSubstanceMaster, Long> implements DrugsActiveSubstanceService {


	@Autowired
	private DrugsActiveSubstanceRepository drugsActiveSubstanceRepository ;

	@Override
	public DrugsActiveSubstanceMaster findData(String dasName) {
		return drugsActiveSubstanceRepository.findData(dasName);
	}
}
