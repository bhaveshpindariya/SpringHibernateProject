package org.healthchain.services.impl;

import org.healthchain.base.UserRoleRepository;
import org.healthchain.entity.UserRoleEntity;
import org.healthchain.services.UserRoleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserRoleServiceImpl extends GenericServiceImpl<UserRoleEntity, Long> implements UserRoleService {

	@Autowired
	private UserRoleRepository userRoleRepository;

}
