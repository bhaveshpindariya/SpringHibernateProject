package org.healthchain.services;

import java.util.List;

import org.healthchain.entity.PatVisitNote;
import org.springframework.data.domain.Pageable;

public interface PatVisitNoteService extends GenericService<PatVisitNote, Long> {
	
	public PatVisitNote findData(Long appointmentId);
	
	public List<PatVisitNote> findPatientData(Long patientID,Pageable pageable);
	
	public List<PatVisitNote> findProviderData(Long providerID,Pageable pageable);
	
    public List<PatVisitNote> findPatientDatas(Long patientID);
	
	public List<PatVisitNote> findProviderDatas(Long providerID);
}