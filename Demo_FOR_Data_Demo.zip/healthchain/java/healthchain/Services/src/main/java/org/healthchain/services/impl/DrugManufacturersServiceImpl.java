package org.healthchain.services.impl;

import java.util.List;

import org.healthchain.base.DrugManufacturersRepository;
import org.healthchain.entity.DrugManufacturersMaster;
import org.healthchain.services.DrugManufacturersService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class DrugManufacturersServiceImpl extends GenericServiceImpl<DrugManufacturersMaster, Long> implements DrugManufacturersService {

	@Autowired
	private DrugManufacturersRepository drugManufacturersRepository ;

	@Override
	public DrugManufacturersMaster findData(String drugMfgrName) {
		return drugManufacturersRepository.findData(drugMfgrName);
	}
	
	@Override
	public List<DrugManufacturersMaster> findbynames(String drugMfgrName) {
		return drugManufacturersRepository.findbynames(drugMfgrName.toLowerCase());
	}
}
