package org.healthchain.services;

public interface MessageByLocaleService {

    public String getMessage(String id);
}