package org.healthchain.services.impl;

import java.util.List;

import org.healthchain.base.FCLProviderLabDrugCompoundMapRepository;
import org.healthchain.entity.FCLProviderLabDrugCompoundMap;
import org.healthchain.services.FCLProviderLabDrugCompoundMapService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class FCLProviderLabDrugCompoundMapServiceImpl extends GenericServiceImpl<FCLProviderLabDrugCompoundMap, Long> implements FCLProviderLabDrugCompoundMapService {

	@Autowired
	private FCLProviderLabDrugCompoundMapRepository fclLProviderLabDrugCompoundMapRepository;
	
	@Override
	public List<FCLProviderLabDrugCompoundMap> getAllData(Long providerId){
		return fclLProviderLabDrugCompoundMapRepository.getAllData(providerId);
	}
	
	@Override
	public List<FCLProviderLabDrugCompoundMap> getAllDatas(Long fclProviderMapID){
		return fclLProviderLabDrugCompoundMapRepository.getAllDatas(fclProviderMapID);
	}
	
	@Override
	public List<FCLProviderLabDrugCompoundMap> getAllFacility(Long fclProviderMapID){
		return fclLProviderLabDrugCompoundMapRepository.getAllFacility(fclProviderMapID);
	}
	
	@Override
	public FCLProviderLabDrugCompoundMap getData(Long providerId,Long drugCompoundID){
		return fclLProviderLabDrugCompoundMapRepository.getData(providerId,drugCompoundID);
	}
	
}
