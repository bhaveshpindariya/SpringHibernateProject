package org.healthchain.services.impl;

import java.util.List;

import org.healthchain.base.PatLabAppointmentRepository;
import org.healthchain.entity.PatLabAppointments;
import org.healthchain.entity.PatientMaster;
import org.healthchain.services.PatLabAppointmentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

@Service
public class PatLabAppointmentServiceImpl extends GenericServiceImpl<PatLabAppointments, Long> implements PatLabAppointmentService {

	@Autowired
	private PatLabAppointmentRepository patLabAppointmentRepository;
	
	@Override
	public List<PatLabAppointments> findPatientData(PatientMaster patientMaster,Pageable pageable){
		return patLabAppointmentRepository.findPatientData(patientMaster.getPatientID(),pageable);
	}
	
	@Override
	public List<PatLabAppointments> findProviderData(Long providerID,Pageable pageable){
		return patLabAppointmentRepository.findProviderData(providerID,pageable);
	}

	@Override
	public List<PatLabAppointments> findPatientDatas(PatientMaster patientMaster){
		return patLabAppointmentRepository.findPatientDatas(patientMaster.getPatientID());
	}
	
	@Override
	public List<PatLabAppointments> findPatient(PatientMaster patientMaster,Long date){
		return patLabAppointmentRepository.findPatient(patientMaster.getPatientID(),date);
	}
	
	@Override
	public List<PatLabAppointments> findProviderDatas(Long providerID){
		return patLabAppointmentRepository.findProviderDatas(providerID);
	}
}
