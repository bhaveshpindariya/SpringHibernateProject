package org.healthchain.services.impl;

import java.util.List;

import org.healthchain.base.FCLProviderHospitalMapRepository;
import org.healthchain.entity.FCLProviderHospitalMap;
import org.healthchain.services.FCLProviderHospitalMapService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class FCLProviderHospitalMapServiceImpl extends GenericServiceImpl<FCLProviderHospitalMap, Long> implements FCLProviderHospitalMapService {

	@Autowired
	private FCLProviderHospitalMapRepository fclLProviderHospitalMapRepository;
	
	@Override
	public List<FCLProviderHospitalMap> getAllData(Long fclProviderMapID){
		return fclLProviderHospitalMapRepository.getAllData(fclProviderMapID);
	}

	@Override
	public List<FCLProviderHospitalMap> getAllDatas(Long fclProviderMapID){
		return fclLProviderHospitalMapRepository.getAllDatas(fclProviderMapID);
	}

	@Override
	public FCLProviderHospitalMap getData(Long providerId,Long hospitalId){
		return fclLProviderHospitalMapRepository.getData(providerId,hospitalId);
	}
}
