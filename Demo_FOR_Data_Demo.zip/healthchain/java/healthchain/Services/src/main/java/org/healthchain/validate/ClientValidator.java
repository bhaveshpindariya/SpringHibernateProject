package org.healthchain.validate;

import org.healthchain.entity.ClientMaster;
import org.healthchain.entity.TimeZoneMaster;
import org.healthchain.services.MessageByLocaleService;
import org.healthchain.services.constants.ServiceConstant;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

@Component
public class ClientValidator implements Validator {

	@Autowired
	private MessageByLocaleService messageByLocaleService;
	
	@Override
	public boolean supports(Class<?> clazz) {
		return ClientMaster.class.isAssignableFrom(clazz);
	}

	@Override
	public void validate(Object target, Errors errors) {
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "clientComapnyName", "error.field.empty",messageByLocaleService.getMessage(ServiceConstant.CLIENT_NAME));
	
		ClientMaster client = (ClientMaster) target;
		
		TimeZoneMaster timeZoneMaster=client.getTimeZoneMaster();
		
		if(timeZoneMaster.getUtcTimeZoneId() == null || timeZoneMaster.getUtcTimeZoneId().equals(0L))
			errors.rejectValue("timeZoneMaster", "error.field.empty",messageByLocaleService.getMessage(ServiceConstant.CLIENT_TIMEZONE));
	}

}
