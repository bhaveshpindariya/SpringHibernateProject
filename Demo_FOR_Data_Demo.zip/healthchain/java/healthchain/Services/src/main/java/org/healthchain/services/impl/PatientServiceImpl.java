package org.healthchain.services.impl;

import java.util.List;

import org.healthchain.base.PatientRepository;
import org.healthchain.entity.PatientMaster;
import org.healthchain.services.PatientService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class PatientServiceImpl extends GenericServiceImpl<PatientMaster, Long> implements PatientService {

	@Autowired
	private PatientRepository patientRepository;
	
	@Override
	public PatientMaster findByPatient(String email){
		// TODO Auto-generated method stub
		return patientRepository.findByPatient(email);
	}

	@Override
	public List<PatientMaster> findbynames(String name) {
		return patientRepository.findbynames(name.toLowerCase());
	}
}
