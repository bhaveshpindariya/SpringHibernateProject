package org.healthchain.services;

import java.util.List;

import org.healthchain.entity.LabReportsLevel1;

public interface LabReportsLevel1Service extends GenericService<LabReportsLevel1, Long> {
	
	public LabReportsLevel1 findData(String Lrl1Category,String Lrl1Name);
	
	public LabReportsLevel1 findNames(String Lrl1Name);
	
	public List<LabReportsLevel1> findbynames(String Lrl1Name);
	
}