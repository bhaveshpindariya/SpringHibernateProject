package org.healthchain.services;

import org.healthchain.entity.LabReportsLevel1;
import org.healthchain.entity.ReportLapApp;

public interface ReportLapAppService extends GenericService<ReportLapApp, Long> {
	
	public LabReportsLevel1 findAlllabreport(Long reportLapApp);
	
}