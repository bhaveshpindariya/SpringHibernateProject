package org.healthchain.validate;

import java.util.regex.Pattern;

import org.healthchain.entity.UserMaster;
import org.healthchain.services.MessageByLocaleService;
import org.healthchain.services.constants.ServiceConstant;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

@Component
public class ForgotPasswordValidator implements Validator {

	@Autowired
	private MessageByLocaleService messageByLocaleService;
	
	@Override
	public boolean supports(Class<?> clazz) {
		return UserMaster.class.isAssignableFrom(clazz);
	}

	@Override
	public void validate(Object target, Errors errors) {
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "userEmail", "error.field.empty",messageByLocaleService.getMessage(ServiceConstant.EMAIL));
		
		UserMaster user = (UserMaster) target;

		String email = user.getUserEmail();
		if (!isValid(email))
			errors.rejectValue("userEmail", "error.userEmail.Wrong",messageByLocaleService.getMessage(ServiceConstant.EMAIL_WRONG));
				
	}

	public static boolean isValid(String email) {
		String emailRegex = "^[a-zA-Z0-9_+&*-]+(?:\\." + "[a-zA-Z0-9_+&*-]+)*@" + "(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,7}$";
		Pattern pat = Pattern.compile(emailRegex);
		if (email == null)
			return false;
		return pat.matcher(email).matches();
	}

}
