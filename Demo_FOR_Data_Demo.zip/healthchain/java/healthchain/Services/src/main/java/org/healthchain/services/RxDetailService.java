package org.healthchain.services;

import java.util.List;

import org.healthchain.entity.DrugCompoundMaster;
import org.healthchain.entity.RxDetail;

public interface RxDetailService extends GenericService<RxDetail, Long> {
	
	public RxDetail findData(Long drugCompoundID,Long rxID);
	
	public List<DrugCompoundMaster> findAll(Long patVisitNoteID);
	
	public List<RxDetail> findAllData(Long rxID);
}