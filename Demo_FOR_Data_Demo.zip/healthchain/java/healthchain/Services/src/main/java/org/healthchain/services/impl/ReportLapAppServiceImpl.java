package org.healthchain.services.impl;

import org.healthchain.base.ReportLapAppRepository;
import org.healthchain.entity.LabReportsLevel1;
import org.healthchain.entity.ReportLapApp;
import org.healthchain.services.ReportLapAppService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ReportLapAppServiceImpl extends GenericServiceImpl<ReportLapApp, Long> implements ReportLapAppService {

	@Autowired
	private ReportLapAppRepository reportLapAppRepository;
	
	@Override
	public LabReportsLevel1 findAlllabreport(Long reportLapApp) {
		return reportLapAppRepository.findAlllabreport(reportLapApp);
	}
}
