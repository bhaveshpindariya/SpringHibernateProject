package org.healthchain.services;

import java.util.List;

import org.healthchain.entity.DrugCompoundMaster;

public interface DrugCompoundService extends GenericService<DrugCompoundMaster, Long> {
	
	public DrugCompoundMaster findData(String drugCompoundName);
	
	public List<DrugCompoundMaster> findbynames(String drugCompoundName);

}