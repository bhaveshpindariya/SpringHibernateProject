package org.healthchain.services;

import org.healthchain.entity.ClientMaster;

public interface ClientService extends GenericService<ClientMaster, Long> {
	
	public ClientMaster findByCenterName(String name);
	
}