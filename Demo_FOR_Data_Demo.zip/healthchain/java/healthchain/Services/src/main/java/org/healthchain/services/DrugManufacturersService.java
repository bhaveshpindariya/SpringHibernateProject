package org.healthchain.services;

import java.util.List;

import org.healthchain.entity.DrugManufacturersMaster;

public interface DrugManufacturersService extends GenericService<DrugManufacturersMaster, Long> {
	
	public DrugManufacturersMaster findData(String drugMfgrName);
	
	public List<DrugManufacturersMaster> findbynames(String drugMfgrName);
}