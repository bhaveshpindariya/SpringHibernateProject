package org.healthchain.services;

import java.util.List;

import org.healthchain.entity.DiagnosisMaster;

public interface DiagnosisService extends GenericService<DiagnosisMaster, Long> {
	
	public DiagnosisMaster findName(String name);
	
	public List<DiagnosisMaster> findbynames(String name);
}
