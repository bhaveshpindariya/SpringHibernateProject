package org.healthchain.config;

import org.healthchain.services.constants.ServiceConstant;
import org.healthchain.services.impl.MyUserDetailsServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.crypto.password.PasswordEncoder;

@Configuration
@EnableWebSecurity
public class SpringSecurityConfig extends WebSecurityConfigurerAdapter {

	@Autowired
	private MyUserDetailsServiceImpl userDetailsService;

	@Override
	protected void configure(final HttpSecurity http) throws Exception {
		http.csrf().disable().httpBasic().and().authorizeRequests()
				.antMatchers(ServiceConstant.LAB_IMAGE).permitAll()
				.antMatchers(ServiceConstant.DOWNLOAD).permitAll()
				.antMatchers(ServiceConstant.MEDICALCENTER_IMAGE).permitAll()
				.antMatchers(ServiceConstant.PATIENT_IMAGE).permitAll()
				.antMatchers(ServiceConstant.REGISTRATION_MATCHER).permitAll()
				.antMatchers(ServiceConstant.FORGOT_MATCHER).permitAll()
				.antMatchers(ServiceConstant.AUTHORIZATION_USER).permitAll()
				.antMatchers(ServiceConstant.LOGIN_MATCHER).fullyAuthenticated()
				.antMatchers(ServiceConstant.COMMON_MATCHER).fullyAuthenticated()
				.antMatchers(ServiceConstant.PROFILE_MATCHER).fullyAuthenticated()
				.antMatchers(ServiceConstant.PATIENT_MATCHER).hasAuthority(ServiceConstant.PATIENT_AUTHORITY)
				.antMatchers(ServiceConstant.ADMIN_MATCHER).hasAuthority(ServiceConstant.AUTHORITY_ADMIN)
				.antMatchers(ServiceConstant.ROLE_MATCHER).hasAuthority(ServiceConstant.AUTHORITY_ADMIN)
				.antMatchers(ServiceConstant.DOCTOR_MATCHER).hasAuthority(ServiceConstant.DOCTOR_AUTHORITY)
				.antMatchers(ServiceConstant.LAB_PROFILE_MATCHER).hasAuthority(ServiceConstant.LABORATORY_AUTHORITY)
				.antMatchers(ServiceConstant.LABORATORY_MATCHER).hasAuthority(ServiceConstant.LABORATORY_AUTHORITY)
				.antMatchers(ServiceConstant.CLINIC_MATCHER).hasAuthority(ServiceConstant.CLINIC_AUTHORITY)
				.antMatchers(ServiceConstant.HOSPITAL_MATCHER).hasAuthority(ServiceConstant.HOSPITAL_AUTHORITY)
				.antMatchers(ServiceConstant.INSURANCE_MATCHER).hasAuthority(ServiceConstant.INSURANCE_AUTHORITY)
				.antMatchers(ServiceConstant.MEDICALCENTER_MATCHER).hasAuthority(ServiceConstant.MEDICALCENTER_AUTHORITY);
				
		
	}

	@Override
	protected void configure(AuthenticationManagerBuilder auth) throws Exception {
		auth.authenticationProvider(authenticationProvider());
	}

	@Bean
	public DaoAuthenticationProvider authenticationProvider() {
		DaoAuthenticationProvider authProvider = new DaoAuthenticationProvider();
		authProvider.setUserDetailsService(userDetailsService);

		authProvider.setPasswordEncoder(encoder());
		return authProvider;
	}

	@Bean
	public PasswordEncoder encoder() {

		return new PasswordEncoder() {

			@Override
			public boolean matches(CharSequence rawPassword, String encodedPassword) {
				// TODO Auto-generated method stub
				System.out.println("RAW PASSWORD"  + rawPassword);
				System.out.println("ENCODED PASSWORD"  + encodedPassword);
				return rawPassword.toString().equals(encodedPassword);
			}

			@Override
			public String encode(CharSequence rawPassword) {
				// TODO Auto-generated method stub
				return rawPassword.toString();
			}
		};
	}

}