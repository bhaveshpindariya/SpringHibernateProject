package org.healthchain.laboratory.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.healthchain.common.constants.CommonConstants;
import org.healthchain.common.constants.ResponseConstant;
import org.healthchain.common.utils.ApiUtil;
import org.healthchain.common.utils.DateUtil;
import org.healthchain.common.utils.HyperledgerApiUtil;
import org.healthchain.common.utils.OperationsUtil;
import org.healthchain.entity.DiagnosisMaster;
import org.healthchain.entity.LabReportsLevel1;
import org.healthchain.entity.PatLabAppointments;
import org.healthchain.entity.ProviderMaster;
import org.healthchain.entity.ReportLapApp;
import org.healthchain.entity.ReportLapReportPatLap;
import org.healthchain.entity.ReportPatLapApp;
import org.healthchain.entity.UserMaster;
import org.healthchain.entity.enums.ProviderTypeStatus;
import org.healthchain.laboratory.constants.LABORATORYURLConstant;
import org.healthchain.pojo.CommonPojo;
import org.healthchain.pojo.DiseasePojo;
import org.healthchain.pojo.LabReportPojo;
import org.healthchain.pojo.LabReportPojoList;
import org.healthchain.pojo.LabReportsLevel1Pojo;
import org.healthchain.pojo.ReportLapPojo;
import org.healthchain.pojo.Response;
import org.healthchain.services.DiagnosisService;
import org.healthchain.services.LabReportsLevel1Service;
import org.healthchain.services.MessageByLocaleService;
import org.healthchain.services.PatLabAppointmentService;
import org.healthchain.services.ProviderService;
import org.healthchain.services.ReportLapAppService;
import org.healthchain.services.ReportLapReportPatLapService;
import org.healthchain.services.ReportPatLapAppService;
import org.healthchain.services.UserService;
import org.healthchain.services.constants.ServiceConstant;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import net.sf.json.JSONObject;

@CrossOrigin
@RestController
@RequestMapping(LABORATORYURLConstant.LAB_ROOT_URL)
public class LabController {

	private static final Log logger = LogFactory.getLog(LabController.class);
	
	@Autowired
	private ProviderService providerService;

	@Autowired
	private UserService userService;
	
	@Autowired
	private LabReportsLevel1Service labReportsLevel1Service;
	
	@Autowired
    private PatLabAppointmentService patLabAppointmentService;
	
	@Autowired
    private DiagnosisService diagnosisService;
		
	@Autowired
	private ReportPatLapAppService reportPatLapAppService;

	@Autowired
	private MessageByLocaleService messageByLocaleService;
	
	@Autowired
	private ReportLapAppService reportLapAppService;
	
	@Autowired
	private ReportLapReportPatLapService reportLapReportPatLapService;

	@RequestMapping(value = LABORATORYURLConstant.GET_LAB_REPORT_LIST_URL, method = RequestMethod.GET, headers = CommonConstants.CONTENT_TYPE_APPLICATION_JSON)
	public ResponseEntity<Response> getAllLabReport(Locale locale,Pageable pageable) {
		Response response = new Response();
		UserDetails userDetails = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		UserMaster userEntity = userService.findByUserName(userDetails.getUsername());
		try {
			ProviderMaster providerMaster=providerService.getProvider(userEntity.getUserEmail(),ProviderTypeStatus.LabUser);
			LabReportPojoList labReportPojoList=new LabReportPojoList();
			List<LabReportPojo> labReportPojo=new ArrayList<LabReportPojo>(0);
			List<PatLabAppointments> patLabAppointments=patLabAppointmentService.findProviderData(providerMaster.getProviderID(),pageable);
			List<PatLabAppointments> patLabAppointment=patLabAppointmentService.findProviderDatas(providerMaster.getProviderID());
			if(patLabAppointments.size()>0) {
				for(PatLabAppointments pla:patLabAppointments) {
					LabReportPojo lrp=SetLabReportPojo(pla,providerMaster);
					labReportPojo.add(lrp);
				}
				labReportPojoList.setTotalNumber(patLabAppointment.size());
				labReportPojoList.setLabReportPojo(labReportPojo);
			}
			response.setStatus(ResponseConstant.SUCCESS);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_SUCCESS));
			response.setData(labReportPojoList);
		} catch (Exception e) {
			logger.error("Error:--", e);
			response.setStatus(ResponseConstant.ERROR);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			response.setData(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Response>(response, HttpStatus.OK);
	}
	
	@RequestMapping(value = LABORATORYURLConstant.ALL_LABREPORT_LABUSER_URL, method = RequestMethod.GET, headers = CommonConstants.CONTENT_TYPE_APPLICATION_JSON)
	public ResponseEntity<Response> getAllLabReportWithoutBook(Locale locale,Pageable pageable) {
		Response response = new Response();
		UserDetails userDetails = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		UserMaster userEntity = userService.findByUserName(userDetails.getUsername());
		try {
			ProviderMaster providerMaster=providerService.getProvider(userEntity.getUserEmail(),ProviderTypeStatus.LabUser);
			LabReportPojoList labReportPojoList=new LabReportPojoList();
			List<LabReportPojo> labReportPojo=new ArrayList<LabReportPojo>(0);
			List<ReportPatLapApp> reportPatLapApps=reportPatLapAppService.findReportAll(userEntity.getUserID(),pageable);
			List<ReportPatLapApp> reportPatLapAppdata=reportPatLapAppService.findReportAlls(userEntity.getUserID());
			if(reportPatLapApps.size()>0) {
				for(ReportPatLapApp reportPatLapApp:reportPatLapApps) {
					LabReportPojo lrp=SetLabReports(reportPatLapApp,providerMaster);
					labReportPojo.add(lrp);
				}
				labReportPojoList.setTotalNumber(reportPatLapAppdata.size());
				labReportPojoList.setLabReportPojo(labReportPojo);
			}
			response.setStatus(ResponseConstant.SUCCESS);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_SUCCESS));
			response.setData(labReportPojoList);
		} catch (Exception e) {
			logger.error("Error:--", e);
			response.setStatus(ResponseConstant.ERROR);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			response.setData(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Response>(response, HttpStatus.OK);
	}
	
	@RequestMapping(value = LABORATORYURLConstant.GET_LAB_REPORT_URL, method = RequestMethod.POST, headers = CommonConstants.CONTENT_TYPE_APPLICATION_JSON)
	public ResponseEntity<Response> ViewLabReport(Locale locale,@RequestBody ReportPatLapApp reportPatLapApps) {
		Response response = new Response();
		UserDetails userDetails = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		UserMaster userEntity = userService.findByUserName(userDetails.getUsername());
		try {
			LabReportPojo lrp=new LabReportPojo();
			ProviderMaster providerMaster=providerService.getProvider(userEntity.getUserEmail(),ProviderTypeStatus.LabUser);
			ReportPatLapApp reportPatLapApp=reportPatLapAppService.get(reportPatLapApps.getReportPatLapAppId());
			if(reportPatLapApp != null) {
				lrp=SetLabReports(reportPatLapApp,providerMaster);
			}
			response.setStatus(ResponseConstant.SUCCESS);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_SUCCESS));
			response.setData(lrp);
		} catch (Exception e) {
			logger.error("Error:--", e);
			response.setStatus(ResponseConstant.ERROR);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			response.setData(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Response>(response, HttpStatus.OK);
	}
	
	private LabReportPojo SetLabReportPojo(PatLabAppointments pla,ProviderMaster providerMaster) {
		LabReportPojo lrp=new LabReportPojo();
		ReportPatLapApp reportPatLapApp=reportPatLapAppService.findReport(pla.getPatLabAppointmentID());
		if(reportPatLapApp !=null) {
			if(reportPatLapApp.getPatLabAppointments() == null) {
				lrp.setPatLabAppointmentID(null);
				lrp.setPatVisitNoteID(null);
			}else {
				lrp.setPatLabAppointmentID(reportPatLapApp.getPatLabAppointments().getPatLabAppointmentID());
				if(reportPatLapApp.getPatLabAppointments().getPatVisitNote() == null) {
					lrp.setPatVisitNoteID(null);
				}else {
					lrp.setPatVisitNoteID(reportPatLapApp.getPatLabAppointments().getPatVisitNote().getPatVisitNoteID());
				}
			}
			lrp.setProviderID(providerMaster.getProviderID());
			lrp.setProviderName(CommonConstants.DR_SHORT+" "+providerMaster.getPersonMaster().getPerFname()+" "+providerMaster.getPersonMaster().getPerLName());
			lrp.setPatientMaster(reportPatLapApp.getPatientMaster().getPatientID());
			lrp.setPatientName(reportPatLapApp.getPatientMaster().getPersonID().getPerFname()+" "+reportPatLapApp.getPatientMaster().getPersonID().getPerLName());
			String dates=DateUtil.getLocalDateFormatted(reportPatLapApp.getCreatedOn(), DateUtil.dateTimeFormatterDDMMMYYYY);
			lrp.setDate(dates);
			String fromtime=DateUtil.getLocalDateFormatted(reportPatLapApp.getCreatedOn(), DateUtil.timeFormatterHHMMA);
			lrp.setTime(fromtime);
			lrp.setReportPatLapAppId(reportPatLapApp.getReportPatLapAppId());
			lrp.setAdditionalDetail(reportPatLapApp.getAdditionalDetail());
			lrp.setReportDetail(reportPatLapApp.getReportDetail());
			List<ReportLapApp> reportLapApp=reportLapReportPatLapService.findReport(reportPatLapApp.getReportPatLapAppId());
			Set<ReportLapPojo> reportLapdata = new HashSet<ReportLapPojo>(0);
			for(ReportLapApp rla:reportLapApp) {
				ReportLapPojo rlp=new ReportLapPojo();
				rlp.setReportLapAppId(rla.getReportLapAppId());
				rlp.setExtraDetail(rla.getExtraDetail());
				rlp.setReportPath(rla.getReportPath());
				Set<DiseasePojo> diagnosisMasterdata = new HashSet<DiseasePojo>(0);
				List<DiagnosisMaster> dms=reportLapReportPatLapService.findDisease(rlp.getReportLapAppId());
				LabReportsLevel1 ll=reportLapAppService.findAlllabreport(rlp.getReportLapAppId());
				for(DiagnosisMaster dm:dms) {
					DiseasePojo diseasePojo=new DiseasePojo();
					diseasePojo.setDiagnosisID(dm.getDiagnosisID());
					diseasePojo.setDiagnosiseName(dm.getDiagnosiseName());
					diagnosisMasterdata.add(diseasePojo);
				}
				LabReportsLevel1Pojo llp=new LabReportsLevel1Pojo();
				llp.setLabReportLevel1ID(ll.getLabReportLevel1ID());
				llp.setLrl1Name(ll.getLrl1Name());
				rlp.setLabReportsLevel1Pojo(llp);
				rlp.setDiagnosisMasterdata(diagnosisMasterdata);
			}
			lrp.setReportLapdata(reportLapdata);
		}
		return lrp;
	}
	
	@RequestMapping(value = LABORATORYURLConstant.LABREPORT_ADD_EDIT_LABUSER_URL, method = RequestMethod.POST, headers = CommonConstants.CONTENT_TYPE_APPLICATION_JSON)
	public ResponseEntity<Response> addOrEditLabReportByLabUser(Locale locale,@RequestBody ReportPatLapApp reportPatLapApp) {
		Response response = new Response();
		UserDetails userDetails = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		UserMaster userEntity = userService.findByUserName(userDetails.getUsername());
		String type = null;
		Boolean isEmpty = OperationsUtil.checkNull(reportPatLapApp);
		if (!isEmpty) {
			try {
				if (reportPatLapApp.getReportPatLapAppId() == null || reportPatLapApp.getReportPatLapAppId().equals(0L)) {
					type = LABORATORYURLConstant.ADD_TYPE;
					reportPatLapApp.setActive(true);
					reportPatLapApp.setCreatedOn(new Date());
					reportPatLapApp.setModifiedOn(new Date());
					reportPatLapApp.setCreatedBy(userEntity);
					reportPatLapApp.setModifiedBy(userEntity);
					reportPatLapApp.setDeleted(false);
				} else {
					reportPatLapApp.setActive(true);
					reportPatLapApp.setDeleted(false);
					reportPatLapApp.setModifiedBy(userEntity);
					reportPatLapApp.setModifiedOn(new Date());
					type = LABORATORYURLConstant.EDIT_TYPE;
				}
				if (reportPatLapApp.getReportPatLapAppId() == null || reportPatLapApp.getReportPatLapAppId().equals(0L)) {
					try {
						reportPatLapApp=reportPatLapAppService.saveOrUpdate(reportPatLapApp);
					}catch (Exception e) {
						logger.error("Error:--", e);
						response.setStatus(ResponseConstant.ERROR);
						response.setMessage(messageByLocaleService.getMessage(LABORATORYURLConstant.LAB_REPORT_ERROR));
						response.setData(messageByLocaleService.getMessage(LABORATORYURLConstant.LAB_REPORT_ERROR));
						return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
					}
					CommonPojo cp=new CommonPojo();
					cp.setReportPatLapAppId(reportPatLapApp.getReportPatLapAppId());
					response.setStatus(ResponseConstant.SUCCESS);
					response.setMessage(messageByLocaleService.getMessage(LABORATORYURLConstant.LAB_REPORT_SUCCESS));
					response.setData(cp);
				}else {
					ReportPatLapApp reportPatLapApps=reportPatLapAppService.get(reportPatLapApp.getReportPatLapAppId());
					reportPatLapApp.setModifiedOn(new Date());
					reportPatLapApp.setModifiedBy(userEntity);
					reportPatLapApp.setCreatedBy(reportPatLapApps.getCreatedBy());
					reportPatLapApp.setCreatedOn(reportPatLapApps.getCreatedOn());
					try {
						reportPatLapApp=reportPatLapAppService.saveOrUpdate(reportPatLapApp);
					}catch (Exception e) {
						logger.error("Error:--", e);
						response.setStatus(ResponseConstant.ERROR);
						response.setMessage(messageByLocaleService.getMessage(LABORATORYURLConstant.LAB_REPORT_ERROR));
						response.setData(messageByLocaleService.getMessage(LABORATORYURLConstant.LAB_REPORT_ERROR));
						return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
					}
					CommonPojo cp=new CommonPojo();
					cp.setReportPatLapAppId(reportPatLapApp.getReportPatLapAppId());
					response.setStatus(ResponseConstant.SUCCESS);
					response.setMessage(messageByLocaleService.getMessage(LABORATORYURLConstant.LAB_REPORT_UPDATE));
					response.setData(cp);
				}
				
			} catch (Exception e) {
				logger.error("Error:--", e);
				response.setStatus(ResponseConstant.ERROR);
				response.setMessage(messageByLocaleService.getMessage(LABORATORYURLConstant.LAB_REPORT_ERROR));
				response.setData(messageByLocaleService.getMessage(LABORATORYURLConstant.LAB_REPORT_ERROR));
				return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
			}
		} else {
			response.setStatus(ResponseConstant.ERROR);
			response.setMessage(messageByLocaleService.getMessage(LABORATORYURLConstant.LAB_REPORT_EXCEPTION));
			response.setData(messageByLocaleService.getMessage(LABORATORYURLConstant.LAB_REPORT_EXCEPTION));
			return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		if(type.equalsIgnoreCase(LABORATORYURLConstant.ADD_TYPE)) {
			return new ResponseEntity<Response>(response, HttpStatus.CREATED);
		}else {
			return new ResponseEntity<Response>(response, HttpStatus.OK);
		}
	}	
	
	@RequestMapping(value = LABORATORYURLConstant.LABREPORT_LABUSER_URL, method = RequestMethod.POST, headers = CommonConstants.CONTENT_TYPE_APPLICATION_JSON)
	public ResponseEntity<Response> getLabReportByLabUser(Locale locale,@RequestBody ReportPatLapApp reportPatLapApps) {
		Response response = new Response();
		try {
			LabReportPojo lrp=new LabReportPojo();
			ReportPatLapApp reportPatLapApp=reportPatLapAppService.get(reportPatLapApps.getReportPatLapAppId());
			if(reportPatLapApp != null) {
				lrp=SetLabReport(reportPatLapApp);
			}
			response.setStatus(ResponseConstant.SUCCESS);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_SUCCESS));
			response.setData(lrp);
		} catch (Exception e) {
			logger.error("Error:--", e);
			response.setStatus(ResponseConstant.ERROR);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			response.setData(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Response>(response, HttpStatus.OK);
	}
	
	private LabReportPojo SetLabReports(ReportPatLapApp reportPatLapApp,ProviderMaster providerMaster) {
		LabReportPojo lrp=new LabReportPojo();
		if(reportPatLapApp !=null) {
			if(reportPatLapApp.getPatLabAppointments() == null) {
				lrp.setPatLabAppointmentID(null);
				lrp.setPatVisitNoteID(null);
			}else {
				lrp.setPatLabAppointmentID(reportPatLapApp.getPatLabAppointments().getPatLabAppointmentID());
				if(reportPatLapApp.getPatLabAppointments().getPatVisitNote() == null) {
					lrp.setPatVisitNoteID(null);
				}else {
					lrp.setPatVisitNoteID(reportPatLapApp.getPatLabAppointments().getPatVisitNote().getPatVisitNoteID());
				}
			}
			lrp.setProviderID(providerMaster.getProviderID());
			lrp.setProviderName(CommonConstants.DR_SHORT+" "+providerMaster.getPersonMaster().getPerFname()+" "+providerMaster.getPersonMaster().getPerLName());
			lrp.setPatientMaster(reportPatLapApp.getPatientMaster().getPatientID());
			lrp.setPatientName(reportPatLapApp.getPatientMaster().getPersonID().getPerFname()+" "+reportPatLapApp.getPatientMaster().getPersonID().getPerLName());
			String dates=DateUtil.getLocalDateFormatted(reportPatLapApp.getCreatedOn(), DateUtil.dateTimeFormatterDDMMMYYYY);
			lrp.setDate(dates);
			String fromtime=DateUtil.getLocalDateFormatted(reportPatLapApp.getCreatedOn(), DateUtil.timeFormatterHHMMA);
			lrp.setTime(fromtime);
			lrp.setReportPatLapAppId(reportPatLapApp.getReportPatLapAppId());
			lrp.setAdditionalDetail(reportPatLapApp.getAdditionalDetail());
			lrp.setReportDetail(reportPatLapApp.getReportDetail());
			List<ReportLapApp> reportLapApp=reportLapReportPatLapService.findReport(reportPatLapApp.getReportPatLapAppId());
			Set<ReportLapPojo> reportLapdata = new HashSet<ReportLapPojo>(0);
			for(ReportLapApp rla:reportLapApp) {
				ReportLapPojo rlp=new ReportLapPojo();
				rlp.setReportLapAppId(rla.getReportLapAppId());
				rlp.setExtraDetail(rla.getExtraDetail());
				rlp.setReportPath(rla.getReportPath());
				Set<DiseasePojo> diagnosisMasterdata = new HashSet<DiseasePojo>(0);
				List<DiagnosisMaster> dms=reportLapReportPatLapService.findDisease(rlp.getReportLapAppId());
				LabReportsLevel1 ll=reportLapAppService.findAlllabreport(rlp.getReportLapAppId());
				for(DiagnosisMaster dm:dms) {
					DiseasePojo diseasePojo=new DiseasePojo();
					diseasePojo.setDiagnosisID(dm.getDiagnosisID());
					diseasePojo.setDiagnosiseName(dm.getDiagnosiseName());
					diagnosisMasterdata.add(diseasePojo);
				}
				LabReportsLevel1Pojo llp=new LabReportsLevel1Pojo();
				llp.setLabReportLevel1ID(ll.getLabReportLevel1ID());
				llp.setLrl1Name(ll.getLrl1Name());
				rlp.setLabReportsLevel1Pojo(llp);
				rlp.setDiagnosisMasterdata(diagnosisMasterdata);
				reportLapdata.add(rlp);
			}
			lrp.setReportLapdata(reportLapdata);
		}
		return lrp;
	}
	
	private LabReportPojo SetLabReport(ReportPatLapApp reportPatLapApp) {
		LabReportPojo lrp=new LabReportPojo();
		if(reportPatLapApp.getPatLabAppointments() == null) {
			lrp.setPatLabAppointmentID(null);
			lrp.setPatVisitNoteID(null);
		}else {
			lrp.setPatLabAppointmentID(reportPatLapApp.getPatLabAppointments().getPatLabAppointmentID());
			if(reportPatLapApp.getPatLabAppointments().getPatVisitNote() == null) {
				lrp.setPatVisitNoteID(null);
			}else {
				lrp.setPatVisitNoteID(reportPatLapApp.getPatLabAppointments().getPatVisitNote().getPatVisitNoteID());
			}
		}
		lrp.setPatientMaster(reportPatLapApp.getPatientMaster().getPatientID());
		lrp.setPatientName(reportPatLapApp.getPatientMaster().getPersonID().getPerFname()+" "+reportPatLapApp.getPatientMaster().getPersonID().getPerLName());
		lrp.setReportPatLapAppId(reportPatLapApp.getReportPatLapAppId());
		lrp.setAdditionalDetail(reportPatLapApp.getAdditionalDetail());
		lrp.setReportDetail(reportPatLapApp.getReportDetail());
		return lrp;
	}
	
	@RequestMapping(value = LABORATORYURLConstant.REPORT_ADD_EDIT_LABUSER_URL, method = RequestMethod.POST)
	public ResponseEntity<Response> addOrEditReportByLabUser(Locale locale,@RequestParam(value = "reportPath", required = true) MultipartFile reportPath,HttpServletRequest request) {
		Response response = new Response();
		UserDetails userDetails = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		UserMaster userEntity = userService.findByUserName(userDetails.getUsername());
		String type = null;
		ReportLapApp reportLapApp=new ReportLapApp();
		if(request.getParameter("reportLapAppId").equalsIgnoreCase("") || request.getParameter("reportLapAppId").equalsIgnoreCase("null") || request.getParameter("reportLapAppId") == null || request.getParameter("reportLapAppId").equalsIgnoreCase("0")) {
			reportLapApp=new ReportLapApp();
		}else {
			reportLapApp=reportLapAppService.get(Long.parseLong(request.getParameter("reportLapAppId")));
		}
		
		try {
			if (reportLapApp.getReportLapAppId() == null || reportLapApp.getReportLapAppId().equals(0L)) {
				type = LABORATORYURLConstant.ADD_TYPE;
				reportLapApp.setActive(true);
				reportLapApp.setCreatedOn(new Date());
				reportLapApp.setModifiedOn(new Date());
				reportLapApp.setCreatedBy(userEntity);
				reportLapApp.setModifiedBy(userEntity);
				reportLapApp.setDeleted(false);
			} else {
				reportLapApp.setActive(true);
				reportLapApp.setDeleted(false);
				reportLapApp.setModifiedBy(userEntity);
				reportLapApp.setModifiedOn(new Date());
				type = LABORATORYURLConstant.EDIT_TYPE;
			}
			Set<DiagnosisMaster> diagnosisMaster = new HashSet<DiagnosisMaster>(0);
			Set<String> dName = new HashSet<String>(0);
			if(request.getParameter("diagnosisMaster").length()>0) {
				String[] dmss = request.getParameter("diagnosisMaster").split(",");
				if(dmss != null && dmss.length > 0) {
					for(String dm:dmss) {
						DiagnosisMaster dms=diagnosisService.get(Long.parseLong(dm));
						dName.add(dms.getDiagnosiseName());
						diagnosisMaster.add(dms);
					}
				}else {
					String d = request.getParameter("diagnosisMaster");
					DiagnosisMaster dms=diagnosisService.get(Long.parseLong(d));
					dName.add(dms.getDiagnosiseName());
					diagnosisMaster.add(dms);
				}
			}
					
			LabReportsLevel1 labReportsLevel1=labReportsLevel1Service.get(Long.parseLong(request.getParameter("labReportLevel1ID")));
			ReportPatLapApp reportPatLapApp=reportPatLapAppService.get(Long.parseLong(request.getParameter("reportPatLapAppId")));
			if (reportLapApp.getReportLapAppId() == null || reportLapApp.getReportLapAppId().equals(0L)) {
				if (reportPath != null) {
					String fileName=OperationsUtil.uploadFile(reportPath,reportPatLapApp.getPatientMaster().getPersonID(),CommonConstants.REPORT);
					if(fileName == null) {
						response.setStatus(ResponseConstant.ERROR);
						response.setMessage(messageByLocaleService.getMessage(LABORATORYURLConstant.LAB_REPORT_ERROR));
						response.setData(messageByLocaleService.getMessage(LABORATORYURLConstant.LAB_REPORT_ERROR));
						return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
					}else {
						reportLapApp.setReportPath(fileName);
					}
				}else {
					reportLapApp.setReportPath(null);
				}
				reportLapApp.setLabReportLevel1ID(labReportsLevel1);
				reportLapApp.setExtraDetail(request.getParameter("extraDetail"));
				try {
					reportLapApp=reportLapAppService.saveOrUpdate(reportLapApp);
				}catch (Exception e) {
					logger.error("Error:--", e);
					response.setStatus(ResponseConstant.ERROR);
					response.setMessage(messageByLocaleService.getMessage(LABORATORYURLConstant.LAB_REPORT_ERROR));
					response.setData(messageByLocaleService.getMessage(LABORATORYURLConstant.LAB_REPORT_ERROR));
					return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
				}
				for(DiagnosisMaster dm:diagnosisMaster) {
					ReportLapReportPatLap rlrp=new ReportLapReportPatLap();
					rlrp.setActive(true);
					rlrp.setCreatedOn(new Date());
					rlrp.setModifiedOn(new Date());
					rlrp.setCreatedBy(userEntity);
					rlrp.setModifiedBy(userEntity);
					rlrp.setDeleted(false);
					rlrp.setDiagnosisMaster(dm);
					rlrp.setReportPatLapApp(reportPatLapApp);
					rlrp.setReportLapApp(reportLapApp);
					try {
						reportLapReportPatLapService.saveOrUpdate(rlrp);
					}catch (Exception e) {
						logger.error("Error:--", e);
						response.setStatus(ResponseConstant.ERROR);
						response.setMessage(messageByLocaleService.getMessage(LABORATORYURLConstant.LAB_REPORT_ERROR));
						response.setData(messageByLocaleService.getMessage(LABORATORYURLConstant.LAB_REPORT_ERROR));
						return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
					}
				}
				if(CommonConstants.getPropertiesValue("TYPE").equalsIgnoreCase(CommonConstants.HYPERLEDGER)) {
						JSONObject userEntityData = new JSONObject();
						userEntityData.put("reportID", reportLapApp.getReportLapAppId());
						userEntityData.put("patientID", reportPatLapApp.getPatientMaster().getPersonID().getUserMaster().getUserHyperledgerID());
						userEntityData.put("reportDetail",reportPatLapApp.getReportDetail());
						userEntityData.put("additionalDetail", reportPatLapApp.getAdditionalDetail());
						userEntityData.put("reportName", labReportsLevel1.getLrl1Name());
						userEntityData.put("attachReport", reportLapApp.getReportPath());
						userEntityData.put("extraDetail", reportLapApp.getExtraDetail());
						userEntityData.put("diseaseAssociated", dName.toString());
						try {
							String userEntityUpdated = (String) HyperledgerApiUtil.post(
									CommonConstants.getPropertiesValue("HYPERLEDGER_BASE_REPORT"),
									CommonConstants.getPropertiesValue("HYPERLEDGER_BASE_HOST"),
									userEntityData);
							if(userEntityUpdated.equalsIgnoreCase(CommonConstants.CODE)) {
								userEntity.setUserHyperledgerID(userEntity.getUserEmail());
							}else {
								JSONObject userEntityDatas = new JSONObject();
								userEntityDatas.put("patientID", reportPatLapApp.getPatientMaster().getPersonID().getUserMaster().getUserHyperledgerID());
								userEntityDatas.put("reportDetail",reportPatLapApp.getReportDetail());
								userEntityDatas.put("additionalDetail", reportPatLapApp.getAdditionalDetail());
								userEntityDatas.put("reportName", labReportsLevel1.getLrl1Name());
								userEntityDatas.put("attachReport", reportLapApp.getReportPath());
								userEntityDatas.put("extraDetail", reportLapApp.getExtraDetail());
								userEntityDatas.put("diseaseAssociated", dName.toString());
								String userEntityUpdateds = (String) HyperledgerApiUtil.put(
										CommonConstants.getPropertiesValue("HYPERLEDGER_BASE_REPORT")+"/"+reportLapApp.getReportLapAppId(),
										CommonConstants.getPropertiesValue("HYPERLEDGER_BASE_HOST"),
										userEntityDatas);
								if(userEntityUpdateds.equalsIgnoreCase(CommonConstants.CODE)) {
									userEntity.setUserHyperledgerID(userEntity.getUserEmail());
								}else {
									userEntity.setUserHyperledgerID(null);
								}
							}
						}catch (Exception e) {
							logger.error("Error:--", e);
						}
				}else {
						JSONObject patVisitEntity = new JSONObject();
						patVisitEntity.put("reportName", labReportsLevel1.getLrl1Name());
						patVisitEntity.put("reportPath",reportLapApp.getReportPath());
						patVisitEntity.put("extraDetail", reportLapApp.getExtraDetail());
						patVisitEntity.put("diseaseAssociated", dName.toString());
						patVisitEntity.put("patientId",reportPatLapApp.getPatientMaster().getPersonID().getUserMaster().getUserTransectionID());
						try {
							JSONObject patVisitUpdated = (JSONObject) ApiUtil.post(
									CommonConstants.getPropertiesValue("BLOCKCHAIN_BASE_REPORT"),
									CommonConstants.getPropertiesValue("BLOCKCHAIN_POST_METHOD"),
									patVisitEntity);
							
							String transectionId = patVisitUpdated.getString("transactionId").toString();
							reportLapApp.setActive(true);
							reportLapApp.setDeleted(false);
							reportLapApp.setModifiedBy(userEntity);
							reportLapApp.setModifiedOn(new Date());
							reportLapApp.setPatTransectionID(transectionId);
							reportLapApp=reportLapAppService.saveOrUpdate(reportLapApp);
						}catch (Exception e) {
							logger.error("Error:--", e);
						}
				}
				List<ReportLapApp> reportLap=reportLapReportPatLapService.findReport(reportPatLapApp.getReportPatLapAppId());
				ReportLapPojo rlp=new ReportLapPojo();
				for(ReportLapApp rla:reportLap) {
					rlp.setReportLapAppId(rla.getReportLapAppId());
					rlp.setExtraDetail(rla.getExtraDetail());
					rlp.setReportPath(rla.getReportPath());
					Set<DiseasePojo> diagnosisMasterdata = new HashSet<DiseasePojo>(0);
					List<DiagnosisMaster> dms=reportLapReportPatLapService.findDisease(rlp.getReportLapAppId());
					LabReportsLevel1 ll=reportLapAppService.findAlllabreport(rlp.getReportLapAppId());
					for(DiagnosisMaster dm:dms) {
						DiseasePojo diseasePojo=new DiseasePojo();
						diseasePojo.setDiagnosisID(dm.getDiagnosisID());
						diseasePojo.setDiagnosiseName(dm.getDiagnosiseName());
						diagnosisMasterdata.add(diseasePojo);
					}
					LabReportsLevel1Pojo llp=new LabReportsLevel1Pojo();
					llp.setLabReportLevel1ID(ll.getLabReportLevel1ID());
					llp.setLrl1Name(ll.getLrl1Name());
					rlp.setLabReportsLevel1Pojo(llp);
					rlp.setDiagnosisMasterdata(diagnosisMasterdata);
				}
				response.setStatus(ResponseConstant.SUCCESS);
				response.setMessage(messageByLocaleService.getMessage(LABORATORYURLConstant.LAB_REPORT_SUCCESS));
				response.setData(rlp);
			}else {
				ReportLapApp reportLapApps=new ReportLapApp();
				reportLapApps.setReportLapAppId(reportLapApp.getReportLapAppId());
				reportLapApps.setCreatedBy(reportLapApp.getCreatedBy());
				reportLapApps.setCreatedOn(reportLapApp.getCreatedOn());
				if (!reportPath.isEmpty()) {
					if(OperationsUtil.uploadFile(reportPath,reportPatLapApp.getPatientMaster().getPersonID(),CommonConstants.REPORT) == null) {
						response.setStatus(ResponseConstant.ERROR);
						response.setMessage(messageByLocaleService.getMessage(LABORATORYURLConstant.LAB_REPORT_ERROR));
						response.setData(messageByLocaleService.getMessage(LABORATORYURLConstant.LAB_REPORT_ERROR));
						return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
					}else {
						reportLapApps.setReportPath(OperationsUtil.uploadFile(reportPath,reportPatLapApp.getPatientMaster().getPersonID(),CommonConstants.REPORT));
					}
				}else {
					reportLapApps.setReportPath(reportLapApp.getReportPath());
				}
				reportLapApp.setLabReportLevel1ID(labReportsLevel1);
				reportLapApps.setExtraDetail(request.getParameter("extraDetail"));
				try {
					reportLapApp=reportLapAppService.saveOrUpdate(reportLapApp);
				}catch (Exception e) {
					logger.error("Error:--", e);
					response.setStatus(ResponseConstant.ERROR);
					response.setMessage(messageByLocaleService.getMessage(LABORATORYURLConstant.LAB_REPORT_ERROR));
					response.setData(messageByLocaleService.getMessage(LABORATORYURLConstant.LAB_REPORT_ERROR));
					return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
				}
				List<ReportLapReportPatLap> reportLapReportPatLap=reportLapReportPatLapService.findData(reportLapApp.getReportLapAppId());
				for(ReportLapReportPatLap rlrp:reportLapReportPatLap) {
					rlrp.setActive(false);
					rlrp.setModifiedOn(new Date());
					rlrp.setModifiedBy(userEntity);
					rlrp.setDeleted(true);
					try {
						reportLapReportPatLapService.saveOrUpdate(rlrp);
					}catch (Exception e) {
						logger.error("Error:--", e);
						response.setStatus(ResponseConstant.ERROR);
						response.setMessage(messageByLocaleService.getMessage(LABORATORYURLConstant.LAB_REPORT_ERROR));
						response.setData(messageByLocaleService.getMessage(LABORATORYURLConstant.LAB_REPORT_ERROR));
						return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
					}
				}
				
				
				for(DiagnosisMaster dm:diagnosisMaster) {
					ReportLapReportPatLap reportLapReportPatLaps=reportLapReportPatLapService.findAllPerameterData(reportLapApp.getReportLapAppId(),dm.getDiagnosisID());
					if(reportLapReportPatLaps == null) {
						ReportLapReportPatLap rlrp=new ReportLapReportPatLap();
						rlrp.setActive(true);
						rlrp.setCreatedOn(new Date());
						rlrp.setModifiedOn(new Date());
						rlrp.setCreatedBy(userEntity);
						rlrp.setModifiedBy(userEntity);
						rlrp.setDeleted(false);
						rlrp.setDiagnosisMaster(dm);
						rlrp.setReportPatLapApp(reportPatLapApp);
						rlrp.setReportLapApp(reportLapApp);
						try {
							reportLapReportPatLapService.saveOrUpdate(rlrp);
						}catch (Exception e) {
							logger.error("Error:--", e);
							response.setStatus(ResponseConstant.ERROR);
							response.setMessage(messageByLocaleService.getMessage(LABORATORYURLConstant.LAB_REPORT_ERROR));
							response.setData(messageByLocaleService.getMessage(LABORATORYURLConstant.LAB_REPORT_ERROR));
							return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
						}
					}else {
						reportLapReportPatLaps.setModifiedBy(userEntity);
						reportLapReportPatLaps.setModifiedOn(new Date());
						try {
							reportLapReportPatLapService.saveOrUpdate(reportLapReportPatLaps);
						}catch (Exception e) {
							logger.error("Error:--", e);
							response.setStatus(ResponseConstant.ERROR);
							response.setMessage(messageByLocaleService.getMessage(LABORATORYURLConstant.LAB_REPORT_ERROR));
							response.setData(messageByLocaleService.getMessage(LABORATORYURLConstant.LAB_REPORT_ERROR));
							return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
						}
					}
					
				}
				if(CommonConstants.getPropertiesValue("TYPE").equalsIgnoreCase(CommonConstants.HYPERLEDGER)) {
					JSONObject userEntityData = new JSONObject();
					userEntityData.put("reportID", reportLapApp.getReportLapAppId());
					userEntityData.put("patientID", reportPatLapApp.getPatientMaster().getPersonID().getUserMaster().getUserHyperledgerID());
					userEntityData.put("reportDetail",reportPatLapApp.getReportDetail());
					userEntityData.put("additionalDetail", reportPatLapApp.getAdditionalDetail());
					userEntityData.put("reportName", labReportsLevel1.getLrl1Name());
					userEntityData.put("attachReport", reportLapApp.getReportPath());
					userEntityData.put("extraDetail", reportLapApp.getExtraDetail());
					userEntityData.put("diseaseAssociated", dName.toString());
					try {
						String userEntityUpdated = (String) HyperledgerApiUtil.post(
								CommonConstants.getPropertiesValue("HYPERLEDGER_BASE_REPORT"),
								CommonConstants.getPropertiesValue("HYPERLEDGER_BASE_HOST"),
								userEntityData);
						if(userEntityUpdated.equalsIgnoreCase(CommonConstants.CODE)) {
							userEntity.setUserHyperledgerID(userEntity.getUserEmail());
						}else {
							JSONObject userEntityDatas = new JSONObject();
							userEntityDatas.put("patientID", reportPatLapApp.getPatientMaster().getPersonID().getUserMaster().getUserHyperledgerID());
							userEntityDatas.put("reportDetail",reportPatLapApp.getReportDetail());
							userEntityDatas.put("additionalDetail", reportPatLapApp.getAdditionalDetail());
							userEntityDatas.put("reportName", labReportsLevel1.getLrl1Name());
							userEntityDatas.put("attachReport", reportLapApp.getReportPath());
							userEntityDatas.put("extraDetail", reportLapApp.getExtraDetail());
							userEntityDatas.put("diseaseAssociated", dName.toString());
							String userEntityUpdateds = (String) HyperledgerApiUtil.put(
									CommonConstants.getPropertiesValue("HYPERLEDGER_BASE_REPORT")+"/"+reportLapApp.getReportLapAppId(),
									CommonConstants.getPropertiesValue("HYPERLEDGER_BASE_HOST"),
									userEntityDatas);
							if(userEntityUpdateds.equalsIgnoreCase(CommonConstants.CODE)) {
								userEntity.setUserHyperledgerID(userEntity.getUserEmail());
							}else {
								userEntity.setUserHyperledgerID(null);
							}
						}
					}catch (Exception e) {
						logger.error("Error:--", e);
					}
			}else {
					JSONObject patVisitEntity = new JSONObject();
					patVisitEntity.put("reportName", labReportsLevel1.getLrl1Name());
					patVisitEntity.put("reportPath",reportLapApp.getReportPath());
					patVisitEntity.put("extraDetail", reportLapApp.getExtraDetail());
					patVisitEntity.put("diseaseAssociated", dName.toString());
					patVisitEntity.put("patientId",reportPatLapApp.getPatientMaster().getPersonID().getUserMaster().getUserTransectionID());
					try {
						JSONObject patVisitUpdated = (JSONObject) ApiUtil.post(
								CommonConstants.getPropertiesValue("BLOCKCHAIN_BASE_REPORT"),
								CommonConstants.getPropertiesValue("BLOCKCHAIN_POST_METHOD"),
								patVisitEntity);
						
						String transectionId = patVisitUpdated.getString("transactionId").toString();
						reportLapApp.setActive(true);
						reportLapApp.setDeleted(false);
						reportLapApp.setModifiedBy(userEntity);
						reportLapApp.setModifiedOn(new Date());
						reportLapApp.setPatTransectionID(transectionId);
						reportLapApp=reportLapAppService.saveOrUpdate(reportLapApp);
					}catch (Exception e) {
						logger.error("Error:--", e);
					}
			}
				List<ReportLapApp> reportLap=reportLapReportPatLapService.findReport(reportPatLapApp.getReportPatLapAppId());
				ReportLapPojo rlp=new ReportLapPojo();
				for(ReportLapApp rla:reportLap) {
					rlp.setReportLapAppId(rla.getReportLapAppId());
					rlp.setExtraDetail(rla.getExtraDetail());
					rlp.setReportPath(rla.getReportPath());
					Set<DiseasePojo> diagnosisMasterdata = new HashSet<DiseasePojo>(0);
					List<DiagnosisMaster> dms=reportLapReportPatLapService.findDisease(rlp.getReportLapAppId());
					LabReportsLevel1 ll=reportLapAppService.findAlllabreport(rlp.getReportLapAppId());
					for(DiagnosisMaster dm:dms) {
						DiseasePojo diseasePojo=new DiseasePojo();
						diseasePojo.setDiagnosisID(dm.getDiagnosisID());
						diseasePojo.setDiagnosiseName(dm.getDiagnosiseName());
						diagnosisMasterdata.add(diseasePojo);
					}
					LabReportsLevel1Pojo llp=new LabReportsLevel1Pojo();
					llp.setLabReportLevel1ID(ll.getLabReportLevel1ID());
					llp.setLrl1Name(ll.getLrl1Name());
					rlp.setLabReportsLevel1Pojo(llp);
					rlp.setDiagnosisMasterdata(diagnosisMasterdata);
				}
				response.setStatus(ResponseConstant.SUCCESS);
				response.setMessage(messageByLocaleService.getMessage(LABORATORYURLConstant.LAB_REPORT_UPDATE));
				response.setData(rlp);
			}
				
		} catch (Exception e) {
			logger.error("Error:--", e);
			response.setStatus(ResponseConstant.ERROR);
			response.setMessage(messageByLocaleService.getMessage(LABORATORYURLConstant.LAB_REPORT_ERROR));
			response.setData(messageByLocaleService.getMessage(LABORATORYURLConstant.LAB_REPORT_ERROR));
			return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		if(type.equalsIgnoreCase(LABORATORYURLConstant.ADD_TYPE)) {
			return new ResponseEntity<Response>(response, HttpStatus.CREATED);
		}else {
			return new ResponseEntity<Response>(response, HttpStatus.OK);
		}
	}	
	
	@RequestMapping(value = LABORATORYURLConstant.REPORT_LABUSER_URL, method = RequestMethod.POST, headers = CommonConstants.CONTENT_TYPE_APPLICATION_JSON)
	public ResponseEntity<Response> getReportByLabUser(Locale locale,@RequestBody ReportPatLapApp reportPatLapApps) {
		Response response = new Response();
		try {
			LabReportPojo lrp=new LabReportPojo();
			ReportPatLapApp reportPatLapApp=reportPatLapAppService.get(reportPatLapApps.getReportPatLapAppId());
			if(reportPatLapApp.getPatLabAppointments() == null) {
				lrp.setPatLabAppointmentID(null);
				lrp.setPatVisitNoteID(null);
			}else {
				lrp.setPatLabAppointmentID(reportPatLapApp.getPatLabAppointments().getPatLabAppointmentID());
				if(reportPatLapApp.getPatLabAppointments().getPatVisitNote() == null) {
					lrp.setPatVisitNoteID(null);
				}else {
					lrp.setPatVisitNoteID(reportPatLapApp.getPatLabAppointments().getPatVisitNote().getPatVisitNoteID());
				}
			}
			lrp.setPatientMaster(reportPatLapApp.getPatientMaster().getPatientID());
			lrp.setPatientName(reportPatLapApp.getPatientMaster().getPersonID().getPerFname()+" "+reportPatLapApp.getPatientMaster().getPersonID().getPerLName());
			String dates=DateUtil.getLocalDateFormatted(reportPatLapApp.getCreatedOn(), DateUtil.dateTimeFormatterDDMMMYYYY);
			lrp.setDate(dates);
			String fromtime=DateUtil.getLocalDateFormatted(reportPatLapApp.getCreatedOn(), DateUtil.timeFormatterHHMMA);
			lrp.setTime(fromtime);
			lrp.setReportPatLapAppId(reportPatLapApp.getReportPatLapAppId());
			lrp.setAdditionalDetail(reportPatLapApp.getAdditionalDetail());
			lrp.setReportDetail(reportPatLapApp.getReportDetail());
			List<ReportLapReportPatLap> reportLapReportPatLap=reportLapReportPatLapService.findData(reportPatLapApps.getReportPatLapAppId());
			Set<ReportLapApp> reportLapApp = new HashSet<ReportLapApp>(0);
			for(ReportLapReportPatLap rlrp:reportLapReportPatLap) {
				reportLapApp.add(rlrp.getReportLapApp());
			}
			Set<ReportLapPojo> reportLapdata = new HashSet<ReportLapPojo>(0);
			for(ReportLapApp rla:reportLapApp) {
				ReportLapPojo rlp=new ReportLapPojo();
				rlp.setReportLapAppId(rla.getReportLapAppId());
				rlp.setExtraDetail(rla.getExtraDetail());
				rlp.setReportPath(rla.getReportPath());
				Set<DiseasePojo> diagnosisMasterdata = new HashSet<DiseasePojo>(0);
				List<DiagnosisMaster> dms=reportLapReportPatLapService.findDisease(rla.getReportLapAppId());
				LabReportsLevel1 ll=reportLapAppService.findAlllabreport(rla.getReportLapAppId());
				for(DiagnosisMaster dm:dms) {
					DiseasePojo diseasePojo=new DiseasePojo();
					diseasePojo.setDiagnosisID(dm.getDiagnosisID());
					diseasePojo.setDiagnosiseName(dm.getDiagnosiseName());
					diagnosisMasterdata.add(diseasePojo);
				}
				LabReportsLevel1Pojo llp=new LabReportsLevel1Pojo();
				llp.setLabReportLevel1ID(ll.getLabReportLevel1ID());
				llp.setLrl1Name(ll.getLrl1Name());
				rlp.setLabReportsLevel1Pojo(llp);
				rlp.setDiagnosisMasterdata(diagnosisMasterdata);
				reportLapdata.add(rlp);
			}
			lrp.setReportLapdata(reportLapdata);
			response.setStatus(ResponseConstant.SUCCESS);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_SUCCESS));
			response.setData(lrp);
		} catch (Exception e) {
			logger.error("Error:--", e);
			response.setStatus(ResponseConstant.ERROR);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			response.setData(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Response>(response, HttpStatus.OK);
	}
		
}
