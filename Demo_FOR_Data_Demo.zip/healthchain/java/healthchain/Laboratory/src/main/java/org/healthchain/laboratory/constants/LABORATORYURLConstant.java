package org.healthchain.laboratory.constants;

public class LABORATORYURLConstant {
	
	public static final String GET_IMAGES_URL="/getImages";
	public static final String LAB_ROOT_URL="/laboratory";
	public static final String LAB_PROFILE_ROOT_URL="/labProfile";
	public static final String LAB_IMAGE_ROOT_URL="/image";
	
	public static final String PROFILE_PROFESSIONAL_URL="/professional";
	public static final String PROFILE_PROFESSIONAL_GETDATA_URL="/getProfessionalData";
	public static final String PROFILE_PROFESSIONAL_LOCATION_GETDATA_URLL="/getProfessionalByLocation";
	public static final String PROFILE_DEMOGRAPHIC_URL="/demographic";
	public static final String PROFILE_DEMOGRAPHIC_GETDATA_URL="/getDemographicData";
	public static final String PROFILE_LABORATORY_GETDATA_URL="/getLaboratoryData";
	public static final String PROFILE_LABORATORY_URL="/laboratory";
	public static final String PROFILE_LABORATORY_ANGULAR_URL="/laboratoryAngular";
	
	public static final String LABREPORT_ADD_EDIT_LABUSER_URL="/addOrEditLabReportByLabUser";
	public static final String LABREPORT_LABUSER_URL="/getLabReportByLabUser";
	
	public static final String ALL_LABREPORT_LABUSER_URL="/getAllLabReportWithoutBook";
	
	public static final String REPORT_ADD_EDIT_LABUSER_URL="/addOrEditReportByLabUser";
	public static final String REPORT_LABUSER_URL="/getReportByLabUser";
	
	public static final String LABREPORT_GET_URL="/getLabReport";
	
	public static final String GET_LAB_REPORT_LIST_URL="/getAllLabReport";
	public static final String GET_LAB_REPORT_URL="/ViewLabReport";
	
	public static final String GET_LAB_URL="/getAllLab";
	public static final String VIEW_AND_EDIT_LAB_URL="/viewAndEditLab";
	
	public static final String LAB_SUCCESS="lab.success";
	public static final String LAB_UPDATE="lab.update";
	public static final String LAB_ERROR="lab.error";
	public static final String LAB_UPDATE_ERROR="lab.update.error";
	public static final String LAB_EXCEPTION="lab.exception";
	
	public static final String PROFESSIONAL_SUCCESS="professional.success";
	public static final String PROFESSIONAL_UPDATE="professional.update";
	public static final String PROFESSIONAL_ERROR="professional.error";
	public static final String PROFESSIONAL_UPDATE_ERROR="professional.update.error";
	public static final String PROFESSIONAL_EXCEPTION="professional.exception";
	
	public static final String LABORATORY_SUCCESS="laboratory.success";
	public static final String LABORATORY_UPDATE="laboratory.update";
	public static final String LABORATORY_ERROR="laboratory.error";
	public static final String LABORATORY_UPDATE_ERROR="laboratory.update.error";
	public static final String LABORATORY_EXCEPTION="laboratory.exception";
	
	public static final String DEMOGRAPHIC_SUCCESS="demographic.success";
	public static final String DEMOGRAPHIC_UPDATE="demographic.update";
	public static final String DEMOGRAPHIC_ERROR="demographic.error";
	public static final String DEMOGRAPHIC_UPDATE_ERROR="demographic.update.error";
	public static final String DEMOGRAPHIC_EXCEPTION="demographic.exception";
	
	public static final String LAB_REPORT_SUCCESS="labreport.success";
	public static final String LAB_REPORT_UPDATE="labreport.update";
	public static final String LAB_REPORT_ERROR="labreport.error";
	public static final String LAB_REPORT_UPDATE_ERROR="labreport.update.error";
	public static final String LAB_REPORT_EXCEPTION="labreport.exception";
	
	public static final String ADD_TYPE="Add";
	public static final String EDIT_TYPE="Update";
	
	
}
