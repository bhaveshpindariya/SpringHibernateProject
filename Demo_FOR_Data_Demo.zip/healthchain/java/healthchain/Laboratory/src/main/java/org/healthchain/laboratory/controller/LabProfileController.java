package org.healthchain.laboratory.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.healthchain.common.constants.CommonConstants;
import org.healthchain.common.constants.ResponseConstant;
import org.healthchain.common.utils.OperationsUtil;
import org.healthchain.entity.DrugCompoundMaster;
import org.healthchain.entity.FCLProviderLabDoctorMap;
import org.healthchain.entity.FCLProviderLabDrugCompoundMap;
import org.healthchain.entity.FCLProviderMap;
import org.healthchain.entity.FCLProviderReportMap;
import org.healthchain.entity.FCLocationMap;
import org.healthchain.entity.FacilityCenterMaster;
import org.healthchain.entity.LabReportsLevel1;
import org.healthchain.entity.LocationMaster;
import org.healthchain.entity.PatLabAppointments;
import org.healthchain.entity.PersonMaster;
import org.healthchain.entity.ProviderMaster;
import org.healthchain.entity.SuggestReport;
import org.healthchain.entity.TimeZoneMaster;
import org.healthchain.entity.UserMaster;
import org.healthchain.entity.enums.ProviderTypeStatus;
import org.healthchain.laboratory.constants.LABORATORYURLConstant;
import org.healthchain.pojo.DrugCompoundPojo;
import org.healthchain.pojo.LabDemographicPojo;
import org.healthchain.pojo.LabReportsLevel1Pojo;
import org.healthchain.pojo.LaboratoryPojo;
import org.healthchain.pojo.LocationPojo;
import org.healthchain.pojo.PatLabAppointmentsPojo;
import org.healthchain.pojo.PatLabAppointmentsPojoList;
import org.healthchain.pojo.ProfessionalPojo;
import org.healthchain.pojo.ProviderPojo;
import org.healthchain.pojo.Response;
import org.healthchain.pojo.TimeZonePojo;
import org.healthchain.services.FCLProviderLabDoctorMapService;
import org.healthchain.services.FCLProviderLabDrugCompoundMapService;
import org.healthchain.services.FCLProviderReportMapService;
import org.healthchain.services.FCLProviderService;
import org.healthchain.services.FCLocationMapService;
import org.healthchain.services.FacilityCenterService;
import org.healthchain.services.LocationService;
import org.healthchain.services.MessageByLocaleService;
import org.healthchain.services.PatLabAppointmentService;
import org.healthchain.services.PersonService;
import org.healthchain.services.ProviderService;
import org.healthchain.services.SuggestReportService;
import org.healthchain.services.TimeZoneService;
import org.healthchain.services.UserService;
import org.healthchain.services.constants.ServiceConstant;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

@CrossOrigin
@RestController
@RequestMapping(LABORATORYURLConstant.LAB_PROFILE_ROOT_URL)
public class LabProfileController {

	private static final Log logger = LogFactory.getLog(LabProfileController.class);
	
	@Autowired
	private ProviderService providerService;

	@Autowired
	private UserService userService;
	
	@Autowired
	private TimeZoneService timeZoneService;
	
	@Autowired
	private PersonService personService;
	
	@Autowired
	private LocationService locationService;
	
	@Autowired
	private FCLProviderReportMapService fclProviderReportMapService;
	
	@Autowired
    private FCLProviderService fclProviderService;
	
	@Autowired
	private FCLocationMapService fcLocationMapService;
	
	@Autowired
    private PatLabAppointmentService patLabAppointmentService;
	
	@Autowired
    private SuggestReportService suggestReportService;
	
	@Autowired
	private FacilityCenterService facilityCenterService;
	
	@Autowired
	private FCLProviderLabDoctorMapService fcLProviderLabDoctorMapService;
	
	@Autowired
	private FCLProviderLabDrugCompoundMapService fcLProviderLabDrugCompoundMapService;

	@Autowired
	private MessageByLocaleService messageByLocaleService;
	
	@RequestMapping(value = LABORATORYURLConstant.PROFILE_LABORATORY_GETDATA_URL, method = RequestMethod.POST, headers = CommonConstants.CONTENT_TYPE_APPLICATION_JSON)
	public ResponseEntity<Response> getLaboratoryData(Locale locale,HttpServletRequest request) {
		Response response = new Response();
		UserDetails userDetails = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		UserMaster userEntity = userService.findByUserName(userDetails.getUsername());
		try {
			LaboratoryPojo laboratoryPojo=new LaboratoryPojo();
			PersonMaster person = personService.findByPerEmailPrimary(userEntity.getUserEmail());
			ProviderMaster providerMaster=providerService.getProvider(userEntity.getUserEmail(),ProviderTypeStatus.LabUser);
			List<FCLProviderMap> fclProviderMap=fclProviderService.getFclDataforDoctor(providerMaster.getProviderID(),providerMaster.getProviderTypeStatus());
			List<String> mlist = person.getPerEmailList();
			List<Map<String, String>> providerMapList = new ArrayList<Map<String, String>>(0);
			for (int i=0;i<mlist.size();i++) {
				Map<String, String> providerMap = new HashMap<String, String>(0);
				providerMap.put("value", mlist.get(i));
				providerMapList.add(providerMap);
			}
			laboratoryPojo.setPerFname(person.getPerFname());
			laboratoryPojo.setPerLName(person.getPerLName());
			laboratoryPojo.setUserName(person.getUserMaster().getUserName());
			laboratoryPojo.setPersonID(person.getPersonID());
			laboratoryPojo.setPerEmailList(providerMapList);
			laboratoryPojo.setPerEmailPrimary(person.getPerEmailPrimary());
			laboratoryPojo.setPerProfile(request.getScheme() + "://" + request.getServerName() + ":"
					+ request.getServerPort() + request.getContextPath() + LABORATORYURLConstant.LAB_IMAGE_ROOT_URL + LABORATORYURLConstant.GET_IMAGES_URL
					+ "?filepath=" +  person.getPerProfile());
			if(laboratoryPojo.getPerProfile().equalsIgnoreCase("/getImages?filepath=null")) {
				laboratoryPojo.setPerProfile(null);
			}
			laboratoryPojo.setFacilityCenterID(fclProviderMap.get(0).getLocationMapID().getFacilityCenterMaster().getFacilityCenterID());
			laboratoryPojo.setFacilityCenterName(fclProviderMap.get(0).getLocationMapID().getFacilityCenterMaster().getFacilityCenterName());
			laboratoryPojo.setAdditionalInformation(fclProviderMap.get(0).getLocationMapID().getFacilityCenterMaster().getAdditionalInformation());
			response.setStatus(ResponseConstant.SUCCESS);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_SUCCESS));
			response.setData(laboratoryPojo);
		} catch (Exception e) {
			logger.error("Error:--", e);
			response.setStatus(ResponseConstant.ERROR);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			response.setData(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Response>(response, HttpStatus.OK);
	}
	
	@RequestMapping(value = LABORATORYURLConstant.PROFILE_LABORATORY_URL, method = RequestMethod.POST)
	public ResponseEntity<Response> laboratory(Locale locale, @RequestParam(value = "perProfile", required = false) MultipartFile files,HttpServletRequest request) {
		Response response = new Response();
		UserDetails userDetails = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		UserMaster userEntity = userService.findByUserName(userDetails.getUsername());
		try {
			
			PersonMaster person = personService.get(Long.parseLong(request.getParameter("personID")));
			personService.deletePersonEmailList(person.getPersonID());
			person.setPerFname(request.getParameter("perFname"));
			person.setPerLName(request.getParameter("perLName"));
			person.setPerEmailPrimary(request.getParameter("perEmailPrimary"));
			if(request.getParameter("perEmailList").length()>0) {
				String[] perEmailList = request.getParameter("perEmailList").split(",");
				if(perEmailList != null && perEmailList.length > 0) {
					List<String> list = new ArrayList<String>(0); 
					for(String s:perEmailList) {
						list.add(s);
					}
					person.getPerEmailList().addAll(list);
				}else {
					String perEmailLists = request.getParameter("perEmailList");
					List<String> list = new ArrayList<String>(0); 
					list.add(perEmailLists);
					person.getPerEmailList().addAll(list);
				}
			}
			person.setActive(true);
			person.setModifiedBy(userEntity);
			person.setModifiedOn(new Date());
			person.setDeleted(false);
			if (!files.isEmpty()) {
				String fileName=OperationsUtil.uploadFile(files,person,CommonConstants.PROFILE);
				if(fileName == null) {
					response.setStatus(ResponseConstant.ERROR);
					response.setMessage(messageByLocaleService.getMessage(LABORATORYURLConstant.LABORATORY_ERROR));
					response.setData(messageByLocaleService.getMessage(LABORATORYURLConstant.LABORATORY_ERROR));
					return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
				}else {
					person.setPerProfile(fileName);
				}
			}else {
				person.setPerProfile(person.getPerProfile());
			}
			
			try {
				person=personService.saveOrUpdate(person);
			}catch (Exception e) {
				logger.error("Error:--", e);
				response.setStatus(ResponseConstant.ERROR);
				response.setMessage(messageByLocaleService.getMessage(LABORATORYURLConstant.LABORATORY_ERROR));
				response.setData(messageByLocaleService.getMessage(LABORATORYURLConstant.LABORATORY_ERROR));
				return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
			}
			
			FacilityCenterMaster facilityCenterMaster=facilityCenterService.get(Long.parseLong(request.getParameter("facilityCenterID")));
			facilityCenterMaster.setAdditionalInformation(request.getParameter("additionalInformation"));
			facilityCenterMaster.setActive(true);
			facilityCenterMaster.setModifiedBy(userEntity);
			facilityCenterMaster.setModifiedOn(new Date());
			facilityCenterMaster.setDeleted(false);
			try {
				facilityCenterService.saveOrUpdate(facilityCenterMaster);
			}catch (Exception e) {
				logger.error("Error:--", e);
				response.setStatus(ResponseConstant.ERROR);
				response.setMessage(messageByLocaleService.getMessage(LABORATORYURLConstant.LABORATORY_ERROR));
				response.setData(messageByLocaleService.getMessage(LABORATORYURLConstant.LABORATORY_ERROR));
				return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
			}
			response.setStatus(ResponseConstant.SUCCESS);
			response.setMessage(messageByLocaleService.getMessage(LABORATORYURLConstant.LABORATORY_UPDATE));
			response.setData(messageByLocaleService.getMessage(LABORATORYURLConstant.LABORATORY_UPDATE));
		} catch (Exception e) {
			logger.error("Error:--", e);
			response.setStatus(ResponseConstant.ERROR);
			response.setMessage(messageByLocaleService.getMessage(LABORATORYURLConstant.LABORATORY_ERROR));
			response.setData(messageByLocaleService.getMessage(LABORATORYURLConstant.LABORATORY_ERROR));
			return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Response>(response, HttpStatus.OK);
	}
	
	@RequestMapping(value = LABORATORYURLConstant.PROFILE_DEMOGRAPHIC_GETDATA_URL, method = RequestMethod.POST, headers = CommonConstants.CONTENT_TYPE_APPLICATION_JSON)
	public ResponseEntity<Response> getDemographicData(Locale locale) {
		Response response = new Response();
		UserDetails userDetails = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		UserMaster userEntity = userService.findByUserName(userDetails.getUsername());
		try {
			PersonMaster person = personService.findByPerEmailPrimary(userEntity.getUserEmail());
			ProviderMaster providerMaster=providerService.getProvider(userEntity.getUserEmail(),ProviderTypeStatus.LabUser);
			List<FCLProviderMap> fclProviderMap=fclProviderService.getFclDataforDoctor(providerMaster.getProviderID(),providerMaster.getProviderTypeStatus());
			LabDemographicPojo demographicPojo = new LabDemographicPojo();
			List<String> mlist = person.getPerMobileList(); 
			List<Map<String, String>> providerMapList = new ArrayList<Map<String, String>>(0);
			for (int i=0;i<mlist.size();i++) {
				Map<String, String> providerMap = new HashMap<String, String>(0);
				providerMap.put("value", mlist.get(i));
				providerMapList.add(providerMap);
			}
			demographicPojo.setPerMobileList(providerMapList);
			demographicPojo.setPersonID(person.getPersonID());
			demographicPojo.setPerMobilePrimary(person.getPerMobilePrimary());
			demographicPojo.setFacilityCenterID(fclProviderMap.get(0).getLocationMapID().getFacilityCenterMaster().getFacilityCenterID());
			List<LocationPojo> locationPojo=new ArrayList<LocationPojo>();
			for(FCLProviderMap fcl:fclProviderMap) {
				LocationMaster lm=locationService.get(fcl.getLocationMapID().getLocationMaster().getLocationID());
				LocationPojo lp=new LocationPojo();
				lp.setFcLocationName(fcl.getLocationMapID().getFcLocationName());
				lp.setFcLocationMapID(fcl.getLocationMapID().getFcLocationMapID());
				lp.setLocationID(lm.getLocationID());
				lp.setAddressLine1(lm.getAddressLine1());
				lp.setAddressLine2(lm.getAddressLine2());
				lp.setAddressLine3(lm.getAddressLine3());
				lp.setArea(lm.getArea());
				lp.setCity(lm.getCity());
				lp.setState(lm.getState());
				lp.setZip(lm.getZip());
				lp.setCountry(lm.getCountry());
				lp.setMilestone1(lm.getMilestone1());
				lp.setMilestone2(lm.getMilestone2());
				TimeZoneMaster tzm = timeZoneService.get(lm.getTimeZoneMaster().getUtcTimeZoneId());
				TimeZonePojo tzp = new TimeZonePojo();
				tzp.setUtcTimeZoneId(tzm.getUtcTimeZoneId());
				tzp.setCountryCode(tzm.getCountryCode());
				tzp.setCountryName(tzm.getCountryName());
				tzp.setTimezoneAbbreviation(tzm.getTimezoneAbbreviation());
				tzp.setTimezoneName(tzm.getTimezoneName());
				tzp.setUtcOffset(tzm.getUtcOffset());
				lp.setTimeZoneMaster(tzp);
				locationPojo.add(lp);
			}
			demographicPojo.setLocationMasterdata(locationPojo);
			response.setStatus(ResponseConstant.SUCCESS);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_SUCCESS));
			response.setData(demographicPojo);
		}catch (Exception e) {
			logger.error("Error:--", e);
			response.setStatus(ResponseConstant.ERROR);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			response.setData(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Response>(response, HttpStatus.OK);
	}
	
	@RequestMapping(value = LABORATORYURLConstant.PROFILE_DEMOGRAPHIC_URL, method = RequestMethod.POST, headers = CommonConstants.CONTENT_TYPE_APPLICATION_JSON)
	public ResponseEntity<Response> demographic(Locale locale, @RequestBody PersonMaster personMaster) {
		Response response = new Response();
		UserDetails userDetails = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		UserMaster userEntity = userService.findByUserName(userDetails.getUsername());
		try {
			    PersonMaster person = personService.get(personMaster.getPersonID());
			    personService.deletePersonMobileList(personMaster.getPersonID());
			    person.setPerMobilePrimary(personMaster.getPerMobilePrimary());
				person.setPerMobileList(personMaster.getPerMobileList());
				person.setActive(true);
				person.setModifiedBy(userEntity);
				person.setModifiedOn(new Date());
				person.setDeleted(false);
				try {
					person=personService.saveOrUpdate(person);
				}catch (Exception e) {
					logger.error("Error:--", e);
					response.setStatus(ResponseConstant.ERROR);
					response.setMessage(messageByLocaleService.getMessage(LABORATORYURLConstant.DEMOGRAPHIC_ERROR));
					response.setData(messageByLocaleService.getMessage(LABORATORYURLConstant.DEMOGRAPHIC_ERROR));
					return new ResponseEntity<Response>(response, HttpStatus.NOT_ACCEPTABLE);
				}
				List<FCLocationMap> fcLocationMaps=fcLocationMapService.getLocation(personMaster.getFacilityCenterMaster());
				for(FCLocationMap fcl:fcLocationMaps) {
					fcl.setActive(false);
					fcl.setModifiedOn(new Date());
					fcl.setModifiedBy(userEntity);
					fcl.setDeleted(true);
					try {
						fcLocationMapService.saveOrUpdate(fcl);
					}catch (Exception e) {
						logger.error("Error:--", e);
						response.setStatus(ResponseConstant.ERROR);
						response.setMessage(messageByLocaleService.getMessage(LABORATORYURLConstant.DEMOGRAPHIC_ERROR));
						response.setData(messageByLocaleService.getMessage(LABORATORYURLConstant.DEMOGRAPHIC_ERROR));
						return new ResponseEntity<Response>(response, HttpStatus.NOT_ACCEPTABLE);
					}
				}
				ProviderMaster providerMaster=providerService.getProvider(userEntity.getUserEmail(),ProviderTypeStatus.LabUser);
				for(LocationMaster lm:personMaster.getLocationMasterdata()) {
					if(lm.getLocationID() == null || lm.getLocationID().equals(0L)) {
						String fcmlocationName=lm.getFcLocationName();
						lm.setActive(true);
						lm.setCreatedOn(new Date());
						lm.setModifiedOn(new Date());
						lm.setCreatedBy(userEntity);
						lm.setModifiedBy(userEntity);
						lm.setDeleted(false);
						try {
							lm = locationService.saveOrUpdate(lm);
						}catch (Exception e) {
							logger.error("Error:--", e);
							response.setStatus(ResponseConstant.ERROR);
							response.setMessage(messageByLocaleService.getMessage(LABORATORYURLConstant.DEMOGRAPHIC_ERROR));
							response.setData(messageByLocaleService.getMessage(LABORATORYURLConstant.DEMOGRAPHIC_ERROR));
							return new ResponseEntity<Response>(response, HttpStatus.NOT_ACCEPTABLE);
						}
						FCLocationMap fcLocationMap = new FCLocationMap();
						fcLocationMap.setActive(true);
						fcLocationMap.setCreatedOn(new Date());
						fcLocationMap.setModifiedOn(new Date());
						fcLocationMap.setCreatedBy(userEntity);
						fcLocationMap.setModifiedBy(userEntity);
						fcLocationMap.setDeleted(false);
						fcLocationMap.setFacilityCenterMaster(personMaster.getFacilityCenterMaster());
						fcLocationMap.setLocationMaster(lm);
						fcLocationMap.setFcLocationName(fcmlocationName);
						fcLocationMap.setDoesOfferHomeservice(false);
						fcLocationMap.setHavechildDepartmentMapCount(0);
						try {
							fcLocationMap=fcLocationMapService.saveOrUpdate(fcLocationMap);
						}catch (Exception e) {
							logger.error("Error:--", e);
							response.setStatus(ResponseConstant.ERROR);
							response.setMessage(messageByLocaleService.getMessage(LABORATORYURLConstant.DEMOGRAPHIC_ERROR));
							response.setData(messageByLocaleService.getMessage(LABORATORYURLConstant.DEMOGRAPHIC_ERROR));
							return new ResponseEntity<Response>(response, HttpStatus.NOT_ACCEPTABLE);
						}
						FCLProviderMap fclProviderMap=new FCLProviderMap();
						fclProviderMap.setProviderID(providerMaster);
						fclProviderMap.setLocationMapID(fcLocationMap);
						fclProviderMap.setActive(true);
						fclProviderMap.setDeleted(false);
						fclProviderMap.setCreatedOn(new Date());
						fclProviderMap.setCreatedBy(userEntity);
						fclProviderMap.setModifiedOn(new Date());
						fclProviderMap.setModifiedBy(userEntity);
						try {
							fclProviderService.saveOrUpdate(fclProviderMap);
						}catch (Exception e) {
							logger.error("Error:--", e);
							response.setStatus(ResponseConstant.ERROR);
							response.setMessage(messageByLocaleService.getMessage(ServiceConstant.EMAIL_EXCEPTION));
							response.setData(messageByLocaleService.getMessage(ServiceConstant.EMAIL_EXCEPTION));
							return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
						}
					}else {
						String fcmlocationName=lm.getFcLocationName();
						LocationMaster lms=locationService.get(lm.getLocationID());
						lm.setLocationID(lms.getLocationID());
						lm.setActive(true);
						lm.setCreatedOn(lms.getCreatedOn());
						lm.setModifiedOn(new Date());
						lm.setCreatedBy(lms.getCreatedBy());
						lm.setModifiedBy(userEntity);
						lm.setDeleted(false);
						try {
							lm = locationService.saveOrUpdate(lm);
						}catch (Exception e) {
							logger.error("Error:--", e);
							response.setStatus(ResponseConstant.ERROR);
							response.setMessage(messageByLocaleService.getMessage(LABORATORYURLConstant.DEMOGRAPHIC_ERROR));
							response.setData(messageByLocaleService.getMessage(LABORATORYURLConstant.DEMOGRAPHIC_ERROR));
							return new ResponseEntity<Response>(response, HttpStatus.NOT_ACCEPTABLE);
						}
						FCLocationMap fcm=fcLocationMapService.getdata(personMaster.getFacilityCenterMaster().getFacilityCenterID(),lm.getLocationID());
						fcm.setFacilityCenterMaster(personMaster.getFacilityCenterMaster());
						fcm.setLocationMaster(lm);
						fcm.setDoesOfferHomeservice(false);
						fcm.setHavechildDepartmentMapCount(0);
						fcm.setFcLocationName(fcmlocationName);
						fcm.setActive(true);
						fcm.setModifiedOn(new Date());
						fcm.setModifiedBy(userEntity);
						fcm.setDeleted(false);
						try {
							fcm=fcLocationMapService.saveOrUpdate(fcm);
						}catch (Exception e) {
							logger.error("Error:--", e);
							response.setStatus(ResponseConstant.ERROR);
							response.setMessage(messageByLocaleService.getMessage(LABORATORYURLConstant.DEMOGRAPHIC_ERROR));
							response.setData(messageByLocaleService.getMessage(LABORATORYURLConstant.DEMOGRAPHIC_ERROR));
							return new ResponseEntity<Response>(response, HttpStatus.NOT_ACCEPTABLE);
						}
						FCLProviderMap fclProviderMap=fclProviderService.getdata(providerMaster.getProviderID(),fcm.getFcLocationMapID());
						fclProviderMap.setProviderID(providerMaster);
						fclProviderMap.setLocationMapID(fcm);
						fclProviderMap.setActive(true);
						fclProviderMap.setDeleted(false);
						fclProviderMap.setModifiedOn(new Date());
						fclProviderMap.setModifiedBy(userEntity);
						try {
							fclProviderService.saveOrUpdate(fclProviderMap);
						}catch (Exception e) {
							logger.error("Error:--", e);
							response.setStatus(ResponseConstant.ERROR);
							response.setMessage(messageByLocaleService.getMessage(ServiceConstant.EMAIL_EXCEPTION));
							response.setData(messageByLocaleService.getMessage(ServiceConstant.EMAIL_EXCEPTION));
							return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
						}
					}
				}
				response.setStatus(ResponseConstant.SUCCESS);
				response.setMessage(messageByLocaleService.getMessage(LABORATORYURLConstant.DEMOGRAPHIC_SUCCESS));
				response.setData(messageByLocaleService.getMessage(LABORATORYURLConstant.DEMOGRAPHIC_SUCCESS));
		} catch (Exception e) {
			logger.error("Error:--", e);
			response.setStatus(ResponseConstant.ERROR);
			response.setMessage(messageByLocaleService.getMessage(LABORATORYURLConstant.DEMOGRAPHIC_ERROR));
			response.setData(messageByLocaleService.getMessage(LABORATORYURLConstant.DEMOGRAPHIC_ERROR));
			return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Response>(response, HttpStatus.OK);
	}
	
	@RequestMapping(value = LABORATORYURLConstant.PROFILE_PROFESSIONAL_GETDATA_URL, method = RequestMethod.POST, headers = CommonConstants.CONTENT_TYPE_APPLICATION_JSON)
	public ResponseEntity<Response> getProfessionalData(Locale locale) {
		Response response = new Response();
		UserDetails userDetails = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		UserMaster userEntity = userService.findByUserName(userDetails.getUsername());
		try {
			ProviderMaster providerMaster=providerService.getProvider(userEntity.getUserEmail(),ProviderTypeStatus.LabUser);
			Set<LabReportsLevel1Pojo> labReportsLevel1=new HashSet<LabReportsLevel1Pojo>(0);
			Set<ProviderPojo> doctor = new HashSet<ProviderPojo>(0);
			List<ProfessionalPojo> professionalPojoData = new ArrayList<ProfessionalPojo>(0);
			Set<DrugCompoundPojo> drugCompoundMaster = new HashSet<DrugCompoundPojo>(0);
			List<FCLProviderMap> fclProviderMap=fclProviderService.getFclDataforDoctor(providerMaster.getProviderID(),providerMaster.getProviderTypeStatus());
			for(FCLProviderMap fpm:fclProviderMap) {
				ProfessionalPojo professionalPojo=new ProfessionalPojo();
				professionalPojo.setFclProviderMap(fpm.getFclProviderMapID());
				professionalPojo.setLocationName(fpm.getLocationMapID().getFcLocationName());
				List<FCLProviderReportMap> fclProviderReportMap=fclProviderReportMapService.getAllData(fpm.getFclProviderMapID());
				if(fclProviderReportMap.size()>0) {
					for(FCLProviderReportMap fpr:fclProviderReportMap) {
						LabReportsLevel1Pojo lrlp=new LabReportsLevel1Pojo();
						lrlp.setLabReportLevel1ID(fpr.getLabReportLevel1ID().getLabReportLevel1ID());
						lrlp.setLrl1Name(fpr.getLabReportLevel1ID().getLrl1Name());
						labReportsLevel1.add(lrlp);
					}
					List<FCLProviderLabDoctorMap> doctors=fcLProviderLabDoctorMapService.getAllData(fpm.getFclProviderMapID());
					for(FCLProviderLabDoctorMap fcldoctorMap:doctors) {
						ProviderPojo pp=new ProviderPojo();
						pp.setFclProviderMapID(fcldoctorMap.getDoctor().getFclProviderMapID());
						pp.setProviderID(fcldoctorMap.getDoctor().getLocationMapID().getFacilityCenterMaster().getFacilityCenterID());
						pp.setProviderName(fcldoctorMap.getDoctor().getLocationMapID().getFacilityCenterMaster().getFacilityCenterName());
						doctor.add(pp);
					}
					List<FCLProviderLabDrugCompoundMap> fcLProviderLabDrugCompoundMap=fcLProviderLabDrugCompoundMapService.getAllData(fpm.getFclProviderMapID());
					for(FCLProviderLabDrugCompoundMap fcLProviderDrugCompound:fcLProviderLabDrugCompoundMap) {
						DrugCompoundPojo drugCompoundPojo=new DrugCompoundPojo();
						drugCompoundPojo.setDrugCompoundID(fcLProviderDrugCompound.getDrugCompoundID().getDrugCompoundID());
						drugCompoundPojo.setDrugCompoundName(fcLProviderDrugCompound.getDrugCompoundID().getDrugCompoundName());
						drugCompoundMaster.add(drugCompoundPojo);
					}
				}
				professionalPojo.setDoctor(doctor);
				professionalPojo.setLabReportLevel1ID(labReportsLevel1);
				professionalPojo.setDrugCompoundMaster(drugCompoundMaster);
				professionalPojoData.add(professionalPojo);
			}
			response.setStatus(ResponseConstant.SUCCESS);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_SUCCESS));
			response.setData(professionalPojoData);
		} catch (Exception e) {
			logger.error("Error:--", e);
			response.setStatus(ResponseConstant.ERROR);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			response.setData(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Response>(response, HttpStatus.OK);
	}
	
	@RequestMapping(value = LABORATORYURLConstant.PROFILE_PROFESSIONAL_LOCATION_GETDATA_URLL, method = RequestMethod.POST, headers = CommonConstants.CONTENT_TYPE_APPLICATION_JSON)
	public ResponseEntity<Response> getProfessionalByLocation(Locale locale,@RequestBody ProfessionalPojo professionalPojo) {
		Response response = new Response();
		try {
			Set<LabReportsLevel1Pojo> labReportsLevel1=new HashSet<LabReportsLevel1Pojo>(0);
			Set<ProviderPojo> doctor = new HashSet<ProviderPojo>(0);
			Set<DrugCompoundPojo> drugCompoundMaster = new HashSet<DrugCompoundPojo>(0);
			List<FCLProviderReportMap> fclProviderReportMap=fclProviderReportMapService.getAllData(professionalPojo.getFclProviderMap());
			if(fclProviderReportMap.size()>0) {
				for(FCLProviderReportMap fpr:fclProviderReportMap) {
					LabReportsLevel1Pojo lrlp=new LabReportsLevel1Pojo();
					lrlp.setLabReportLevel1ID(fpr.getLabReportLevel1ID().getLabReportLevel1ID());
					lrlp.setLrl1Name(fpr.getLabReportLevel1ID().getLrl1Name());
					labReportsLevel1.add(lrlp);
				}
				List<FCLProviderLabDoctorMap> doctors=fcLProviderLabDoctorMapService.getAllData(professionalPojo.getFclProviderMap());
				for(FCLProviderLabDoctorMap fcldoctorMap:doctors) {
					ProviderPojo pp=new ProviderPojo();
					pp.setFclProviderMapID(fcldoctorMap.getDoctor().getFclProviderMapID());
					pp.setProviderID(fcldoctorMap.getDoctor().getLocationMapID().getFacilityCenterMaster().getFacilityCenterID());
					pp.setProviderName(fcldoctorMap.getDoctor().getLocationMapID().getFacilityCenterMaster().getFacilityCenterName());
					doctor.add(pp);
				}
				List<FCLProviderLabDrugCompoundMap> fcLProviderLabDrugCompoundMap=fcLProviderLabDrugCompoundMapService.getAllData(professionalPojo.getFclProviderMap());
				for(FCLProviderLabDrugCompoundMap fcLProviderDrugCompound:fcLProviderLabDrugCompoundMap) {
					DrugCompoundPojo drugCompoundPojo=new DrugCompoundPojo();
					drugCompoundPojo.setDrugCompoundID(fcLProviderDrugCompound.getDrugCompoundID().getDrugCompoundID());
					drugCompoundPojo.setDrugCompoundName(fcLProviderDrugCompound.getDrugCompoundID().getDrugCompoundName());
					drugCompoundMaster.add(drugCompoundPojo);
				}
			}
			professionalPojo.setDoctor(doctor);
			professionalPojo.setLabReportLevel1ID(labReportsLevel1);
			professionalPojo.setDrugCompoundMaster(drugCompoundMaster);
			response.setStatus(ResponseConstant.SUCCESS);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_SUCCESS));
			response.setData(professionalPojo);
		} catch (Exception e) {
			logger.error("Error:--", e);
			response.setStatus(ResponseConstant.ERROR);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			response.setData(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Response>(response, HttpStatus.OK);
	}
	
	@RequestMapping(value = LABORATORYURLConstant.PROFILE_PROFESSIONAL_URL, method = RequestMethod.POST, headers = CommonConstants.CONTENT_TYPE_APPLICATION_JSON)
	public ResponseEntity<Response> professional(Locale locale, @RequestBody FCLProviderReportMap fclProviderReportMap) {
		Response response = new Response();
		UserDetails userDetails = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		UserMaster userEntity = userService.findByUserName(userDetails.getUsername());
		String type = null;
		Boolean isEmpty = OperationsUtil.checkNull(fclProviderReportMap);
		if (!isEmpty) {
			try {
				List<FCLProviderReportMap> fclProvider=fclProviderReportMapService.getAllDatas(fclProviderReportMap.getFclProviderMap());
				Set<DrugCompoundMaster> drugCompoundMaster = fclProviderReportMap.getDrugCompoundMaster();
				Set<LabReportsLevel1> labReportsLevel1 = fclProviderReportMap.getLabReportsLevel1();
				Set<FCLProviderMap> doctor = fclProviderReportMap.getDoctor();
				if(fclProvider.size()>0) {
					for(FCLProviderReportMap fprm:fclProvider) {
						fprm.setModifiedOn(new Date());
						fprm.setModifiedBy(userEntity);
						fprm.setActive(false);
						fprm.setDeleted(true);
						try {
							fclProviderReportMapService.saveOrUpdate(fprm);
						}catch (Exception e) {
							logger.error("Error:--", e);
							response.setStatus(ResponseConstant.ERROR);
							response.setMessage(messageByLocaleService.getMessage(LABORATORYURLConstant.PROFESSIONAL_ERROR));
							response.setData(messageByLocaleService.getMessage(LABORATORYURLConstant.PROFESSIONAL_ERROR));
							return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
						}
					}
			    }
			    List<FCLProviderLabDoctorMap> doctors=fcLProviderLabDoctorMapService.getAllDatas(fclProviderReportMap.getFclProviderMap());
				if(doctors.size()>0) {
					for(FCLProviderLabDoctorMap fprm:doctors) {
						fprm.setModifiedOn(new Date());
						fprm.setModifiedBy(userEntity);
						fprm.setActive(false);
						fprm.setDeleted(true);
						try {
							fcLProviderLabDoctorMapService.saveOrUpdate(fprm);
						}catch (Exception e) {
							logger.error("Error:--", e);
							response.setStatus(ResponseConstant.ERROR);
							response.setMessage(messageByLocaleService.getMessage(LABORATORYURLConstant.PROFESSIONAL_ERROR));
							response.setData(messageByLocaleService.getMessage(LABORATORYURLConstant.PROFESSIONAL_ERROR));
							return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
						}
					}
				}
				List<FCLProviderLabDrugCompoundMap> fclPDrugCompoundMap=fcLProviderLabDrugCompoundMapService.getAllDatas(fclProviderReportMap.getFclProviderMap());
				if(fclPDrugCompoundMap.size()>0) {
					for(FCLProviderLabDrugCompoundMap fprm:fclPDrugCompoundMap) {
						fprm.setModifiedOn(new Date());
						fprm.setModifiedBy(userEntity);
						fprm.setActive(false);
						fprm.setDeleted(true);
						try {
							fcLProviderLabDrugCompoundMapService.saveOrUpdate(fprm);
						}catch (Exception e) {
							logger.error("Error:--", e);
							response.setStatus(ResponseConstant.ERROR);
							response.setMessage(messageByLocaleService.getMessage(LABORATORYURLConstant.PROFESSIONAL_ERROR));
							response.setData(messageByLocaleService.getMessage(LABORATORYURLConstant.PROFESSIONAL_ERROR));
							return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
						}
					}
				}
				for(LabReportsLevel1 ll:labReportsLevel1) {
					FCLProviderReportMap fclpr=fclProviderReportMapService.getData(fclProviderReportMap.getFclProviderMap(),ll.getLabReportLevel1ID());
					if(fclpr == null) {
						FCLProviderReportMap fclProviderReportMaps=new FCLProviderReportMap();
						type = LABORATORYURLConstant.ADD_TYPE;
						fclProviderReportMaps.setActive(true);
						fclProviderReportMaps.setCreatedOn(new Date());
						fclProviderReportMaps.setModifiedOn(new Date());
						fclProviderReportMaps.setCreatedBy(userEntity);
						fclProviderReportMaps.setModifiedBy(userEntity);
						fclProviderReportMaps.setDeleted(false);
						FCLProviderMap fclProviderMapID=fclProviderService.get(fclProviderReportMap.getFclProviderMap());
						fclProviderReportMaps.setFclProviderMapID(fclProviderMapID);
						fclProviderReportMaps.setLabReportLevel1ID(ll);
						try {
							fclProviderReportMapService.saveOrUpdate(fclProviderReportMaps);
						}catch (Exception e) {
							logger.error("Error:--", e);
							response.setStatus(ResponseConstant.ERROR);
							response.setMessage(messageByLocaleService.getMessage(LABORATORYURLConstant.PROFESSIONAL_ERROR));
							response.setData(messageByLocaleService.getMessage(LABORATORYURLConstant.PROFESSIONAL_ERROR));
							return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
						}
						response.setStatus(ResponseConstant.SUCCESS);
						response.setMessage(messageByLocaleService.getMessage(LABORATORYURLConstant.PROFESSIONAL_SUCCESS));
						response.setData(messageByLocaleService.getMessage(LABORATORYURLConstant.PROFESSIONAL_SUCCESS));
					}else {
						fclpr.setActive(true);
						fclpr.setDeleted(false);
						fclpr.setModifiedBy(userEntity);
						fclpr.setModifiedOn(new Date());
						type = LABORATORYURLConstant.EDIT_TYPE;
						fclpr.setFclProviderReportMapID(fclpr.getFclProviderReportMapID());
						FCLProviderMap fclProviderMapID=fclProviderService.get(fclProviderReportMap.getFclProviderMap());
						fclpr.setFclProviderMapID(fclProviderMapID);
						fclpr.setLabReportLevel1ID(ll);
						try {
							fclProviderReportMapService.saveOrUpdate(fclpr);
						}catch (Exception e) {
							logger.error("Error:--", e);
							response.setStatus(ResponseConstant.ERROR);
							response.setMessage(messageByLocaleService.getMessage(LABORATORYURLConstant.PROFESSIONAL_ERROR));
							response.setData(messageByLocaleService.getMessage(LABORATORYURLConstant.PROFESSIONAL_ERROR));
							return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
						}
					}
				}
				for(DrugCompoundMaster dcm:drugCompoundMaster) {
					FCLProviderLabDrugCompoundMap fclpr=fcLProviderLabDrugCompoundMapService.getData(fclProviderReportMap.getFclProviderMap(),dcm.getDrugCompoundID());
					if(fclpr == null) {
						FCLProviderLabDrugCompoundMap fdc=new FCLProviderLabDrugCompoundMap();
						type = LABORATORYURLConstant.ADD_TYPE;
						fdc.setActive(true);
						fdc.setCreatedOn(new Date());
						fdc.setCreatedBy(userEntity);
						fdc.setModifiedBy(userEntity);
						fdc.setModifiedOn(new Date());
						fdc.setDeleted(false);
						FCLProviderMap fclProviderMapID=fclProviderService.get(fclProviderReportMap.getFclProviderMap());
						fdc.setFclProviderMapID(fclProviderMapID);
						fdc.setDrugCompoundID(dcm);
						try {
							fcLProviderLabDrugCompoundMapService.saveOrUpdate(fdc);
						}catch (Exception e) {
							logger.error("Error:--", e);
							response.setStatus(ResponseConstant.ERROR);
							response.setMessage(messageByLocaleService.getMessage(LABORATORYURLConstant.PROFESSIONAL_ERROR));
							response.setData(messageByLocaleService.getMessage(LABORATORYURLConstant.PROFESSIONAL_ERROR));
							return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
						}
						response.setStatus(ResponseConstant.SUCCESS);
						response.setMessage(messageByLocaleService.getMessage(LABORATORYURLConstant.PROFESSIONAL_SUCCESS));
						response.setData(messageByLocaleService.getMessage(LABORATORYURLConstant.PROFESSIONAL_SUCCESS));
					}else {
						fclpr.setActive(true);
						fclpr.setDeleted(false);
						fclpr.setModifiedBy(userEntity);
						fclpr.setModifiedOn(new Date());
						type = LABORATORYURLConstant.EDIT_TYPE;
						fclpr.setFclProviderLabDrugCompoundMapID(fclpr.getFclProviderLabDrugCompoundMapID());
						FCLProviderMap fclProviderMapID=fclProviderService.get(fclProviderReportMap.getFclProviderMap());
						fclpr.setFclProviderMapID(fclProviderMapID);
						fclpr.setDrugCompoundID(dcm);
						try {
							fcLProviderLabDrugCompoundMapService.saveOrUpdate(fclpr);
						}catch (Exception e) {
							logger.error("Error:--", e);
							response.setStatus(ResponseConstant.ERROR);
							response.setMessage(messageByLocaleService.getMessage(LABORATORYURLConstant.PROFESSIONAL_ERROR));
							response.setData(messageByLocaleService.getMessage(LABORATORYURLConstant.PROFESSIONAL_ERROR));
							return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
						}
					}
				}
				for(FCLProviderMap doct:doctor) {
					FCLProviderLabDoctorMap fclpr=fcLProviderLabDoctorMapService.getData(fclProviderReportMap.getFclProviderMap(),doct.getFclProviderMapID());
					if(fclpr == null) {
						FCLProviderLabDoctorMap fdc=new FCLProviderLabDoctorMap();
						type = LABORATORYURLConstant.ADD_TYPE;
						fdc.setActive(true);
						fdc.setCreatedOn(new Date());
						fdc.setCreatedBy(userEntity);
						fdc.setModifiedBy(userEntity);
						fdc.setModifiedOn(new Date());
						fdc.setDeleted(false);
						FCLProviderMap fclProviderMapID=fclProviderService.get(fclProviderReportMap.getFclProviderMap());
						fdc.setFclProviderMapID(fclProviderMapID);
						fdc.setDoctor(doct);
						try {
							fcLProviderLabDoctorMapService.saveOrUpdate(fdc);
						}catch (Exception e) {
							logger.error("Error:--", e);
							response.setStatus(ResponseConstant.ERROR);
							response.setMessage(messageByLocaleService.getMessage(LABORATORYURLConstant.PROFESSIONAL_ERROR));
							response.setData(messageByLocaleService.getMessage(LABORATORYURLConstant.PROFESSIONAL_ERROR));
							return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
						}
					}else {
						fclpr.setActive(true);
						fclpr.setDeleted(false);
						fclpr.setModifiedBy(userEntity);
						fclpr.setModifiedOn(new Date());
						type = LABORATORYURLConstant.EDIT_TYPE;
						fclpr.setFclProviderLabDoctorMapID(fclpr.getFclProviderLabDoctorMapID());
						FCLProviderMap fclProviderMapID=fclProviderService.get(fclProviderReportMap.getFclProviderMap());
						fclpr.setFclProviderMapID(fclProviderMapID);
						fclpr.setDoctor(doct);
						try {
							fcLProviderLabDoctorMapService.saveOrUpdate(fclpr);
						}catch (Exception e) {
							logger.error("Error:--", e);
							response.setStatus(ResponseConstant.ERROR);
							response.setMessage(messageByLocaleService.getMessage(LABORATORYURLConstant.PROFESSIONAL_ERROR));
							response.setData(messageByLocaleService.getMessage(LABORATORYURLConstant.PROFESSIONAL_ERROR));
							return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
						}
					}
				}
			} catch (Exception e) {
				logger.error("Error:--", e);
				response.setStatus(ResponseConstant.ERROR);
				response.setMessage(messageByLocaleService.getMessage(LABORATORYURLConstant.PROFESSIONAL_ERROR));
				response.setData(messageByLocaleService.getMessage(LABORATORYURLConstant.PROFESSIONAL_ERROR));
				return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
			}
		} else {
			response.setStatus(ResponseConstant.ERROR);
			response.setMessage(messageByLocaleService.getMessage(LABORATORYURLConstant.PROFESSIONAL_EXCEPTION));
			response.setData(messageByLocaleService.getMessage(LABORATORYURLConstant.PROFESSIONAL_EXCEPTION));
			return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		if(type.equalsIgnoreCase(LABORATORYURLConstant.ADD_TYPE)) {
			return new ResponseEntity<Response>(response, HttpStatus.CREATED);
		}else {
			return new ResponseEntity<Response>(response, HttpStatus.OK);
		}
	}
	
	@RequestMapping(value = LABORATORYURLConstant.GET_LAB_URL, method = RequestMethod.GET, headers = CommonConstants.CONTENT_TYPE_APPLICATION_JSON)
	public ResponseEntity<Response> getAllLab(Locale locale,Pageable pageable) {
		Response response = new Response();
		PatLabAppointmentsPojoList patLabAppointmentsPojoList=new PatLabAppointmentsPojoList();
		List<PatLabAppointmentsPojo> patLabAppointmentsPojo=new ArrayList<PatLabAppointmentsPojo>();
		UserDetails userDetails = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		UserMaster userEntity = userService.findByUserName(userDetails.getUsername());
		try {
			ProviderMaster providerMaster=providerService.getProvider(userEntity.getUserEmail(),ProviderTypeStatus.LabUser);
			List<PatLabAppointments> patLabAppointments=patLabAppointmentService.findProviderData(providerMaster.getProviderID(),pageable);
			List<PatLabAppointments> patLabAppointment=patLabAppointmentService.findProviderDatas(providerMaster.getProviderID());
			if(patLabAppointments.size()>0) {
				for(PatLabAppointments pa:patLabAppointments) {
					PatLabAppointmentsPojo pap=SetPatLabAppointmentsPojo(pa);
					patLabAppointmentsPojo.add(pap);
				}
				patLabAppointmentsPojoList.setTotalNumber(patLabAppointment.size());
				patLabAppointmentsPojoList.setPatLabAppointmentsPojo(patLabAppointmentsPojo);
			}
			response.setStatus(ResponseConstant.SUCCESS);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_SUCCESS));
			response.setData(patLabAppointmentsPojoList);
		}catch (Exception e) {
			logger.error("Error:--", e);
			response.setStatus(ResponseConstant.ERROR);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			response.setData(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Response>(response, HttpStatus.OK);
	}
	
	@RequestMapping(value = LABORATORYURLConstant.VIEW_AND_EDIT_LAB_URL, method = RequestMethod.POST, headers = CommonConstants.CONTENT_TYPE_APPLICATION_JSON)
	public ResponseEntity<Response> viewAndEditLab(Locale locale,@RequestBody PatLabAppointments patLabAppointments) {
		Response response = new Response();
		try {
			PatLabAppointments pa=patLabAppointmentService.get(patLabAppointments.getPatLabAppointmentID());
			PatLabAppointmentsPojo pap=SetPatLabAppointmentsPojo(pa);
			response.setStatus(ResponseConstant.SUCCESS);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_SUCCESS));
			response.setData(pap);
		}catch (Exception e) {
			logger.error("Error:--", e);
			response.setStatus(ResponseConstant.ERROR);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			response.setData(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Response>(response, HttpStatus.OK);
	}
	
	private PatLabAppointmentsPojo SetPatLabAppointmentsPojo(PatLabAppointments pa) {
		PatLabAppointmentsPojo pap=new PatLabAppointmentsPojo();
		pap.setAthome(pa.isAthome());
		pap.setPatLabAppointmentID(pa.getPatLabAppointmentID());
		pap.setPatientID(pa.getFclpID().getPatientID().getPatientID());
		pap.setName(pa.getFclpID().getPatientID().getPersonID().getPerFname()+" "+pa.getFclpID().getPatientID().getPersonID().getPerLName());
		pap.setFclProviderMapID(pa.getFclProviderMapID().getFclProviderMapID());
		pap.setProviderID(pa.getFclProviderMapID().getProviderID().getProviderID());
		pap.setProviderName(CommonConstants.DR_SHORT+" "+pa.getFclProviderMapID().getProviderID().getPersonMaster().getPerFname()+" "+pa.getFclProviderMapID().getProviderID().getPersonMaster().getPerLName());
		pap.setPatLabAppDate(pa.getPatLabAppDate());
		pap.setPatLabAppTimeFrom(pa.getPatLabAppTimeFrom());
		pap.setPatLabAppTimeTo(pa.getPatLabAppTimeTo());
		pap.setFcLocationMapID(pa.getFclProviderMapID().getLocationMapID().getFcLocationMapID());
		pap.setFcLocationName(pa.getFclProviderMapID().getLocationMapID().getFcLocationName());
		pap.setFacilityCenterID(pa.getFclProviderMapID().getLocationMapID().getFacilityCenterMaster().getFacilityCenterID());
		pap.setFacilityCenterName(pa.getFclProviderMapID().getLocationMapID().getFacilityCenterMaster().getFacilityCenterName());
		pap.setFacilityCenterType(pa.getFclProviderMapID().getLocationMapID().getFacilityCenterMaster().getFacilityCenterType());
		pap.setPatAppType(pa.getPatAppType());
		pap.setPatAppStatus(pa.getPatAppStatus());
		pap.setPatientLabAppointmentReason(pa.getPatientLabAppointmentReason());
		pap.setPatLabDetail(pa.getPatLabDetail());
		if(pa.getPatVisitNote() !=null) {
			pap.setPatVisitNoteID(pa.getPatVisitNote().getPatVisitNoteID());
		}else {
			pap.setPatVisitNoteID(null);
		}
		List<SuggestReport> sr=suggestReportService.findAll(pa.getPatLabAppointmentID());
		List<LabReportsLevel1Pojo> labReportsLevel1Pojo = new ArrayList<LabReportsLevel1Pojo>();
		for(SuggestReport srs:sr) {
			LabReportsLevel1Pojo lrlp = new LabReportsLevel1Pojo();
			lrlp.setLabReportLevel1ID(srs.getLabReportsLevel1().getLabReportLevel1ID());
			lrlp.setLrl1Category(srs.getLabReportsLevel1().getLrl1Category());
			lrlp.setLabReportType(srs.getLabReportsLevel1().getLabReportType());
			lrlp.setLrl1Name(srs.getLabReportsLevel1().getLrl1Name());
			lrlp.setGenericTestcode(srs.getLabReportsLevel1().getGenericTestcode());
			lrlp.setGenericSourceName(srs.getLabReportsLevel1().getGenericSourceName());
			labReportsLevel1Pojo.add(lrlp);
		}
		pap.setData(labReportsLevel1Pojo);
		return pap;
	}
	
}
