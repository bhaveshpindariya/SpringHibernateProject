package org.healthchain.doctor.constants;

public class DOCTORURLConstant {
	
	
	public static final String DOCTOR_ROOT_URL="/doctor";
	
	public static final String ADD_TYPE="Add";
	public static final String EDIT_TYPE="Update";
	
	public static final String ADD_OR_EDIT_DOCTOR_VISIT_URL="/addOrEditDoctorVisit";
	public static final String GET_DOCTOR_VISIT_URL="/getAllDoctorVisit";
	public static final String VIEW_AND_EDIT_DOCTOR_VISIT_URL="/viewAndEditDoctorVisit";
	
	public static final String GET_APPOINTMENT_DOCTOR_URL="/getAppointmentDoctor";
	public static final String VIEW_AND_EDIT_APPOINTMENT_DOCTOR_URL="/viewAndEditAppointmentDoctor";
	
	public static final String DOCTOR_VISIT_SUCCESS="doctorvisit.success";
	public static final String DOCTOR_VISIT_UPDATE="doctorvisit.update";
	public static final String DOCTOR_VISIT_EXIT="doctorvisit.exit";
	public static final String DOCTOR_VISIT_ERROR="doctorvisit.error";
	public static final String DOCTOR_VISIT_EXCEPTION="doctorvisit.exception";
	
}
	
