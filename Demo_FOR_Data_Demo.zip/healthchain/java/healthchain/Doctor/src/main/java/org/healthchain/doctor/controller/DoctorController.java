package org.healthchain.doctor.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.healthchain.common.constants.CommonConstants;
import org.healthchain.common.constants.ResponseConstant;
import org.healthchain.common.utils.ApiUtil;
import org.healthchain.common.utils.DateUtil;
import org.healthchain.common.utils.HyperledgerApiUtil;
import org.healthchain.common.utils.OperationsUtil;
import org.healthchain.doctor.constants.DOCTORURLConstant;
import org.healthchain.entity.CFLPatRegistrationMap;
import org.healthchain.entity.DiagnosisMaster;
import org.healthchain.entity.DrugCompoundMaster;
import org.healthchain.entity.FCLProviderMap;
import org.healthchain.entity.FCLocationMap;
import org.healthchain.entity.LabPatvisitNote;
import org.healthchain.entity.LabReportsLevel1;
import org.healthchain.entity.PatAppointments;
import org.healthchain.entity.PatDiagnosis;
import org.healthchain.entity.PatVisitNote;
import org.healthchain.entity.PatientMaster;
import org.healthchain.entity.ProviderMaster;
import org.healthchain.entity.RxDetail;
import org.healthchain.entity.RxHeader;
import org.healthchain.entity.UserMaster;
import org.healthchain.entity.enums.PatientAppointmentType;
import org.healthchain.entity.enums.ProviderTypeStatus;
import org.healthchain.pojo.DiseasePojo;
import org.healthchain.pojo.DrugCompoundPojo;
import org.healthchain.pojo.LabReportsLevel1Pojo;
import org.healthchain.pojo.PatAppointmentPojo;
import org.healthchain.pojo.PatAppointmentPojoList;
import org.healthchain.pojo.PatVisitNotePojo;
import org.healthchain.pojo.PatVisitNotePojoList;
import org.healthchain.pojo.Response;
import org.healthchain.services.CFLPatRegistrationMapService;
import org.healthchain.services.DiagnosisService;
import org.healthchain.services.DrugCompoundService;
import org.healthchain.services.FCLProviderService;
import org.healthchain.services.LabPatvisitNoteService;
import org.healthchain.services.LabReportsLevel1Service;
import org.healthchain.services.MessageByLocaleService;
import org.healthchain.services.PatAppointmentService;
import org.healthchain.services.PatDiagnosisService;
import org.healthchain.services.PatVisitNoteService;
import org.healthchain.services.PatientService;
import org.healthchain.services.ProviderService;
import org.healthchain.services.RxDetailService;
import org.healthchain.services.RxHeaderService;
import org.healthchain.services.UserService;
import org.healthchain.services.constants.MethodConstants;
import org.healthchain.services.constants.ServiceConstant;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import net.sf.json.JSONObject;

@CrossOrigin
@RestController
@RequestMapping(DOCTORURLConstant.DOCTOR_ROOT_URL)
public class DoctorController {

	private static final Log logger = LogFactory.getLog(DoctorController.class);
	
	@Autowired
	private PatVisitNoteService patVisitNoteService;
	
	@Autowired
	private PatientService patientService;
	
	@Autowired
	private UserService userService;
	
	@Autowired
    private PatAppointmentService patAppointmentService;
	
	@Autowired
    private FCLProviderService fclProviderService;
	
	@Autowired
	private ProviderService providerService;
	
	@Autowired
    private CFLPatRegistrationMapService cflPatRegistrationMapService;
	
	@Autowired
    private PatDiagnosisService patDiagnosisService;
	
	@Autowired
    private RxDetailService rxDetailService;
	
	@Autowired
    private RxHeaderService rxHeaderService;
	
	@Autowired
    private LabPatvisitNoteService labPatvisitNoteService;
	
	@Autowired
	private DiagnosisService diagnosisService;
	
	@Autowired
	private DrugCompoundService drugCompoundService;
	
	@Autowired
	private LabReportsLevel1Service labReportsLevel1Service;
	
	@Autowired
	private MessageByLocaleService messageByLocaleService;
	
	@RequestMapping(value = DOCTORURLConstant.ADD_OR_EDIT_DOCTOR_VISIT_URL, method = RequestMethod.POST, headers = CommonConstants.CONTENT_TYPE_APPLICATION_JSON)
	public ResponseEntity<Response> addOrEditDoctorVisit(Locale locale,@RequestBody PatVisitNote patVisitNote) {
		UserDetails userDetails = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		UserMaster userEntity = userService.findByUserName(userDetails.getUsername());
		Boolean isEmpty = OperationsUtil.checkNull(patVisitNote);
		Response response = new Response();
		String type=null;
		if (!isEmpty) {
			ProviderMaster providerMaster=providerService.getProvider(userEntity.getUserEmail(),ProviderTypeStatus.Doctor);
			try {
				if(patVisitNote.getPatVisitNoteID() == null || patVisitNote.getPatVisitNoteID().equals(0L)) {
					type=DOCTORURLConstant.ADD_TYPE;
					patVisitNote.setActive(true);
					patVisitNote.setPatVisitDate(new Date());
					patVisitNote.setCreatedOn(new Date());
					patVisitNote.setModifiedOn(new Date());
					patVisitNote.setCreatedBy(userEntity);
					patVisitNote.setModifiedBy(userEntity);
					patVisitNote.setDeleted(false);
				}else {
					patVisitNote.setActive(true);
					patVisitNote.setDeleted(false);
					patVisitNote.setModifiedBy(userEntity);
					patVisitNote.setModifiedOn(new Date());
					type=DOCTORURLConstant.EDIT_TYPE;
				}
				Set<DiagnosisMaster>  diagnosisMasters= patVisitNote.getDiagnosisMaster(); 
				Set<String> diName= new HashSet<String>(); 
				if(diagnosisMasters.size()>0) {
					for(DiagnosisMaster dm:diagnosisMasters) {
						dm=diagnosisService.get(dm.getDiagnosisID());
						diName.add(dm.getDiagnosiseName());
					}
				}
				Set<LabReportsLevel1> labReportsLevel1s= patVisitNote.getLabReportsLevel1();
				Set<String> ll= new HashSet<String>(); 
				if(labReportsLevel1s.size()>0) {
					for(LabReportsLevel1 ll1:labReportsLevel1s) {
						ll1=labReportsLevel1Service.get(ll1.getLabReportLevel1ID());
						ll.add(ll1.getLrl1Name());
					}
				}
				Set<DrugCompoundMaster> drugCompoundMasters= patVisitNote.getDrugCompoundMaster();
				Set<String> dcms= new HashSet<String>(); 
				if(drugCompoundMasters.size()>0) {
					for(DrugCompoundMaster dc:drugCompoundMasters) {
						dc=drugCompoundService.get(dc.getDrugCompoundID());
						dcms.add(dc.getDrugCompoundName());
					}
				}
				if(patVisitNote.getPatVisitNoteID() == null || patVisitNote.getPatVisitNoteID().equals(0L)) {
					if(patVisitNote.getAppointmentID() !=null) {
						patVisitNote.setPatVisitType(patVisitNote.getAppointmentID().getPatAppType());
					}
					if(patVisitNote.getAppointmentID() == null) {
						patVisitNote.setPatVisitType(PatientAppointmentType.New);
					}
					
					PatientMaster patientMaster = patientService.get(patVisitNote.getPatientMaster().getPatientID());
					UserMaster patient = userService.findByUserEmail(patientMaster.getPersonID().getUserMaster().getUserEmail());
					CFLPatRegistrationMap getcflPatRegistrationMap=cflPatRegistrationMapService.findCflData(patVisitNote.getPatientMaster().getPatientID(), patVisitNote.getFcLocationMap().getFcLocationMapID());
					if(getcflPatRegistrationMap !=null) {
						getcflPatRegistrationMap.setModifiedBy(userEntity);
						getcflPatRegistrationMap.setModifiedOn(new Date());
						patVisitNote.setClfPatRegistrationMap(getcflPatRegistrationMap);
					}else {
						CFLPatRegistrationMap cflPatRegistrationMap=SetCFLPatRegistrationMap(userEntity,patVisitNote.getFcLocationMap(),patVisitNote.getPatientMaster());
						patVisitNote.setClfPatRegistrationMap(cflPatRegistrationMap);
					}
					FCLProviderMap fclProviderMap=fclProviderService.getdata(providerMaster.getProviderID(), patVisitNote.getFcLocationMap().getFcLocationMapID());
					patVisitNote.setFclProviderMapID(fclProviderMap);
					try {
						patVisitNote = patVisitNoteService.saveOrUpdate(patVisitNote);
					}catch (Exception e) {
						logger.error("Error:--", e);
						response.setStatus(ResponseConstant.ERROR);
						response.setMessage(messageByLocaleService.getMessage(DOCTORURLConstant.DOCTOR_VISIT_ERROR));
						response.setData(messageByLocaleService.getMessage(DOCTORURLConstant.DOCTOR_VISIT_ERROR));
						return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
					}
					if(CommonConstants.getPropertiesValue("TYPE").equalsIgnoreCase(CommonConstants.HYPERLEDGER)) {
						JSONObject userEntityData = new JSONObject();
						userEntityData.put("visitID", patVisitNote.getPatVisitNoteID());
						userEntityData.put("patientID", patient.getUserHyperledgerID());
						userEntityData.put("facilityName",patVisitNote.getFclProviderMapID().getLocationMapID().getFacilityCenterMaster().getFacilityCenterName());
						userEntityData.put("facilityLocation", patVisitNote.getFclProviderMapID().getLocationMapID().getFcLocationName());
						if(patVisitNote.getPatSymptoms() == null) {
							userEntityData.put("symptoms", "");
						}else {
							userEntityData.put("symptoms", patVisitNote.getPatSymptoms());
						}
						if(patVisitNote.getTreatmentProvided() == null) {
							userEntityData.put("treatmentProvided", "");
						}else {
							userEntityData.put("treatmentProvided", patVisitNote.getTreatmentProvided());
						}
						if(diName.size()>0) {
							userEntityData.put("possibleDiseaseName",diName.toString());
						}else {
							userEntityData.put("possibleDiseaseName", "");
						}
						if(patVisitNote.getPatSideEffect() == null) {
							userEntityData.put("sideEffect", "");
						}else {
							userEntityData.put("sideEffect", patVisitNote.getPatSideEffect());
						}
						if(patVisitNote.getPatExtraDetails() == null) {
							userEntityData.put("extraDetails","");
						}else {
							userEntityData.put("extraDetails",patVisitNote.getPatExtraDetails());
						}
						if(dcms.size()>0) {
							userEntityData.put("medicineRequired",dcms.toString());
						}else {
							userEntityData.put("medicineRequired", "");
						}
						if(ll.size()>0) {
							userEntityData.put("reportRequired",ll.toString());
						}else {
							userEntityData.put("reportRequired","");
						}
						try {
							String userEntityUpdated = (String) HyperledgerApiUtil.post(
									CommonConstants.getPropertiesValue("HYPERLEDGER_BASE_VISITNOTE"),
									CommonConstants.getPropertiesValue("HYPERLEDGER_BASE_HOST"),
									userEntityData);
							if(userEntityUpdated.equalsIgnoreCase(CommonConstants.CODE)) {
								userEntity.setUserHyperledgerID(userEntity.getUserEmail());
							}else {
								JSONObject userEntityDatas = new JSONObject();
								userEntityDatas.put("patientID", patient.getUserHyperledgerID());
								userEntityDatas.put("facilityName",patVisitNote.getFclProviderMapID().getLocationMapID().getFacilityCenterMaster().getFacilityCenterName());
								userEntityDatas.put("facilityLocation", patVisitNote.getFclProviderMapID().getLocationMapID().getFcLocationName());
								if(patVisitNote.getPatSymptoms() == null) {
									userEntityDatas.put("symptoms", "");
								}else {
									userEntityDatas.put("symptoms", patVisitNote.getPatSymptoms());
								}
								if(patVisitNote.getTreatmentProvided() == null) {
									userEntityDatas.put("treatmentProvided", "");
								}else {
									userEntityDatas.put("treatmentProvided", patVisitNote.getTreatmentProvided());
								}
								if(diName.size()>0) {
									userEntityDatas.put("possibleDiseaseName",diName.toString());
								}else {
									userEntityDatas.put("possibleDiseaseName", "");
								}
								if(patVisitNote.getPatSideEffect() == null) {
									userEntityDatas.put("sideEffect", "");
								}else {
									userEntityDatas.put("sideEffect", patVisitNote.getPatSideEffect());
								}
								if(patVisitNote.getPatExtraDetails() == null) {
									userEntityDatas.put("extraDetails","");
								}else {
									userEntityDatas.put("extraDetails",patVisitNote.getPatExtraDetails());
								}
								if(dcms.size()>0) {
									userEntityDatas.put("medicineRequired",dcms.toString());
								}else {
									userEntityDatas.put("medicineRequired", "");
								}
								if(ll.size()>0) {
									userEntityDatas.put("reportRequired",ll.toString());
								}else {
									userEntityDatas.put("reportRequired","");
								}
								String userEntityUpdateds = (String) HyperledgerApiUtil.put(
										CommonConstants.getPropertiesValue("HYPERLEDGER_BASE_VISITNOTE")+"/"+patVisitNote.getPatVisitNoteID(),
										CommonConstants.getPropertiesValue("HYPERLEDGER_BASE_HOST"),
										userEntityDatas);
								if(userEntityUpdateds.equalsIgnoreCase(CommonConstants.CODE)) {
									userEntity.setUserHyperledgerID(userEntity.getUserEmail());
								}else {
									userEntity.setUserHyperledgerID(null);
								}
							}
						}catch (Exception e) {
							logger.error("Error:--", e);
						}
					}else {
						JSONObject patVisitEntity = new JSONObject();
						patVisitEntity.put("visitId", patVisitNote.getPatVisitNoteID());
						patVisitEntity.put("patientId",patient.getUserBlockChainID());
						if(patVisitNote.getPatSymptoms() == null) {
							patVisitEntity.put("symptoms", "");
						}else {
							patVisitEntity.put("symptoms", patVisitNote.getPatSymptoms());
						}
						if(patVisitNote.getTreatmentProvided() == null) {
							patVisitEntity.put("treatmentProvided", "");
						}else {
							patVisitEntity.put("treatmentProvided", patVisitNote.getTreatmentProvided());
						}
						if(diName.size()>0) {
							patVisitEntity.put("possibleDiesesName",diName.toString());
						}else {
							patVisitEntity.put("possibleDiesesName", "");
						}
						if(patVisitNote.getPatSideEffect() == null) {
							patVisitEntity.put("sideEffect", "");
						}else {
							patVisitEntity.put("sideEffect", patVisitNote.getPatSideEffect());
						}
						if(patVisitNote.getPatExtraDetails() == null) {
							patVisitEntity.put("extraDetail","");
						}else {
							patVisitEntity.put("extraDetail",patVisitNote.getPatExtraDetails());
						}
						if(dcms.size()>0) {
							patVisitEntity.put("medicineRequired",dcms.toString());
						}else {
							patVisitEntity.put("medicineRequired", "");
						}
						if(ll.size()>0) {
							patVisitEntity.put("reportRequired",ll.toString());
						}else {
							patVisitEntity.put("reportRequired","");
						}
						try {
							JSONObject patVisitUpdated = (JSONObject) ApiUtil.post(
									CommonConstants.getPropertiesValue("BLOCKCHAIN_BASE_VISITNOTE"),
									CommonConstants.getPropertiesValue("BLOCKCHAIN_POST_METHOD"),
									patVisitEntity);
							
							String transectionId = patVisitUpdated.getString("transactionId").toString();
							patVisitNote.setPatTransectionID(transectionId);
							patVisitNote = patVisitNoteService.saveOrUpdate(patVisitNote);
						}catch (Exception e) {
							logger.error("Error:--", e);
						}
					}
					for(DiagnosisMaster dm:diagnosisMasters) {
						SetPatDiagnosis(userEntity,dm,patVisitNote);
					}
					for(LabReportsLevel1 lrp:labReportsLevel1s) {
						SetLabPatvisitNote(userEntity,lrp,patVisitNote);
					}
					RxHeader rxHeader=new RxHeader();
					rxHeader.setRxDate(new Date());
					rxHeader.setActive(true);
					rxHeader.setCreatedOn(new Date());
					rxHeader.setModifiedOn(new Date());
					rxHeader.setCreatedBy(userEntity);
					rxHeader.setModifiedBy(userEntity);
					rxHeader.setDeleted(false);
					rxHeader.setPatVisitNote(patVisitNote);
					try {
						rxHeader=rxHeaderService.saveOrUpdate(rxHeader);
					}catch (Exception e) {
						logger.error("Error:--", e);
						response.setStatus(ResponseConstant.ERROR);
						response.setMessage(messageByLocaleService.getMessage(DOCTORURLConstant.DOCTOR_VISIT_ERROR));
						response.setData(messageByLocaleService.getMessage(DOCTORURLConstant.DOCTOR_VISIT_ERROR));
						return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
					}
					
					for(DrugCompoundMaster dcm:drugCompoundMasters) {
						SetRxDetail(dcm,rxHeader,userEntity);
					}
					response.setStatus(ResponseConstant.SUCCESS);
					response.setMessage(messageByLocaleService.getMessage(DOCTORURLConstant.DOCTOR_VISIT_SUCCESS));
					response.setData(messageByLocaleService.getMessage(DOCTORURLConstant.DOCTOR_VISIT_SUCCESS));
				}else {
					PatVisitNote patVisitNoteEntitys=patVisitNoteService.get(patVisitNote.getPatVisitNoteID());
					if(patVisitNoteEntitys.getPatVisitNoteID().equals(patVisitNote.getPatVisitNoteID())) {
						if(patVisitNote.getAppointmentID() == null) {
							patVisitNote.setPatVisitType(PatientAppointmentType.New);
						}else {
							patVisitNote.setPatVisitType(patVisitNote.getAppointmentID().getPatAppType());
						}
						PatientMaster patientMaster = patientService.get(patVisitNote.getPatientMaster().getPatientID());
						UserMaster patient = userService.findByUserEmail(patientMaster.getPersonID().getUserMaster().getUserEmail());
						
						CFLPatRegistrationMap getcflPatRegistrationMap=cflPatRegistrationMapService.findCflData(patVisitNote.getPatientMaster().getPatientID(), patVisitNote.getFcLocationMap().getFcLocationMapID());
						if(getcflPatRegistrationMap !=null) {
							getcflPatRegistrationMap.setModifiedBy(userEntity);
							getcflPatRegistrationMap.setModifiedOn(new Date());
							patVisitNote.setClfPatRegistrationMap(getcflPatRegistrationMap);
						}else {
							CFLPatRegistrationMap cflPatRegistrationMap=SetCFLPatRegistrationMap(userEntity,patVisitNote.getFcLocationMap(),patVisitNote.getPatientMaster());
							patVisitNote.setClfPatRegistrationMap(cflPatRegistrationMap);
						}
						FCLProviderMap fclProviderMap=fclProviderService.getdata(providerMaster.getProviderID(), patVisitNote.getFcLocationMap().getFcLocationMapID());
						patVisitNote.setFclProviderMapID(fclProviderMap);
						patVisitNote.setCreatedBy(patVisitNoteEntitys.getCreatedBy());
						patVisitNote.setCreatedOn(patVisitNoteEntitys.getCreatedOn());
						patVisitNote.setPatVisitDate(patVisitNoteEntitys.getPatVisitDate());
						try {
							patVisitNote = patVisitNoteService.saveOrUpdate(patVisitNote);
						}catch (Exception e) {
							logger.error("Error:--", e);
							response.setStatus(ResponseConstant.ERROR);
							response.setMessage(messageByLocaleService.getMessage(DOCTORURLConstant.DOCTOR_VISIT_ERROR));
							response.setData(messageByLocaleService.getMessage(DOCTORURLConstant.DOCTOR_VISIT_ERROR));
							return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
						}
						
						if(CommonConstants.getPropertiesValue("TYPE").equalsIgnoreCase(CommonConstants.HYPERLEDGER)) {
							JSONObject userEntityData = new JSONObject();
							userEntityData.put("visitID", patVisitNote.getPatVisitNoteID());
							userEntityData.put("patientID", patient.getUserHyperledgerID());
							userEntityData.put("facilityName",patVisitNote.getFclProviderMapID().getLocationMapID().getFacilityCenterMaster().getFacilityCenterName());
							userEntityData.put("facilityLocation", patVisitNote.getFclProviderMapID().getLocationMapID().getFcLocationName());
							if(patVisitNote.getPatSymptoms() == null) {
								userEntityData.put("symptoms", "");
							}else {
								userEntityData.put("symptoms", patVisitNote.getPatSymptoms());
							}
							if(patVisitNote.getTreatmentProvided() == null) {
								userEntityData.put("treatmentProvided", "");
							}else {
								userEntityData.put("treatmentProvided", patVisitNote.getTreatmentProvided());
							}
							if(diName.size()>0) {
								userEntityData.put("possibleDiseaseName",diName.toString());
							}else {
								userEntityData.put("possibleDiseaseName", "");
							}
							if(patVisitNote.getPatSideEffect() == null) {
								userEntityData.put("sideEffect", "");
							}else {
								userEntityData.put("sideEffect", patVisitNote.getPatSideEffect());
							}
							if(patVisitNote.getPatExtraDetails() == null) {
								userEntityData.put("extraDetails","");
							}else {
								userEntityData.put("extraDetails",patVisitNote.getPatExtraDetails());
							}
							if(dcms.size()>0) {
								userEntityData.put("medicineRequired",dcms.toString());
							}else {
								userEntityData.put("medicineRequired", "");
							}
							if(ll.size()>0) {
								userEntityData.put("reportRequired",ll.toString());
							}else {
								userEntityData.put("reportRequired","");
							}
							try {
								String userEntityUpdated = (String) HyperledgerApiUtil.post(
										CommonConstants.getPropertiesValue("HYPERLEDGER_BASE_VISITNOTE"),
										CommonConstants.getPropertiesValue("HYPERLEDGER_BASE_HOST"),
										userEntityData);
								if(userEntityUpdated.equalsIgnoreCase(CommonConstants.CODE)) {
									userEntity.setUserHyperledgerID(userEntity.getUserEmail());
								}else {
									JSONObject userEntityDatas = new JSONObject();
									userEntityDatas.put("patientID", patient.getUserHyperledgerID());
									userEntityDatas.put("facilityName",patVisitNote.getFclProviderMapID().getLocationMapID().getFacilityCenterMaster().getFacilityCenterName());
									userEntityDatas.put("facilityLocation", patVisitNote.getFclProviderMapID().getLocationMapID().getFcLocationName());
									if(patVisitNote.getPatSymptoms() == null) {
										userEntityDatas.put("symptoms", "");
									}else {
										userEntityDatas.put("symptoms", patVisitNote.getPatSymptoms());
									}
									if(patVisitNote.getTreatmentProvided() == null) {
										userEntityDatas.put("treatmentProvided", "");
									}else {
										userEntityDatas.put("treatmentProvided", patVisitNote.getTreatmentProvided());
									}
									if(diName.size()>0) {
										userEntityDatas.put("possibleDiseaseName",diName.toString());
									}else {
										userEntityDatas.put("possibleDiseaseName", "");
									}
									if(patVisitNote.getPatSideEffect() == null) {
										userEntityDatas.put("sideEffect", "");
									}else {
										userEntityDatas.put("sideEffect", patVisitNote.getPatSideEffect());
									}
									if(patVisitNote.getPatExtraDetails() == null) {
										userEntityDatas.put("extraDetails","");
									}else {
										userEntityDatas.put("extraDetails",patVisitNote.getPatExtraDetails());
									}
									if(dcms.size()>0) {
										userEntityDatas.put("medicineRequired",dcms.toString());
									}else {
										userEntityDatas.put("medicineRequired", "");
									}
									if(ll.size()>0) {
										userEntityDatas.put("reportRequired",ll.toString());
									}else {
										userEntityDatas.put("reportRequired","");
									}
									String userEntityUpdateds = (String) HyperledgerApiUtil.put(
											CommonConstants.getPropertiesValue("HYPERLEDGER_BASE_VISITNOTE")+"/"+patVisitNote.getPatVisitNoteID(),
											CommonConstants.getPropertiesValue("HYPERLEDGER_BASE_HOST"),
											userEntityDatas);
									if(userEntityUpdateds.equalsIgnoreCase(CommonConstants.CODE)) {
										userEntity.setUserHyperledgerID(userEntity.getUserEmail());
									}else {
										userEntity.setUserHyperledgerID(null);
									}
								}
							}catch (Exception e) {
								logger.error("Error:--", e);
							}
						}else {
							JSONObject patVisitEntity = new JSONObject();
							patVisitEntity.put("visitId", patVisitNote.getPatVisitNoteID());
							patVisitEntity.put("patientId",patient.getUserBlockChainID());
							if(patVisitNote.getPatSymptoms() == null) {
								patVisitEntity.put("symptoms", "");
							}else {
								patVisitEntity.put("symptoms", patVisitNote.getPatSymptoms());
							}
							if(patVisitNote.getTreatmentProvided() == null) {
								patVisitEntity.put("treatmentProvided", "");
							}else {
								patVisitEntity.put("treatmentProvided", patVisitNote.getTreatmentProvided());
							}
							if(diName.size()>0) {
								patVisitEntity.put("possibleDiesesName",diName.toString());
							}else {
								patVisitEntity.put("possibleDiesesName", "");
							}
							if(patVisitNote.getPatSideEffect() == null) {
								patVisitEntity.put("sideEffect", "");
							}else {
								patVisitEntity.put("sideEffect", patVisitNote.getPatSideEffect());
							}
							if(patVisitNote.getPatExtraDetails() == null) {
								patVisitEntity.put("extraDetail","");
							}else {
								patVisitEntity.put("extraDetail",patVisitNote.getPatExtraDetails());
							}
							if(dcms.size()>0) {
								patVisitEntity.put("medicineRequired",dcms.toString());
							}else {
								patVisitEntity.put("medicineRequired", "");
							}
							if(ll.size()>0) {
								patVisitEntity.put("reportRequired",ll.toString());
							}else {
								patVisitEntity.put("reportRequired","");
							}
							try {
								JSONObject patVisitUpdated = (JSONObject) ApiUtil.post(
										CommonConstants.getPropertiesValue("BLOCKCHAIN_BASE_VISITNOTE"),
										CommonConstants.getPropertiesValue("BLOCKCHAIN_POST_METHOD"),
										patVisitEntity);
								
								String transectionId = patVisitUpdated.getString("transactionId").toString();
								patVisitNote.setPatTransectionID(transectionId);
								patVisitNote = patVisitNoteService.saveOrUpdate(patVisitNote);
							}catch (Exception e) {
								logger.error("Error:--", e);
							}
						}
						
						List<PatDiagnosis> all=patDiagnosisService.findAllData(patVisitNote.getPatVisitNoteID());
						for(PatDiagnosis pd:all) {
							SetPatDiagnosisDiseble(userEntity,pd);
						}
						for(DiagnosisMaster dm:diagnosisMasters) {
							PatDiagnosis pgs=patDiagnosisService.findData(dm.getDiagnosisID(), patVisitNote.getPatVisitNoteID());
							if(pgs == null) {
								SetPatDiagnosis(userEntity,dm,patVisitNote);
							}else {
								pgs.setModifiedOn(new Date());
								pgs.setModifiedBy(userEntity);
								pgs.setActive(true);
								pgs.setDeleted(false);
								try {
									patDiagnosisService.saveOrUpdate(pgs);
								}catch (Exception e) {
									logger.error("Error:--", e);
									response.setStatus(ResponseConstant.ERROR);
									response.setMessage(messageByLocaleService.getMessage(DOCTORURLConstant.DOCTOR_VISIT_ERROR));
									response.setData(messageByLocaleService.getMessage(DOCTORURLConstant.DOCTOR_VISIT_ERROR));
									return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
								}
							}
						}
						
						List<LabPatvisitNote> alls=labPatvisitNoteService.findAllData(patVisitNote.getPatVisitNoteID());
						for(LabPatvisitNote lpn:alls) {
							SetLabPatvisitNoteDiseble(userEntity,lpn);
						}
						
						for(LabReportsLevel1 lrp:labReportsLevel1s) {
							LabPatvisitNote ln=labPatvisitNoteService.findData(lrp.getLabReportLevel1ID(),patVisitNote.getPatVisitNoteID());
							if(ln == null) {
								SetLabPatvisitNote(userEntity,lrp,patVisitNote);
							}else {
								ln.setModifiedOn(new Date());
								ln.setModifiedBy(userEntity);
								ln.setActive(true);
								ln.setDeleted(false);
								try {
									labPatvisitNoteService.saveOrUpdate(ln);
								}catch (Exception e) {
									logger.error("Error:--", e);
									response.setStatus(ResponseConstant.ERROR);
									response.setMessage(messageByLocaleService.getMessage(DOCTORURLConstant.DOCTOR_VISIT_ERROR));
									response.setData(messageByLocaleService.getMessage(DOCTORURLConstant.DOCTOR_VISIT_ERROR));
									return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
								}
							}
						}
						RxHeader rxHeader=rxHeaderService.findData(patVisitNote.getPatVisitNoteID());
						rxHeader.setActive(true);
						rxHeader.setModifiedOn(new Date());
						rxHeader.setModifiedBy(userEntity);
						rxHeader.setDeleted(false);
						try {
							rxHeader=rxHeaderService.saveOrUpdate(rxHeader);
						}catch (Exception e) {
							logger.error("Error:--", e);
							response.setStatus(ResponseConstant.ERROR);
							response.setMessage(messageByLocaleService.getMessage(DOCTORURLConstant.DOCTOR_VISIT_ERROR));
							response.setData(messageByLocaleService.getMessage(DOCTORURLConstant.DOCTOR_VISIT_ERROR));
							return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
						}
						
						List<RxDetail> rd=rxDetailService.findAllData(rxHeader.getRxID());
						for(RxDetail rds:rd) {
							SetRxDetailDiseble(rds,userEntity);
						}
						for(DrugCompoundMaster dcm:drugCompoundMasters) {
							RxDetail rxds=rxDetailService.findData(dcm.getDrugCompoundID(),rxHeader.getRxID());
							if(rxds == null) {
								SetRxDetail(dcm,rxHeader,userEntity);
							}else {
								rxds.setActive(true);
								rxds.setDeleted(false);
								rxds.setModifiedOn(new Date());
								rxds.setModifiedBy(userEntity);
								try {
									rxDetailService.saveOrUpdate(rxds);
								}catch (Exception e) {
									logger.error("Error:--", e);
									response.setStatus(ResponseConstant.ERROR);
									response.setMessage(messageByLocaleService.getMessage(DOCTORURLConstant.DOCTOR_VISIT_ERROR));
									response.setData(messageByLocaleService.getMessage(DOCTORURLConstant.DOCTOR_VISIT_ERROR));
									return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
								}
							}
						}
						response.setStatus(ResponseConstant.SUCCESS);
						response.setMessage(messageByLocaleService.getMessage(DOCTORURLConstant.DOCTOR_VISIT_UPDATE));
						response.setData(messageByLocaleService.getMessage(DOCTORURLConstant.DOCTOR_VISIT_UPDATE));
					}else {
						response.setStatus(ResponseConstant.WARNING);
						response.setMessage(messageByLocaleService.getMessage(DOCTORURLConstant.DOCTOR_VISIT_EXIT));
						response.setData(messageByLocaleService.getMessage(DOCTORURLConstant.DOCTOR_VISIT_EXIT));
						return new ResponseEntity<Response>(response, HttpStatus.CONFLICT);
					}
				}
			} catch (Exception e) {
				logger.error("Error:--", e);
				response.setStatus(ResponseConstant.ERROR);
				response.setMessage(messageByLocaleService.getMessage(DOCTORURLConstant.DOCTOR_VISIT_ERROR));
				response.setData(messageByLocaleService.getMessage(DOCTORURLConstant.DOCTOR_VISIT_ERROR));
				return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
			}
		}else {
			response.setStatus(ResponseConstant.ERROR);
			response.setMessage(messageByLocaleService.getMessage(DOCTORURLConstant.DOCTOR_VISIT_EXCEPTION));
			response.setData(messageByLocaleService.getMessage(DOCTORURLConstant.DOCTOR_VISIT_EXCEPTION));
			return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}

		if(type.equalsIgnoreCase(DOCTORURLConstant.ADD_TYPE)) {
			return new ResponseEntity<Response>(response, HttpStatus.CREATED);
		}else {
			return new ResponseEntity<Response>(response, HttpStatus.OK);
		}
	}
	
	@RequestMapping(value = DOCTORURLConstant.GET_DOCTOR_VISIT_URL, method = RequestMethod.GET, headers = CommonConstants.CONTENT_TYPE_APPLICATION_JSON)
	public ResponseEntity<Response> getAllDoctorVisit(Locale locale,Pageable pageable) {
		Response response = new Response();
		PatVisitNotePojoList patVisitNotePojoList=new PatVisitNotePojoList();
		List<PatVisitNotePojo> patVisitNotePojo=new ArrayList<PatVisitNotePojo>();
		UserDetails userDetails = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		UserMaster userEntity = userService.findByUserName(userDetails.getUsername());
		try {
			ProviderMaster providerMaster=providerService.getProvider(userEntity.getUserEmail(),ProviderTypeStatus.Doctor);
			List<PatVisitNote> patVisitNote=patVisitNoteService.findProviderData(providerMaster.getProviderID(),pageable);
			List<PatVisitNote> patVisitNotes=patVisitNoteService.findProviderDatas(providerMaster.getProviderID());
			if(patVisitNote.size()>0) {
				for(PatVisitNote pvn:patVisitNote) {
					PatVisitNotePojo pvnp=SetPatVisitNote(pvn);
					patVisitNotePojo.add(pvnp);
				}
				patVisitNotePojoList.setTotalNumber(patVisitNotes.size());
				patVisitNotePojoList.setPatVisitNotePojo(patVisitNotePojo);
			}
			response.setStatus(ResponseConstant.SUCCESS);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_SUCCESS));
			response.setData(patVisitNotePojoList);
		}catch (Exception e) {
			logger.error("Error:--", e);
			response.setStatus(ResponseConstant.ERROR);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			response.setData(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Response>(response, HttpStatus.OK);
	}
	
	@RequestMapping(value = DOCTORURLConstant.VIEW_AND_EDIT_DOCTOR_VISIT_URL, method = RequestMethod.POST, headers = CommonConstants.CONTENT_TYPE_APPLICATION_JSON)
	public ResponseEntity<Response> viewAndEditDoctorVisit(Locale locale,@RequestBody PatVisitNote patVisitNote) {
		Response response = new Response();
		try {
			PatVisitNote pvn=patVisitNoteService.get(patVisitNote.getPatVisitNoteID());
			PatVisitNotePojo pap=SetPatVisitNote(pvn);
			response.setStatus(ResponseConstant.SUCCESS);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_SUCCESS));
			response.setData(pap);
		}catch (Exception e) {
			logger.error("Error:--", e);
			response.setStatus(ResponseConstant.ERROR);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			response.setData(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Response>(response, HttpStatus.OK);
	}
	
	@RequestMapping(value = DOCTORURLConstant.GET_APPOINTMENT_DOCTOR_URL, method = RequestMethod.GET, headers = CommonConstants.CONTENT_TYPE_APPLICATION_JSON)
	public ResponseEntity<Response> getAppointmentDoctor(Locale locale,Pageable pageable) {
		Response response = new Response();
		PatAppointmentPojoList patAppointmentPojoList=new PatAppointmentPojoList();
		List<PatAppointmentPojo> patAppointmentPojo=new ArrayList<PatAppointmentPojo>();
		UserDetails userDetails = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		UserMaster userEntity = userService.findByUserName(userDetails.getUsername());
		try {
			ProviderMaster providerMaster=providerService.getProvider(userEntity.getUserEmail(),ProviderTypeStatus.Doctor);
			List<PatAppointments> patAppointments=patAppointmentService.findProviderData(providerMaster.getProviderID(),pageable);
			List<PatAppointments> patAppointment=patAppointmentService.findProviderDatas(providerMaster.getProviderID());
			if(patAppointments.size()>0) {
				for(PatAppointments pa:patAppointments) {
					PatAppointmentPojo pap=MethodConstants.SetPatAppointmentPojo(pa);
					patAppointmentPojo.add(pap);
				}
				patAppointmentPojoList.setTotalNumber(patAppointment.size());
				patAppointmentPojoList.setPatAppointmentPojo(patAppointmentPojo);
			}
			response.setStatus(ResponseConstant.SUCCESS);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_SUCCESS));
			response.setData(patAppointmentPojoList);
		}catch (Exception e) {
			logger.error("Error:--", e);
			response.setStatus(ResponseConstant.ERROR);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			response.setData(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Response>(response, HttpStatus.OK);
	}
	
	@RequestMapping(value = DOCTORURLConstant.VIEW_AND_EDIT_APPOINTMENT_DOCTOR_URL, method = RequestMethod.POST, headers = CommonConstants.CONTENT_TYPE_APPLICATION_JSON)
	public ResponseEntity<Response> viewAndEditAppointmentDoctor(Locale locale,@RequestBody PatAppointments patAppointmentsMaster) {
		Response response = new Response();
		try {
			PatAppointments pa=patAppointmentService.get(patAppointmentsMaster.getPatAppointmentID());
			PatAppointmentPojo pap=MethodConstants.SetPatAppointmentPojo(pa);
			response.setStatus(ResponseConstant.SUCCESS);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_SUCCESS));
			response.setData(pap);
		}catch (Exception e) {
			logger.error("Error:--", e);
			response.setStatus(ResponseConstant.ERROR);
			response.setMessage(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			response.setData(messageByLocaleService.getMessage(ServiceConstant.GET_DATA_ERROR));
			return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Response>(response, HttpStatus.OK);
	}
	
	private PatVisitNotePojo SetPatVisitNote(PatVisitNote pvn) {
		PatVisitNotePojo pvp=new PatVisitNotePojo();
		pvp.setPatVisitNoteID(pvn.getPatVisitNoteID());
		String dates=DateUtil.getLocalDateFormatted(pvn.getPatVisitDate(), DateUtil.dateTimeFormatterDDMMMYYYY);
		pvp.setPatVisitDate(dates);
		String tim=DateUtil.getLocalDateFormatted(pvn.getPatVisitDate(), DateUtil.timeFormatterHHMMA);
		pvp.setTimes(tim);
		pvp.setTreatmentProvided(pvn.getTreatmentProvided());
		pvp.setPatSymptoms(pvn.getPatSymptoms());
		pvp.setPatSideEffect(pvn.getPatSideEffect());
		pvp.setPatExtraDetails(pvn.getPatExtraDetails());
		pvp.setPatVisitType(pvn.getPatVisitType());
		List<PatDiagnosis> patDiagnosis=patDiagnosisService.findAll(pvn.getPatVisitNoteID());
		List<DiseasePojo> dm=new ArrayList<DiseasePojo>();
		for(PatDiagnosis pd : patDiagnosis){
			DiseasePojo dms=new DiseasePojo();
			dms.setDiagnosisID(pd.getDiagnosisMaster().getDiagnosisID());
			dms.setDiagnosiseName(pd.getDiagnosisMaster().getDiagnosiseName());
			dm.add(dms);
		}
		pvp.setDiagnosisMaster(dm);
		pvp.setPatientID(pvn.getClfPatRegistrationMap().getPatientID().getPatientID());
		pvp.setName(pvn.getClfPatRegistrationMap().getPatientID().getPersonID().getPerFname()+" "+pvn.getClfPatRegistrationMap().getPatientID().getPersonID().getPerLName());
		pvp.setProviderID(pvn.getFclProviderMapID().getProviderID().getProviderID());
		pvp.setProviderName(CommonConstants.DR_SHORT+" "+pvn.getFclProviderMapID().getProviderID().getPersonMaster().getPerFname()+" "+pvn.getFclProviderMapID().getProviderID().getPersonMaster().getPerLName());
		pvp.setFcLocationMapID(pvn.getFclProviderMapID().getLocationMapID().getFcLocationMapID());
		pvp.setFcLocationName(pvn.getFclProviderMapID().getLocationMapID().getFcLocationName());
		pvp.setFacilityCenterID(pvn.getFclProviderMapID().getLocationMapID().getFacilityCenterMaster().getFacilityCenterID());
		pvp.setFacilityCenterName(pvn.getFclProviderMapID().getLocationMapID().getFacilityCenterMaster().getFacilityCenterName());
		pvp.setFacilityCenterType(pvn.getFclProviderMapID().getLocationMapID().getFacilityCenterMaster().getFacilityCenterType());
		if(pvn.getAppointmentID() != null) {
			pvp.setAppointmentID(pvn.getAppointmentID().getPatAppointmentID());
		}
		List<LabPatvisitNote> labPatvisitNote=labPatvisitNoteService.findAll(pvn.getPatVisitNoteID());
		List<LabReportsLevel1Pojo> llp=new ArrayList<LabReportsLevel1Pojo>();
		for(LabPatvisitNote lpn : labPatvisitNote){
			LabReportsLevel1Pojo ll=new LabReportsLevel1Pojo();
			ll.setLabReportLevel1ID(lpn.getLabReportsLevel1().getLabReportLevel1ID());
			ll.setLabReportType(lpn.getLabReportsLevel1().getLabReportType());
			ll.setLrl1Category(lpn.getLabReportsLevel1().getLrl1Category());
			ll.setLrl1Name(lpn.getLabReportsLevel1().getLrl1Name());
			ll.setGenericTestcode(lpn.getLabReportsLevel1().getGenericTestcode());
			ll.setGenericSourceName(lpn.getLabReportsLevel1().getGenericSourceName());
			llp.add(ll);
		}
		pvp.setLabReportsLevel1(llp);
		List<DrugCompoundMaster> rxds=rxDetailService.findAll(pvn.getPatVisitNoteID());
		List<DrugCompoundPojo> drugCompoundPojo=new ArrayList<DrugCompoundPojo>();
		for(DrugCompoundMaster dcm:rxds) {
			DrugCompoundPojo dcp=new DrugCompoundPojo();
			dcp.setDrugCompoundID(dcm.getDrugCompoundID());
			dcp.setDrugCompoundName(dcm.getDrugCompoundName());
			drugCompoundPojo.add(dcp);
		}
		pvp.setDrugCompoundMaster(drugCompoundPojo);
		return pvp;
	}
	
	private CFLPatRegistrationMap SetCFLPatRegistrationMap(UserMaster userEntity,FCLocationMap fclProviderMap,PatientMaster patientMaster) {
		CFLPatRegistrationMap cflPatRegistrationMap=new CFLPatRegistrationMap();
		cflPatRegistrationMap.setActive(true);
		cflPatRegistrationMap.setDateRegistered(new Date());
		cflPatRegistrationMap.setCreatedOn(new Date());
		cflPatRegistrationMap.setModifiedOn(new Date());
		cflPatRegistrationMap.setCreatedBy(userEntity);
		cflPatRegistrationMap.setModifiedBy(userEntity);
		cflPatRegistrationMap.setDeleted(false);
		cflPatRegistrationMap.setFcLocationMap(fclProviderMap);
		cflPatRegistrationMap.setPatientID(patientMaster);
		return cflPatRegistrationMapService.saveOrUpdate(cflPatRegistrationMap);
	}
	
	private void SetRxDetail(DrugCompoundMaster dcm,RxHeader rxHeader,UserMaster userEntity) {
		RxDetail rxd=new RxDetail();
		rxd.setRxHeader(rxHeader);
		rxd.setDrugCompoundMaster(dcm);
		rxd.setActive(true);
		rxd.setCreatedOn(new Date());
		rxd.setModifiedOn(new Date());
		rxd.setCreatedBy(userEntity);
		rxd.setModifiedBy(userEntity);
		rxd.setDeleted(false);
		try {
			rxDetailService.saveOrUpdate(rxd);
		}catch (Exception e) {
			logger.error("Error:--", e);
		}
	}
	
	private void SetRxDetailDiseble(RxDetail rxd,UserMaster userEntity) {
		rxd.setActive(false);
		rxd.setModifiedOn(new Date());
		rxd.setModifiedBy(userEntity);
		rxd.setDeleted(true);
		try {
			rxDetailService.saveOrUpdate(rxd);
		}catch (Exception e) {
			logger.error("Error:--", e);
		}
	}
	
	private void SetLabPatvisitNote(UserMaster userEntity,LabReportsLevel1 ll1,PatVisitNote patVisitNote)  {
		LabPatvisitNote ln=new LabPatvisitNote();
		ln.setLabReportsLevel1(ll1);
		ln.setPatVisitNote(patVisitNote);
		ln.setActive(true);
		ln.setCreatedOn(new Date());
		ln.setModifiedOn(new Date());
		ln.setCreatedBy(userEntity);
		ln.setModifiedBy(userEntity);
		ln.setDeleted(false);
		try {
			labPatvisitNoteService.saveOrUpdate(ln);
		}catch (Exception e) {
			logger.error("Error:--", e);
		}
		
	}
	
	private void SetLabPatvisitNoteDiseble(UserMaster userEntity,LabPatvisitNote ln)  {
		ln.setActive(false);
		ln.setModifiedOn(new Date());
		ln.setModifiedBy(userEntity);
		ln.setDeleted(true);
		try {
			labPatvisitNoteService.saveOrUpdate(ln);
		}catch (Exception e) {
			logger.error("Error:--", e);
		}
		
	}
	
	private void SetPatDiagnosis(UserMaster userEntity,DiagnosisMaster dm,PatVisitNote patVisitNote) {
		PatDiagnosis pg=new PatDiagnosis();
		pg.setDiagnosisMaster(dm);
		pg.setPatVisitNoteOutdoor(patVisitNote);
		pg.setActive(true);
		pg.setCreatedOn(new Date());
		pg.setModifiedOn(new Date());
		pg.setCreatedBy(userEntity);
		pg.setModifiedBy(userEntity);
		pg.setDeleted(false);
		try {
			patDiagnosisService.saveOrUpdate(pg);
		}catch (Exception e) {
			logger.error("Error:--", e);
		}
		
	}
	
	private void SetPatDiagnosisDiseble(UserMaster userEntity,PatDiagnosis pg) {
		pg.setActive(false);
		pg.setModifiedOn(new Date());
		pg.setModifiedBy(userEntity);
		pg.setDeleted(true);
		try {
			patDiagnosisService.saveOrUpdate(pg);
		}catch (Exception e) {
			logger.error("Error:--", e);
		}
		
	}
}
