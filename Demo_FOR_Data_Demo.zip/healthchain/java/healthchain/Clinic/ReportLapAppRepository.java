package org.healthchain.base;

import org.healthchain.entity.ReportPatLapApp;
import org.springframework.stereotype.Repository;

@Repository
public interface ReportPatLapAppRepository extends GenericRepository<ReportPatLapApp, Long> {

	
}
